# Oidis Studio — Uživatelský návod

## Požadavky

Aplikace nevyžaduje instalaci žádných dodatečných modulů ani závislostí — vše potřebné je součástí přiložené složky. Spustitelná verze je sestavena pro operační systém **Windows**.

---

## Spuštění aplikace

1. Spusťte příkaz:
   ```
   ./OidisStudio.cmd start
   ```
   Spouštěcí skript se nachází ve složce `cmd/`.
2. Spuštění může chvíli trvat. Po dokončení konzole vypíše adresu lokálního serveru, například:
   ```
   http://localhost:8080
   ```
3. Otevřete uvedenou adresu v prohlížeči. Na úvodní stránce klikněte na odkaz **MainPage** pro přechod do editoru.

Tento dokument dále obsahuje:

**Návod k ovládání** — popis jednotlivých funkcí editoru:
- *Otevření souboru* — požadovaný formát absolutní cesty a automatické odvození pracovního adresáře
- *Konfigurační soubory* — automatické načítání `BootstrapConfig.json` a `ProjectConfig.json` z kořene projektu
- *Označené a neoznačené soubory* — rozdíl mezi soubory s generovanými bloky a ručně psanými soubory a jejich chování při uložení
- *Rozvržení editoru a nástrojová lišta* — popis jednotlivých panelů a dostupných akcí
- *Práce s Oidis komponentami* — nastavení OIDIS Bind názvu a Import Variant pro generování kódu
- *Obrázky a cesty k prostředkům* — automatický překlad relativních cest `/resource/...` při zobrazení v editoru

**Struktura projektu** — přehled souborů implementovaných v rámci práce s popisem jejich zodpovědnosti.

---

## Otevření souboru

Po spuštění editoru se zobrazí **dialog pro zadání cesty**. Zadejte **absolutní cestu** k TypeScript souboru komponenty, který chcete editovat.
> Pro účely testování je možné použít testovací projekt nebo panely ze zdrojových kódů této aplikace, jelikož Oidis Studio také odpovídá běžným aplikacím založeným na Oidis Frameworku. Napřiklad:

```
D:\Projects\my-oidis-app\dependencies\io-oidis-studio-gui\source\typescript\Io\Oidis\Studio\Gui\Panels\MyPanel.ts
```

Editor automaticky odvodí pracovní adresář (kořen projektu) a relativní cestu k souboru z absolutní cesty. Po potvrzení se soubor načte a jeho HTML se zobrazí na editační ploše.

**Obnova stránky** — po obnovení stránky (F5) se naposledy otevřený soubor načte znovu.




---

## Konfigurační soubory

Po otevření souboru editor vyhledá konfigurační soubory v detekovaném kořeni projektu a načte je automaticky. Žádné ruční nastavení není potřeba.

### BootstrapConfig.json

Umístění: `dependencies/io-oidis-usercontrols/bin/project/configs/BootstrapConfig.json`

Mapuje typy komponent GrapesJS (např. `button`, `textInput`) na TypeScript třídy použité ve frameworku Oidis. Pokud soubor existuje, každá mapovaná komponenta získá v panelu Options rozbalovací nabídku **Import Variant**, která umožňuje vybrat třídu použitou při generování kódu.

### ProjectConfig.json

Umístění: `bin/project/configs/ProjectConfig.json`

Deklaruje komponenty specifické pro projekt. Pokud soubor existuje, tyto komponenty jsou zaregistrovány jako typy GrapesJS a zobrazí se v kategorii **Project components** v katalogu bloků.

Každá taková komponenta zobrazuje v editoru vizuální placeholder, ale při uložení se exportuje pouze prázdný vnější `<div>` — obsah placeholderu slouží pouze jako vizuální vodítko a do výstupu se nezahrnuje.

---

## Označené a neoznačené soubory

Editor rozlišuje dva typy souborů podle přítomnosti komentářových bloků pro generovaný kód:

**Označený soubor** — obsahuje všechny čtyři bloky `//generated … start/end`:
```
//generated imports start … //generated imports end
//generated variables start … //generated variables end
//generated inicialization start … //generated inicialization end
//generated html start … //generated html end
```
Při uložení editor nahradí pouze obsah uvnitř těchto bloků. Vše mimo ně zůstane beze změny.

**Neoznačený soubor** — existující ručně psaný TypeScript soubor bez markerů. Editor detekuje metodu `innerHtml()`, extrahuje HTML a existující proměnné a při uložení aplikuje cílené opravy (nahrazuje jednotlivé řádky importů a proměnných). Po prvním uložení se soubor stane plně označeným.

---

## Rozvržení editoru

| Oblast                      | Účel                                                                                 |
|-----------------------------|--------------------------------------------------------------------------------------|
| **Editační plocha** (střed) | Vizuální editace — přetahování, přesouvání a výběr komponent                         |
| **Bloky** (levý panel)      | Katalog dostupných typů komponent k přetažení na plochu                              |
| **Strom HTML** (levý panel) | Hierarchický strom všech komponent na ploše                                          |
| **Options** (pravý panel) | Traity specifické pro Oidis — bind název, třídy, atributy a nastavení Bootstrap tříd |
| **Styles** (pravý panel) | Editor CSS stylů pro vybranou komponentu                                             |
| **HTML náhled** (spodní panel) | Výstupní HTML v režimu jen pro čtení — aktualizuje se průběžně                       |

---

## Akce nástrojové lišty

| Tlačítko | Akce |
|---|---|
| **File / Open another file** | Otevře dialog pro načtení jiného souboru |
| **Save file to current path** | Zapíše aktuální stav plochy zpět do TypeScript souboru |
| **Export File** | Stáhne samostatný `.ts` soubor vygenerovaný z aktuálního stavu plochy |
| **Desktop / Tablet / Mobile** | Přepne šířku náhledové plochy pro responzivní preview |

---

## Práce s Oidis komponentami

### OIDIS Bind

Každá komponenta, se kterou vývojář chce pracovat ve výsledném kódu, musí mít v panelu Options nastaven název **OIDIS Bind**.

- Bind název se stane názvem TypeScript proměnné (např. `myButton`).
- Editor zapíše `data-oidis-bind="${this.myButton}"` na HTML element.
- Při uložení se automaticky vygeneruje deklarace pole `public readonly myButton : Button;` a řádek inicializace `this.myButton = new Button();` v konstruktoru.

> **Důležité** — bind názvy musí být platné TypeScript identifikátory (bez mezer a pomlček). Duplicitní názvy editor nedetekuje.

### Import Variant

Pokud má typ komponenty více možných importních cest (nakonfigurovaných v `BootstrapConfig.json`), zobrazí se v panelu Options rozbalovací nabídka **Import Variant**. Výběrem třídy se určí, který příkaz `import` bude vygenerován.

---

## Obrázky a cesty k prostředkům

Cestu ke zdrojovému souboru obrázku lze zadávat stejným způsobem jako v kódu komponenty — tedy jako relativní cestu začínající `/resource/...`, například:

```
/resource/graphics/Logo.svg
```

Editor podle této cesty automaticky dohledá a načte obrázek z katalogu otevřeného projektu a zobrazí jej na editační ploše. Uložené HTML si původní relativní cestu zachová beze změny.

---

## Struktura projektu (zkompilovaná aplikace neobsahuje přímo tyto soubory)

### Backend — `source/typescript/Io/Oidis/Studio/Utils/`

| Soubor | Zodpovědnost |
|---|---|
| `FileHelper.ts` | `@Extern` fasáda — zpřístupňuje veřejné metody pro frontend: načtení souboru, uložení souboru, načtení konfigurací, překlad cest k prostředkům |
| `FileParserMarked.ts` | Extrahuje obsah z označených bloků a parsuje importy a deklarace proměnných z označených souborů |
| `FileParserUnmarked.ts` | Extrahuje HTML a parsuje importy a deklarace polí třídy z ručně psaných souborů bez markerů |
| `FileWriterMarked.ts` | Nahrazuje obsah bloků v označených souborech |
| `FileWriterUnmarked.ts` | Opravuje importy, deklarace proměnných, inicializace v konstruktoru a HTML v neoznačených souborech; generuje také kompletní šablonu souboru od základu |

### Frontend — `dependencies/io-oidis-studio-gui/source/typescript/Io/Oidis/Studio/Gui/`

| Soubor / Adresář | Zodpovědnost |
|---|---|
| `Controllers/Pages/MainPageController.ts` | Hlavní řídící třída — inicializuje GrapesJS, propojuje tlačítka nástrojové lišty, řídí tok otevírání a ukládání souborů, načítání konfigurací |
| `Connectors/FileHelperConnector.ts` | WebSocket klientský konektor — mapuje asynchronní volání frontendu na backendové metody `@Extern` |
| `Panels/HomePanel.ts` | Kořenový layout panel — deklaruje všechny UI sloty (plátno, panely, bloky, vrstvy, styly, options, kontejner notifikací) |
| `Panels/TopActionsPanel.ts` | Panel nástrojové lišty — deklaruje akční tlačítka (import, uložení, export, ohraničení, přepínač zařízení) |
| `Dialogs/PathInputDialog.ts` | Dialog pro otevření souboru |
| `Models/TypeRegistration.ts` | Registruje všechny vlastní typy komponent GrapesJS (heading, button, link, container, dropdown, image, …) s jejich traity |
| `Models/BasicComponents.ts` | Definuje záznamy katalogu bloků — mapuje typy komponent na kategorie a popisky |
| `Models/TraitsRegistration.ts` | Registruje vlastní typy traitů GrapesJS používané napříč komponentami |
| `Models/Options/GeneralCategory.ts` | Sdílený základ modelu — `BaseComponentModel`, `GeneralTraits` (ID, OIDIS Bind), konstanta `GuiCommonsImport` |
| `Models/Options/FlexboxCategory.ts` | Možnosti traitů pro Flexbox layout |
| `Models/Options/MarginPaddingCategory.ts` | Možnosti traitů pro margin a padding |
| `Models/Options/DisplayCategory.ts` | Možnosti traitů pro zobrazení a viditelnost |
| `Models/Options/InputCategory.ts` | Definice traitů pro typy komponent input, textarea a checkbox |
| `Bindings/TraitsBuilder.ts` | Utilita převádějící definice kategorií možností na deskriptory traitů GrapesJS |
| `Interfaces/ILoadedFile.ts` | Sdílené rozhraní pro parsovaná data souboru (html, imports, variables, hasMarkers) |
| `Interfaces/IBootstrapConfig.ts` | Rozhraní pro `BootstrapConfig.json` |
| `Interfaces/IProjectConfig.ts` | Rozhraní pro `ProjectConfig.json` |

### Frontend — `dependencies/io-oidis-studio-gui/resource/`

| Cesta | Obsah |
|---|---|
| `graphics/` | Ikony aplikace a logo |
| `sass/` | SCSS styly pro rozvržení editoru (`HomePanel.scss`, `MainPage.scss`, globální proměnné) |
| `template/` | Přibalené CSS/JS pro stránku editoru (`oidis.min.css`, `oidis.min.js`) a Bootstrap CSS vkládaný do iframe plátna GrapesJS |


