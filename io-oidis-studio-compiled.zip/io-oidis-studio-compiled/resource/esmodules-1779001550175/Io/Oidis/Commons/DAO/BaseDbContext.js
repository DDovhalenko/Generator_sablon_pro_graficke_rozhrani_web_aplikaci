/*! ******************************************************************************************************** *
 *
 * Copyright 2024-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IModel } from "../Interfaces/IBaseObject.js";
import { BaseObject } from "../Primitives/BaseObject.js";
import { isBrowser } from "../Utils/EnvironmentHelper.js";
import { ObjectValidator } from "../Utils/ObjectValidator.js";
import { Reflection } from "../Utils/Reflection.js";
import { BaseInclusionConverter } from "./Converters/BaseInclusionConverter.js";
export class BaseDbDriver extends BaseObject {
    models;
    constructor() {
        super();
        this.models = [];
    }
    /**
     * @returns {Array<BaseModel>} Returns all registered model instances.
     */
    getAllModels() {
        return this.models;
    }
}
export class BaseDbContext extends BaseObject {
    driver;
    schema;
    model;
    constructor($driver, $model) {
        super();
        this.driver = $driver;
        this.schema = null;
        if (!ObjectValidator.IsEmptyOrNull($model)) {
            if (ObjectValidator.IsSet($model.ClassName) && ObjectValidator.IsFunction($model.ClassName)) {
                const prototype = Reflection.getInstance().getClass($model.ClassName());
                this.model = new prototype();
            }
            else {
                this.model = $model;
            }
        }
    }
    /**
     * @returns {BaseModel} Returns model instance bound to this context.
     */
    get Model() {
        return this.model;
    }
    /**
     * @param {any} $model Model instance to bind to this context.
     * @returns {void}
     */
    setModel($model) {
        this.model = $model;
    }
    /**
     * @returns {any} Returns database schema derived from model property definitions.
     */
    getSchema() {
        if (!ObjectValidator.IsEmptyOrNull(this.schema)) {
            return this.schema;
        }
        this.schema = {};
        for (const item of this.model.modelProperties) {
            if (!ObjectValidator.IsEmptyOrNull(item.schemaOptions.type)) {
                if (ObjectValidator.IsArray(item.schemaOptions.type)) {
                    // TODO(mkelnar) _id is forced to false because it is common in current use
                    //  check again if this should be forced or addId will be used control will be used instead.
                    //  exp: current use disables all _id generation for array props and all objects in array (not for inclusion)
                    // TODO(mkelnar) BaseModel derivatives validation is not optimal in such form, however type could be anything so
                    //  it looks that there is no other way except: why th reflection.Implements needs constructed instance and not
                    //  working with namespace-string or class prototype?
                    if (item.schemaOptions.type[0].hasOwnProperty("ClassName") &&
                        Reflection.getInstance().Implements(new (item.schemaOptions.type[0])(), IModel)) {
                        if (Reflection.getInstance().IsMemberOf(item.converter, BaseInclusionConverter)) {
                            this.schema[item.symbol] = [(new (item.schemaOptions.type[0])()).getSchema()];
                            item.isInclusion = true;
                        }
                        else {
                            this.schema[item.symbol] = [
                                {
                                    _id: false,
                                    required: item.schemaOptions.required,
                                    type: String
                                }
                            ];
                        }
                    }
                    else {
                        this.schema[item.symbol] = [
                            {
                                _id: false,
                                required: item.schemaOptions.required,
                                type: item.schemaOptions.type[0]
                            }
                        ];
                    }
                }
                else {
                    if (item.schemaOptions.type.hasOwnProperty("ClassName") &&
                        Reflection.getInstance().Implements(new item.schemaOptions.type(), IModel)) {
                        if (Reflection.getInstance().IsMemberOf(item.converter, BaseInclusionConverter)) {
                            this.schema[item.symbol] = (new item.schemaOptions.type()).getSchema();
                            item.isInclusion = true;
                        }
                        else {
                            this.schema[item.symbol] = {
                                required: item.schemaOptions.required,
                                type: String
                            };
                        }
                    }
                    else {
                        this.schema[item.symbol] = {
                            required: item.schemaOptions.required,
                            type: item.schemaOptions.type
                        };
                    }
                }
                if (!ObjectValidator.IsEmptyOrNull(item.schemaOptions.alias)) {
                    this.schema[item.symbol].alias = item.schemaOptions.alias;
                }
                if (item.symbol !== "_id") {
                    // turn of native id key generation for property (should have an effect only for object types but has been
                    // set for every property from the BaseModel beginning so used it in the same way
                    if (!item.isInclusion && !ObjectValidator.IsArray(item.schemaOptions.type)) {
                        this.schema[item.symbol]._id = item.schemaOptions.addId;
                    }
                }
            }
        }
        return this.schema;
    }
    /**
     * @param {any} [$property] Property name or raw value to extract from document.
     * @returns {any} Returns document object or specific property value.
     */
    DocumentToObject($property) {
        if (ObjectValidator.IsSet($property)) {
            if (ObjectValidator.IsString($property)) {
                return this.Model.getDocument()[$property];
            }
            return $property;
        }
        return this.Model.getDocument();
    }
    /**
     * @returns {Promise<boolean>} Returns true if model validation passes, otherwise false.
     */
    async Validate() {
        /// TODO: implement validation based on metadata from getSchema instead of model.Validate()
        return this.Model.Validate();
    }
    /**
     * @returns {any} Returns database document handle for the current model.
     */
    getDocument() {
        return this.driver.getModel(this.Model.getSymbolicName());
    }
    backendOnlyAssert() {
        if (isBrowser) {
            throw new Error("Method or feature is allowed only at backend. This is code design issue.");
        }
    }
    frontendOnlyAssert() {
        if (!isBrowser) {
            throw new Error("Method or feature is allowed only at frontend. This is code design issue.");
        }
    }
    getModelInstance() {
        const prototype = Reflection.getInstance().getClass(this.Model.getClassName());
        return new prototype();
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.DAO.BaseDbDriver", BaseDbDriver);
globalThis.RegisterClass("Io.Oidis.Commons.DAO.BaseDbContext", BaseDbContext);
//# sourceMappingURL=BaseDbContext.js.map