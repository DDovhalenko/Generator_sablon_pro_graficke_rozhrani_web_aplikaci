/*! ******************************************************************************************************** *
 *
 * Copyright 2020-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IBaseObject } from "../../Interfaces/IBaseObject.js";
import { BaseObject } from "../../Primitives/BaseObject.js";
import { LogIt } from "../../Utils/LogIt.js";
export class BaseConverter extends BaseObject {
    /**
     * @param {any} $value Raw value from database document.
     * @param {IContext} $context Conversion context with parent model and property metadata.
     * @returns {Promise<any>} Returns converted value for model property.
     */
    async from($value, $context) {
        LogIt.Warning("Skipping unsupported \"from()\" conversion in " + IConverter.ClassName() + ".");
        return $value;
    }
    /**
     * @param {any} $value Model property value.
     * @param {IContext} $context Conversion context with parent model and property metadata.
     * @returns {Promise<any>} Returns converted value for database document.
     */
    async to($value, $context) {
        LogIt.Warning("Skipping unsupported \"to()\" conversion in " + IConverter.ClassName() + ".");
        return $value;
    }
}
// generated-code-start
export const IConverter = globalThis.RegisterInterface(["to", "from"], IBaseObject);
globalThis.RegisterClass("Io.Oidis.Commons.DAO.Converters.BaseConverter", BaseConverter);
globalThis.RegisterClass("Io.Oidis.Commons.DAO.Converters.IConverter", IConverter);
//# sourceMappingURL=BaseConverter.js.map