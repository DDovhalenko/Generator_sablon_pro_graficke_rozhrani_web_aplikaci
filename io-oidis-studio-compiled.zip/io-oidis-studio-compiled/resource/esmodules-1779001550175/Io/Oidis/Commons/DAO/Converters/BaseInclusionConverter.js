import { BaseModel } from "../../Primitives/BaseModel.js";
import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { BaseConverter } from "./BaseConverter.js";
export class BaseInclusionConverter extends BaseConverter {
    model;
    constructor($modelClass) {
        super();
        if (ObjectValidator.IsEmptyOrNull($modelClass)) {
            $modelClass = BaseModel;
        }
        this.model = $modelClass;
    }
    /**
     * @param {any} $value Raw inclusion document data.
     * @param {IContext} $context Conversion context with data translation flag.
     * @returns {Promise<any>} Returns hydrated model instance from inclusion data.
     */
    async from($value, $context) {
        const instance = this.getInclusionInstance();
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            if ($context.dataTranslation) {
                instance.document = $value;
            }
            else {
                instance.document = Object.assign(instance.document, instance.context.DocumentToObject($value));
            }
            await instance.fromModel({ dataTranslation: $context.dataTranslation });
        }
        return instance;
    }
    /**
     * @param {any} $value Model instance to convert to document.
     * @param {IContext} $context Conversion context.
     * @returns {Promise<any>} Returns document object from model, or null if value is empty.
     */
    async to($value, $context) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            await $value.toModel();
            await $value.context.Validate(); // call validate manually to rise potential errors directly
            return $value.context.DocumentToObject();
        }
        return null;
    }
    getInclusionInstance() {
        return new this.model();
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.DAO.Converters.BaseInclusionConverter", BaseInclusionConverter);
//# sourceMappingURL=BaseInclusionConverter.js.map