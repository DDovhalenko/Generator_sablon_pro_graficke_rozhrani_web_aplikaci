import { BaseConverter } from "./BaseConverter.js";
export class IdentityConverter extends BaseConverter {
    /**
     * @param {any} $value Raw value from database document.
     * @param {IContext} $context Conversion context.
     * @returns {Promise<any>} Returns the value unchanged.
     */
    async from($value, $context) {
        return $value;
    }
    /**
     * @param {any} $value Model property value.
     * @param {IContext} $context Conversion context.
     * @returns {Promise<any>} Returns the value unchanged.
     */
    async to($value, $context) {
        return $value;
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.DAO.Converters.IdentityConverter", IdentityConverter);
//# sourceMappingURL=IdentityConverter.js.map