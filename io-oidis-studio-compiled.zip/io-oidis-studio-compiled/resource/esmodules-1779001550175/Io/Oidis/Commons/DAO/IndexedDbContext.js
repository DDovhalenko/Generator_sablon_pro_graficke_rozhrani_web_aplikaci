/*! ******************************************************************************************************** *
 *
 * Copyright 2024-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IModel } from "../Interfaces/IBaseObject.js";
import { Loader } from "../Loader.js";
import { BaseModel } from "../Primitives/BaseModel.js";
import { JsonUtils } from "../Utils/JsonUtils.js";
import { LogIt } from "../Utils/LogIt.js";
import { ObjectValidator } from "../Utils/ObjectValidator.js";
import { Reflection } from "../Utils/Reflection.js";
import { BaseDbContext, BaseDbDriver } from "./BaseDbContext.js";
export class IndexedDbDriver extends BaseDbDriver {
    driver;
    onUpgradeHandler;
    isOpen;
    /**
     * @returns {boolean} Returns true if IndexedDB is supported in the current environment.
     */
    static IsSupported() {
        return "indexedDB" in window;
    }
    constructor() {
        super();
        this.driver = null;
        this.isOpen = false;
        this.onUpgradeHandler = ($db) => {
            // default handler
        };
    }
    /**
     * @param {string} $className Symbolic name of the model collection.
     * @returns {any} Returns IndexedDB object store transaction for the specified class name.
     */
    getModel($className) {
        const transaction = this.driver.transaction($className, "readwrite").objectStore($className);
        transaction.onerror = () => {
            throw new Error("Save transaction issue: " + transaction.error);
        };
        return transaction;
    }
    /**
     * @returns {boolean} Returns true if the IndexedDB connection is open, otherwise false.
     */
    IsOpen() {
        return this.isOpen;
    }
    /**
     * @param {IDbConfiguration} $config Database connection configuration.
     * @param {boolean} [$autoReconnect=false] Enable automatic reconnection on version change.
     * @returns {Promise<boolean>} Returns true if connection was opened successfully, otherwise false.
     */
    async Open($config, $autoReconnect = false) {
        if (!ObjectValidator.IsEmptyOrNull(this.driver)) {
            this.isOpen = true;
            return true;
        }
        return await new Promise(($resolve) => {
            try {
                if (ObjectValidator.IsEmptyOrNull($config.dbName)) {
                    $config.dbName = Loader.getInstance().getEnvironmentArgs().getProjectName();
                }
                LogIt.Debug("Opening IndexDB: " + $config.dbName);
                const openRequest = window.indexedDB.open($config.dbName, Loader.getInstance().getEnvironmentArgs().getProjectConfig().build.timestamp);
                openRequest.onerror = (ev) => {
                    LogIt.Error("Open IndexDB error: " + openRequest.error);
                    this.isOpen = false;
                    $resolve(false);
                };
                openRequest.onblocked = () => {
                    LogIt.Warning("DB transaction is blocked - waiting for end of unfinished job, maybe in another tab");
                };
                openRequest.onupgradeneeded = (event) => {
                    const db = event.target.result;
                    const transaction = event.target.transaction;
                    const reflection = Reflection.getInstance();
                    const baseClasses = [
                        BaseModel.ClassName(), "Io.Oidis.Hub.Gui.Models.BaseModel", "Io.Oidis.Hub.DAO.Models.BaseModel"
                    ];
                    for (const modelClass of reflection.getAllClasses()) {
                        const modelPrototype = reflection.getClass(modelClass);
                        if (!ObjectValidator.IsEmptyOrNull(modelPrototype)) {
                            if (reflection.ClassHasInterface(modelPrototype, IModel) && !baseClasses.includes(modelClass)) {
                                const instance = new modelPrototype();
                                if (ObjectValidator.IsSet(instance.getContext) &&
                                    reflection.IsMemberOf(instance.getContext(), IndexedDbContext)) {
                                    let objectStore;
                                    if (!db.objectStoreNames.contains(instance.getSymbolicName())) {
                                        objectStore = db.createObjectStore(instance.getSymbolicName(), {
                                            autoIncrement: true,
                                            keyPath: "_id"
                                        });
                                    }
                                    else {
                                        objectStore = transaction.objectStore(instance.getSymbolicName());
                                    }
                                    const props = instance.Properties;
                                    props.forEach(($prop) => {
                                        if (!objectStore.indexNames.contains($prop.symbol)) {
                                            objectStore.createIndex($prop.symbol, $prop.symbol, { unique: false });
                                        }
                                    });
                                    if (!this.models.includes(instance)) {
                                        this.models.push(instance);
                                    }
                                }
                            }
                        }
                    }
                    this.onUpgradeHandler(openRequest.result);
                };
                openRequest.onsuccess = (ev) => {
                    this.driver = openRequest.result;
                    this.driver.onversionchange = () => {
                        void this.Close();
                        LogIt.Warning("Database is outdated please reload context");
                        if ($autoReconnect) {
                            void this.Open($config, $autoReconnect);
                        }
                    };
                    this.isOpen = true;
                    $resolve(true);
                };
            }
            catch (ex) {
                LogIt.Error(ex);
                this.isOpen = false;
                $resolve(false);
            }
        });
    }
    /**
     * @param {boolean} [$force=false] Force close the connection.
     * @returns {Promise<boolean>} Returns true if connection was closed successfully, otherwise false.
     */
    async Close($force = false) {
        return await new Promise(($resolve) => {
            try {
                if (!ObjectValidator.IsEmptyOrNull(this.driver)) {
                    this.driver.onclose = () => {
                        this.driver = null;
                        this.isOpen = false;
                        $resolve(true);
                    };
                    this.driver.close();
                }
                else {
                    $resolve(true);
                }
            }
            catch (ex) {
                LogIt.Error(ex);
                this.isOpen = false;
                $resolve(false);
            }
        });
    }
    /**
     * @returns {any} Returns underlying IndexedDB database instance.
     */
    getDb() {
        return this.driver;
    }
    /**
     * @param {any} $handler Callback invoked during IndexedDB upgrade.
     * @returns {void}
     */
    setOnUpgradeHandler($handler) {
        if (!ObjectValidator.IsEmptyOrNull($handler)) {
            this.onUpgradeHandler = $handler;
        }
    }
    /**
     * @param {any} $model Model instance or class to create context for.
     * @returns {IndexedDbContext} Returns IndexedDB context bound to the specified model.
     */
    getContextFor($model) {
        return new IndexedDbContext(this, $model);
    }
}
export class IndexedDbContext extends BaseDbContext {
    /**
     * @returns {any} Returns database document handle for the current model.
     */
    getDocument() {
        this.frontendOnlyAssert();
        return super.getDocument();
    }
    /**
     * @param {string} $className Model class name.
     * @param {any} $schema Database schema definition.
     * @param {string} $collection Collection name.
     * @returns {any} Returns created document with generated id and timestamps.
     */
    CreateDocument($className, $schema, $collection) {
        return {
            _id: this.getUID(),
            created: new Date(),
            lastModified: new Date()
        };
    }
    /**
     * @param {string} $id Document identifier.
     * @param {IModelFindOptions} [$options] Query options.
     * @returns {Promise<T>} Returns found model instance or null.
     */
    async FindById($id, $options) {
        const models = await this.Find($id, $options);
        if (!ObjectValidator.IsEmptyOrNull(models)) {
            if (models.length > 1) {
                LogIt.Warning("Found more than one document with id: " + $id);
            }
            return models[0];
        }
        return null;
    }
    /**
     * @param {any} $query Search query object or string identifier.
     * @param {IModelFindOptions} [$options] Query options for limit, offset, and sort.
     * @returns {Promise<T[]>} Returns array of matching model instances.
     */
    async Find($query, $options) {
        this.frontendOnlyAssert();
        $options = JsonUtils.Extend({
            limit: -1,
            offset: 0,
            sort: "prev" // prevunique, next, nextunique | next is descendant, prev is ascendant
        }, $options);
        const models = await new Promise(($resolve, $reject) => {
            try {
                const objectStore = this.getDocument();
                let targetStore = objectStore;
                const getAllRecords = ObjectValidator.IsEmptyOrNull($query) || JSON.stringify($query) === "{}";
                let find = $query;
                if (!getAllRecords && !ObjectValidator.IsString($query)) {
                    const keys = Object.keys($query);
                    if (keys.length > 1) {
                        LogIt.Warning("Current implementation of IndexedDB Context Find do not support more that one key! " +
                            "Try to use different approach for search, e.g. Model.Find({}).find({Native JS Array find syntax here ...})");
                    }
                    const key = Object.keys($query)[0];
                    find = $query[key];
                    targetStore = objectStore.index(key);
                }
                const request = getAllRecords ? targetStore.openCursor() : targetStore.openCursor(find, $options.sort);
                const models = [];
                request.onsuccess = ($event) => {
                    const cursor = $event.target.result;
                    if (cursor) {
                        const model = this.getModelInstance();
                        model.document = cursor.value;
                        models.push(model);
                        if ($options.limit <= 0 || models.length < $options.limit) {
                            if ($options.offset <= 0) {
                                cursor.continue();
                            }
                            else {
                                cursor.advance($options.offset);
                            }
                        }
                    }
                    else {
                        $resolve(models);
                    }
                };
                request.onerror = () => {
                    $reject(new Error("Find error: " + request.error));
                };
            }
            catch (ex) {
                $reject(ex);
            }
        });
        for await (const model of models) {
            await model.fromModel();
        }
        return models;
    }
    /**
     * @param {any[] | IModelAggregateOptions} $chain Aggregation pipeline queries or options.
     * @param {IModelFindOptions} [$options] Query options.
     * @returns {Promise<any>} Returns concatenated results from all queries.
     */
    async Aggregate($chain, $options) {
        this.frontendOnlyAssert();
        let queries;
        if (ObjectValidator.IsArray($chain)) {
            queries = $chain;
        }
        else {
            queries = $chain.filterQuery;
        }
        let result = [];
        for await (const query of queries) {
            result = result.concat(await this.Find(query, $options));
        }
        return result;
    }
    /**
     * @returns {Promise<void>}
     */
    async Save() {
        this.frontendOnlyAssert();
        return await new Promise(($resolve, $reject) => {
            try {
                this.Model.LastModified = new Date();
                const request = this.getDocument().put(this.Model.getDocument());
                request.onsuccess = ($event) => {
                    $resolve();
                };
                request.onerror = () => {
                    $reject(new Error(request.error));
                };
            }
            catch (ex) {
                $reject(ex);
            }
        });
    }
    /**
     * @param {string} $property Property name to update in the document.
     * @returns {Promise<void>}
     */
    async Update($property) {
        for await (const property of this.Model.Properties) {
            if (property.name === $property || property.symbol === $property) {
                const value = this[property.fieldKey];
                if (ObjectValidator.IsObject(property) && Reflection.getInstance().Implements(value, IModel)) {
                    this.Model.getDocument()[property.symbol] = await property.converter.to(value, {
                        dataTranslation: false,
                        parent: this.Model,
                        property
                    });
                }
                else {
                    this.Model.getDocument()[property.symbol] = value;
                }
            }
        }
        return await this.Save();
    }
    /**
     * @param {IModelFindOptions} [$options] Query options for refresh.
     * @returns {Promise<void>}
     */
    async Refresh($options) {
        this.frontendOnlyAssert();
        return await new Promise(($resolve, $reject) => {
            try {
                const objectStore = this.getDocument();
                const request = objectStore.openCursor(this.Model.Id, "prev");
                request.onsuccess = ($event) => {
                    const cursor = $event.target.result;
                    if (cursor) {
                        this.Model.document = cursor.value;
                        this.Model.fromModel($options).then(() => {
                            $resolve();
                        }).catch(($ex) => {
                            $reject($ex);
                        });
                    }
                    else {
                        $reject(new Error("Failed to find model record for id: " + this.Model.Id));
                    }
                };
                request.onerror = () => {
                    $reject(new Error("Failed to sync model: " + request.error));
                };
            }
            catch (ex) {
                $reject(ex);
            }
        });
    }
    /**
     * @param {string} [$property] Property name to remove. Removes entire document if not specified.
     * @param {string} [$child] Child key within the property to remove.
     * @returns {Promise<void>}
     */
    async Remove($property, $child) {
        this.frontendOnlyAssert();
        if (ObjectValidator.IsEmptyOrNull($property)) {
            return await new Promise(($resolve, $reject) => {
                const request = this.getDocument().delete(this.Model.Id);
                request.onsuccess = () => {
                    $resolve();
                };
                request.onerror = () => {
                    $reject(request.error);
                };
            });
        }
        else {
            for (const property of this.Model.Properties) {
                if (property.name === $property || property.symbol === $property) {
                    if (!ObjectValidator.IsEmptyOrNull($child)) {
                        delete this.Model.document()[property.symbol][$child];
                    }
                    else {
                        delete this.Model.document[property.symbol];
                    }
                }
            }
            return await new Promise(($resolve, $reject) => {
                try {
                    const request = this.getDocument().put(this.Model.getDocument());
                    request.onsuccess = ($event) => {
                        $resolve();
                    };
                    request.onerror = () => {
                        $reject(request.error);
                    };
                }
                catch (ex) {
                    $reject(ex);
                }
            });
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.DAO.IndexedDbDriver", IndexedDbDriver);
globalThis.RegisterClass("Io.Oidis.Commons.DAO.IndexedDbContext", IndexedDbContext);
//# sourceMappingURL=IndexedDbContext.js.map