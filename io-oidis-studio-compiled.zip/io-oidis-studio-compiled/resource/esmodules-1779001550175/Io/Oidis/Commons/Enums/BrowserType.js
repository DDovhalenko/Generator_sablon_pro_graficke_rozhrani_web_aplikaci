/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
export var BrowserType;
(function (BrowserType) {
    BrowserType[BrowserType["INTERNET_EXPLORER"] = 0] = "INTERNET_EXPLORER";
    BrowserType[BrowserType["FIREFOX"] = 1] = "FIREFOX";
    BrowserType[BrowserType["GOOGLE_CHROME"] = 2] = "GOOGLE_CHROME";
    BrowserType[BrowserType["OPERA"] = 3] = "OPERA";
    BrowserType[BrowserType["SAFARI"] = 4] = "SAFARI";
    BrowserType[BrowserType["EDGE"] = 5] = "EDGE";
    BrowserType[BrowserType["JAVA_RE"] = 6] = "JAVA_RE";
    BrowserType[BrowserType["DEBUG_RE"] = 7] = "DEBUG_RE";
    BrowserType[BrowserType["UNKNOWN"] = 8] = "UNKNOWN";
})(BrowserType || (BrowserType = {}));
//# sourceMappingURL=BrowserType.js.map