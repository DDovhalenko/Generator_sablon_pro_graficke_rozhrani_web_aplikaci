/*! ******************************************************************************************************** *
 *
 * Copyright 2024-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "../Primitives/BaseEnum.js";
export class DataFormatType extends BaseEnum {
    static UTF8 = "utf8";
    static BINARY = "binary";
    static JSON = "json";
    static URL_ENCODED = "urlencoded";
    static BASE64 = "base64";
    static AUTO = "auto";
}
globalThis.RegisterClass("Io.Oidis.Commons.Enums.DataFormatType", DataFormatType);
//# sourceMappingURL=DataFormatType.js.map