/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "../../Primitives/BaseEnum.js";
export class EventType extends BaseEnum {
    static ON_START = "onstart";
    static ON_CHANGE = "onchange";
    static ON_COMPLETE = "oncomplete";
    static BEFORE_LOAD = "beforereload";
    static ON_LOAD = "onload";
    static BEFORE_REFRESH = "beforerefresh";
    static ON_HTTP_REQUEST = "onhttprequest";
    static ON_ASYNC_REQUEST = "onasyncrequest";
    static ON_SUCCESS = "onsuccess";
    static ON_ERROR = "onerror";
    static ON_MESSAGE = "onmessage";
}
globalThis.RegisterClass("Io.Oidis.Commons.Enums.Events.EventType", EventType);
//# sourceMappingURL=EventType.js.map