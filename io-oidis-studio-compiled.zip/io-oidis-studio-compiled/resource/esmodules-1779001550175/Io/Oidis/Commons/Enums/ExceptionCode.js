/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
export var ExceptionCode;
(function (ExceptionCode) {
    ExceptionCode[ExceptionCode["EXIT"] = -1] = "EXIT";
    ExceptionCode[ExceptionCode["GENERAL"] = 0] = "GENERAL";
    ExceptionCode[ExceptionCode["FATAL_ERROR"] = 1] = "FATAL_ERROR";
    ExceptionCode[ExceptionCode["NULL_POINTER"] = 2] = "NULL_POINTER";
    ExceptionCode[ExceptionCode["ILLEGAL_ARGUMENT"] = 3] = "ILLEGAL_ARGUMENT";
    ExceptionCode[ExceptionCode["OUT_OF_RANGE"] = 4] = "OUT_OF_RANGE";
    ExceptionCode[ExceptionCode["ERROR_PAGE_EXCEPTION"] = 5] = "ERROR_PAGE_EXCEPTION";
    ExceptionCode[ExceptionCode["RESOLVER_EXCEPTION"] = 6] = "RESOLVER_EXCEPTION";
})(ExceptionCode || (ExceptionCode = {}));
//# sourceMappingURL=ExceptionCode.js.map