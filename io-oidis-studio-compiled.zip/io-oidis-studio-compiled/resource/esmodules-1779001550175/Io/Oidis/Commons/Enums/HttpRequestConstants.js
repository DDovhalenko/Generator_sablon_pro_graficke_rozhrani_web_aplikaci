/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "../Primitives/BaseEnum.js";
export class HttpRequestConstants extends BaseEnum {
    static EXCEPTION_TYPE = "ErrorType";
    static EXCEPTIONS_LIST = "ErrorsList";
    static HTTP301_LINK = "Http301Link";
    static HTTP404_FILE_PATH = "Http404FilePath";
    static APP_NAME = "AppName";
    static APP_PID = "AppPid";
    static DESIGNER = "Designer";
    static RELEASE_NAME = "ReleaseName";
    static PLATFORM = "Platform";
}
globalThis.RegisterClass("Io.Oidis.Commons.Enums.HttpRequestConstants", HttpRequestConstants);
//# sourceMappingURL=HttpRequestConstants.js.map