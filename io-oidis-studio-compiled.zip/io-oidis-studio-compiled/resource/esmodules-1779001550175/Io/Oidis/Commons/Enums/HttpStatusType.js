/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
export var HttpStatusType;
(function (HttpStatusType) {
    HttpStatusType[HttpStatusType["SUCCESS"] = 200] = "SUCCESS";
    HttpStatusType[HttpStatusType["CONTINUE"] = 201] = "CONTINUE";
    HttpStatusType[HttpStatusType["MOVED"] = 301] = "MOVED";
    HttpStatusType[HttpStatusType["CACHED"] = 304] = "CACHED";
    HttpStatusType[HttpStatusType["NOT_AUTHORIZED"] = 401] = "NOT_AUTHORIZED";
    HttpStatusType[HttpStatusType["FORBIDDEN"] = 403] = "FORBIDDEN";
    HttpStatusType[HttpStatusType["NOT_FOUND"] = 404] = "NOT_FOUND";
    HttpStatusType[HttpStatusType["NOT_ALLOWED"] = 405] = "NOT_ALLOWED";
    HttpStatusType[HttpStatusType["NOT_ACCEPTABLE"] = 406] = "NOT_ACCEPTABLE";
    HttpStatusType[HttpStatusType["ERROR"] = 500] = "ERROR";
})(HttpStatusType || (HttpStatusType = {}));
//# sourceMappingURL=HttpStatusType.js.map