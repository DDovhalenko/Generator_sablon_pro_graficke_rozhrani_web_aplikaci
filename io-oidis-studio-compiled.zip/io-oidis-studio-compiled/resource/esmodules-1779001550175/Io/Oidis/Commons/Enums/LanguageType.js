/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "../Primitives/BaseEnum.js";
export class LanguageType extends BaseEnum {
    static EN = "En";
    static CZ = "Cz";
    static DE = "De";
    static CN = "Cn";
}
globalThis.RegisterClass("Io.Oidis.Commons.Enums.LanguageType", LanguageType);
//# sourceMappingURL=LanguageType.js.map