/*! ******************************************************************************************************** *
 *
 * Copyright 2019 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
export var LogSeverity;
(function (LogSeverity) {
    LogSeverity[LogSeverity["LOW"] = 0] = "LOW";
    LogSeverity[LogSeverity["MEDIUM"] = 1] = "MEDIUM";
    LogSeverity[LogSeverity["HIGH"] = 2] = "HIGH";
})(LogSeverity || (LogSeverity = {}));
//# sourceMappingURL=LogSeverity.js.map