/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "../Primitives/BaseEnum.js";
export class SpecialCharacters extends BaseEnum {
    static WHITESPACE = "&nbsp;";
    static TAB = "&nbsp;&nbsp;&nbsp;";
    static AMPERSAND = "&amp;";
    static COPYRIGHT = "&copy;";
    static REGISTERED = "&reg;";
}
globalThis.RegisterClass("Io.Oidis.Commons.Enums.SpecialCharacters", SpecialCharacters);
//# sourceMappingURL=SpecialCharacters.js.map