/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
export class SyntaxConstants {
    static UNDEFINED = ["undefined", undefined];
    static CONSTRUCTOR = "constructor";
    static ALIASES = ["", "anonymous", "Anonymous"];
    static FUNCTION = "function";
    static BOOLEAN = "boolean";
    static NUMBER = "number";
    static STRING = "string";
    static ARRAYS = ["array", "[object Array]"];
    static OBJECT = "object";
    static CLASS_NAME = "getClassName";
    static TO_STRING = "ToString";
    static IS_EMPTY = "IsEmpty";
    static IS_TYPE_OF = "IsTypeOf";
    static LENGTH = "Length";
    static ERROR = "[object Error]";
}
globalThis.RegisterClass("Io.Oidis.Commons.Enums.SyntaxConstants", SyntaxConstants);
//# sourceMappingURL=SyntaxConstants.js.map