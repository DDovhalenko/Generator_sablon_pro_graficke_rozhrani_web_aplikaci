/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "../Primitives/BaseEnum.js";
export class WebServiceClientType extends BaseEnum {
    static AJAX = "Ajax";
    static AJAX_SYNCHRONOUS = "AjaxSync";
    static IFRAME = "Iframe";
    static POST_MESSAGE = "PostMessage";
    static HTTP = "Http";
    static WEB_SOCKETS = "WebSockets";
    static CEF_QUERY = "CefQuery";
    static JXBROWSER_BRIDGE = "JxbrowserBridge";
}
globalThis.RegisterClass("Io.Oidis.Commons.Enums.WebServiceClientType", WebServiceClientType);
//# sourceMappingURL=WebServiceClientType.js.map