import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { HttpRequestEventArgs } from "./HttpRequestEventArgs.js";
/**
 * AsyncRequestEventArgs class provides args connected with asynchronous request events.
 */
export class AsyncRequestEventArgs extends HttpRequestEventArgs {
    result;
    /**
     * @param {string} $url Set url, which should be asynchronously resolved.
     * @param {ArrayList<any>} [$POST] Specify data, which should be passed to request resolver.
     */
    constructor($url, $POST) {
        super($url, $POST);
    }
    /**
     * @param {object} $value Set result of asynchronous request.
     * @returns {object} Returns result of asynchronous request.
     */
    Result($value) {
        if (ObjectValidator.IsSet($value)) {
            this.result = $value;
        }
        return this.result;
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.Events.Args.AsyncRequestEventArgs", AsyncRequestEventArgs);
//# sourceMappingURL=AsyncRequestEventArgs.js.map