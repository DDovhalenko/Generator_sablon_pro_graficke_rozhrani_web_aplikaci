/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { Exception } from "../../Exceptions/Type/Exception.js";
import { Convert } from "../../Utils/Convert.js";
import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { Property } from "../../Utils/Property.js";
import { StringUtils } from "../../Utils/StringUtils.js";
import { EventArgs } from "./EventArgs.js";
/**
 * ErrorEventArgs class provides args connected with asynchronous error.
 */
export class ErrorEventArgs extends EventArgs {
    message;
    exception;
    /**
     * @param {string|Exception|Error} $message Specify error message.
     */
    constructor($message) {
        super();
        if (ObjectValidator.IsString($message)) {
            this.message = $message;
            this.exception = new Exception(this.message);
        }
        else {
            this.Exception($message);
        }
    }
    /**
     * @param {string} [$value] Set error message.
     * @returns {string} Returns error message.
     */
    Message($value) {
        return this.message = Property.String(this.message, $value);
    }
    /**
     * @param {Exception|Error} [$value] Set exception object data.
     * @returns {Exception} Returns error exception object.
     */
    Exception($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            if (ObjectValidator.IsObject($value) && ObjectValidator.IsSet($value.IsMemberOf) &&
                $value.IsMemberOf(Exception)) {
                this.exception = $value;
            }
            else {
                this.exception = new Exception($value.message);
                if (ObjectValidator.IsSet($value.stack)) {
                    this.exception.Stack($value.stack);
                }
            }
            this.message = this.exception.Message();
        }
        if (!ObjectValidator.IsSet(this.exception)) {
            this.exception = new Exception();
        }
        return this.exception;
    }
    /**
     * @param {string} [$prefix=""] Prefix for each output line.
     * @param {boolean} [$htmlTag=true] Use HTML tags in output.
     * @returns {string} Returns formatted error event args string.
     */
    ToString($prefix = "", $htmlTag = true) {
        let output = "";
        output += $prefix + this.getClassName() + StringUtils.NewLine($htmlTag);
        output += $prefix + "[\"Message\"] " + this.Message() + StringUtils.NewLine($htmlTag);
        output += $prefix + "[\"Owner\"] ";
        if (ObjectValidator.IsObject(this.Owner())) {
            output += this.Owner().getClassName() + StringUtils.NewLine($htmlTag);
        }
        else {
            output += Convert.ObjectToString(this.Owner()) + StringUtils.NewLine($htmlTag);
        }
        return output;
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.Events.Args.ErrorEventArgs", ErrorEventArgs);
//# sourceMappingURL=ErrorEventArgs.js.map