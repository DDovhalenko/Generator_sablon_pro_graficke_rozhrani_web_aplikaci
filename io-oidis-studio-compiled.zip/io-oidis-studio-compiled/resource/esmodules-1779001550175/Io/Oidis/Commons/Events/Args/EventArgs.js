import { BaseArgs } from "../../Primitives/BaseArgs.js";
import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { Property } from "../../Utils/Property.js";
/**
 * EventArgs class provides basic events structure.
 */
export class EventArgs extends BaseArgs {
    owner;
    type;
    nativeEventArgs;
    constructor() {
        super();
        this.owner = this;
    }
    /**
     * @param {any} [$owner] Specified object, which owns current args.
     * @returns {any} Returns current event args owner object.
     */
    Owner($owner) {
        if (!ObjectValidator.IsEmptyOrNull($owner)) {
            this.owner = $owner;
        }
        return this.owner;
    }
    /**
     * @param {string} [$value] If specified, set type of event, which handles current args.
     * @returns {string} Returns current event args type of.
     */
    Type($value) {
        return this.type = Property.String(this.type, $value);
    }
    /**
     * @param {Event} [$value] If specified, set event args of native event.
     * @returns {Event} Returns native event args provided by native event handler.
     */
    NativeEventArgs($value) {
        if (ObjectValidator.IsSet($value)) {
            this.nativeEventArgs = $value;
        }
        return this.nativeEventArgs;
    }
    /**
     * Skip execution of native event
     * @returns {void}
     */
    PreventDefault() {
        if (ObjectValidator.IsSet(this.nativeEventArgs)) {
            if (ObjectValidator.IsSet(this.nativeEventArgs.preventDefault)) {
                this.nativeEventArgs.preventDefault();
            }
            else {
                this.nativeEventArgs.returnValue = false;
            }
        }
    }
    /**
     * Stop event bubbling
     * @returns {void}
     */
    StopAllPropagation() {
        this.PreventDefault();
        if (ObjectValidator.IsSet(this.nativeEventArgs)) {
            if (ObjectValidator.IsSet(this.nativeEventArgs.stopPropagation)) {
                this.nativeEventArgs.stopPropagation();
                this.nativeEventArgs.stopImmediatePropagation();
            }
            else {
                this.nativeEventArgs.cancelBubble = true;
            }
        }
    }
    /**
     * @returns {string} Returns string representation of this event args.
     */
    toString() {
        return this.ToString();
    }
    toStringFilter($methodName) {
        if ($methodName === "Owner") {
            return ObjectValidator.IsString(this.owner);
        }
        return super.toStringFilter($methodName);
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.Events.Args.EventArgs", EventArgs);
//# sourceMappingURL=EventArgs.js.map