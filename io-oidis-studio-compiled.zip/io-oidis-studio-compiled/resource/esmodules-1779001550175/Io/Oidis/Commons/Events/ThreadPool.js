import { BaseObject } from "../Primitives/BaseObject.js";
import { ObjectValidator } from "../Utils/ObjectValidator.js";
/**
 * ThreadPool class provides asynchronous handling of custom events group.
 */
export class ThreadPool extends BaseObject {
    static threadId;
    /**
     * @param {string} $owner Specify thread owner.
     * @param {string} $type Specify type of thread.
     * @returns {boolean} Returns true, if specified thread is running, otherwise false.
     */
    static IsRunning($owner, $type) {
        return ThreadPool.getEvents().Exists($owner, $type);
    }
    /**
     * @param {string} $owner Specify thread owner.
     * @param {string} $type Specify type of thread.
     * @param {IEventsHandler} [$handler] Function suitable for handling of the thread.
     * @param {IEventArgs} [$args] Specify initial thread args.
     * @returns {void}
     */
    static AddThread($owner, $type, $handler, $args) {
        ThreadPool.getEvents().setEvent($owner, $type, $handler, $args);
    }
    /**
     * @param {string} $owner Specify thread owner.
     * @param {string} $type Specify type of thread.
     * @param {IEventArgs} $args Specify current thread args.
     * @returns {void}
     */
    static setThreadArgs($owner, $type, $args) {
        ThreadPool.getEvents().setEventArgs($owner, $type, $args);
    }
    /**
     * @param {string} $owner Specify thread owner.
     * @param {string} $type Specify type of thread, which should be removed.
     * @returns {void}
     */
    static RemoveThread($owner, $type) {
        ThreadPool.getEvents().Clear($owner, $type);
    }
    /**
     * Fire execution of all registered threads.
     * @returns {void}
     */
    static Execute() {
        const events = ThreadPool.getEvents();
        if (!events.getAll().IsEmpty()) {
            ThreadPool.threadId = events.FireAsynchronousMethod(() => {
                const owners = events.getAll().getKeys();
                let ownerIndex;
                let typeIndex;
                for (ownerIndex = 0; ownerIndex < owners.length; ownerIndex++) {
                    const types = events.getAll().getItem(owners[ownerIndex]).getKeys();
                    for (typeIndex = 0; typeIndex < types.length; typeIndex++) {
                        events.FireEvent(owners[ownerIndex], types[typeIndex]);
                    }
                }
                ThreadPool.Execute();
            }, 5);
        }
    }
    /**
     * Stop execution of all registered threads.
     * @returns {void}
     */
    static Clear() {
        if (!ObjectValidator.IsEmptyOrNull(ThreadPool.threadId)) {
            clearTimeout(ThreadPool.threadId);
        }
        ThreadPool.getEvents().Clear();
    }
    static getEvents() {
        const instance = new globalThis.Io.Oidis.Commons.Events.EventsManager();
        this.getEvents = () => {
            return instance;
        };
        return instance;
    }
}
globalThis.Io.Oidis.Commons.Events.ThreadPool = ThreadPool;
globalThis.RegisterClass("Io.Oidis.Commons.Events.ThreadPool", ThreadPool);
//# sourceMappingURL=ThreadPool.js.map