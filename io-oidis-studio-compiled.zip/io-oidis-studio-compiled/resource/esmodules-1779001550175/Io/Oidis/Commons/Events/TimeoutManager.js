/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "../Enums/Events/EventType.js";
import { ExceptionsManager } from "../Exceptions/ExceptionsManager.js";
import { BaseObject } from "../Primitives/BaseObject.js";
import { ObjectValidator } from "../Utils/ObjectValidator.js";
import { EventsManager } from "./EventsManager.js";
/**
 * TimeoutManager class provides handling of setTimeout methods without window timeout errors.
 */
export class TimeoutManager extends BaseObject {
    register;
    index;
    size;
    id;
    handle;
    /**
     * @param {number} [$time=1000] Specify time in milliseconds for which should be execution paused.
     * @returns {void}
     */
    static async Sleep($time = 1000) {
        return await new Promise(($resolve) => {
            setTimeout(() => {
                $resolve();
            }, $time);
        });
    }
    constructor() {
        super();
        this.register = [];
        this.index = -1;
        this.size = 0;
        this.id = this.getUID();
        this.handle = null;
    }
    /**
     * @returns {string} Returns manager's thread identification hash suitable for hook at manager's events.
     */
    getId() {
        return this.id;
    }
    /**
     * @returns {number} Returns count of the registered handlers.
     */
    Length() {
        return this.size;
    }
    /**
     * @param {ITimeoutHandler} $handler Register timeout handler.
     * @returns {void}
     */
    Add($handler) {
        this.register[this.size] = $handler;
        this.size++;
    }
    /**
     * @returns {string} Returns manager's thread identification hash suitable for hook at manager's events.
     */
    Execute() {
        EventsManager.getInstanceSingleton().FireEvent(this.getClassName(), EventType.ON_START);
        EventsManager.getInstanceSingleton().FireEvent(this.id, EventType.ON_START);
        this.getNextFunction();
        return this.id;
    }
    /**
     * Clear registered handlers and kill execution.
     * @returns {void}
     */
    Clear() {
        this.register = [];
        this.index = -1;
        this.size = 0;
        if (this.handle !== null) {
            clearTimeout(this.handle);
            this.handle = null;
        }
    }
    getNextFunction() {
        const events = EventsManager.getInstanceSingleton();
        this.handle = setTimeout(() => {
            try {
                const nextIndex = this.index++;
                if (nextIndex < this.size) {
                    this.getNextFunction();
                    if (ObjectValidator.IsSet(this.register[nextIndex])) {
                        this.register[nextIndex](nextIndex);
                    }
                }
                else {
                    this.handle = null;
                    this.Clear();
                    events.FireEvent(this.getClassName(), EventType.ON_COMPLETE);
                    events.FireEvent(this.getId(), EventType.ON_COMPLETE);
                }
            }
            catch (ex) {
                ExceptionsManager.HandleException(ex);
            }
        }, 0);
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.Events.TimeoutManager", TimeoutManager);
//# sourceMappingURL=TimeoutManager.js.map