/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ExceptionCode } from "../../Enums/ExceptionCode.js";
import { BaseArgs } from "../../Primitives/BaseArgs.js";
import { Convert } from "../../Utils/Convert.js";
import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { Property } from "../../Utils/Property.js";
import { StringUtils } from "../../Utils/StringUtils.js";
/**
 * Exception class should be used as structure object describing particular type of exception.
 */
export class Exception extends BaseArgs {
    owner;
    message;
    line;
    file;
    code;
    stack;
    /**
     * @param {string} [$message] Set exception message by constructor argument.
     */
    constructor($message) {
        super();
        this.owner = "";
        if (ObjectValidator.IsSet($message)) {
            this.message = $message;
        }
        else {
            this.message = "";
        }
        this.code = ExceptionCode.GENERAL;
        this.stack = "";
    }
    /**
     * @param {(string|IBaseObject)} [$value] Specify who has been exception throwing.
     * @returns {string} Returns exception owner.
     */
    Owner($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            // eslint-disable-next-line @typescript-eslint/no-unused-expressions
            ObjectValidator.IsObject($value) ? this.owner = $value.getClassName() : this.owner = $value;
        }
        return this.owner;
    }
    /**
     * @param {string} [$value] Specify exception's message.
     * @returns {string} Returns exception's message.
     */
    Message($value) {
        this.message = Property.String(this.message, $value);
        return this.message;
    }
    /**
     * @param {number} [$value] Specify line number where exception has been thrown.
     * @returns {number} Returns line number where exception has been thrown.
     */
    Line($value) {
        this.line = Property.PositiveInteger(this.line, $value);
        return this.line;
    }
    /**
     * @param {string} [$value] Specify file name where has been exception throwing.
     * @returns {string} Returns exception's file name.
     */
    File($value) {
        this.file = Property.String(this.file, $value);
        return this.file;
    }
    /**
     * @param {ExceptionCode} [$value] Specify exception code for better identification.
     * @returns {ExceptionCode} Returns exception's code.
     */
    Code($value) {
        if (ObjectValidator.IsSet($value)) {
            this.code = $value;
        }
        return this.code;
    }
    /**
     * @param {string} [$value] Specify additional information about exception.
     * @returns {string} Returns more info about exception.
     */
    Stack($value) {
        this.stack = Property.String(this.stack, $value);
        return this.stack;
    }
    /**
     * @param {string} [$prefix=""] Prefix for each output line.
     * @param {boolean} [$htmlTag=true] Use HTML tags in output.
     * @returns {string} Returns formatted exception details including message, file, line, and stack.
     */
    ToString($prefix = "", $htmlTag = true) {
        let output = this.message;
        if (!$htmlTag) {
            output = StringUtils.StripTags(StringUtils.Replace(output, StringUtils.NewLine(), StringUtils.NewLine(false)));
        }
        if (!ObjectValidator.IsEmptyOrNull(this.stack)) {
            this.stack = StringUtils.Replace(StringUtils.Replace(this.stack, "</", ":"), "\n", StringUtils.NewLine($htmlTag));
        }
        if ($htmlTag) {
            output += StringUtils.NewLine();
            if (!ObjectValidator.IsEmptyOrNull(this.file)) {
                output += $prefix + "file: " + this.file + StringUtils.NewLine();
            }
            if (!ObjectValidator.IsEmptyOrNull(this.line)) {
                output += $prefix + "at line: " + this.line + StringUtils.NewLine();
            }
            if (!ObjectValidator.IsEmptyOrNull(this.stack)) {
                output += Convert.ToHtmlContentBlock("", this.stack, "Stack trace");
            }
        }
        else {
            if (!ObjectValidator.IsEmptyOrNull(this.file)) {
                output += ", file: " + this.file;
            }
            if (!ObjectValidator.IsEmptyOrNull(this.line)) {
                output += ", at line: " + this.line;
            }
            if (!ObjectValidator.IsEmptyOrNull(this.stack)) {
                output += ", stack: " + StringUtils.NewLine(false) +
                    StringUtils.StripTags(StringUtils.Replace(this.stack, StringUtils.NewLine(), StringUtils.NewLine(false)));
            }
        }
        return $prefix + output;
    }
    /**
     * @returns {string} Returns string representation of this exception.
     */
    toString() {
        return this.ToString();
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.Exceptions.Type.Exception", Exception);
//# sourceMappingURL=Exception.js.map