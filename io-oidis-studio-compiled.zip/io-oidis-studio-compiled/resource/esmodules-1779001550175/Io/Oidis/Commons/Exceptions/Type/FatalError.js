/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ExceptionCode } from "../../Enums/ExceptionCode.js";
import { Exception } from "./Exception.js";
/**
 * FatalError class should be used in case of fatal script or resources error.
 */
export class FatalError extends Exception {
    constructor($message) {
        super($message);
        this.Code(ExceptionCode.FATAL_ERROR);
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.Exceptions.Type.FatalError", FatalError);
//# sourceMappingURL=FatalError.js.map