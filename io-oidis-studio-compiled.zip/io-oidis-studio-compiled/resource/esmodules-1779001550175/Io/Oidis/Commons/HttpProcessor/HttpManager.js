/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "../Enums/Events/EventType.js";
import { GeneralEventOwner } from "../Enums/Events/GeneralEventOwner.js";
import { HttpRequestConstants } from "../Enums/HttpRequestConstants.js";
import { BrowserErrorPage } from "../ErrorPages/BrowserErrorPage.js";
import { CookiesErrorPage } from "../ErrorPages/CookiesErrorPage.js";
import { ExceptionErrorPage } from "../ErrorPages/ExceptionErrorPage.js";
import { Http301MovedPage } from "../ErrorPages/Http301MovedPage.js";
import { Http403ForbiddenPage } from "../ErrorPages/Http403ForbiddenPage.js";
import { Http404NotFoundPage } from "../ErrorPages/Http404NotFoundPage.js";
import { AsyncRequestEventArgs } from "../Events/Args/AsyncRequestEventArgs.js";
import { EventsManager } from "../Events/EventsManager.js";
import { ExceptionsManager } from "../Exceptions/ExceptionsManager.js";
import { Loader } from "../Loader.js";
import { CacheManager } from "../PersistenceApi/CacheManager.js";
import { ArrayList } from "../Primitives/ArrayList.js";
import { BaseObject } from "../Primitives/BaseObject.js";
import { Convert } from "../Utils/Convert.js";
import { LogIt } from "../Utils/LogIt.js";
import { ObjectValidator } from "../Utils/ObjectValidator.js";
import { StringUtils } from "../Utils/StringUtils.js";
import { HttpResolversCollection } from "./HttpResolversCollection.js";
import { BaseHttpResolver } from "./Resolvers/BaseHttpResolver.js";
import { JsonUtils } from "../Utils/JsonUtils.js";
import { HttpRequestEventArgs } from "../Events/Args/HttpRequestEventArgs.js";
import { TraceBack } from "../Utils/TraceBack.js";
/* dev:start */
import { HttpRequestParserTest } from "../RuntimeTests/HttpRequestParserTest.js";
/* dev:end */
/**
 * HttpManager class manages registration of http request resolvers,
 * provides finding of appropriate resolver and parsing of request parameters.
 */
export class HttpManager extends BaseObject {
    processStartTime;
    request;
    resolversCollection;
    parameters;
    /**
     * @param {HttpRequestParser} $httpRequest Http request info which should be managed by manager instance.
     */
    constructor($httpRequest) {
        super();
        if (ObjectValidator.IsEmptyOrNull(this.processStartTime)) {
            this.processStartTime = new Date().getTime();
        }
        this.request = $httpRequest;
        this.resolversCollection = new HttpResolversCollection(this.request.getHostUrl());
        this.registerGeneralResolvers();
        this.parameters = new ArrayList();
    }
    /**
     * @returns {number} Returns time needed for process of the script.
     */
    getProcessTime() {
        return new Date().getTime() - this.processStartTime;
    }
    /**
     * Helper method providing creation of link in correct format. Recursive calls are supported.
     * Link, which does not point to localhost is automatically detected and passed without formatting.
     * Double slashes are replaced by single slashes.
     * Path directory separators are replaced by http request separators.
     * @param {string} $link Link which should be formatted. Link can be created as relative, if does not
     * starts with '/'. If link starts with '/', it will be appended to the base url.
     * @returns {string} Returns correctly formatted link.
     */
    CreateLink($link) {
        if (StringUtils.IsEmpty($link)) {
            $link = this.request.getUrl();
        }
        else {
            if (this.request.getRelativeRoot() !== "/" &&
                StringUtils.Contains("/" + $link, this.request.getRelativeRoot())) {
                const relativeRoot = this.request.getRelativeRoot();
                $link = StringUtils.Substring($link, StringUtils.IndexOf($link, relativeRoot, false) + StringUtils.Length(relativeRoot), StringUtils.Length($link));
            }
            if (!StringUtils.StartsWith($link, "mailto:")) {
                if (StringUtils.Contains($link, "http://", "https://", "ssh://", "www.")) {
                    if (StringUtils.Contains($link, this.request.getBaseUrl())) {
                        $link = StringUtils.Remove($link, this.request.getHostUrl());
                    }
                    else if (!StringUtils.StartsWith($link, "http://") &&
                        !StringUtils.StartsWith($link, "https://") &&
                        !StringUtils.StartsWith($link, "ssh://")) {
                        $link = "http://" + $link;
                    }
                }
                else if (StringUtils.StartsWith($link, "/")) {
                    $link = "/" + this.request.getRelativeRoot() + $link;
                }
                else {
                    $link = "/" + this.request.getRelativeDirectory() + "/" + $link;
                }
            }
            $link = StringUtils.Replace($link, "\\", "/");
            while (StringUtils.Contains($link, "//")) {
                $link = StringUtils.Replace($link, "//", "/");
            }
            $link = StringUtils.Replace($link, ":/", "://");
        }
        return $link;
    }
    /**
     * Reload current page content.
     * @returns {void}
     */
    Reload() {
        this.Refresh();
    }
    /**
     * Redirect page to destination link or just refresh the page.
     * @param {string} [$link] Destination link value. If not specified page will be refreshed.
     * @param {any} [$data] Data, which should be passed to the desired resolver.
     * @param {boolean} [$async] Specify, if request should be executed asynchronously.
     * @returns {void}
     */
    ReloadTo($link, $data, $async) {
        $link = this.CreateLink($link);
        if (ObjectValidator.IsSet($async) && $async) {
            if (ObjectValidator.IsEmptyOrNull($data)) {
                $data = new ArrayList();
            }
            EventsManager.getInstanceSingleton().FireEvent(GeneralEventOwner.WINDOW, EventType.ON_ASYNC_REQUEST, new AsyncRequestEventArgs($link, $data), false);
        }
        else {
            if ((!ObjectValidator.IsSet($data) || !ObjectValidator.IsBoolean($data)) &&
                StringUtils.Contains($link, this.request.getRelativeRoot())) {
                window.location.hash = $link;
                if (!ObjectValidator.IsEmptyOrNull($data)) {
                    window.location.hashData = $data;
                }
            }
            else if (ObjectValidator.IsBoolean($data) && $data) {
                window.open($link, "_blank");
            }
            else {
                window.location.href = $link;
            }
        }
    }
    async NavigateTo($link, $options, $timeout) {
        $link = this.CreateLink($link);
        if (!StringUtils.Contains($link, this.request.getRelativeRoot())) {
            throw new Error("NavigateTo is supported only by history API at same origin - use relative link instead. " +
                "Required link was: " + $link);
        }
        const options = {
            force: false,
            data: null,
            timeout: 5000
        };
        if (!ObjectValidator.IsEmptyOrNull($options)) {
            if (ObjectValidator.IsArray($options)) {
                options.data = $options;
            }
            else {
                JsonUtils.Extend(options, $options);
            }
        }
        if (!ObjectValidator.IsEmptyOrNull($timeout)) {
            options.timeout = $timeout;
        }
        if (![$link, "#" + $link].includes(window.location.hash)) {
            return await new Promise(($resolve, $reject) => {
                const timeout = EventsManager.getInstanceSingleton().FireAsynchronousMethod(() => {
                    $reject(new Error("NavigateTo timeout reached for: " + $link));
                }, options.timeout);
                EventsManager.getInstanceSingleton().setEvent(GeneralEventOwner.WINDOW, EventType.ON_HTTP_REQUEST, () => {
                    clearTimeout(timeout);
                    $resolve();
                });
                this.ReloadTo($link, options.data);
            });
        }
        else if (options.force) {
            EventsManager.getInstanceSingleton().FireEvent(GeneralEventOwner.WINDOW, EventType.ON_HTTP_REQUEST, new HttpRequestEventArgs(window.location.hash));
        }
        else {
            LogIt.Error("NavigateTo is called with same link (hash) as current one \"" + window.location.hash + "\" " +
                "from \"" + TraceBack.CaptureEntry(1).from + "\". " +
                "If it is intentional then add force option or handle controller's data fetch manually.");
        }
    }
    /**
     * Go to a correct destination link instead of the incorrect requested value.
     * @param {string} $link Correct destination link value.
     * @returns {void}
     */
    Return301Moved($link) {
        const data = new ArrayList();
        data.Add(this.CreateLink($link), HttpRequestConstants.HTTP301_LINK);
        this.ReloadTo("/ServerError/Http/Moved", data, true);
    }
    /**
     * Inform about access denied and stop the thread execution.
     * @returns {void}
     */
    Return403Forbidden() {
        this.ReloadTo("/ServerError/Http/Forbidden", null, true);
    }
    /**
     * Inform file has not been found and stop the thread execution.
     * @param {string} [$requiredFilePath] Specify a file path, which has been required,
     * so it can be reported by the error page handler.
     * @returns {void}
     */
    Return404NotFound($requiredFilePath) {
        let data = null;
        if (!ObjectValidator.IsEmptyOrNull($requiredFilePath)) {
            data = new ArrayList();
            data.Add($requiredFilePath, HttpRequestConstants.HTTP404_FILE_PATH);
        }
        this.ReloadTo("/ServerError/Http/NotFound", data, true);
    }
    /**
     * @returns {HttpRequestParser} Returns parsed information about current request.
     */
    getRequest() {
        return this.request;
    }
    /**
     * Refresh current page content.
     * @returns {void}
     */
    Refresh() {
        try {
            window.location.reload();
        }
        catch (ex) {
            ExceptionsManager.Throw(this.getClassName(), ex);
        }
    }
    /**
     * Go back in the browser history and refresh current page content.
     * @returns {void}
     */
    ReloadBack() {
        try {
            window.history.back();
        }
        catch (ex) {
            ExceptionsManager.Throw(this.getClassName(), ex);
        }
    }
    /**
     * Refresh information about current request and restart process time counter without page reload.
     * @returns {void}
     */
    RefreshWithoutReload() {
        this.processStartTime = new Date().getTime();
        this.request = Loader.getInstance().getHttpResolver().CreateRequest();
    }
    /**
     * @param {Callback} $callback Returns true, if connection is alive, otherwise false.
     * @returns {void}
     */
    IsOnline($callback) {
        if (this.getRequest().IsOnServer()) {
            $callback(true);
        }
        else if (window.navigator.onLine) {
            let testData = document.createElement("iframe");
            let iframeValidation = true;
            let timeoutId; // eslint-disable-line prefer-const
            const cleanup = () => {
                if (!ObjectValidator.IsEmptyOrNull(timeoutId)) {
                    clearTimeout(timeoutId);
                }
                if (iframeValidation && !ObjectValidator.IsEmptyOrNull(testData.parentNode)) {
                    testData.parentNode.removeChild(testData);
                }
            };
            if (ObjectValidator.IsEmptyOrNull(testData)) {
                testData = document.createElement("img");
                testData.crossOrigin = "Anonymous";
                iframeValidation = false;
            }
            else {
                testData.width = 0;
                testData.height = 0;
                document.body.appendChild(testData);
            }
            testData.onload = () => {
                cleanup();
                $callback(true);
            };
            testData.onerror = () => {
                cleanup();
                if (iframeValidation) {
                    $callback(false);
                }
                else {
                    LogIt.Debug("IsOnline validation based on image failure. " +
                        "Fallback to navigator.onLine state reached maybe do to CORS policy.");
                    $callback(true);
                }
            };
            testData.src = "https://hub.oidis.io/ping." + (iframeValidation ? "txt" : "png") +
                "?dummy=" + (new Date().getTime());
            timeoutId = setTimeout(() => {
                cleanup();
                LogIt.Debug("IsOnline validation failure. Timeout reached.");
                $callback(false);
            }, 2500);
        }
        else {
            $callback(false);
        }
    }
    /**
     * @param {string} $httpRequest Http patter subscribed to resolver. Pattern can contains wilcards '*' as placeholder
     * for characters and fixed http parts. Pattern can contains double start '**' as placeholder for floating http path parts.
     * Pattern can contains '{paramName}' as placeholder for fixed http path parts, which will be served as resolver variables.
     * Pattern is resolved as absolute path, if starts with '/' otherwise is resolved as relative path.
     * If pattern has been registered already it will not be overridden (use OverrideResolver method for force resolver registration).
     * @param {any} $resolver Resolver callback subscribed to http pattern.
     * @param {boolean} [$ignoreCase = true] If true, resolver http pattern and http request without case insensitive,
     * otherwise as case sensitive.
     * @returns {void}
     */
    RegisterResolver($httpRequest, $resolver, $ignoreCase = true) {
        if (!ObjectValidator.IsEmptyOrNull($resolver)) {
            const subRequests = this.splitRequest($httpRequest);
            const subRequestsCount = subRequests.length;
            let collection = this.resolversCollection;
            let requestIndex;
            for (requestIndex = 1; requestIndex < subRequestsCount; requestIndex++) {
                const formatted = this.formatSubrequest(subRequests[requestIndex]);
                const subRequest = formatted[0];
                const parameterName = formatted[1];
                const collectionParent = new HttpResolversCollection(subRequest);
                if (requestIndex === subRequestsCount - 1) {
                    collectionParent.ResolverClassName($resolver);
                    collectionParent.IgnoreCase($ignoreCase);
                }
                collection.AddChild(collectionParent);
                const flexibleRequest = subRequest === "**";
                collection.LevelsCount(subRequestsCount - requestIndex, flexibleRequest);
                collection = collection.getChild(subRequest);
                collection.ParameterName(parameterName);
                if (flexibleRequest) {
                    let parent = this.resolversCollection;
                    parent.LevelsCount(parent.LevelsCount(), true);
                    let parentIndex;
                    for (parentIndex = 1; parentIndex < requestIndex; parentIndex++) {
                        const parentKey = subRequests[parentIndex];
                        parent = parent.getChild(parentKey);
                        parent.LevelsCount(parent.LevelsCount(), true);
                    }
                }
            }
        }
    }
    /**
     * @param {string} $httpRequest Http patter subscribed to resolver. Pattern can contains wilcards '*' as placeholder
     * for characters and fixed http parts. Pattern can contains double start '**' as placeholder for floating http path parts.
     * Pattern can contains '{paramName}' as placeholder for fixed http path parts, which will be served as resolver variables.
     * Pattern is resolved as absolute path, if starts with '/' otherwise is resolved as relative path.
     * If pattern has not been registered already it will not be overridden (use RegisterResolver method for resolver registration).
     * @param {any} $resolver Resolver callback subscribed to http pattern.
     * @param {boolean} [$ignoreCase = true] If true, resolver http pattern and http request without case insensitive,
     * otherwise as case sensitive.
     * @returns {void}
     */
    OverrideResolver($httpRequest, $resolver, $ignoreCase = true) {
        if (!ObjectValidator.IsEmptyOrNull($resolver)) {
            const subRequests = this.splitRequest($httpRequest);
            const subRequestsCount = subRequests.length;
            let collection = this.resolversCollection;
            let requestIndex;
            for (requestIndex = 1; requestIndex < subRequestsCount; requestIndex++) {
                const formatted = this.formatSubrequest(subRequests[requestIndex]);
                const subRequest = formatted[0];
                const parameterName = formatted[1];
                if (collection.Contains(subRequest)) {
                    collection = collection.getChild(subRequest);
                }
                else {
                    break;
                }
                if (requestIndex === subRequestsCount - 1) {
                    collection.ResolverClassName($resolver);
                    collection.IgnoreCase($ignoreCase);
                }
                collection.ParameterName(parameterName);
            }
        }
    }
    /**
     * @param {string} $pattern Specify http pattern, which should be validated.
     * @returns {boolean} Returns true, if http pattern has been already used for registration of Resolver callback, otherwise false.
     */
    HttpPatternExists($pattern) {
        const subRequests = this.splitRequest($pattern);
        const subRequestsCount = subRequests.length;
        let collection = this.resolversCollection;
        let requestIndex;
        for (requestIndex = 1; requestIndex < subRequestsCount; requestIndex++) {
            const formatted = this.formatSubrequest(subRequests[requestIndex]);
            if (collection.Contains(formatted[0])) {
                collection = collection.getChild(formatted[0]);
            }
            else {
                return false;
            }
        }
        return true;
    }
    /**
     * @param {string} $requireLink Require link which should be matched with registered resolvers.
     * @returns {any} Returns Resolver callback in case of that require link is in match with one of registered resolver,
     * otherwise returns null.
     */
    getResolverClassName($requireLink) {
        $requireLink = this.CreateLink($requireLink);
        this.parameters.Clear();
        let className = null;
        const subRequires = StringUtils.Split($requireLink, "/");
        const getNextCollection = ($subRequireIndex, $collectionIndex, $collections, $isFlexible) => {
            if ($collectionIndex < $collections.length && $subRequireIndex < subRequires.length) {
                const collection = $collections[$collectionIndex];
                const pattern = collection.Pattern();
                let nextPattern = "";
                if ($collectionIndex + 1 < $collections.length) {
                    nextPattern = $collections[$collectionIndex + 1].Pattern();
                }
                const subRequire = subRequires[$subRequireIndex];
                if (pattern === subRequire || StringUtils.PatternMatched(pattern, subRequire)) {
                    let assign = true;
                    if (pattern === "*" &&
                        ObjectValidator.IsEmptyOrNull(collection.ParameterName()) &&
                        !ObjectValidator.IsEmptyOrNull(className)) {
                        assign = false;
                    }
                    if (pattern === "**") {
                        assign = false;
                        $isFlexible = true;
                    }
                    if (assign) {
                        if (!ObjectValidator.IsEmptyOrNull(collection.ParameterName())) {
                            this.parameters.Add(subRequire, collection.ParameterName());
                        }
                        if (!ObjectValidator.IsEmptyOrNull(collection.ResolverClassName()) &&
                            $subRequireIndex === subRequires.length - 1) {
                            className = collection.ResolverClassName();
                        }
                    }
                    if (!collection.getChildrenList().IsEmpty()) {
                        collection.OrderChildrenCollection();
                        getNextCollection($subRequireIndex + 1, 0, collection.getChildrenList().getAll(), $isFlexible);
                    }
                }
                if (ObjectValidator.IsEmptyOrNull(className) ||
                    (pattern !== subRequire && nextPattern !== "*" && StringUtils.Contains(nextPattern, "*"))) {
                    getNextCollection($subRequireIndex, $collectionIndex + 1, $collections, $isFlexible);
                }
            }
            else if ($isFlexible && $subRequireIndex + 1 < subRequires.length) {
                getNextCollection($subRequireIndex + 1, 0, $collections, $isFlexible);
            }
        };
        try {
            this.resolversCollection.OrderChildrenCollection();
            getNextCollection(StringUtils.StartsWith($requireLink, "/") ? 1 : 0, 0, this.resolversCollection.getChildrenList().getAll(), false);
        }
        catch (ex) {
            LogIt.Error(this.getClassName(), ex);
            className = null;
            this.parameters.Clear();
        }
        return className;
    }
    /**
     * @returns {ArrayList<string>} Returns ArrayList of parsed parameters in case of, that current resolver callback
     * has been found and resolver pattern contains parameters names, otherwise returns empty string.
     */
    getResolverParameters() {
        return this.parameters;
    }
    /**
     * @returns {HttpResolversCollection} Returns all registered resolver to the current manager.
     */
    getResolversCollection() {
        return this.resolversCollection;
    }
    /**
     * @returns {string} Returns string representation of request and resolvers collection.
     */
    ToString() {
        return Convert.ObjectToString(this.request) + StringUtils.NewLine() +
            Convert.ObjectToString(this.getResolversCollection());
    }
    /**
     * @returns {string} Returns string representation of this manager.
     */
    toString() {
        return this.ToString();
    }
    registerGeneralResolvers() {
        this.RegisterResolver("/ServerError/Cookies", CookiesErrorPage);
        this.RegisterResolver("/ServerError/Browser", BrowserErrorPage);
        this.RegisterResolver("/ServerError/Exception/{" + HttpRequestConstants.EXCEPTION_TYPE + "}", ExceptionErrorPage);
        this.RegisterResolver("/ServerError/Http/Moved", Http301MovedPage);
        this.RegisterResolver("/ServerError/Http/Forbidden", Http403ForbiddenPage);
        this.RegisterResolver("/ServerError/Http/NotFound", Http404NotFoundPage);
        this.RegisterResolver("/ServerError/Http/DefaultPage", BaseHttpResolver);
        this.RegisterResolver("/about/Cache", CacheManager);
        /* dev:start */
        this.RegisterResolver("/about/Env", HttpRequestParserTest);
        /* dev:end */
    }
    splitRequest($httpRequest) {
        while (StringUtils.Contains($httpRequest, "**/**")) {
            $httpRequest = StringUtils.Replace($httpRequest, "**/**", "**");
        }
        $httpRequest = this.CreateLink($httpRequest);
        return StringUtils.Split($httpRequest, "/");
    }
    formatSubrequest($subRequest) {
        if ($subRequest !== "**" && $subRequest !== "*" && StringUtils.Contains($subRequest, "*")) {
            while (StringUtils.Contains($subRequest, "**")) {
                $subRequest = StringUtils.Replace($subRequest, "**", "*");
            }
        }
        let parameterName = null;
        if (StringUtils.Contains($subRequest, "{", "}")) {
            parameterName = StringUtils.Substring($subRequest, StringUtils.IndexOf($subRequest, "{") + 1, StringUtils.IndexOf($subRequest, "}"));
            $subRequest = "*";
        }
        return [$subRequest, parameterName];
    }
}
// generated-code-start
export const INavigateOptions = globalThis.RegisterInterface(["force", "data", "timeout"]);
globalThis.RegisterClass("Io.Oidis.Commons.HttpProcessor.HttpManager", HttpManager);
globalThis.RegisterClass("Io.Oidis.Commons.HttpProcessor.INavigateOptions", INavigateOptions);
//# sourceMappingURL=HttpManager.js.map