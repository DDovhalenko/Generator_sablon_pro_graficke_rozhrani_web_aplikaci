/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { AsyncRequestEventArgs } from "../Events/Args/AsyncRequestEventArgs.js";
import { HttpRequestEventArgs } from "../Events/Args/HttpRequestEventArgs.js";
import { EventsManager } from "../Events/EventsManager.js";
import { ExceptionsManager } from "../Exceptions/ExceptionsManager.js";
import { Loader } from "../Loader.js";
import { BaseObject } from "../Primitives/BaseObject.js";
import { ResolverScope, ResolverType } from "../Primitives/Decorators.js";
import { ObjectValidator } from "../Utils/ObjectValidator.js";
import { Reflection } from "../Utils/Reflection.js";
import { StringUtils } from "../Utils/StringUtils.js";
import { HttpManager } from "./HttpManager.js";
import { HttpRequestParser } from "./HttpRequestParser.js";
import { BaseHttpResolver } from "./Resolvers/BaseHttpResolver.js";
/**
 * HttpResolver class provides handling of current http request and hash on change events.
 */
export class HttpResolver extends BaseObject {
    static baseUrl;
    manager;
    events;
    resolvers;
    /**
     * @param {string} [$baseUrl] Set baseUrl for http resolver
     */
    constructor($baseUrl) {
        super();
        if (!ObjectValidator.IsEmptyOrNull($baseUrl) && $baseUrl !== "#") {
            if (Loader.getInstance().getEnvironmentArgs().HtmlOutputAllowed() && ObjectValidator.IsEmptyOrNull(window.location.hash)) {
                if (!StringUtils.StartsWith($baseUrl, "/")) {
                    $baseUrl = "/" + $baseUrl;
                }
                if (!StringUtils.EndsWith($baseUrl, "/")) {
                    $baseUrl += "/";
                }
                window.location.hash = $baseUrl;
            }
        }
        const httpManger = this.getHttpManagerClass();
        this.manager = new httpManger(this.CreateRequest($baseUrl));
        const eventsManger = this.getEventsManagerClass();
        this.events = new eventsManger();
        this.resolvers = {};
    }
    /**
     * @param {string} [$baseUrl] Specify base url for new instance of request parser.
     * @returns {HttpRequestParser} Returns new instance of request parser based on HttpResolver definition.
     */
    CreateRequest($baseUrl) {
        if (!ObjectValidator.IsEmptyOrNull($baseUrl) && HttpResolver.baseUrl !== $baseUrl) {
            HttpResolver.baseUrl = $baseUrl;
        }
        const parserClass = this.getRequestParserClass();
        return new parserClass(HttpResolver.baseUrl);
    }
    /**
     * @returns {EventsManager} Returns EventsManager instance used for management of request events.
     */
    getEvents() {
        return this.events;
    }
    /**
     * @returns {HttpManager} Returns HttpManager instance used for management of resolved requests.
     */
    getManager() {
        return this.manager;
    }
    /**
     * Find out appropriate request resolver class based on current http request and execute resolver Process method.
     * @param {HttpRequestEventArgs|AsyncRequestEventArgs} [$eventArgs] Specify request args, which should be resolved.
     * @returns {void}
     */
    ResolveRequest($eventArgs) {
        try {
            if (ObjectValidator.IsEmptyOrNull($eventArgs) ||
                !Reflection.getInstance().IsMemberOf($eventArgs, HttpRequestEventArgs)) {
                $eventArgs = new HttpRequestEventArgs(this.manager.getRequest().getScriptPath());
            }
            const isAsync = Reflection.getInstance().IsMemberOf($eventArgs, AsyncRequestEventArgs);
            if (!isAsync) {
                window.location.hash = $eventArgs.Url();
                this.manager.RefreshWithoutReload();
            }
            let resolver;
            let resolverName = this.manager.getResolverClassName($eventArgs.Url());
            if (ObjectValidator.IsEmptyOrNull(resolverName)) {
                resolverName = this.manager.getResolverClassName("/ServerError/Http/DefaultPage");
                if (ObjectValidator.IsEmptyOrNull(resolverName)) {
                    resolverName = BaseHttpResolver;
                }
            }
            else {
                const getData = this.manager.getResolverParameters();
                getData.Copy(this.manager.getRequest().getUrlArgs());
                $eventArgs.GET(getData);
            }
            if (!ObjectValidator.IsEmptyOrNull(window.location.hashData)) {
                $eventArgs.POST(window.location.hashData);
                delete window.location.hashData;
            }
            resolver = resolverName.getInstance(); // eslint-disable-line prefer-const
            let canResolve = true;
            if (!ObjectValidator.IsEmptyOrNull(globalThis.Io.Oidis.Gui)) {
                canResolve = !resolver.IsMemberOf("Io.Oidis.Gui.HttpProcessor.Resolvers.AsyncBaseHttpController");
            }
            if (!isAsync && canResolve) {
                let lastTimeoutId = setTimeout(
                /* istanbul ignore next : callback placeholder for ability to get lastTimeoutId */
                () => {
                    // force invoke creation of last timeout id
                }, 0);
                do {
                    clearTimeout(lastTimeoutId);
                } while (lastTimeoutId--);
                let lastIntervalId = setInterval(
                /* istanbul ignore next : callback placeholder for ability to get lastIntervalId */
                () => {
                    // force invoke creation of last interval id
                }, 0);
                do {
                    clearInterval(lastIntervalId);
                } while (lastIntervalId--);
            }
            resolver.RequestArgs($eventArgs);
            resolver.Process();
        }
        catch (ex) {
            ExceptionsManager.HandleException(ex);
        }
    }
    /**
     * @returns {string} Returns string representation of the resolver.
     */
    toString() {
        return this.ToString();
    }
    /**
     * @returns {Promise<void>}
     */
    async RegisterResolvers() {
        const context = {
            isBrowser: globalThis.isBrowser,
            isProd: Loader.getInstance().getEnvironmentArgs().IsProductionMode()
        };
        await this.getStartupResolvers(context);
        await this.processDecoratedResolvers(context);
        Reflection.Refresh();
        let httpPattern;
        for (httpPattern in this.resolvers) {
            /* istanbul ignore else : bulletproof condition */
            if (ObjectValidator.IsSet(this.resolvers[httpPattern])) {
                const resolver = this.resolvers[httpPattern];
                if (!ObjectValidator.IsEmptyOrNull(resolver) && ObjectValidator.IsSet(resolver.ClassName)) {
                    if (this.manager.HttpPatternExists(httpPattern)) {
                        this.manager.OverrideResolver(httpPattern, resolver);
                    }
                    else {
                        this.manager.RegisterResolver(httpPattern, resolver);
                    }
                }
            }
        }
    }
    getEventsManagerClass() {
        return EventsManager;
    }
    getHttpManagerClass() {
        return HttpManager;
    }
    getRequestParserClass() {
        return HttpRequestParser;
    }
    async getStartupResolvers($context) {
        /// TODO: how to add to context something like bootstrap, react, GQL etc.? -> by solution?
        return {};
    }
    async registerResolver($from, ...$to) {
        return await this.addResolver($from, $to);
    }
    async overrideResolver($from, ...$to) {
        return await this.addResolver($from, $to, true);
    }
    async addResolver($from, $to, $force = false) {
        let resolverClass = null;
        for await (const path of $to) {
            if (!this.resolvers.hasOwnProperty(path) || $force) {
                if (resolverClass === null) {
                    resolverClass = await $from();
                    Reflection.Refresh();
                }
                this.resolvers[path] = resolverClass;
            }
        }
        return this.resolvers;
    }
    async processDecoratedResolvers($context) {
        if (!globalThis.hasOwnProperty("oidisResolvers")) {
            globalThis.oidisResolvers = [];
        }
        const reflection = Reflection.getInstance();
        for (const resolver of globalThis.oidisResolvers) {
            if (resolver.options.type === ResolverType.UNIVERSAL) {
                const memberOf = reflection.getClassHierarchyOf(resolver.instance);
                if (memberOf.includes("Io.Oidis.Services.HttpProcessor.Resolvers.AsyncBasePageController") ||
                    memberOf.includes("Io.Oidis.Gui.Bootstrap.Primitives.BasePanelController")) {
                    resolver.options.type = ResolverType.FRONTEND_ONLY;
                }
                else if (memberOf.includes("Io.Oidis.Localhost.HttpProcessor.Resolvers.BaseHttpResolver")) {
                    resolver.options.type = ResolverType.BACKEND_ONLY;
                }
            }
        }
        const loaderNamespaces = Loader.getInstance().getNamespaceHierarchy();
        loaderNamespaces.pop();
        let sorted = [];
        const sortResolvers = ($scopes) => {
            for (const loaderNamespace of loaderNamespaces) {
                for (const resolver of globalThis.oidisResolvers) {
                    if (StringUtils.StartsWith(resolver.ClassName(), loaderNamespace) && $scopes.includes(resolver.options.scope)) {
                        if (resolver.options.type === ResolverType.UNIVERSAL ||
                            ($context.isBrowser && resolver.options.type === ResolverType.FRONTEND_ONLY) ||
                            (!$context.isBrowser && resolver.options.type === ResolverType.BACKEND_ONLY)) {
                            if (!$context.isBrowser && resolver.options.type === ResolverType.BACKEND_ONLY &&
                                !resolver.options.forceRegister && resolver.options.priority === 1) {
                                resolver.options.priority = 2;
                            }
                            sorted.push(resolver);
                        }
                    }
                }
            }
        };
        if (!$context.isProd) {
            sortResolvers([ResolverScope.DEV]);
        }
        sortResolvers([ResolverScope.ALL_PROFILES, ResolverScope.PROD]);
        sorted = sorted.sort(($a, $b) => {
            return ($a.options.priority > $b.options.priority) ? -1 : ($a.options.priority < $b.options.priority) ? 1 : 0;
        });
        for await (const resolver of sorted) {
            const instanceClass = resolver.instance;
            const links = [];
            const addToList = (...$links) => {
                $links.forEach(($link) => {
                    if (!StringUtils.StartsWith($link, "/")) {
                        $link = "/" + $link;
                    }
                    $link = StringUtils.Replace($link, "/#/", "/");
                    if (!ObjectValidator.IsEmptyOrNull($link) && !links.includes($link)) {
                        links.push($link);
                    }
                });
            };
            if ((!$context.isBrowser && resolver.options.type !== ResolverType.FRONTEND_ONLY) ||
                ($context.isBrowser && resolver.options.type !== ResolverType.BACKEND_ONLY)) {
                const instance = new instanceClass();
                if (ObjectValidator.IsEmptyOrNull(globalThis.Io.Oidis.Gui) ||
                    (!ObjectValidator.IsEmptyOrNull(globalThis.Io.Oidis.Gui) &&
                        !reflection.IsMemberOf(instance, "Io.Oidis.Gui.Bootstrap.Primitives.BasePanelController"))) {
                    addToList(instanceClass.getLink());
                    addToList(...instanceClass.getAltLinks());
                    if (!ObjectValidator.IsEmptyOrNull(globalThis.Io.Oidis.Hub) &&
                        !ObjectValidator.IsEmptyOrNull(globalThis.Io.Oidis.Hub.Gui) &&
                        reflection.IsMemberOf(instance, "Io.Oidis.Hub.Gui.Primitives.BasePageLayoutController")) {
                        instance.InstanceOwner().getTabsList().forEach(($tab) => {
                            if (!ObjectValidator.IsEmptyOrNull($tab.controller) && ObjectValidator.IsSet($tab.controller.getLink)) {
                                addToList($tab.controller.getLink());
                                addToList(...$tab.controller.getAltLinks());
                            }
                        });
                    }
                }
                if (!ObjectValidator.IsEmptyOrNull(links)) {
                    if (!resolver.options.forceRegister) {
                        await this.registerResolver(async () => instanceClass, ...links);
                    }
                    else {
                        await this.overrideResolver(async () => instanceClass, ...links);
                    }
                }
            }
        }
    }
}
// generated-code-start
export const IHttpResolverContext = globalThis.RegisterInterface(["isBrowser", "isProd"]);
globalThis.RegisterClass("Io.Oidis.Commons.HttpProcessor.HttpResolver", HttpResolver);
globalThis.RegisterClass("Io.Oidis.Commons.HttpProcessor.IHttpResolverContext", IHttpResolverContext);
//# sourceMappingURL=HttpResolver.js.map