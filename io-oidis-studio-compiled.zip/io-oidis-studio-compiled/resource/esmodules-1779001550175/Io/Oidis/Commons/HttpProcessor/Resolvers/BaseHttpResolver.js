/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BrowserType } from "../../Enums/BrowserType.js";
import { EventType } from "../../Enums/Events/EventType.js";
import { GeneralEventOwner } from "../../Enums/Events/GeneralEventOwner.js";
import { HttpRequestEventArgs } from "../../Events/Args/HttpRequestEventArgs.js";
import { ExceptionsManager } from "../../Exceptions/ExceptionsManager.js";
import { Exit } from "../../Exceptions/Type/Exit.js";
import { Loader } from "../../Loader.js";
import { BaseObject } from "../../Primitives/BaseObject.js";
import { Echo } from "../../Utils/Echo.js";
import { LogIt } from "../../Utils/LogIt.js";
import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { HttpRequestParser } from "../HttpRequestParser.js";
/**
 * BaseHttpResolver class is abstract class providing basic http request resolving and
 * each http resolver should be extending this class for security reason.
 */
export class BaseHttpResolver extends BaseObject {
    events;
    environment;
    httpManager;
    request;
    requestArgs;
    nonce;
    /**
     * @returns {BaseHttpResolver} Returns new instance of the resolver.
     */
    static getInstance() {
        return new this();
    }
    constructor() {
        super();
        this.environment = Loader.getInstance().getEnvironmentArgs();
        this.httpManager = Loader.getInstance().getHttpManager();
        this.request = this.httpManager.getRequest();
        this.events = Loader.getInstance().getHttpResolver().getEvents();
        this.requestArgs = new HttpRequestEventArgs(this.httpManager.getRequest().getScriptPath());
    }
    /**
     * @param {HttpRequestEventArgs} $value Specify request arguments, which should be processed by resolver instance.
     * @returns {HttpRequestEventArgs} Returns current request arguments
     */
    RequestArgs($value) {
        if (ObjectValidator.IsSet($value)) {
            this.requestArgs = $value;
            if ($value.Owner().IsMemberOf(HttpRequestParser)) {
                this.request = $value.Owner();
                this.requestArgs.GET().Copy(this.request.getUrlArgs());
            }
            if (this.requestArgs.POST().KeyExists("Protocol")) {
                const protocol = this.requestArgs.POST().getItem("Protocol");
                if (!ObjectValidator.IsEmptyOrNull(protocol.nonce)) {
                    this.nonce = protocol.nonce;
                }
            }
            this.argsHandler(this.requestArgs.GET(), this.requestArgs.POST());
        }
        return this.requestArgs;
    }
    /**
     * Execute resolver implementation.
     * @returns {void}
     */
    Process() {
        if (!this.browserValidator()) {
            LogIt.Error("Unsupported browser. User Agent: " + this.request.getUserAgent());
            this.httpManager.ReloadTo("/ServerError/Browser", null, true);
            if (this.getEnvironmentArgs().HtmlOutputAllowed()) {
                this.stop();
            }
        }
        else {
            const resolve = () => {
                this.events.FireEvent(GeneralEventOwner.BODY, EventType.ON_LOAD);
            };
            const reject = ($ex) => {
                ExceptionsManager.HandleException($ex);
            };
            void this.accessValidator().then(($status) => {
                if ($status) {
                    Echo.ClearAll();
                    try {
                        const promiseInterface = this.resolver();
                        if (!ObjectValidator.IsEmptyOrNull(promiseInterface)) {
                            if (promiseInterface instanceof Promise || promiseInterface.constructor.name === "Promise") {
                                promiseInterface.then(resolve).catch(reject);
                            }
                            else {
                                reject(new Error("Standard Promise interface is required for asynchronous http resolver."));
                            }
                        }
                        else {
                            resolve();
                        }
                    }
                    catch (ex) {
                        reject(ex);
                    }
                }
                else {
                    this.httpManager.Return403Forbidden();
                    if (this.getEnvironmentArgs().HtmlOutputAllowed()) {
                        this.stop();
                    }
                }
            }).catch(reject);
        }
    }
    /**
     * @returns {string} Returns string representation of this resolver.
     */
    toString() {
        return this.ToString();
    }
    /**
     * @returns {boolean} Returns true, if browser is valid for execution the resolver, otherwise false.
     */
    browserValidator() {
        return !(this.request.getBrowserType() === BrowserType.UNKNOWN ||
            (this.request.getBrowserType() === BrowserType.INTERNET_EXPLORER && this.request.getBrowserVersion() < 5));
    }
    async accessValidator() {
        return true;
    }
    argsHandler($GET, $POST) {
        // handle request args
    }
    resolver() {
        Echo.Println("This is abstract BaseHttpResolver, which has been executed at: " + this.request.getUrl());
    }
    stop() {
        ExceptionsManager.Throw(this.getClassName(), new Exit());
    }
    exit() {
        this.stop();
    }
    getRequest() {
        return this.request;
    }
    getHttpManager() {
        return this.httpManager;
    }
    getEventsManager() {
        return this.events;
    }
    getEnvironmentArgs() {
        return this.environment;
    }
    createLink($link) {
        return this.httpManager.CreateLink($link);
    }
    registerResolver($httpRequest, $resolver, $ignoreCase = true) {
        this.httpManager.RegisterResolver($httpRequest, $resolver, $ignoreCase);
    }
    overrideResolver($httpRequest, $resolver, $ignoreCase = true) {
        this.httpManager.OverrideResolver($httpRequest, $resolver, $ignoreCase);
    }
    getNonce() {
        return this.nonce;
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.HttpProcessor.Resolvers.BaseHttpResolver", BaseHttpResolver);
//# sourceMappingURL=BaseHttpResolver.js.map