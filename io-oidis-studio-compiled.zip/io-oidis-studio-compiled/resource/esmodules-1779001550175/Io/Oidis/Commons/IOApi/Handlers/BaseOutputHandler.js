import { BaseObject } from "../../Primitives/BaseObject.js";
import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { Property } from "../../Utils/Property.js";
/**
 * BaseOutputHandler class provides abstract API for handling output to custom resources types.
 */
export class BaseOutputHandler extends BaseObject {
    static handlerIterator = 0;
    onPrintHandler;
    name;
    handler;
    encoding;
    newLineType;
    /**
     * @param {string} [$handlerName] Set handler name for future identification and internal use.
     */
    constructor($handlerName) {
        super();
        BaseOutputHandler.handlerIterator++;
        if (ObjectValidator.IsSet($handlerName)) {
            this.name = $handlerName;
        }
        else {
            this.name = "OutputHandler_" + BaseOutputHandler.handlerIterator;
        }
        this.onPrintHandler = ($message) => void {};
    }
    /**
     * Provides initialization, which is specific for each type of output handler.
     * @returns {void}
     */
    Init() {
        this.setEncoding("UTF-8");
    }
    /**
     * @returns {string} Returns handler's name used as unique identifier for IO factory.
     */
    Name() {
        return this.name;
    }
    /**
     * @returns {string} Returns string representation of encoding specific for each type of handler.
     */
    Encoding() {
        return this.encoding;
    }
    /**
     * @returns {NewLineType} Returns type of line ending specific for each type of handler.
     */
    NewLineType() {
        return this.newLineType;
    }
    /**
     * @param {string} $message Value which should be printed to resource handled by handler.
     * @returns {void}
     */
    Print($message) {
        this.onPrintHandler($message);
        throw new Error("'" + this.getClassName() + "' is abstract class and does not provides fully implemented Print method.");
    }
    /**
     * @param {Function} $handler Callback, which should be called in time on message print.
     * @returns {void}
     */
    setOnPrint($handler) {
        if (ObjectValidator.IsFunction($handler)) {
            this.onPrintHandler = $handler;
        }
    }
    /**
     * Clean up resource handled by handler.
     * @returns {void}
     */
    Clear() {
        // provide implementation, which can clear handled resource
    }
    toString() {
        return this.ToString();
    }
    setHandler($handler) {
        this.handler = $handler;
    }
    getHandler() {
        if (ObjectValidator.IsEmptyOrNull(this.handler)) {
            this.Init();
        }
        return this.handler;
    }
    setEncoding($value) {
        this.encoding = Property.String($value);
    }
    setNewLineType($value) {
        this.newLineType = $value;
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.IOApi.Handlers.BaseOutputHandler", BaseOutputHandler);
//# sourceMappingURL=BaseOutputHandler.js.map