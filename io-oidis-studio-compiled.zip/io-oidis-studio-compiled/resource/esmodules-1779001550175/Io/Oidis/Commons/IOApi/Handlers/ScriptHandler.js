/*! ******************************************************************************************************** *
 *
 * Copyright 2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IOHandlerType } from "../../Enums/IOHandlerType.js";
import { BaseObject } from "../../Primitives/BaseObject.js";
import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { Property } from "../../Utils/Property.js";
import { StringUtils } from "../../Utils/StringUtils.js";
import { IOHandlerFactory } from "../IOHandlerFactory.js";
/**
 * ScriptHandler class provides basic mechanism for reading of external data over script tag.
 */
export class ScriptHandler extends BaseObject {
    static Data;
    successHandler;
    errorHandler;
    mimeType;
    data;
    path;
    timeout;
    timeoutId;
    constructor() {
        super();
        this.path = null;
        this.mimeType = "text/javascript";
        this.timeout = 100;
        this.successHandler = () => {
            // default success handler
        };
        this.errorHandler = ($error) => {
            try {
                const console = IOHandlerFactory.getHandler(IOHandlerType.CONSOLE);
                if (!ObjectValidator.IsEmptyOrNull($error) && !ObjectValidator.IsEmptyOrNull($error.message)) {
                    console.Print($error.message);
                }
                else if (!ObjectValidator.IsEmptyOrNull(this.path)) {
                    console.Print("Failed to load resource at: " + this.path);
                }
                else {
                    console.Print("Failed to load resource");
                }
            }
            catch (ex) {
                console.log(ex.stack); // eslint-disable-line no-console
            }
        };
    }
    /**
     * @param {number} [$value] Specify maximal time in milliseconds for script load.
     * @returns {number} Returns maximal time allowed for script load.
     */
    Timeout($value) {
        return this.timeout = Property.PositiveInteger(this.timeout, $value);
    }
    /**
     * @param {string} [$value] Specify mime type of data which should be loaded.
     * Value "json" can be used as shorthand for JSON data type.
     * @returns {string} Returns mime type used by current script loader instance.
     */
    MimeType($value) {
        if (ObjectValidator.IsEmptyOrNull($value) && StringUtils.ToLowerCase($value) === "json") {
            $value = "application/json";
        }
        return this.mimeType = Property.String(this.mimeType, $value);
    }
    /**
     * @param {string} [$value] Specify path to external data, which should be loaded.
     * @returns {string} Returns path to external data if it has been specified otherwise null.
     */
    Path($value) {
        return this.path = Property.String(this.path, $value);
    }
    /**
     * @param {object|string} [$value] Specify data which should be converted from string to JSON object.
     * @returns {object} Returns data in JSON format which has been loaded or converted.
     */
    Data($value) {
        if (ObjectValidator.IsSet($value)) {
            try {
                this.data = $value;
            }
            catch (ex) {
                this.errorHandler(ex);
            }
        }
        return this.data;
    }
    /**
     * @param {IClassName} $class Specify class which should be in role of JSONP data namespace.
     * @param {string} $method Specify method which will be used for consumption of JSONP data.
     * @returns {void}
     */
    DataHandler($class, $method) {
        if (!ObjectValidator.IsEmptyOrNull($class)) {
            $class[$method] = ($data) => {
                this.data = $data;
            };
        }
    }
    /**
     * @param {Function} $handler Specify handler which should be invoked on successful data load.
     * @returns {void}
     */
    SuccessHandler($handler) {
        if (!ObjectValidator.IsEmptyOrNull($handler)) {
            this.successHandler = $handler;
        }
    }
    /**
     * @param {Function} $handler Specify method which should be invoked in case of load errors.
     * @returns {void}
     */
    ErrorHandler($handler) {
        if (!ObjectValidator.IsEmptyOrNull($handler)) {
            this.errorHandler = $handler;
        }
    }
    /**
     * Init processing of external data based on specified configuration
     * @returns {void}
     */
    Load() {
        const loader = document.createElement("script");
        loader.scriptType = "ScriptHandler";
        if (!ObjectValidator.IsEmptyOrNull(this.path)) {
            loader.src = this.path;
        }
        else if (!ObjectValidator.IsEmptyOrNull(this.data) && ObjectValidator.IsString(this.data)) {
            loader.text = this.data;
            this.data = undefined;
        }
        else {
            this.errorHandler(new Error("Path or body for resource must be defined before load."));
        }
        loader.type = this.mimeType;
        if (!ObjectValidator.IsEmptyOrNull(globalThis.nonce)) {
            loader.nonce = globalThis.nonce;
        }
        const cleanUp = () => {
            let passed = true;
            try {
                if (!ObjectValidator.IsEmptyOrNull(this.timeoutId)) {
                    clearTimeout(this.timeoutId);
                }
                if (!ObjectValidator.IsEmptyOrNull(loader.parentNode)) {
                    loader.parentNode.removeChild(loader);
                }
            }
            catch (ex) {
                passed = false;
                this.errorHandler(new Error("Failed to clean up ScriptHandler."));
            }
            return passed;
        };
        const errorBackup = window.onerror;
        window.onerror = () => {
            return true;
        };
        loader.onerror = ($error) => {
            window.onerror = errorBackup;
            if (cleanUp()) {
                if (ObjectValidator.IsEmptyOrNull($error.message)) {
                    this.errorHandler(new Error("Failed to load resource" +
                        (!ObjectValidator.IsEmptyOrNull(this.path) ? " from: " + this.path : ".")));
                }
                else {
                    this.errorHandler($error);
                }
            }
            return true;
        };
        let loaded = false;
        const onloadHandler = () => {
            window.onerror = errorBackup;
            if (cleanUp()) {
                try {
                    if (!loaded) {
                        loaded = true;
                        if (this.data !== undefined) {
                            this.successHandler();
                        }
                        else {
                            this.errorHandler(new Error("Failed to load resource data" +
                                (!ObjectValidator.IsEmptyOrNull(this.path) ? " from: " + this.path : ".")));
                        }
                    }
                }
                catch (ex) {
                    this.errorHandler(ex);
                }
            }
        };
        if (ObjectValidator.IsEmptyOrNull(loader.text)) {
            loader.onload = onloadHandler;
            loader.onreadystatechange = () => {
                if (loader.readyState === "complete" || loader.readyState === "loaded") {
                    onloadHandler();
                }
            };
        }
        cleanUp();
        this.timeoutId = setTimeout(($error) => {
            if (cleanUp()) {
                this.errorHandler($error);
            }
        }, this.timeout, new Error("Timeout reached"));
        document.body.appendChild(loader);
        if (!ObjectValidator.IsEmptyOrNull(loader.text)) {
            onloadHandler();
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.IOApi.Handlers.ScriptHandler", ScriptHandler);
//# sourceMappingURL=ScriptHandler.js.map