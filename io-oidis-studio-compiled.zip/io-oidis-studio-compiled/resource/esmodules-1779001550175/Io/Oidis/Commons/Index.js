var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseHttpResolver } from "./HttpProcessor/Resolvers/BaseHttpResolver.js";
import { Echo } from "./Utils/Echo.js";
import { Resolver, ResolverScope } from "./Primitives/Decorators.js";
/**
 * Index request resolver class provides handling of web index page.
 */
let Index = class Index extends BaseHttpResolver {
    resolver() {
        /* dev:start */
        Echo.Print("<H3>Runtime tests</H3>");
        Echo.Print("<a href=\"#" + this.createLink("/web/HttpRequestParserTest") + "\">HttpRequestParserTest</a>");
        Echo.Println("<a href=\"#" + this.createLink("/web/HttpManagerTest") + "\">HttpManagerTest</a>");
        Echo.Println("<a href=\"#" + this.createLink("/web/PersistenceApiTest") + "\">PersistenceApiTest</a>");
        Echo.Println("<a href=\"#" + this.createLink("/web/EventsManagerTest") + "\">EventsManagerTest</a>");
        Echo.Println("<a href=\"#" + this.createLink("/web/ExceptionsManagerTest") + "\">ExceptionsManagerTest</a>");
        Echo.Println("<a href=\"#" + this.createLink("/web/TimeoutTest") + "\">TimeoutTest</a>");
        Echo.Println("<a href=\"#" + this.createLink("/web/ChromiumConnectorTest") + "\">ChromiumConnectorTest</a>");
        Echo.Println("<a href=\"#" + this.createLink("/web/CoverageTest") + "\">CoverageTest</a>");
        Echo.Println("<a href=\"#" + this.createLink("/web/AsyncRuntimeTest") + "\">AsyncRuntimeTest</a>");
        Echo.Println("<a href=\"#" + this.createLink("/web/JsonpFileReaderTest") + "\">JsonpFileReaderTest</a>");
        Echo.Println("<a href=\"#" + this.createLink("/web/JxbrowserBridgeClientTest") + "\">JxbrowserBridgeClientTest</a>");
        Echo.Println("<a href=\"#" + this.createLink("/web/LogItTest") + "\">LogItTest</a>");
        /* dev:end */
        Echo.Print("<H3>About resolvers</H3>");
        Echo.Print("<a href=\"#" + this.createLink("/about/Cache") + "\">/about/Cache</a>");
        Echo.Println("<a href=\"#" + this.createLink("/about/Env") + "\">/about/Env</a>");
    }
};
Index = __decorate([
    Resolver(["/", "/index", "/index.html", "/web/"], { scope: ResolverScope.DEV })
], Index);
export { Index };
globalThis.RegisterClass("Io.Oidis.Commons.Index", Index);
//# sourceMappingURL=Index.js.map