// generated-code-start
export const IWebServiceClientEvents = globalThis.RegisterInterface(["OnStart", "OnClose", "OnTimeout", "OnError"]);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.Events.IWebServiceClientEvents", IWebServiceClientEvents);
//# sourceMappingURL=IWebServiceClientEvents.js.map