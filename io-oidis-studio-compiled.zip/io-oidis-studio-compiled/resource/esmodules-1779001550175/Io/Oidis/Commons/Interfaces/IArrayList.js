import { IBaseObject } from "./IBaseObject.js";
// generated-code-start
/* eslint-disable */
export const IArrayList = globalThis.RegisterInterface(["Add", "getKeys", "getKey", "KeyExists", "Contains", "IndexOf", "getAll", "getItem", "getFirst", "getLast", "Equal", "Length", "IsEmpty", "Clear", "Copy", "RemoveAt", "RemoveLast", "SortByKeyUp", "SortByKeyDown", "foreach", "ToArray"], IBaseObject);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IArrayList", IArrayList);
//# sourceMappingURL=IArrayList.js.map