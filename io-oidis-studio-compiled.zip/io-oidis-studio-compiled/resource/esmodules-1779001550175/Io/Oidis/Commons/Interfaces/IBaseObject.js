// generated-code-start
/* eslint-disable */
export const IBaseObject = globalThis.RegisterInterface(["getClassName", "getNamespaceName", "getClassNameWithoutNamespace", "getClassHierarchy", "getNamespaceHierarchy", "getProperties", "getMethods", "IsTypeOf", "IsMemberOf", "Implements", "ToString", "toString", "SerializationData", "getHash", "getUID", "ValidateProperties", "ValidateDeep"]);
export const IModel = globalThis.RegisterInterface(["Validate", "ToJSON", "Save", "Update", "Refresh", "Remove", "Delete", "getCollection", "getSymbolicName", "getDocument", "ToInterface"], IBaseObject);
export const ISchemaOptions = globalThis.RegisterInterface(["type", "default", "required", "addId", "alias"]);
export const IObjectProperty = globalThis.RegisterInterface(["name", "symbol", "fieldKey", "validator", "noAutoListValidation", "modifiers", "schemaOptions", "converter", "isInclusion"]);
export const IObjectModifiers = globalThis.RegisterInterface(["noJSON", "noSerialize", "noResolve"]);
export const IObjectSerializerOptions = globalThis.RegisterInterface(["idsOnly", "expanded", "preserveUndefined"]);
export const IContext = globalThis.RegisterInterface(["parent", "property", "dataTranslation"]);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IBaseObject", IBaseObject);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IModel", IModel);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.ISchemaOptions", ISchemaOptions);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IObjectProperty", IObjectProperty);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IObjectModifiers", IObjectModifiers);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IObjectSerializerOptions", IObjectSerializerOptions);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IContext", IContext);
//# sourceMappingURL=IBaseObject.js.map