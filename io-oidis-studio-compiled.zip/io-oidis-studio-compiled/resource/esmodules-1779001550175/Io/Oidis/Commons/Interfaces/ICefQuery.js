/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IBaseObject } from "./IBaseObject.js";
// generated-code-start
export const ICefQuery = globalThis.RegisterInterface([], IBaseObject);
export const ICefQueryMessage = globalThis.RegisterInterface(["request", "persistent", "onSuccess", "onFailure"]);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.ICefQuery", ICefQuery);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.ICefQueryMessage", ICefQueryMessage);
//# sourceMappingURL=ICefQuery.js.map