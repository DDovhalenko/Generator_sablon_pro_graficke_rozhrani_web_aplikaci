// generated-code-start
export const IEventsHandler = globalThis.RegisterInterface([]);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IEventsHandler", IEventsHandler);
//# sourceMappingURL=IEventsHandler.js.map