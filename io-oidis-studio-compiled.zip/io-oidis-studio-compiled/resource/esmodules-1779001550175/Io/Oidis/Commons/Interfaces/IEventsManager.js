import { IBaseObject } from "./IBaseObject.js";
// generated-code-start
/* eslint-disable */
export const IEventsManager = globalThis.RegisterInterface(["Exists", "getAll", "setEvent", "setEventArgs", "FireEvent", "FireAsynchronousMethod", "RemoveHandler", "Clear"], IBaseObject);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IEventsManager", IEventsManager);
//# sourceMappingURL=IEventsManager.js.map