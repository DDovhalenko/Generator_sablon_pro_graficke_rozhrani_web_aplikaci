// generated-code-start
export const IFileSystemItemProtocol = globalThis.RegisterInterface(["name", "type", "value", "attributes", "map"]);
export const IBaseFileSystemItem = globalThis.RegisterInterface(["name", "type"]);
export const IFileSystemFileProtocol = globalThis.RegisterInterface(["attributes"], IBaseFileSystemItem);
export const IFileSystemDirectoryProtocol = globalThis.RegisterInterface(["map"], IFileSystemFileProtocol);
export const IFileSystemDriveProtocol = globalThis.RegisterInterface(["value", "map"], IBaseFileSystemItem);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IFileSystemItemProtocol", IFileSystemItemProtocol);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IBaseFileSystemItem", IBaseFileSystemItem);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IFileSystemFileProtocol", IFileSystemFileProtocol);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IFileSystemDirectoryProtocol", IFileSystemDirectoryProtocol);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IFileSystemDriveProtocol", IFileSystemDriveProtocol);
//# sourceMappingURL=IFileSystemItemProtocol.js.map