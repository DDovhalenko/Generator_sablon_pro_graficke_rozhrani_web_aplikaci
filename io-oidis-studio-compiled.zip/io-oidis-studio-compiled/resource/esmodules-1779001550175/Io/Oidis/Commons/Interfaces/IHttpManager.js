import { IBaseObject } from "./IBaseObject.js";
// generated-code-start
/* eslint-disable */
export const IHttpManager = globalThis.RegisterInterface(["RegisterResolver", "OverrideResolver", "getResolverClassName", "getResolverParameters", "getResolversCollection"], IBaseObject);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IHttpManager", IHttpManager);
//# sourceMappingURL=IHttpManager.js.map