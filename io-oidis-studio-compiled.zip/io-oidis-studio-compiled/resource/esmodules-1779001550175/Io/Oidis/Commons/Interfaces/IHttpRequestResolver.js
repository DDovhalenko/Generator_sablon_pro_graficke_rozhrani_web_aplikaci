import { IBaseObject } from "./IBaseObject.js";
// generated-code-start
export const IHttpRequestResolver = globalThis.RegisterInterface(["RequestArgs", "Process"], IBaseObject);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IHttpRequestResolver", IHttpRequestResolver);
//# sourceMappingURL=IHttpRequestResolver.js.map