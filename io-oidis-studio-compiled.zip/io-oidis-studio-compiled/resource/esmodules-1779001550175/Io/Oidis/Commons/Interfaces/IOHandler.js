import { IBaseObject } from "./IBaseObject.js";
// generated-code-start
/* eslint-disable */
export const IOHandler = globalThis.RegisterInterface(["Init", "Name", "Encoding", "NewLineType", "Print", "setOnPrint", "Clear"], IBaseObject);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IOHandler", IOHandler);
//# sourceMappingURL=IOHandler.js.map