import { IBaseObject } from "./IBaseObject.js";
// generated-code-start
/* eslint-disable */
export const IPersistenceHandler = globalThis.RegisterInterface(["getSessionId", "getSize", "getLoadTime", "getRawData", "LoadPersistenceAsynchronously", "DisableCRC", "ExpireTime", "Variable", "Exists", "Destroy", "Clear"], IBaseObject);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IPersistenceHandler", IPersistenceHandler);
//# sourceMappingURL=IPersistenceHandler.js.map