// generated-code-start
/* eslint-disable */
export const IProject = globalThis.RegisterInterface(["name", "version", "description", "license", "homepage", "author", "contributors", "target", "loaderClass", "guiLoaderClass", "namespaces", "namespaceMappings", "packageName", "build", "logger", "dbConfigs", "lcpConfig", "sentry"]);
export const IProjectAuthor = globalThis.RegisterInterface(["name", "organization", "email"]);
export const IProjectTarget = globalThis.RegisterInterface(["name", "companyName", "copyright", "description", "appDataPath", "embedFeatures", "withFrontendHeaders"]);
export const IBuildProductArgs = globalThis.RegisterInterface(["type", "os", "arch", "toolchain"]);
export const IBuildArgs = globalThis.RegisterInterface(["platform", "product", "releaseName", "time", "timestamp", "type"]);
export const INamespaceMapping = globalThis.RegisterInterface(["namespace", "mappedTo", "childNamespaces"]);
export const ILoggerConfiguration = globalThis.RegisterInterface(["level", "severity", "debug", "verbose", "adapters", "symbols", "reportIgnoreList"]);
export const IDbConfiguration = globalThis.RegisterInterface(["dbName"]);
export const ILCPConfiguration = globalThis.RegisterInterface(["format"]);
export const ISentryConfiguration = globalThis.RegisterInterface(["dsn", "environment", "tracesSampleRate", "tunnel", "useStrictSSL", "debug", "tags", "maxMessageLength", "cspReportTunnel", "ignoreErrors"]);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IProject", IProject);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IProjectAuthor", IProjectAuthor);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IProjectTarget", IProjectTarget);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IBuildProductArgs", IBuildProductArgs);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IBuildArgs", IBuildArgs);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.INamespaceMapping", INamespaceMapping);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.ILoggerConfiguration", ILoggerConfiguration);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IDbConfiguration", IDbConfiguration);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.ILCPConfiguration", ILCPConfiguration);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.ISentryConfiguration", ISentryConfiguration);
//# sourceMappingURL=IProject.js.map