export {};
//# sourceMappingURL=ITimeoutHandler.js.map