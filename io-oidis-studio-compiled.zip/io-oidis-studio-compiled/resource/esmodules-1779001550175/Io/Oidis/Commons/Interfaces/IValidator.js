/*! ******************************************************************************************************** *
 *
 * Copyright 2022-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IBaseObject } from "./IBaseObject.js";
// generated-code-start
export const IValidator = globalThis.RegisterInterface(["validate"], IBaseObject);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IValidator", IValidator);
//# sourceMappingURL=IValidator.js.map