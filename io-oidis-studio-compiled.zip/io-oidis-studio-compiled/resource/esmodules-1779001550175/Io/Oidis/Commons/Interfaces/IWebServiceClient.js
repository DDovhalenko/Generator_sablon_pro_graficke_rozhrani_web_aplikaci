import { IBaseObject } from "./IBaseObject.js";
// generated-code-start
/* eslint-disable */
export const IWebServiceClient = globalThis.RegisterInterface(["getId", "getServerUrl", "getServerPath", "getEvents", "StartCommunication", "StopCommunication", "CommunicationIsRunning", "Send", "setRequestFormatter", "setResponseFormatter"], IBaseObject);
export const IWebServiceRequestFormatterData = globalThis.RegisterInterface(["value", "key"]);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IWebServiceClient", IWebServiceClient);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IWebServiceRequestFormatterData", IWebServiceRequestFormatterData);
//# sourceMappingURL=IWebServiceClient.js.map