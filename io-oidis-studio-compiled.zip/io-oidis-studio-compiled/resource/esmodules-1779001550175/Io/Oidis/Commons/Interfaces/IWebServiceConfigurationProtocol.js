// generated-code-start
/* eslint-disable */
export const IWebServiceConfigurationProtocol = globalThis.RegisterInterface(["location", "responseUrl", "address", "port", "base", "protocol", "timeout", "version", "accept"]);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IWebServiceConfigurationProtocol", IWebServiceConfigurationProtocol);
//# sourceMappingURL=IWebServiceConfigurationProtocol.js.map