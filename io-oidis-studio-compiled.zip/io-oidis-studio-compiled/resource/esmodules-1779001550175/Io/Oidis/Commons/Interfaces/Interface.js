/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/**
 * Interface class is abstract class providing declaration of methods accessible from implemented interfaces.
 */
export class Interface {
    static getInstance($declarations, $parent = null) {
        /* istanbul ignore next : interface will never have an instance */
        const child = function () {
            // default constructor with empty body
        };
        /* istanbul ignore if : interface will never have an instance */
        if ($parent === null) {
            $parent = function () {
                // default constructor with empty body
            };
            $parent.classNamespace = "";
            $parent.className = "";
            $parent.ClassName = function () {
                return this.classNamespace + "." + this.className;
            };
            $parent.NamespaceName = function () {
                return this.classNamespace;
            };
            $parent.ClassNameWithoutNamespace = function () {
                return this.className;
            };
            $parent.ToString = $parent.ClassName;
            $parent.toString = $parent.ToString;
        }
        let property;
        for (property in $parent) {
            /* istanbul ignore else */
            if (!child.hasOwnProperty(property)) {
                child[property] = $parent[property];
            }
        }
        let index;
        for (index = 0; index < $declarations.length; index++) {
            if (!child.hasOwnProperty($declarations[index])) {
                child[$declarations[index]] = null;
            }
        }
        return child;
    }
    /**
     * @returns {string} Returns class name with namespace in string format.
     */
    ClassName() {
        return null;
    }
    /**
     * @returns {string} Returns namespace of the class in string format.
     */
    NamespaceName() {
        return null;
    }
    /**
     * @returns {string} Returns only the class name without namespace in string format.
     */
    ClassNameWithoutNamespace() {
        return null;
    }
    ToString() {
        return null;
    }
    toString() {
        return null;
    }
}
globalThis.RegisterInterface = ($declarations, $parent) => {
    return Interface.getInstance($declarations, $parent);
};
// generated-code-start
export const IClassName = globalThis.RegisterInterface([]);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.Interface", Interface);
globalThis.RegisterClass("Io.Oidis.Commons.Interfaces.IClassName", IClassName);
//# sourceMappingURL=Interface.js.map