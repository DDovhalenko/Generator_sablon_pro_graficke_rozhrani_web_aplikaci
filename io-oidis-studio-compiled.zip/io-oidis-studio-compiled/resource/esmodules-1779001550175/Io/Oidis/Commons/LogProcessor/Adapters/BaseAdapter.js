/*! ******************************************************************************************************** *
 *
 * Copyright 2021-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IOHandlerType } from "../../Enums/IOHandlerType.js";
import { LogLevel } from "../../Enums/LogLevel.js";
import { IOHandlerFactory } from "../../IOApi/IOHandlerFactory.js";
import { BaseObject } from "../../Primitives/BaseObject.js";
import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { Property } from "../../Utils/Property.js";
import { StringUtils } from "../../Utils/StringUtils.js";
export class BaseAdapter extends BaseObject {
    debug;
    verbose;
    output;
    handlerType;
    owner;
    enabled;
    constructor() {
        super();
        this.enabled = true;
        this.setHandler(IOHandlerFactory.getHandler(IOHandlerType.CONSOLE));
    }
    /**
     * @returns {string} Returns SHA1 hash of adapter output configuration.
     */
    getConfigSHA() {
        return StringUtils.getSha1(this.HtmlSupported() + "" + this.NewLineType());
    }
    /**
     * @returns {boolean} Returns true if adapter supports HTML output, otherwise false.
     */
    HtmlSupported() {
        return false;
    }
    /**
     * @returns {NewLineType} Returns new line type used by the adapter output handler.
     */
    NewLineType() {
        return this.output.NewLineType();
    }
    /**
     * @param {boolean} $debug Enable or disable debug mode.
     * @param {boolean} $verbose Enable or disable verbose mode.
     * @returns {void}
     */
    setModes($debug, $verbose) {
        this.debug = Property.Boolean(this.debug, $debug);
        this.verbose = Property.Boolean(this.verbose, $verbose);
    }
    /**
     * @param {boolean} [$value] If specified, set enabled state of the adapter.
     * @returns {boolean} Returns true if adapter is enabled, otherwise false.
     */
    Enabled($value) {
        return this.enabled = Property.Boolean(this.enabled, $value);
    }
    /**
     * @param {ILoggerTrace} $trace Log trace entry to process and output.
     * @returns {void}
     */
    Process($trace) {
        if (!ObjectValidator.IsEmptyOrNull($trace.message) && this.enabled) {
            try {
                $trace.time = this.timeToString($trace.time);
                $trace.entryPoint = this.traceBackToString($trace.entryPoint);
                this.print(this.formatter($trace), this.getHandler());
            }
            catch (ex) {
                console.error(ex); // eslint-disable-line no-console
            }
        }
    }
    /**
     * @param {any} $value Logger instance that owns this adapter.
     * @returns {void}
     */
    setOwner($value) {
        this.owner = $value;
    }
    setHandler($handler) {
        if (!ObjectValidator.IsEmptyOrNull($handler)) {
            this.output = $handler;
            this.output.Init();
            this.handlerType = IOHandlerFactory.getHandlerType(this.output);
        }
    }
    getHandler() {
        return this.output;
    }
    getOwner() {
        return this.owner;
    }
    timeToString($value) {
        return new Date($value).toLocaleTimeString([], {
            hour12: false,
            timeZone: "UTC",
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit"
        });
    }
    traceBackToString($traceback) {
        let trace = "";
        if (this.verbose && !ObjectValidator.IsEmptyOrNull($traceback)) {
            if ($traceback.at !== "undefined" && $traceback.at !== "anonymous") {
                trace = $traceback.at;
            }
            if (!ObjectValidator.IsEmptyOrNull(trace)) {
                trace = "> " + trace + this.NewLineType();
            }
            if ($traceback.from !== "undefined" && $traceback.from !== "anonymous") {
                if (!ObjectValidator.IsEmptyOrNull(trace)) {
                    trace += "> from ";
                }
                else {
                    trace += "> ";
                }
                trace += $traceback.from + this.NewLineType();
            }
        }
        return trace;
    }
    formatter($trace) {
        if (this.debug) {
            $trace.message = StringUtils.Format(this.verbose && !ObjectValidator.IsEmptyOrNull($trace.entryPoint) ? "{2}[{0}][{1}] {3}" : "[{0}][{1}] {3}", $trace.time, LogLevel[$trace.level], $trace.entryPoint, $trace.message);
        }
        return $trace;
    }
    print($trace, $handler) {
        $handler.Print($trace.message);
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.LogProcessor.Adapters.BaseAdapter", BaseAdapter);
//# sourceMappingURL=BaseAdapter.js.map