/*! ******************************************************************************************************** *
 *
 * Copyright 2024-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { LogLevel } from "../../Enums/LogLevel.js";
import { Loader } from "../../Loader.js";
import { isBrowser } from "../../Utils/EnvironmentHelper.js";
import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { StringUtils } from "../../Utils/StringUtils.js";
import { BaseAdapter } from "./BaseAdapter.js";
export class SentryAdapter extends BaseAdapter {
    context;
    constructor() {
        super();
        this.context = "";
    }
    /**
     * @param {string} $value User context identifier for Sentry scope.
     * @returns {void}
     */
    setContext($value) {
        this.context = $value;
    }
    getHandler() {
        const handler = super.getHandler();
        const config = Loader.getInstance().getEnvironmentArgs()?.getProjectConfig().sentry;
        if (!ObjectValidator.IsEmptyOrNull(config?.dsn)) {
            const profile = {
                debug: config.debug,
                dsn: config.dsn,
                maxValueLength: config.maxMessageLength,
                release: Loader.getInstance().getEnvironmentArgs().getProjectVersion()
            };
            if (config.tracesSampleRate > 0) {
                profile.tracesSampleRate = config.tracesSampleRate;
            }
            if (!isBrowser) {
                globalThis.Sentry = require("@sentry/node");
            }
            else if (!ObjectValidator.IsEmptyOrNull(config.tunnel)) {
                profile.tunnel = config.tunnel;
            }
            if (!ObjectValidator.IsEmptyOrNull(config.environment) && config.environment !== "none") {
                profile.environment = config.environment;
            }
            const ignoreList = [].concat(this.getOwner().getIgnoreList()).concat(config.ignoreErrors);
            if (!ObjectValidator.IsEmptyOrNull(ignoreList)) {
                profile.ignoreErrors = ignoreList;
            }
            Sentry.init(profile);
            Sentry.setTag("version", Loader.getInstance().getEnvironmentArgs().getProjectVersion());
            for (const tagName in config.tags) {
                if (tagName.toLowerCase() !== "version" && config.tags.hasOwnProperty(tagName)) {
                    Sentry.setTag(tagName, config.tags[tagName]);
                }
            }
        }
        else {
            this.Enabled(false);
        }
        this.getHandler = () => {
            return handler;
        };
        return handler;
    }
    timeToString($value) {
        return $value;
    }
    traceBackToString($traceback) {
        return $traceback;
    }
    formatter($trace) {
        return $trace;
    }
    print($trace) {
        if (!$trace.isForwarded && ($trace.level === LogLevel.ERROR || $trace.level === LogLevel.WARNING) && this.Enabled()) {
            Sentry.withScope(($scope) => {
                if (!ObjectValidator.IsEmptyOrNull(this.context)) {
                    /// TODO: user can be described also by email and username, but context should be anonymous
                    $scope.setUser({
                        id: this.context
                    });
                }
                if ($trace.level === LogLevel.WARNING) {
                    $scope.setLevel("warning");
                    Sentry.captureMessage($trace.message);
                }
                else {
                    if (StringUtils.ContainsIgnoreCase($trace.message, "\n")) {
                        const error = new Error($trace.message.split("\n")[0]);
                        error.stack = $trace.message;
                        Sentry.captureException(error);
                    }
                    else {
                        $scope.setLevel("error");
                        Sentry.captureMessage($trace.message);
                    }
                }
            });
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.LogProcessor.Adapters.SentryAdapter", SentryAdapter);
//# sourceMappingURL=SentryAdapter.js.map