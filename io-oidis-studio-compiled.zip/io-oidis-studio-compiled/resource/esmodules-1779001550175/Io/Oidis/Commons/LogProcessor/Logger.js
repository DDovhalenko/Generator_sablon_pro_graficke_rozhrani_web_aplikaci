/*! ******************************************************************************************************** *
 *
 * Copyright 2021-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { LogAdapterType } from "../Enums/LogAdapterType.js";
import { LogLevel } from "../Enums/LogLevel.js";
import { LogSeverity } from "../Enums/LogSeverity.js";
import { ArrayList } from "../Primitives/ArrayList.js";
import { BaseObject } from "../Primitives/BaseObject.js";
import { Convert } from "../Utils/Convert.js";
import { JsonUtils } from "../Utils/JsonUtils.js";
import { ObjectValidator } from "../Utils/ObjectValidator.js";
import { Property } from "../Utils/Property.js";
import { Reflection } from "../Utils/Reflection.js";
import { StringUtils } from "../Utils/StringUtils.js";
import { TraceBack } from "../Utils/TraceBack.js";
import { ConsoleAdapter } from "./Adapters/ConsoleAdapter.js";
import { HTMLAdapter } from "./Adapters/HTMLAdapter.js";
import { SentryAdapter } from "./Adapters/SentryAdapter.js";
export class Logger extends BaseObject {
    debug;
    verbose;
    adapters;
    level;
    severity;
    anonymizer;
    trackBackEntryPoint;
    ignoreList;
    constructor() {
        super();
        this.debug = false;
        this.verbose = false;
        this.ignoreList = [];
        this.setAdapters(this.buildInAdapters().map(($type) => {
            return this.getAdapter($type);
        }));
        this.enableAdapters();
        this.setLevels(LogLevel.INFO, LogSeverity.HIGH);
    }
    /**
     * @param {ILoggerConfiguration} $value Logger configuration object.
     * @returns {void}
     */
    setConfig($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            const config = JsonUtils.Clone($value);
            if (!ObjectValidator.IsEmptyOrNull(config.level)) {
                if (config.level > 6) {
                    config.level = 1;
                }
                if (config.level <= 0) {
                    config.level = -1;
                }
            }
            if (!ObjectValidator.IsEmptyOrNull(config.severity)) {
                if (config.severity > 2) {
                    config.severity = 2;
                }
                if (config.severity < 0) {
                    config.severity = 0;
                }
            }
            this.ignoreList = [];
            // eslint-disable-next-line @typescript-eslint/no-for-in-array
            for (const item in config.reportIgnoreList) {
                if (config.reportIgnoreList.hasOwnProperty(item) && config.reportIgnoreList[item] && !this.ignoreList.includes(item)) {
                    this.ignoreList.push(item);
                }
            }
            this.setLevels(config.level, config.severity);
            this.setModes(config.debug, config.verbose);
            this.setAnonymizer(config.symbols);
            if (ObjectValidator.IsEmptyOrNull(config.adapters)) {
                config.adapters = [];
            }
            this.enableAdapters(config.adapters.map(($value) => {
                return StringUtils.ToUpperCase($value);
            }));
        }
    }
    /**
     * @param {LogLevel} $level Minimum log level to display.
     * @param {LogSeverity} $severity Minimum log severity to display.
     * @returns {void}
     */
    setLevels($level, $severity) {
        if (!ObjectValidator.IsEmptyOrNull($level)) {
            this.level = $level;
        }
        if (!ObjectValidator.IsEmptyOrNull($severity)) {
            this.severity = $severity;
        }
    }
    /**
     * @returns {void}
     */
    MuteToggle() {
        if (ObjectValidator.IsEmptyOrNull(this._level)) {
            this._level = this.level;
            this.level = LogLevel.OFF;
        }
        else {
            this.level = this._level;
            delete this._level;
        }
    }
    /**
     * @param {boolean} $debug Enable or disable debug mode.
     * @param {boolean} $verbose Enable or disable verbose mode.
     * @returns {void}
     */
    setModes($debug, $verbose) {
        this.debug = Property.Boolean(this.debug, $debug);
        this.verbose = Property.Boolean(this.verbose, $verbose);
        this.adapters.forEach(($adapter) => {
            $adapter.setModes(this.debug, this.verbose);
        });
    }
    /**
     * @param {any} $class Class or function used as traceback entry point.
     * @returns {void}
     */
    setTrackBackEntryPoint($class) {
        this.trackBackEntryPoint = $class;
    }
    /**
     * @param {any} [$patterns] Key-value pairs of anonymization patterns.
     * @returns {void}
     */
    setAnonymizer($patterns) {
        if (!ObjectValidator.IsSet(this.anonymizer)) {
            this.anonymizer = this.getAnonymizerSymbols();
        }
        if (!ObjectValidator.IsEmptyOrNull($patterns)) {
            let pattern;
            for (pattern in $patterns) {
                if ($patterns.hasOwnProperty(pattern) && !ObjectValidator.IsEmptyOrNull($patterns[pattern])) {
                    this.anonymizer.values[pattern] = $patterns[pattern];
                }
            }
        }
    }
    /**
     * @param {BaseAdapter} $adapter Adapter instance to add to the logger.
     * @returns {void}
     */
    AddAdapter($adapter) {
        $adapter.setModes(this.debug, this.verbose);
        $adapter.setOwner(this);
        this.adapters.push($adapter);
    }
    /**
     * @param {BaseAdapter[]} $adapters Array of adapter instances to replace current adapters.
     * @returns {void}
     */
    setAdapters($adapters) {
        if (!ObjectValidator.IsEmptyOrNull($adapters)) {
            this.adapters = [];
            $adapters.forEach(($adapter) => {
                if (!ObjectValidator.IsEmptyOrNull($adapter)) {
                    $adapter.setOwner(this);
                    this.adapters.push($adapter);
                }
            });
            this.setModes(this.debug, this.verbose);
        }
        else {
            this.adapters = [];
        }
    }
    /**
     * @returns {string[]} Returns list of ignored error patterns.
     */
    getIgnoreList() {
        return this.ignoreList;
    }
    /**
     * @param {string} $message Log message with optional format placeholders.
     * @param {any[]} $parameters Format parameters or leading severity value.
     * @returns {void}
     */
    Info($message, ...$parameters) {
        let severity = LogSeverity.HIGH;
        if ($parameters.length >= 1 && $parameters[0] in LogSeverity) {
            severity = $parameters[0];
            $parameters.shift();
        }
        this.process(LogLevel.INFO, StringUtils.Format.apply(StringUtils, [$message].concat($parameters)), severity); // eslint-disable-line
    }
    /**
     * @param {string} $message Warning message with optional format placeholders.
     * @param {any[]} $parameters Format parameters.
     * @returns {void}
     */
    Warning($message, ...$parameters) {
        this.process(LogLevel.WARNING, StringUtils.Format.apply(StringUtils, [$message].concat($parameters))); // eslint-disable-line
    }
    /**
     * @param {string | Error} $message Error message or Error instance.
     * @param {any[]} $parameters Format parameters or trailing Error instance.
     * @returns {void}
     */
    Error($message, ...$parameters) {
        let exception = null;
        if (this.verbose && ObjectValidator.IsString($message)) {
            exception = new Error($message);
            exception.message = "";
        }
        if (!ObjectValidator.IsString($message)) {
            const errorCopy = new Error("");
            try {
                const origMessage = $message.message;
                $message.message = "";
                errorCopy.stack = $message.stack;
                $message.message = origMessage;
                $message = origMessage;
            }
            catch (ex) {
                errorCopy.stack = $message.stack;
                $message = $message.message;
            }
            exception = errorCopy;
        }
        if ($parameters.length === 1 && ObjectValidator.IsError($parameters[0])) {
            exception = $parameters[0];
            $parameters.shift();
        }
        if ($parameters.length > 0) {
            $message = StringUtils.Format.apply(StringUtils, [$message].concat($parameters)); // eslint-disable-line
        }
        let data = $message;
        if (!ObjectValidator.IsEmptyOrNull(exception) && ObjectValidator.IsSet(exception.stack)) {
            data = {
                _isLoggerObject: true,
                error: exception,
                message: $message
            };
        }
        this.process(LogLevel.ERROR, data);
    }
    /**
     * @param {string | any} $messageOrObject Debug message or object to log.
     * @param {any[]} $parameters Format parameters.
     * @returns {void}
     */
    Debug($messageOrObject, ...$parameters) {
        if (ObjectValidator.IsSet($parameters) && ObjectValidator.IsString($messageOrObject)) {
            this.process(LogLevel.DEBUG, {
                _isLoggerObject: true,
                args: $parameters,
                message: $messageOrObject
            });
        }
        else {
            this.process(LogLevel.DEBUG, $messageOrObject);
        }
    }
    /**
     * @param {string} $message Verbose message with optional format placeholders.
     * @param {any[]} $parameters Format parameters.
     * @returns {void}
     */
    Verbose($message, ...$parameters) {
        this.process(LogLevel.VERBOSE, StringUtils.Format.apply(StringUtils, [$message].concat($parameters))); // eslint-disable-line
    }
    /**
     * @param {LogAdapterType} $type Type of adapter to retrieve.
     * @returns {BaseAdapter} Returns adapter instance for the specified type, or null if unknown.
     */
    getAdapter($type) {
        const name = "adapter" + $type;
        switch ($type) {
            case LogAdapterType.CONSOLE:
                if (ObjectValidator.IsEmptyOrNull(this[name])) {
                    this[name] = new ConsoleAdapter();
                }
                return this[name];
            case LogAdapterType.HTML:
                if (ObjectValidator.IsEmptyOrNull(this[name])) {
                    this[name] = new HTMLAdapter();
                }
                return this[name];
            case LogAdapterType.SENTRY:
                if (ObjectValidator.IsEmptyOrNull(this[name])) {
                    this[name] = new SentryAdapter();
                }
                return this[name];
            default:
                return null;
        }
    }
    getAnonymizerSymbols() {
        return {
            format: "{0}",
            values: []
        };
    }
    serializeMessage($message, $htmlTagEnabled, $newLineType) {
        if (!ObjectValidator.IsString($message)) {
            if (ObjectValidator.IsSet($message._isLoggerObject)) {
                if (ObjectValidator.IsSet($message.error)) {
                    if (!ObjectValidator.IsEmptyOrNull($message.error.message) &&
                        !StringUtils.Contains($message.message, $message.error.message)) {
                        if (!StringUtils.EndsWith($message.message, ".")) {
                            $message.message += ".";
                        }
                        if (!StringUtils.EndsWith($message.message, " ")) {
                            $message.message += " ";
                        }
                        $message.message += $message.error.message;
                    }
                    $message.message += $newLineType + "Stack trace: ";
                    if ($htmlTagEnabled) {
                        $message.message += StringUtils.Replace(StringUtils.Replace($message.error.stack, "</", ":"), "\n", StringUtils.NewLine());
                    }
                    else {
                        let trace = $message.error.stack;
                        if (StringUtils.Contains(trace, "\n")) {
                            trace = trace.substring(trace.indexOf("\n"));
                        }
                        $message.message += trace;
                    }
                    $message = $message.message;
                }
                else if (ObjectValidator.IsSet($message.args)) {
                    const args = [$message.message];
                    let index;
                    for (index = 0; index < $message.args.length; index++) {
                        args[index + 1] = Convert.ObjectToString($message.args[index], "", $htmlTagEnabled);
                    }
                    $message = StringUtils.Format.apply(StringUtils, args); // eslint-disable-line
                }
            }
            else {
                $message = Convert.ObjectToString($message, "", $htmlTagEnabled);
            }
        }
        return $message;
    }
    buildInAdapters() {
        return [LogAdapterType.CONSOLE, LogAdapterType.SENTRY];
    }
    defaultAdapters() {
        return [LogAdapterType.CONSOLE, LogAdapterType.SENTRY];
    }
    process($level, $message, $severity) {
        const minLevel = this.debug || this.verbose ? LogLevel.ALL : this.level;
        if (minLevel === LogLevel.ALL ||
            minLevel === LogLevel.DEBUG ||
            (minLevel === LogLevel.ERROR && $level === LogLevel.ERROR) ||
            (minLevel === LogLevel.WARNING && ($level === LogLevel.ERROR || $level === LogLevel.WARNING)) ||
            (minLevel === LogLevel.INFO && ($level === LogLevel.INFO || $level === LogLevel.WARNING || $level === LogLevel.ERROR))) {
            if ($level === LogLevel.INFO && !ObjectValidator.IsEmptyOrNull($severity)) {
                let minSeverity = this.severity;
                if (this.verbose) {
                    minSeverity = LogSeverity.LOW;
                }
                else if (this.debug) {
                    minSeverity = LogSeverity.MEDIUM;
                }
                if ($severity < minSeverity) {
                    $message = "";
                }
            }
            if (!ObjectValidator.IsEmptyOrNull($message)) {
                const messages = new ArrayList();
                this.adapters.forEach(($adapter) => {
                    if ($adapter.Enabled()) {
                        const type = $adapter.getConfigSHA();
                        if (!messages.KeyExists(type)) {
                            messages.Add(this.anonymize(this.serializeMessage($message, $adapter.HtmlSupported(), $adapter.NewLineType())), type);
                        }
                    }
                });
                const entryPoint = TraceBack.CaptureEntry(this.toType());
                entryPoint.at = this.anonymize(entryPoint.at);
                entryPoint.from = this.anonymize(entryPoint.from);
                this.adapters.forEach(($adapter) => {
                    if ($adapter.Enabled()) {
                        $adapter.Process({
                            entryPoint,
                            level: $level,
                            message: messages.getItem($adapter.getConfigSHA()),
                            severity: $severity,
                            time: new Date().getTime(),
                            trace: TraceBack.getTrace()
                        });
                    }
                });
            }
        }
    }
    enableAdapters($allowed) {
        if (ObjectValidator.IsEmptyOrNull($allowed)) {
            $allowed = this.defaultAdapters();
        }
        this.buildInAdapters().forEach(($type) => {
            const adapter = this.getAdapter($type);
            if (!ObjectValidator.IsEmptyOrNull(adapter)) {
                adapter.Enabled($allowed.includes($type));
            }
        });
    }
    anonymize($message) {
        if (!this.debug) {
            if (!ObjectValidator.IsSet(this.anonymizer)) {
                this.anonymizer = this.getAnonymizerSymbols();
            }
            let key;
            for (key in this.anonymizer.values) {
                if (this.anonymizer.values.hasOwnProperty(key) && StringUtils.Contains($message, this.anonymizer.values[key])) {
                    $message = StringUtils.Replace($message, this.anonymizer.values[key], StringUtils.Format(this.anonymizer.format, key));
                }
            }
        }
        return $message;
    }
    toType() {
        const entryPoint = ObjectValidator.IsEmptyOrNull(this.trackBackEntryPoint) ?
            Reflection.getInstance().getClass(this.getClassName()) : this.trackBackEntryPoint;
        let type = "Function.";
        let match = (entryPoint + "").match(/function\s(\w*)/);
        if (match === null) {
            match = (({}).toString.call(entryPoint) + "").match(/\s([a-zA-Z]+)/);
            type += (match[1] + "").toLowerCase();
        }
        else {
            type += match[1];
        }
        this.toType = () => {
            return type;
        };
        return type;
    }
}
// generated-code-start
export const ILoggerTrace = globalThis.RegisterInterface(["level", "message", "severity", "time", "trace", "entryPoint"]);
globalThis.RegisterClass("Io.Oidis.Commons.LogProcessor.Logger", Logger);
globalThis.RegisterClass("Io.Oidis.Commons.LogProcessor.ILoggerTrace", ILoggerTrace);
//# sourceMappingURL=Logger.js.map