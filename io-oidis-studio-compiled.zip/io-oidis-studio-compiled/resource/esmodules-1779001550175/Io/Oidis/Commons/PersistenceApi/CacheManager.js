/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseHttpResolver } from "../HttpProcessor/Resolvers/BaseHttpResolver.js";
import { Loader } from "../Loader.js";
import { Convert } from "../Utils/Convert.js";
import { Echo } from "../Utils/Echo.js";
import { Property } from "../Utils/Property.js";
import { StorageHandler } from "./Handlers/StorageHandler.js";
/**
 * CacheManager class is providing master management for all storage types.
 */
export class CacheManager extends BaseHttpResolver {
    static clearCookies() {
        if (Loader.getInstance().getHttpManager().getRequest().IsCookieEnabled()) {
            const cookies = Loader.getInstance().getHttpManager().getRequest().getCookies();
            cookies.foreach(($value, $key) => {
                document.cookie = $key + "=; expires=" + Convert.TimeToGMTformat(Property.Time(null, "-1 year"));
            });
        }
        Loader.getInstance().getHttpManager().Refresh();
    }
    static clearStorage() {
        if (StorageHandler.IsSupported()) {
            const items = Loader.getInstance().getHttpManager().getRequest().getStorageItems();
            items.foreach(($value, $key) => {
                localStorage.removeItem($key);
            });
        }
        Loader.getInstance().getHttpManager().Refresh();
    }
    resolver() {
        Echo.Println("<h1>Local cache manager</h1>");
        Echo.Println("<h2>Domain cookies</h2>");
        Echo.Printf(this.getRequest().getCookies());
        Echo.Println("<span style=\"CURSOR: pointer; FONT-SIZE: 10px; COLOR: #BE0000; FONT-FAMILY: Verdana, sans-serif;\" " +
            "onclick=\"" + this.getClassName() + ".clearCookies();\">Clear cookies</span>");
        Echo.Println("<h2>Local storage items</h2>");
        Echo.Printf(this.getRequest().getStorageItems());
        Echo.Println("<span style=\"CURSOR: pointer; FONT-SIZE: 10px; COLOR: #BE0000; FONT-FAMILY: Verdana, sans-serif;\" " +
            "onclick=\"" + this.getClassName() + ".clearStorage();\">Clear storage</span>");
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.PersistenceApi.CacheManager", CacheManager);
//# sourceMappingURL=CacheManager.js.map