import { JsonpFileReader } from "../../IOApi/Handlers/JsonpFileReader.js";
import { ArrayList } from "../../Primitives/ArrayList.js";
import { BaseObject } from "../../Primitives/BaseObject.js";
import { ObjectDecoder } from "../../Utils/ObjectDecoder.js";
import { ObjectEncoder } from "../../Utils/ObjectEncoder.js";
import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { Property } from "../../Utils/Property.js";
import { StringUtils } from "../../Utils/StringUtils.js";
/**
 * BasePersistenceHandler class provides abstract API for handling of persistence resources.
 */
export class BasePersistenceHandler extends BaseObject {
    sessionId;
    variables;
    crcCheckEnabled;
    expireTime;
    currentExpireTime;
    /**
     * @param {string} [$sessionId] If not defined, session is persistent for browser instance
     * (depends on allowed cookies), otherwise it is persistent for server.
     */
    constructor($sessionId) {
        super();
        if (!ObjectValidator.IsEmptyOrNull($sessionId)) {
            this.sessionId = $sessionId;
        }
        else {
            this.sessionId = "";
        }
        this.crcCheckEnabled = true;
    }
    /**
     * @returns {string} Returns session id, which should be used as part of http argument in case of,
     * that session id can not be provided by cookies.
     */
    getSessionId() {
        return this.sessionId;
    }
    /**
     * @returns {number} Returns original or modified value as integer.
     */
    getSize() {
        return 0;
    }
    /**
     * @returns {number} Returns time needed for load.
     */
    getLoadTime() {
        return 0;
    }
    /**
     * @param {Function} $asyncHandler Callback, which should be executed when persistence has been loaded.
     * @param {string} [$sourceFilePath] Specify path to data in expected format, which should be loaded as persistence resource.
     * @returns {void}
     */
    LoadPersistenceAsynchronously($asyncHandler, $sourceFilePath) {
        if (!ObjectValidator.IsEmptyOrNull($sourceFilePath)) {
            JsonpFileReader.Load($sourceFilePath, ($data) => {
                if (!ObjectValidator.IsEmptyOrNull($data)) {
                    ObjectDecoder.Unserialize(ObjectDecoder.Base64($data), ($object) => {
                        this.variables = $object;
                        $asyncHandler();
                    });
                }
                else {
                    $asyncHandler();
                }
            });
        }
        else {
            $asyncHandler();
        }
    }
    /**
     * @returns {void}
     */
    DisableCRC() {
        this.crcCheckEnabled = false;
    }
    /**
     * @param {string|number} [$value] Specify expiration time for data stored in current persistent resource.
     * @returns {number} Returns expiration time in seconds.
     */
    ExpireTime($value) {
        if (ObjectValidator.IsSet($value)) {
            if (!ObjectValidator.IsEmptyOrNull($value)) {
                if (!StringUtils.StartsWith($value, "+") || !StringUtils.StartsWith($value, "-")) {
                    $value = "+" + $value;
                }
                this.expireTime = Property.String(this.expireTime, $value + "");
            }
            else {
                this.expireTime = "";
            }
        }
        return this.getExpireTime();
    }
    /**
     * @param {string|ArrayList<any>} $name Specify variable name, which should be managed.
     * List of variable/values pairs is allowed for ability to store multiple values at once.
     * @param {any} [$value] Specify value, which should be stored.
     * @param {Function} [$asyncHandler] Enable asynchronous load of variable.
     * @returns {any} Returns value associated with variable name, if persistence has been loaded and variable name exists,
     * otherwise null.
     */
    Variable($name, $value, $asyncHandler) {
        if (!ObjectValidator.IsEmptyOrNull($name) && ObjectValidator.IsString($name)) {
            if (ObjectValidator.IsSet($value)) {
                this.addVariable($name, $value);
            }
            return this.variables.getItem($name);
        }
        else {
            return null;
        }
    }
    /**
     * @param {string} $name Key of exists handler in string format, which should be validated.
     * @returns {boolean} Returns true, if key has been mapped, otherwise false.
     */
    Exists($name) {
        return this.variables.KeyExists($name);
    }
    /**
     * Clean up content of  registered handler.
     * @param {string|ArrayList<string>} [$name] Specify variable name or list of variables, which should be destroyed.
     * @returns {void}
     */
    Destroy($name) {
        if (!ObjectValidator.IsEmptyOrNull($name) && ObjectValidator.IsString($name)) {
            this.removeVariable($name);
        }
    }
    /**
     * Clean up resource handled by handler.
     * @returns {void}
     */
    Clear() {
        this.variables = null;
    }
    ToString($prefix = "", $htmlTag = true) {
        if (!ObjectValidator.IsSet(this.variables)) {
            this.variables = new ArrayList();
        }
        return this.variables.ToString($prefix, $htmlTag);
    }
    toString() {
        return this.ToString();
    }
    /**
     * @param {Function} [$asyncHandler] Callback, which should be executed in case of asynchronous data load.
     * @returns {string} Returns raw persistence data synchronously in case of that $asyncHandler has not been specified,
     * otherwise empty string.
     */
    getRawData($asyncHandler) {
        if (!ObjectValidator.IsSet($asyncHandler)) {
            return ObjectEncoder.Serialize(this.variables);
        }
        else {
            ObjectEncoder.Serialize(this.variables, $asyncHandler);
            return "";
        }
    }
    crcEnabled() {
        return this.crcCheckEnabled;
    }
    encode($value, $asyncHandler) {
        if (!ObjectValidator.IsSet($asyncHandler)) {
            return ObjectEncoder.Serialize($value);
        }
        else {
            ObjectEncoder.Serialize($value, $asyncHandler);
            return "";
        }
    }
    decode($value, $asyncHandler) {
        if (!ObjectValidator.IsSet($asyncHandler)) {
            return ObjectDecoder.Unserialize($value);
        }
        else {
            ObjectDecoder.Unserialize($value, $asyncHandler);
            return new ArrayList();
        }
    }
    addVariable($key, $value) {
        this.variables.Add($value, $key);
    }
    removeVariable($key) {
        if (this.variables.KeyExists($key)) {
            this.variables.RemoveAt(this.variables.getKeys().indexOf($key));
        }
    }
    getExpireTime() {
        return this.currentExpireTime = Property.Time(this.currentExpireTime, this.expireTime);
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.PersistenceApi.Handlers.BasePersistenceHandler", BasePersistenceHandler);
//# sourceMappingURL=BasePersistenceHandler.js.map