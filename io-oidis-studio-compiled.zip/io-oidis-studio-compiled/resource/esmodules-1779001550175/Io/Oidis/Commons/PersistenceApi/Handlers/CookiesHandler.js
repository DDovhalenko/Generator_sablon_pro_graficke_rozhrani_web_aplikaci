/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ExceptionsManager } from "../../Exceptions/ExceptionsManager.js";
import { FatalError } from "../../Exceptions/Type/FatalError.js";
import { IllegalArgumentException } from "../../Exceptions/Type/IllegalArgumentException.js";
import { JsonpFileReader } from "../../IOApi/Handlers/JsonpFileReader.js";
import { Loader } from "../../Loader.js";
import { ArrayList } from "../../Primitives/ArrayList.js";
import { Convert } from "../../Utils/Convert.js";
import { ObjectDecoder } from "../../Utils/ObjectDecoder.js";
import { ObjectEncoder } from "../../Utils/ObjectEncoder.js";
import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { Property } from "../../Utils/Property.js";
import { StringUtils } from "../../Utils/StringUtils.js";
import { BasePersistenceHandler } from "./BasePersistenceHandler.js";
/**
 * CookiesHandler class provides API for handling of cookies.
 */
export class CookiesHandler extends BasePersistenceHandler {
    session;
    size;
    loadTime;
    static setCookie(name, value, ttl = 0) {
        let expires = "";
        if (ttl !== 0) {
            expires = " expires=" + Convert.TimeToGMTformat(ttl);
        }
        document.cookie = name + "=" + value + ";" + expires;
    }
    /**
     * @param {string} [$sessionId] If not defined, session id will be generated.
     */
    constructor($sessionId) {
        super($sessionId);
        this.size = 0;
        this.loadTime = 0;
        if (ObjectValidator.IsEmptyOrNull(this.sessionId)) {
            this.sessionId = this.getUID();
        }
    }
    /**
     * @returns {number} Returns original or modified value as integer.
     */
    getSize() {
        return this.size;
    }
    /**
     * @returns {number} Returns time needed for load of the Cookies.
     */
    getLoadTime() {
        return this.loadTime;
    }
    /**
     * @param {Function} $asyncHandler Callback, which should be executed when persistence has been loaded.
     * @param {string} [$sourceFilePath] Specify path to data in expected format, which should be loaded as persistence resource.
     * @returns {void}
     */
    LoadPersistenceAsynchronously($asyncHandler, $sourceFilePath) {
        if (ObjectValidator.IsEmptyOrNull(this.session)) {
            if (!ObjectValidator.IsEmptyOrNull($sourceFilePath)) {
                JsonpFileReader.Load($sourceFilePath, ($data) => {
                    if (!ObjectValidator.IsEmptyOrNull($data)) {
                        ObjectDecoder.Unserialize(ObjectDecoder.Base64($data), ($object) => {
                            this.session = $object;
                            $asyncHandler();
                        });
                    }
                    else {
                        this.initSession($asyncHandler);
                    }
                }, () => {
                    this.initSession($asyncHandler);
                });
            }
            else {
                this.initSession($asyncHandler);
            }
        }
        else {
            $asyncHandler();
        }
    }
    /**
     * @param {string|ArrayList<any>} $name Specify variable name, which should be managed.
     * List of variable/values pairs is allowed for ability to store multiple values at once.
     * @param {any} [$value] Specify value, which should be stored.
     * @param {Function} [$asyncHandler] Enable asynchronous load of variable.
     * @returns {any} Returns value associated with variable name, if persistence has been loaded and variable name exists,
     * otherwise null.
     */
    Variable($name, $value, $asyncHandler) {
        const async = ObjectValidator.IsSet($value) && ObjectValidator.IsSet($asyncHandler);
        this.initSession();
        let updateSession = false;
        if (!ObjectValidator.IsSet($value)) {
            if (ObjectValidator.IsArray($name)) {
                const keys = $name.getKeys();
                const data = $name.getAll();
                let index;
                for (index = 0; index < $name.Length(); index++) {
                    this.addVariable(keys[index], data[index]);
                    updateSession = true;
                }
            }
        }
        else if (ObjectValidator.IsString($name) || ObjectValidator.IsInteger($name)) {
            this.addVariable($name, $value);
            updateSession = true;
        }
        else {
            ExceptionsManager.Throw("CookiesHandler", new IllegalArgumentException("Persistence name is supposed to be type of string or integer"));
        }
        if (updateSession) {
            this.session.Add(this.variables, "variables");
            if (this.crcEnabled()) {
                if (async) {
                    ObjectEncoder.Serialize(this.variables, ($data) => {
                        this.session.Add(StringUtils.getCrc($data), "crc");
                        this.save($asyncHandler);
                    });
                }
                else {
                    this.session.Add(StringUtils.getCrc(ObjectEncoder.Serialize(this.variables)), "crc");
                    this.save();
                }
            }
            else {
                this.save($asyncHandler);
            }
        }
        if ((ObjectValidator.IsString($name) || ObjectValidator.IsInteger($name)) &&
            this.variables.KeyExists($name)) {
            return this.variables.getItem($name);
        }
        else {
            return null;
        }
    }
    /**
     * @param {string} $name Key of exists handler in string format, which should be validated.
     * @returns {boolean} Returns true, if key has been mapped, otherwise false.
     */
    Exists($name) {
        this.initSession();
        return super.Exists($name);
    }
    /**
     * Clean up content of  registered handler.
     * @param {string|ArrayList<string>} [$name] Specify variable name or list of variables, which should be destroyed.
     * @returns {void}
     */
    Destroy($name) {
        if (!ObjectValidator.IsEmptyOrNull($name)) {
            this.initSession();
            let updateSession = false;
            if (ObjectValidator.IsArray($name)) {
                const removeNames = $name.getAll();
                let index;
                for (index = 0; index < removeNames.length; index++) {
                    this.removeVariable(removeNames[index]);
                    updateSession = true;
                }
            }
            else {
                this.removeVariable($name);
                updateSession = true;
            }
            if (updateSession) {
                this.session.Add(this.variables, "variables");
                if (this.crcEnabled()) {
                    this.session.Add(StringUtils.getCrc(ObjectEncoder.Serialize(this.variables)), "crc");
                }
                this.save();
            }
        }
    }
    /**
     * Clean up resource handled by handler.
     * @returns {void}
     */
    Clear() {
        this.remove();
        this.session = null;
        this.variables = null;
        this.initSession();
    }
    toString() {
        this.initSession();
        return this.ToString();
    }
    /**
     * @param {Function} [$asyncHandler] Callback, which should be executed in case of asynchronous data load.
     * @returns {string} Returns raw persistence data synchronously in case of that $asyncHandler has not been specified,
     * otherwise empty string.
     */
    getRawData($asyncHandler) {
        if (!ObjectValidator.IsSet($asyncHandler)) {
            return ObjectEncoder.Serialize(this.session);
        }
        else {
            ObjectEncoder.Serialize(this.session, $asyncHandler);
            return "";
        }
    }
    encode($value, $asyncHandler) {
        if (ObjectValidator.IsSet($asyncHandler)) {
            super.encode($value, ($data) => {
                $asyncHandler(ObjectEncoder.Base64($data, true));
            });
            return "";
        }
        else {
            return ObjectEncoder.Base64(super.encode($value), true);
        }
    }
    decode($value, $asyncHandler) {
        return super.decode(ObjectDecoder.Base64($value), $asyncHandler);
    }
    load() {
        let data = "";
        const cookies = Loader.getInstance().getHttpManager().getRequest().getCookies();
        const sessionId = this.sessionId;
        cookies.foreach(($value, $key) => {
            if (StringUtils.StartsWith($key, sessionId)) {
                data += $value;
            }
        });
        this.size = StringUtils.Length(data);
        return data;
    }
    save($asyncHandler) {
        const sessionId = this.sessionId;
        const saveCookies = ($encoded) => {
            const contentSize = 4 * 1000;
            const cookiesCount = Math.ceil(StringUtils.Length($encoded) / contentSize);
            let index;
            for (index = 0; index < cookiesCount; index++) {
                CookiesHandler.setCookie(sessionId + index, StringUtils.Substring($encoded, index * contentSize, (index + 1) * contentSize), Property.Time(null, "+5 year"));
            }
        };
        if (ObjectValidator.IsSet($asyncHandler)) {
            this.encode(this.session, ($data) => {
                saveCookies($data);
                $asyncHandler();
            });
        }
        else {
            saveCookies(this.encode(this.session));
        }
    }
    remove() {
        const cookies = Loader.getInstance().getHttpManager().getRequest().getCookies();
        const sessionId = this.sessionId;
        cookies.foreach(($value, $key) => {
            if (StringUtils.StartsWith($key, sessionId)) {
                CookiesHandler.setCookie($key, "", Property.Time(null, "-1 year"));
            }
        });
    }
    backup() {
        const cookies = Loader.getInstance().getHttpManager().getRequest().getCookies();
        const sessionId = this.sessionId;
        cookies.foreach(($value, $key) => {
            if (StringUtils.StartsWith($key, sessionId)) {
                CookiesHandler.setCookie(StringUtils.getSha1("back" + $key), $value, Property.Time(null, "+5 year"));
            }
        });
        this.remove();
    }
    initSession($asyncHandler) {
        if (!Loader.getInstance().getHttpManager().getRequest().IsCookieEnabled()) {
            Loader.getInstance().getHttpManager().ReloadTo("/ServerError/Cookies", null, true);
            ExceptionsManager.ThrowExit();
        }
        const setVariables = () => {
            if (ObjectValidator.IsEmptyOrNull(this.variables)) {
                this.variables = this.session.getItem("variables");
            }
            if (!ObjectValidator.IsEmptyOrNull(this.getExpireTime())) {
                if (this.session.KeyExists("ttl") && this.session.getItem("ttl") < new Date().getTime()) {
                    this.remove();
                    this.session.Add(this.getExpireTime(), "ttl");
                    this.session.Add(null, "crc");
                    this.session.Add(new ArrayList(), "variables");
                    this.variables = null;
                    this.initSession($asyncHandler);
                }
                else {
                    this.session.Add(this.getExpireTime(), "ttl");
                }
            }
        };
        if (ObjectValidator.IsEmptyOrNull(this.session)) {
            const startTime = new Date().getTime();
            const session = this.load();
            if (!ObjectValidator.IsEmptyOrNull(session)) {
                const validateCrc = ($values) => {
                    if (this.session.getItem("crc") !== StringUtils.getCrc($values)) {
                        this.backup();
                        ExceptionsManager.Throw("Cookies Handler", new FatalError("Cookies data has been externally changed. " +
                            "We can not trust them, so they has been removed!"));
                    }
                };
                const initData = ($asyncHandler) => {
                    if (this.crcEnabled()) {
                        if (ObjectValidator.IsSet($asyncHandler)) {
                            ObjectEncoder.Serialize(this.session.getItem("variables"), ($data) => {
                                validateCrc($data);
                                this.loadTime = new Date().getTime() - startTime;
                                setVariables();
                                $asyncHandler();
                            });
                        }
                        else {
                            validateCrc(ObjectEncoder.Serialize(this.session.getItem("variables")));
                            this.loadTime = new Date().getTime() - startTime;
                            setVariables();
                        }
                    }
                    else {
                        this.loadTime = new Date().getTime() - startTime;
                        setVariables();
                        if (ObjectValidator.IsSet($asyncHandler)) {
                            $asyncHandler();
                        }
                    }
                };
                if (ObjectValidator.IsSet($asyncHandler)) {
                    this.decode(session, ($decoded) => {
                        this.session = $decoded;
                        initData($asyncHandler);
                    });
                }
                else {
                    this.session = this.decode(session);
                    initData();
                }
            }
            else {
                this.session = new ArrayList();
                this.session.Add(new ArrayList(), "variables");
                this.loadTime = new Date().getTime() - startTime;
            }
        }
        if (!ObjectValidator.IsSet($asyncHandler)) {
            setVariables();
        }
        else if (!ObjectValidator.IsEmptyOrNull(this.session)) {
            $asyncHandler();
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.PersistenceApi.Handlers.CookiesHandler", CookiesHandler);
//# sourceMappingURL=CookiesHandler.js.map