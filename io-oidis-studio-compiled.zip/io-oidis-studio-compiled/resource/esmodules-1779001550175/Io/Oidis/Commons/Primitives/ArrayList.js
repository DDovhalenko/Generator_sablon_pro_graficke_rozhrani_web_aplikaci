/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpResolversCollection } from "../HttpProcessor/HttpResolversCollection.js";
import { Convert } from "../Utils/Convert.js";
import { ObjectValidator } from "../Utils/ObjectValidator.js";
import { StringUtils } from "../Utils/StringUtils.js";
import { BaseObject } from "./BaseObject.js";
/**
 * ArrayList class provides generic manipulation with primitive values or objects.
 */
export class ArrayList extends BaseObject {
    size;
    keys;
    data;
    lastIndex;
    /**
     * @param {any} $input Object for conversion to ArrayList.
     * @returns {ArrayList<any>} Returns ArrayList converted from $input object type of any.
     */
    static ToArrayList($input) {
        const output = new ArrayList();
        if (ObjectValidator.IsArray($input)) {
            if (!($input instanceof ArrayList)) {
                let index;
                let value;
                for (index = 0; index < $input.length; index++) {
                    value = $input[index];
                    if (ObjectValidator.IsArray(value)) {
                        output.Add(this.ToArrayList(value), index);
                    }
                    else {
                        output.Add(value, index);
                    }
                }
            }
            else {
                $input.foreach(($value, $key) => {
                    if (ObjectValidator.IsArray($value)) {
                        output.Add(ArrayList.ToArrayList($value), $key);
                    }
                    else {
                        output.Add($value, $key);
                    }
                });
            }
        }
        else {
            output.Add($input);
        }
        return output;
    }
    /**
     * @param {T} [$value] Set initial array item value.
     * @param {string|number} [$key] Set initial array item key.
     */
    constructor($value, $key) {
        super();
        this.size = 0;
        this.keys = [];
        this.data = [];
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.Add($value, $key);
        }
    }
    /**
     * @param {T} $value Value which should be added/overridden to the array.
     * @param {(string|number)} [$key] Set value key, if not specified key will be generated.
     * @returns {void}
     */
    Add($value, $key) {
        if (ObjectValidator.IsSet($key)) {
            if (!this.KeyExists($key)) {
                this.keys[this.size] = $key;
                this.data[this.size] = $value;
                this.size++;
                if (ObjectValidator.IsDigit($key) && ($key > this.lastIndex)) {
                    this.lastIndex = $key + 1;
                }
            }
            else {
                this.data[this.keys.indexOf($key)] = $value;
            }
        }
        else {
            if (!ObjectValidator.IsSet(this.lastIndex)) {
                let index = this.size - 1;
                while (index >= 0 && !ObjectValidator.IsDigit(this.keys[index])) {
                    index--;
                }
                if (index >= 0) {
                    this.lastIndex = this.keys[index] + 1;
                }
                else {
                    this.lastIndex = 0;
                }
            }
            this.data[this.size] = $value;
            this.keys[this.size] = this.lastIndex;
            this.size++;
            this.lastIndex++;
        }
    }
    /**
     * @returns {(Array<string|number>)} Returns native array of ArrayList keys.
     */
    getKeys() {
        return this.keys;
    }
    /**
     * @param {T} $value Search for this value in the array.
     * @returns {(string|number)} Returns key associated to searched value, if value has been found, otherwise null.
     */
    getKey($value) {
        let index;
        for (index = 0; index < this.size; index++) {
            if (this.data[index] === $value) {
                return this.keys[index];
            }
        }
        return null;
    }
    /**
     * @param {(string|number)} $value Search for this key in the array.
     * @returns {boolean} Returns true, if key has been found, otherwise false.
     */
    KeyExists($value) {
        if (ObjectValidator.IsEmptyOrNull($value)) {
            return false;
        }
        if (!ObjectValidator.IsDigit($value) && !ObjectValidator.IsString($value)) {
            throw new Error("Only string or number type of key is allowed for '" + this.getClassName() + "'" +
                ", passed typeof: " + Convert.ObjectToString($value));
        }
        else {
            return this.keys.includes($value);
        }
    }
    /**
     * @param {T} $value Search for this value in the array.
     * @returns {boolean} Returns true, if the value has been found, otherwise false.
     */
    Contains($value) {
        let index;
        for (index = 0; index < this.size; index++) {
            if (this.data[index] === $value) {
                return true;
            }
        }
        return false;
    }
    /**
     * @param {T} $value Search for this value in the array.
     * @returns {number} Returns index of value in the array, if the value has been found, otherwise -1.
     */
    IndexOf($value) {
        let index;
        for (index = 0; index < this.size; index++) {
            if (this.data[index] === $value) {
                return index;
            }
        }
        return -1;
    }
    /**
     * Fix items indexes based on real item position in the array.
     * @returns {void}
     */
    Reindex() {
        if (this.size > 0) {
            this.lastIndex = 0;
            let index;
            for (index = 0; index < this.size; index++) {
                if (!ObjectValidator.IsString(this.keys[index])) {
                    this.keys[index] = this.lastIndex;
                    this.lastIndex++;
                }
            }
        }
    }
    /**
     * @param {(string|number)} $key Search for this key in the array.
     * @returns {T} Returns value associated with searched key, if the key has been found, otherwise null.
     */
    getItem($key) {
        if (this.KeyExists($key)) {
            return this.data[this.keys.indexOf($key)];
        }
        else {
            return null;
        }
    }
    /**
     * @returns {T} Returns first value in the array, if the array is not empty, otherwise null.
     */
    getFirst() {
        if (!this.IsEmpty()) {
            return this.data[0];
        }
        else {
            return null;
        }
    }
    /**
     * @returns {T} Returns last value in the array, if the array is not empty, otherwise null.
     */
    getLast() {
        if (!this.IsEmpty()) {
            return this.data[this.size - 1];
        }
        else {
            return null;
        }
    }
    /**
     * @returns {Array<T>} Returns native array of values without keys. Array is not sorted by the default.
     */
    getAll() {
        return this.data;
    }
    /**
     * @param {ArrayList<any>} $compareWith Data source for compare with the array.
     * @returns {boolean} Returns true if arrays are equal, otherwise false.
     */
    Equal($compareWith) {
        const keys = $compareWith.getKeys();
        let index;
        for (index = 0; index < keys.length; index++) {
            if (!this.KeyExists(keys[index])) {
                return false;
            }
            else if (this.getItem(keys[index]) !== $compareWith.getItem(keys[index])) {
                return false;
            }
        }
        return true;
    }
    /**
     * @returns {number} Returns length of the array.
     */
    Length() {
        return this.size;
    }
    /**
     * @returns {boolean} Returns true if length of the array is equal to 0, otherwise false.
     */
    IsEmpty() {
        return this.size === 0;
    }
    /**
     * @returns {void}
     */
    Clear() {
        this.data = [];
        this.keys = [];
        this.size = 0;
        this.lastIndex = 0;
    }
    /**
     * @param {ArrayList<T>} $copyFrom Data source for copy of values to the array.
     * @param {number} [$count] Count of values witch will be copied.
     * @param {boolean} [$clearBefore] If true the array will be cleaned up before copy.
     * @returns {void}
     */
    Copy($copyFrom, $count, $clearBefore) {
        let count = 0;
        if ($count && $count > 0) {
            count = $count;
        }
        else {
            count = $copyFrom.Length();
        }
        if ($clearBefore) {
            this.Clear();
        }
        let addIterator = 0;
        const keys = $copyFrom.getKeys();
        let index;
        for (index = 0; index < $copyFrom.Length(); index++) {
            this.Add($copyFrom.getItem(keys[index]), keys[index]);
            addIterator++;
            if (addIterator >= count) {
                break;
            }
        }
    }
    /**
     * @param {number} $index Index of value in the array which should be removed.
     * @returns {void}
     */
    RemoveAt($index) {
        if ($index < this.size) {
            let index;
            let newIndex = 0;
            const data = [];
            const keys = [];
            for (index = 0; index < this.size; index++) {
                if (index !== $index) {
                    data[newIndex] = this.data[index];
                    keys[newIndex] = this.keys[index];
                    newIndex++;
                }
            }
            this.data = data;
            this.keys = keys;
            this.size = newIndex;
        }
    }
    /**
     * Removes last item in the array.
     * @returns {void}
     */
    RemoveLast() {
        this.RemoveAt(this.size - 1);
    }
    /**
     * Sort items by key up.
     * @returns {void}
     */
    SortByKeyUp() {
        let current;
        let next;
        let tmp;
        const length = this.size - 1;
        let index;
        for (index = 0; index < length; index++) {
            current = this.keys[index];
            next = this.keys[index + 1];
            if (current.toString() > next.toString()) {
                tmp = this.data[index];
                this.keys[index] = next;
                this.data[index] = this.data[index + 1];
                this.keys[index + 1] = current;
                this.data[index + 1] = tmp;
                index = -1;
            }
        }
    }
    /**
     * Sort items by key down.
     * @returns {void}
     */
    SortByKeyDown() {
        let current;
        let next;
        let tmp;
        const length = this.size - 1;
        let index;
        for (index = 0; index < length; index++) {
            current = this.keys[index];
            next = this.keys[index + 1];
            if (current.toString() < next.toString()) {
                tmp = this.data[index];
                this.keys[index] = next;
                this.data[index] = this.data[index + 1];
                this.keys[index + 1] = current;
                this.data[index + 1] = tmp;
                index = -1;
            }
        }
    }
    /**
     * Go through all items and process callback function with parameters {value: T, key?: any} on each of them.
     * @param {Function} $handler Callback function for handling of array values.
     * @returns {void}
     */
    foreach($handler) {
        let index;
        for (index = 0; index < this.size; index++) {
            const result = $handler(this.data[index], this.keys[index]);
            if (ObjectValidator.IsBoolean(result) && !result) {
                break;
            }
        }
    }
    /**
     * @returns {Array<T>} Returns native array of values without keys. Method is equal to method getAll.
     */
    ToArray() {
        return this.data;
    }
    /**
     * @returns {object} Return validate object data for serialization.
     */
    SerializationData() {
        return { size: this.size, keys: this.keys, data: this.data };
    }
    /**
     * @param {string} $prefix value converted to string.
     * @param {boolean} $htmlTag Specify, if output format should be HTML or plain text.
     * @returns String of prefix value and HTML tag.
     */
    ToString($prefix = "", $htmlTag = true) {
        let output = "";
        let key;
        let value;
        let index;
        for (index = 0; index < this.size; index++) {
            key = this.keys[index];
            value = this.data[index];
            output += $prefix;
            if (ObjectValidator.IsString(key)) {
                key = "\"" + key + "\"";
            }
            if (value !== null) {
                if (value instanceof ArrayList) {
                    value = value.ToString($prefix + StringUtils.Tab(2, $htmlTag), $htmlTag);
                }
                else if (ObjectValidator.IsArray(value)) {
                    value = Convert.ArrayToString(value, $prefix + StringUtils.Tab(2, $htmlTag), $htmlTag);
                }
                else if (ObjectValidator.IsBoolean(value)) {
                    value = Convert.BooleanToString(value) + StringUtils.NewLine($htmlTag);
                }
                else if (!ObjectValidator.IsString(value)) {
                    if (ObjectValidator.IsClass(value) && value instanceof HttpResolversCollection) {
                        value = value.ToString($prefix, $htmlTag);
                    }
                    else {
                        value = Convert.ObjectToString(value, "", $htmlTag) + StringUtils.NewLine($htmlTag);
                    }
                }
                else if (value === "") {
                    if ($htmlTag) {
                        value += "<b>EMPTY</b>";
                    }
                    else {
                        value += "EMPTY";
                    }
                    value += StringUtils.NewLine($htmlTag);
                }
                else {
                    value += StringUtils.NewLine($htmlTag);
                }
            }
            else {
                value = "NULL" + StringUtils.NewLine($htmlTag);
            }
            output += "[ " + key + " ]" + StringUtils.Space(4, $htmlTag) + value;
        }
        if (StringUtils.IsEmpty(output)) {
            output = $prefix + "Data object ";
            if ($htmlTag) {
                output += "<b>EMPTY</b>";
            }
            else {
                output += "EMPTY";
            }
        }
        if ($htmlTag) {
            output = Convert.ToHtmlContentBlock("<i>" + this.getClassName() + " object</i> ", output);
        }
        else {
            output = this.getClassName() + " object" + StringUtils.NewLine(false) + output;
        }
        return output;
    }
    /**
     * @returns {string} Returns string representation of the ArrayList.
     */
    toString() {
        return this.ToString();
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.Primitives.ArrayList", ArrayList);
//# sourceMappingURL=ArrayList.js.map