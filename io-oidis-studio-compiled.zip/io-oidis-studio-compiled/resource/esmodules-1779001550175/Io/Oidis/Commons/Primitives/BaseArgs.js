/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { SyntaxConstants } from "../Enums/SyntaxConstants.js";
import { Convert } from "../Utils/Convert.js";
import { StringUtils } from "../Utils/StringUtils.js";
import { BaseObject } from "./BaseObject.js";
/**
 * BaseArgs class is abstract class providing automatic convert of whole args to the string.
 */
export class BaseArgs extends BaseObject {
    /**
     * @param {string} [$prefix=""] Prefix for each output line.
     * @param {boolean} [$htmlTag=true] Use HTML tags in output.
     * @returns {string} Returns string representation of all args methods and their values.
     */
    ToString($prefix = "", $htmlTag = true) {
        const methods = this.getMethods();
        let output = "";
        let index;
        for (index = 0; index < methods.length; index++) {
            const methodName = methods[index];
            if (this.toStringFilter(methodName)) {
                let methodValue;
                try {
                    methodValue = this[methodName]();
                }
                catch (ex) {
                    methodValue = Convert.FunctionToString(this[methodName]);
                }
                output += $prefix + "[" + methodName + "] " +
                    Convert.ObjectToString(methodValue, $prefix, $htmlTag) + StringUtils.NewLine($htmlTag);
            }
        }
        return output;
    }
    /**
     * @returns {string} Returns string representation of this args instance.
     */
    toString() {
        return this.ToString();
    }
    toStringFilter($methodName) {
        return ($methodName !== SyntaxConstants.CONSTRUCTOR &&
            $methodName !== "toStringFilter" &&
            $methodName !== "getMethods" &&
            $methodName !== "getProperties" &&
            $methodName !== "SerializationData" &&
            $methodName !== "getUID" &&
            StringUtils.ToLowerCase($methodName) !== StringUtils.ToLowerCase(SyntaxConstants.TO_STRING) &&
            $methodName !== SyntaxConstants.IS_TYPE_OF);
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.Primitives.BaseArgs", BaseArgs);
//# sourceMappingURL=BaseArgs.js.map