/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { SyntaxConstants } from "../Enums/SyntaxConstants.js";
/**
 * BaseEnum class is abstract class providing base methods for reflection of extended enums.
 */
export class BaseEnum {
    static classNamespace = "";
    static className = "";
    /**
     * @returns {string} Returns class name with namespace in string format.
     */
    /* istanbul ignore next: function is running in Reflection Class */
    static ClassName() {
        globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance();
        return this.classNamespace + "." + this.className;
    }
    /**
     * @returns {string} Returns namespace of the class in string format.
     */
    /* istanbul ignore next: function is running in Reflection Class */
    static NamespaceName() {
        globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance();
        return this.classNamespace;
    }
    /**
     * @returns {string} Returns only the class name without namespace in string format.
     */
    /* istanbul ignore next: function is running in Reflection Class */
    static ClassNameWithoutNamespace() {
        globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance();
        return this.className;
    }
    /**
     * @param {any} $value Search this value in the enum
     * @returns {boolean} Returns true if searched value has been found in the enum, otherwise false.
     */
    static Contains($value) {
        const thisClass = globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance().getClass(this.ClassName());
        let parameter;
        for (parameter in thisClass) {
            if (typeof thisClass[parameter] !== SyntaxConstants.FUNCTION && thisClass[parameter] === $value) {
                return true;
            }
        }
        return false;
    }
    /**
     * @returns {string[]} Returns string array of all properties defined by the enum.
     */
    static getProperties() {
        const output = [];
        const thisClass = globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance().getClass(this.ClassName());
        let parameter;
        let index = 0;
        for (parameter in thisClass) {
            if (parameter !== "classNamespace" &&
                parameter !== "className" &&
                thisClass.hasOwnProperty(parameter) &&
                typeof thisClass[parameter] !== SyntaxConstants.FUNCTION) {
                output[index] = parameter;
                index++;
            }
        }
        return output;
    }
    /**
     * @param {any} $value Search this value in the enum
     * @returns {string} Returns property name of first occurrence of desired value in the enum,
     * if value has been defined otherwise null.
     */
    static getKey($value) {
        const thisClass = globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance().getClass(this.ClassName());
        let parameter;
        for (parameter in thisClass) {
            if (typeof thisClass[parameter] !== SyntaxConstants.FUNCTION && thisClass[parameter] === $value) {
                return parameter;
            }
        }
        return null;
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.Primitives.BaseEnum", BaseEnum);
//# sourceMappingURL=BaseEnum.js.map