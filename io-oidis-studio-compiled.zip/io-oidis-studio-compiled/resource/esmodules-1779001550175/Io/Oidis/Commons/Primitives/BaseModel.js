var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { LogSeverity } from "../Enums/LogSeverity.js";
import { IModel } from "../Interfaces/IBaseObject.js";
import { Loader } from "../Loader.js";
import { isBrowser } from "../Utils/EnvironmentHelper.js";
import { JsonUtils } from "../Utils/JsonUtils.js";
import { LogIt } from "../Utils/LogIt.js";
import { ObjectValidator } from "../Utils/ObjectValidator.js";
import { Reflection } from "../Utils/Reflection.js";
import { BaseObject } from "./BaseObject.js";
import { Property } from "./Decorators.js";
/// TODO: implement flush mechanism hooked to change of LCP token,
//        where also property should have secret attribute where it will be not stored/auto-flushed and from BE to FE not send at all
export class BaseModel extends BaseObject {
    /**
     * Sentinel string used to represent an explicit `undefined` value across JSON serialization boundaries.
     * JSON.stringify silently drops `undefined` properties, which loses the "delete this field from DB" intent.
     * Set `preserveUndefined: true` in `ToInterface` or `ToJSON` options to emit this sentinel instead of omitting
     * undefined properties. `SyncWith` automatically converts sentinel values back to `undefined`.
     */
    static UNDEFINED_SENTINEL = "__OIDIS_UNDEFINED__";
    modelProperties;
    context;
    hasSyncedModel;
    saveOptions;
    lastUpdated;
    modelDocument;
    /**
     * @returns {string} Returns database collection name for the model.
     */
    static getCollection() {
        return this.getSymbolicName();
    }
    /**
     * @returns {string} Returns symbolic name for the model based on entity decorator or class name.
     */
    static getSymbolicName() {
        let symbol = this.ClassName();
        const prototype = Reflection.getInstance().getClass(this.ClassName());
        if (prototype.hasOwnProperty("__entitySymbolicName")) {
            symbol = prototype.__entitySymbolicName();
        }
        return symbol.replace(/[._]/g, "");
    }
    /**
     * @param {string} $id Specify document identifier to find.
     * @param {IModelFindOptions} [$options] Specify find options.
     * @returns {Promise<T>} Returns resolved model instance by identifier.
     */
    static async FindById($id, $options) {
        return await Loader.getInstance().getDBDriver().getContextFor(this).FindById($id, $options);
    }
    /**
     * @param {any} $query Specify query filter for searching documents.
     * @param {IModelFindOptions} [$options] Specify find options.
     * @returns {Promise<T[]>} Returns array of resolved model instances matching the query.
     */
    static async Find($query, $options) {
        return await Loader.getInstance().getDBDriver().getContextFor(this).Find($query, $options);
    }
    /**
     * @param {any} $data Specify raw data object to construct model instance from.
     * @returns {Promise<T>} Returns model instance populated with provided data.
     */
    static async From($data) {
        const prototype = this;
        const instance = new prototype();
        instance.document = $data;
        await instance.fromModel({ dataTranslation: true });
        return instance;
    }
    /**
     * @param {any[] | IModelAggregateOptions} $chain Specify aggregation pipeline or options.
     * @param {IModelFindOptions} [$options] Specify find options.
     * @returns {Promise<any>} Returns aggregation result.
     */
    static async Aggregate($chain, $options) {
        return await Loader.getInstance().getDBDriver().getContextFor(this).Aggregate($chain, $options);
    }
    /**
     * @returns {any} Returns underlying database document model.
     */
    static Model() {
        return Loader.getInstance().getDBDriver().getContextFor(this).getDocument();
    }
    constructor() {
        super();
        if (!ObjectValidator.IsEmptyOrNull(Loader.getInstance().getDBDriver())) {
            this.context = Loader.getInstance().getDBDriver().getContextFor(this);
        }
        this.hasSyncedModel = false;
        this.modelProperties = [];
        this.lastUpdated = [];
        if (!ObjectValidator.IsEmptyOrNull(this._modelProperties)) {
            this.modelProperties = this._modelProperties;
        }
        if (!ObjectValidator.IsEmptyOrNull(this._lastUpdated)) {
            this.lastUpdated = this._lastUpdated;
        }
        this.saveOptions = {};
        this.Created = new Date();
        this.LastModified = new Date();
        this.ClassName = this.getClassName();
        for (const property of this.modelProperties) {
            // DO NOT skip "_id" default value initialisation on FE
            if (ObjectValidator.IsSet(property.schemaOptions.type) &&
                property.schemaOptions.type.hasOwnProperty("ClassName") &&
                Reflection.getInstance().Implements(new property.schemaOptions.type(), IModel) &&
                property.schemaOptions.required) {
                if (ObjectValidator.IsSet(property.schemaOptions.default)) {
                    if (!ObjectValidator.IsEmptyOrNull(property.schemaOptions.default)) {
                        this[property.name] = property.schemaOptions.default;
                        LogIt.Warning("Default value from @Property for BaseModel derivative types uses same reference for all instances.");
                    }
                }
                else {
                    // required BaseModel derivatives are constructed with a default constructor, if this behavior is not optimal for
                    // some specific use case, then definition is expected in model constructor.
                    this[property.name] = new property.schemaOptions.type();
                }
            }
            else if (ObjectValidator.IsSet(property.schemaOptions.default)) {
                if (ObjectValidator.IsFunction(property.schemaOptions.default)) {
                    this[property.name] = property.schemaOptions.default();
                }
                else if (ObjectValidator.IsArray(property.schemaOptions.default) && property.schemaOptions.default.length === 0) {
                    this[property.name] = [];
                }
                else if (property.schemaOptions.default instanceof Date) {
                    this[property.name] = new Date(property.schemaOptions.default.getTime());
                }
                else if (!isBrowser && property.schemaOptions.default instanceof Buffer) {
                    this[property.name] = new Buffer(property.schemaOptions.default);
                }
                else if (ObjectValidator.IsObject(property.schemaOptions.default)) {
                    this[property.name] = { ...property.schemaOptions.default };
                }
                else {
                    this[property.name] = property.schemaOptions.default;
                }
            }
        }
        this.attachStringify();
    }
    /**
     * @returns {IObjectProperty[]} Returns array of model property descriptors.
     */
    get Properties() {
        return this.modelProperties;
    }
    get document() {
        if (ObjectValidator.IsEmptyOrNull(this.modelDocument)) {
            this.modelDocument = this.context.CreateDocument(this.getClassName(), this.getSchema(), this.getCollection());
            if (ObjectValidator.IsEmptyOrNull(this.Id)) {
                this.Id = this.modelDocument._id;
            }
        }
        return this.modelDocument;
    }
    set document($value) {
        this.modelDocument = $value;
    }
    /**
     * @returns {BaseDbContext} Returns database context for the model.
     */
    getContext() {
        return this.context;
    }
    /**
     * @param {BaseDbContext} $context Specify database context to assign to the model.
     * @returns {void}
     */
    setContext($context) {
        $context.setModel(this);
        this.context = $context;
    }
    /**
     * @returns {string[]} Returns array of property symbols that were updated since last save.
     */
    getLastUpdated() {
        return this.lastUpdated;
    }
    /**
     * @returns {string} Returns database collection name for the model instance.
     */
    getCollection() {
        return this.constructor.getCollection();
    }
    /**
     * @returns {string} Returns symbolic name for the model instance.
     */
    getSymbolicName() {
        return this.constructor.getSymbolicName();
    }
    /**
     * @returns {any} Returns underlying database document.
     */
    getDocument() {
        return this.document;
    }
    /**
     * @param {IModelSaveOptions} [$options] Specify save options including validation control.
     * @returns {Promise<void>}
     */
    async Save($options) {
        this.saveOptions = JsonUtils.Extend({
            skipValidation: false,
            verbose: true
        }, $options);
        if (!this.saveOptions.skipValidation) {
            if (!this.Validate()) {
                throw new Error("Database model " + this.getClassName() + " property values validation failed.");
            }
        }
        else if (this.saveOptions.verbose) {
            LogIt.Warning("Insecure model " + this.getClassName() + " save due to skipValidation option");
        }
        await this.toModel();
        try {
            await this.context.Save();
            LogIt.Info("Database saved: " + this.getClassName() + " - [" + this.getSymbolicName() +
                "]" + "; " + this.Id, LogSeverity.LOW);
            this.saveOptions.skipValidation = false;
        }
        catch (ex) {
            this.saveOptions.skipValidation = false;
            LogIt.Debug("Database {1} save error: {0}", ex.message, this.getClassNameWithoutNamespace());
            throw ex;
        }
        this.lastUpdated = [];
    }
    /**
     * @param {string} $property Specify property name to update in the database.
     * @returns {Promise<void>}
     */
    async Update($property) {
        if (this.hasSyncedModel) {
            try {
                await this.context.Update($property);
            }
            catch (ex) {
                LogIt.Debug("Database property {0} update error: {1}", $property, ex.message);
                throw ex;
            }
        }
    }
    /**
     * @param {IModelFindOptions} [$options] Specify find options for refresh.
     * @returns {Promise<void>}
     */
    async Refresh($options) {
        if (this.hasSyncedModel) {
            return await this.context.Refresh($options);
        }
    }
    /**
     * @returns {Promise<void>}
     */
    async Delete() {
        this.Deleted = true;
        return await this.Save();
    }
    /**
     * @param {string} [$property] Specify property name to remove from the document.
     * @param {string} [$child] Specify child identifier within the property to remove.
     * @returns {Promise<void>}
     */
    async Remove($property, $child) {
        if (this.hasSyncedModel) {
            try {
                await this.context.Remove($property, $child);
            }
            catch (ex) {
                LogIt.Debug("Database delete item error: {0}", ex.message);
                throw ex;
            }
        }
    }
    /**
     * @param {T} $model Specify source model to synchronize properties from.
     * @returns {void}
     */
    SyncWith($model) {
        if (ObjectValidator.IsEmptyOrNull($model)) {
            return;
        }
        const reflection = Reflection.getInstance();
        for (const prop of this.modelProperties) {
            try {
                let value;
                if (Object.prototype.hasOwnProperty.call($model, prop.fieldKey)) {
                    value = $model[prop.fieldKey];
                }
                else if (Object.prototype.hasOwnProperty.call($model, prop.name)) {
                    value = $model[prop.name];
                }
                else {
                    continue;
                }
                if (value === BaseModel.UNDEFINED_SENTINEL) {
                    value = undefined;
                }
                if (!ObjectValidator.IsEmptyOrNull(this[prop.name]) && reflection.Implements(this[prop.name], IModel)) {
                    if (reflection.IsMemberOf(value, BaseModel)) {
                        this[prop.name] = value;
                    }
                    else {
                        this[prop.name].SyncWith(value);
                    }
                }
                else if (!ObjectValidator.IsEmptyOrNull(value) && ObjectValidator.IsEmptyOrNull(this[prop.name]) &&
                    ObjectValidator.IsSet(prop.schemaOptions.type) &&
                    prop.schemaOptions.type.hasOwnProperty("ClassName") &&
                    reflection.Implements(new prop.schemaOptions.type(), IModel)) {
                    if (reflection.IsMemberOf(value, BaseModel)) {
                        this[prop.name] = value;
                    }
                    else {
                        let modelClassName = null;
                        if (!ObjectValidator.IsEmptyOrNull(value) && !ObjectValidator.IsEmptyOrNull(value.ClassName)) {
                            modelClassName = value.ClassName;
                        }
                        if (ObjectValidator.IsEmptyOrNull(modelClassName) && ObjectValidator.IsSet(prop.schemaOptions.type) &&
                            prop.schemaOptions.type.hasOwnProperty("ClassName")) {
                            modelClassName = prop.schemaOptions.type;
                        }
                        if (ObjectValidator.IsString(modelClassName)) {
                            modelClassName = reflection.getClass(modelClassName);
                        }
                        this[prop.name] = new (modelClassName)();
                        this[prop.name].SyncWith(value);
                    }
                }
                else if (ObjectValidator.IsArray(value)) {
                    if (ObjectValidator.IsArray(prop.schemaOptions.type) &&
                        prop.schemaOptions.type.length >= 1 &&
                        prop.schemaOptions.type[0].hasOwnProperty("ClassName") &&
                        reflection.Implements(new prop.schemaOptions.type[0](), IModel)) {
                        if (ObjectValidator.IsEmptyOrNull(this[prop.name])) {
                            this[prop.name] = [];
                        }
                        const syncedArray = [];
                        value.forEach(($new) => {
                            if (ObjectValidator.IsEmptyOrNull($new)) {
                                syncedArray.push(null);
                            }
                            else if (reflection.IsMemberOf($new, BaseModel)) {
                                syncedArray.push($new);
                            }
                            else {
                                let itemModel = null;
                                this[prop.name].forEach(($current) => {
                                    if ($new.Id === $current.Id) {
                                        itemModel = $current;
                                    }
                                });
                                if (ObjectValidator.IsEmptyOrNull(itemModel)) {
                                    let itemClass = null;
                                    if (!ObjectValidator.IsEmptyOrNull($new.ClassName)) {
                                        itemClass = $new.ClassName;
                                    }
                                    if (ObjectValidator.IsEmptyOrNull(itemClass)) {
                                        itemClass = prop.schemaOptions.type[0];
                                    }
                                    if (ObjectValidator.IsString(itemClass)) {
                                        try {
                                            itemClass = reflection.getClass(itemClass);
                                        }
                                        catch (ex) {
                                            LogIt.Info("Failed to find item class: " + itemClass + " Using default schema type.", LogSeverity.LOW);
                                            itemClass = prop.schemaOptions.type[0];
                                        }
                                    }
                                    itemModel = new (itemClass)();
                                }
                                itemModel.SyncWith($new);
                                syncedArray.push(itemModel);
                            }
                        });
                        this[prop.name] = syncedArray;
                    }
                    else {
                        this[prop.name] = $model[prop.name];
                    }
                }
                else {
                    if (value === null || value === undefined) {
                        this[prop.name] = value;
                    }
                    else if (prop.schemaOptions.type === Date) {
                        this[prop.name] = new Date(value);
                    }
                    else {
                        this[prop.name] = value;
                    }
                }
            }
            catch (ex) {
                LogIt.Error("Sync error for: " + prop.name, ex);
                throw ex;
            }
        }
    }
    /**
     * @returns {this} Returns deep clone of the model instance.
     */
    Clone() {
        const prototype = Reflection.getInstance().getClass(this.getClassName());
        const instance = new prototype();
        instance.SyncWith(this);
        return instance;
    }
    /**
     * Validate model properties for value condition over defined validators. Validation runs by default also for array elements, and
     * this feature could be turned off by noAutoListValidation in model property options to use explicit array validator.
     * @param $property Specify property name, symbol, key or let empty to validate all properties in a model.
     * @param $verbose Specify if model validation should print validation errors.
     * @returns Returns true if value(s) are valid or false when not.
     */
    Validate($property, $verbose = true) {
        return this.ValidateProperties($property, $verbose);
    }
    /**
     * ValidateDeep is similar to Validate, but it returns a list of property symbols of founded issues.
     * @param $property Specify property name, symbol, key or let empty to validate all properties in a model.
     * @param $verbose Specify if model validation should print validation errors.
     * @returns Returns an empty array if value(s) are valid or findings when not.
     */
    ValidateDeep($property, $verbose = true) {
        if (!this.saveOptions.skipValidation) {
            return super.ValidateDeep($property, $verbose);
        }
        else {
            LogIt.Warning("Skipping model " + this.getClassName() + " validation due to skipValidation option");
        }
        return [];
    }
    /**
     * @param {IObjectSerializerOptions} [$options] Specify serialization options.
     * @returns {Promise<any>} Returns serialized model as plain object with async resolution.
     */
    async ToJSON($options) {
        $options = JsonUtils.Extend({ idsOnly: false, expanded: false, preserveUndefined: false }, $options);
        const retVal = {};
        const process = async ($key, $serialized) => {
            if (ObjectValidator.IsArray(this[$key])) {
                const list = [];
                for await (const property of this[$key]) {
                    if (ObjectValidator.IsObject(property) && Reflection.getInstance().Implements(property, IModel)) {
                        list.push($serialized ? await property.ToJSON($options) : property.Id);
                    }
                    else if ($serialized) {
                        list.push(property);
                    }
                }
                return list;
            }
            else if (ObjectValidator.IsObject(this[$key]) && Reflection.getInstance().Implements(this[$key], IModel)) {
                return $serialized ? this[$key].ToJSON($options) : this[$key].Id;
            }
            else {
                return this[$key];
            }
        };
        for await (const property of this.modelProperties) {
            if (!property.modifiers.noJSON) {
                const value = await process(property.fieldKey, ((!property.modifiers.noSerialize || $options.expanded) && !$options.idsOnly));
                retVal[property.name] = (value === undefined && $options.preserveUndefined) ? BaseModel.UNDEFINED_SENTINEL : value;
            }
        }
        return retVal;
    }
    /**
     * @param {IObjectSerializerOptions} [$options] Specify serialization options.
     * @returns {any} Returns serialized model as plain object synchronously.
     */
    ToInterface($options) {
        $options = JsonUtils.Extend({ idsOnly: false, expanded: false, preserveUndefined: false }, $options);
        const retVal = {};
        const process = ($key, $serialized) => {
            if (ObjectValidator.IsArray(this[$key])) {
                const list = [];
                for (const property of this[$key]) {
                    if (ObjectValidator.IsObject(property) && Reflection.getInstance().Implements(property, IModel)) {
                        list.push($serialized ? property.ToInterface($options) : property.Id);
                    }
                    else if ($serialized) {
                        list.push(property);
                    }
                }
                return list;
            }
            else if (ObjectValidator.IsObject(this[$key]) && Reflection.getInstance().Implements(this[$key], IModel)) {
                return $serialized ? this[$key].ToInterface($options) : this[$key].Id;
            }
            else {
                return this[$key];
            }
        };
        for (const property of this.modelProperties) {
            if (!property.modifiers.noJSON) {
                const value = process(property.fieldKey, ((!property.modifiers.noSerialize || $options.expanded) && !$options.idsOnly));
                if (ObjectValidator.IsSet(value)) {
                    retVal[property.name] = value;
                }
                else if (value === undefined && $options.preserveUndefined) {
                    retVal[property.name] = BaseModel.UNDEFINED_SENTINEL;
                }
            }
        }
        return retVal;
    }
    getSchema() {
        return this.context.getSchema();
    }
    /**
     * This method is called from constructor and applies override for native toJSON function which is implicitly called by
     * JSON.stringify(). It is by default connected to BaseModel.ToInterface().
     */
    attachStringify() {
        this.toJSON = () => {
            return this.ToInterface();
        };
    }
    getSaveOptions() {
        return this.saveOptions;
    }
    async toModel() {
        for await (const item of this.modelProperties) {
            let changed = false;
            const tmp = await item.converter.to(this[item.fieldKey], { parent: this, property: item, dataTranslation: false });
            if (!ObjectValidator.IsEmptyOrNull(tmp) || ObjectValidator.IsArray(tmp)) {
                if (ObjectValidator.IsArray(this.document[item.symbol])) {
                    changed = (JSON.stringify(tmp) !== JSON.stringify(this.context.DocumentToObject(item.symbol)));
                }
                else if (ObjectValidator.IsEmptyOrNull(this.document[item.symbol])) {
                    changed = true;
                }
                else {
                    changed = (tmp !== this.document[item.symbol]);
                }
                if (changed) {
                    this.document[item.symbol] = tmp;
                }
            }
            else if (!ObjectValidator.IsEmptyOrNull(this.document[item.symbol]) && tmp === null) {
                this.document[item.symbol] = null;
            }
        }
        this.hasSyncedModel = true;
    }
    async fromModel($options) {
        $options = JsonUtils.Extend({ partial: false, expanded: false, dataTranslation: false }, $options);
        for await (const item of this.modelProperties) {
            if (!item.isInclusion && (item.modifiers.noResolve || $options.partial) && !$options.expanded) {
                // this could be unsafe because it could return a different (native) type of property!
                if (Array.isArray(this.document[item.symbol])) {
                    this[item.fieldKey] = [];
                    for (const doc of this.document[item.symbol]) {
                        this[item.fieldKey].push(doc);
                    }
                }
                else {
                    this[item.fieldKey] = this.document[item.symbol];
                }
            }
            else {
                if (!ObjectValidator.IsEmptyOrNull(this.document) && (!ObjectValidator.IsEmptyOrNull(this.document[item.symbol]) ||
                    ObjectValidator.IsArray(this.document[item.symbol]))) {
                    this[item.fieldKey] = await item.converter.from(this.document[item.symbol], {
                        dataTranslation: ObjectValidator.IsEmptyOrNull($options.dataTranslation) ? false : $options.dataTranslation,
                        parent: this,
                        property: item
                    });
                }
            }
        }
        this.hasSyncedModel = true;
    }
}
__decorate([
    Property({ type: String, symbol: "_id", alias: "id", default: isBrowser ? () => Reflection.UID() : require("uuid").v1 }),
    __metadata("design:type", String)
], BaseModel.prototype, "Id", void 0);
__decorate([
    Property({ type: Boolean, required: false, default: false }),
    __metadata("design:type", Boolean)
], BaseModel.prototype, "Deleted", void 0);
__decorate([
    Property({ type: Date, default: new Date() }),
    __metadata("design:type", Date)
], BaseModel.prototype, "LastModified", void 0);
__decorate([
    Property({ type: Date, default: new Date() }),
    __metadata("design:type", Date)
], BaseModel.prototype, "Created", void 0);
__decorate([
    Property({ type: String, required: false }),
    __metadata("design:type", String)
], BaseModel.prototype, "ClassName", void 0);
// generated-code-start
export const IModelSaveOptions = globalThis.RegisterInterface(["skipValidation", "verbose"]);
export const IModelFindOptions = globalThis.RegisterInterface(["expanded", "partial", "offset", "limit", "sort", "dataTranslation"]);
export const IModelAggregateOptions = globalThis.RegisterInterface(["filterQuery", "resultQuery", "sortQuery"]);
globalThis.RegisterClass("Io.Oidis.Commons.Primitives.BaseModel", BaseModel);
globalThis.RegisterClass("Io.Oidis.Commons.Primitives.IModelSaveOptions", IModelSaveOptions);
globalThis.RegisterClass("Io.Oidis.Commons.Primitives.IModelFindOptions", IModelFindOptions);
globalThis.RegisterClass("Io.Oidis.Commons.Primitives.IModelAggregateOptions", IModelAggregateOptions);
//# sourceMappingURL=BaseModel.js.map