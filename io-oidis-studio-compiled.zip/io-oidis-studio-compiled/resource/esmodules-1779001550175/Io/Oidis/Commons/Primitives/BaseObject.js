/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { SyntaxConstants } from "../Enums/SyntaxConstants.js";
import { IBaseObject } from "../Interfaces/IBaseObject.js";
/**
 * BaseObject class provides helper methods focused on validations and handling of class instance.
 */
export class BaseObject {
    static classNamespace = "";
    static className = "";
    objectNamespace;
    objectClassName;
    /**
     * @returns {string} Returns class name with namespace in string format.
     */
    /* istanbul ignore next: function is called by ClassName and running in Reflection Class */
    static ClassName() {
        globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance();
        return this.classNamespace + "." + this.className;
    }
    /**
     * @returns {string[]} Returns list of classes hierarchy for current class.
     */
    static ClassHierarchy() {
        return globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance().getClassHierarchyOf(this.ClassName());
    }
    /**
     * @returns {string} Returns namespace of the class in string format.
     */
    /* istanbul ignore next: function is running in Reflection Class */
    static NamespaceName() {
        globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance();
        return this.classNamespace;
    }
    /**
     * @returns {string[]} Returns list of namespaces hierarchy for current class.
     */
    static NamespaceHierarchy() {
        return globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance().getNamespaceHierarchyOf(this.ClassName());
    }
    /**
     * @returns {string} Returns only the class name without namespace in string format.
     */
    /* istanbul ignore next: function is running in Reflection Class */
    static ClassNameWithoutNamespace() {
        globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance();
        return this.className;
    }
    /**
     * @returns {string} Returns unique identifier, based on class name and timestamp.
     */
    static UID() {
        return globalThis.Io.Oidis.Commons.Utils.Reflection.UID(this.className);
    }
    /**
     * @param {any} [$dataObject] Data object suitable for data reconstruction.
     * @returns {any} Returns class instance in case of, that data object is suitable for object reconstruction,
     * otherwise null. This method is mainly focused to unserialization purposes, but it can also returns class singleton.
     */
    static getInstance($dataObject) {
        return globalThis.Io.Oidis.Commons.Utils.Reflection.getInstanceOf(this.ClassName(), $dataObject);
    }
    static hashProcessor($input, $cache, $cacheIndex) {
        if ($cache.includes($input)) {
            return "";
        }
        $cache[$cacheIndex] = $input;
        $cacheIndex++;
        let exclude = [];
        if ($input instanceof BaseObject) {
            exclude = $input.excludeIdentityHashData();
        }
        const parameters = [];
        Object.getOwnPropertyNames($input).forEach(($parameter) => {
            if (!parameters.includes($parameter)) {
                parameters.push($parameter);
            }
        });
        let output = "";
        parameters.forEach(($parameter) => {
            if ($input.hasOwnProperty($parameter) && $input[$parameter] !== null && !exclude.includes($parameter)) {
                const type = typeof $input[$parameter];
                if (type !== SyntaxConstants.FUNCTION) {
                    output += $parameter + ":";
                    if (type === SyntaxConstants.OBJECT) {
                        output += BaseObject.hashProcessor($input[$parameter], $cache, $cacheIndex);
                    }
                    else {
                        output += $input[$parameter];
                    }
                    output += ",";
                }
            }
        });
        return output;
    }
    /**
     * @returns {string} Returns unique identifier, based on class name and timestamp.
     */
    getUID() {
        return globalThis.Io.Oidis.Commons.Utils.Reflection.UID(this.getClassName());
    }
    /**
     * @returns {string} Returns class name with namespace for the class instance in string format.
     */
    /* istanbul ignore next: function is called by ClassName and running in Reflection Class */
    getClassName() {
        if (SyntaxConstants.UNDEFINED.includes(this.objectClassName)) {
            this.objectClassName = globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance().getClassName(this);
        }
        if (this.objectClassName === "") {
            this.objectClassName = this[SyntaxConstants.CONSTRUCTOR].toString().match(/function\s(\w*)/)[1];
            this.objectClassName = SyntaxConstants.ALIASES.includes(this.objectClassName) ? "Function" : this.objectClassName;
        }
        return this.objectClassName;
    }
    /**
     * @returns {string[]} Returns list of classes hierarchy for current instance.
     */
    getClassHierarchy() {
        return globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance().getClassHierarchyOf(this);
    }
    /**
     * @returns {string} Returns namespace of the class in string format.
     */
    /* istanbul ignore next: function is running in Reflection Class */
    getNamespaceName() {
        const fullName = this.getClassName();
        return (fullName + "").substring(0, (fullName + "").lastIndexOf("."));
    }
    /**
     * @returns {string[]} Returns list of namespaces hierarchy for current instance.
     */
    getNamespaceHierarchy() {
        return globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance().getNamespaceHierarchyOf(this);
    }
    /**
     * @returns {string} Returns only the class name without namespace in string format.
     */
    /* istanbul ignore next: function is running in Reflection Class */
    getClassNameWithoutNamespace() {
        const fullName = this.getClassName();
        return (fullName + "").substring((this.getNamespaceName() + "").length + 1);
    }
    /**
     * @returns {string[]} Returns string array of all properties in the class instance.
     */
    getProperties() {
        const output = [];
        Object.getOwnPropertyNames(Object.getPrototypeOf(this)).forEach(($parameter) => {
            if (!output.includes($parameter) && typeof this[$parameter] !== SyntaxConstants.FUNCTION) {
                output.push($parameter);
                // console.log("Obj: add property: " + $parameter);
            }
        });
        let parameter;
        for (parameter in this) {
            if (!output.includes(parameter) &&
                typeof this[parameter] !== SyntaxConstants.FUNCTION) {
                output.push(parameter);
                // console.log("Obj: add missing property: " + parameter);
            }
        }
        return output;
    }
    /**
     * @returns {string[]} Returns string array of all methods in the class instance.
     */
    getMethods() {
        const output = [];
        Object.getOwnPropertyNames(Object.getPrototypeOf(this)).forEach(($parameter) => {
            if (!output.includes($parameter) &&
                typeof this[$parameter] === SyntaxConstants.FUNCTION && $parameter !== SyntaxConstants.CONSTRUCTOR) {
                output.push($parameter);
                // console.log("Obj: add method: " + $parameter);
            }
        });
        let parameter;
        for (parameter in this) {
            if (!output.includes(parameter) &&
                typeof this[parameter] === SyntaxConstants.FUNCTION && parameter !== SyntaxConstants.CONSTRUCTOR) {
                output.push(parameter);
                // console.log("Obj: add missing method: " + parameter);
            }
        }
        return output;
    }
    /**
     * @param {ClassName|string} $className Class name for validation.
     * @returns {boolean} Returns true if the class instance is type of $className, otherwise false.
     */
    IsTypeOf($className) {
        return globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance().IsInstanceOf(this, $className);
    }
    /**
     * @param {ClassName|string} $className Class name for validation.
     * @returns {boolean} Returns true if the class instance is type of $className object or it's child, otherwise false.
     */
    IsMemberOf($className) {
        return globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance().IsMemberOf(this, $className);
    }
    /**
     * @param {(Interface|string)} $className Interface class name in string format or as Object, which should be validated.
     * @returns {boolean} Returns true if the class instance implements $className interface, otherwise false.
     */
    Implements($className) {
        return globalThis.Io.Oidis.Commons.Utils.Reflection.getInstance().Implements(this, $className);
    }
    /**
     * @returns {object} Returns data suitable for object serialization.
     */
    SerializationData() {
        const properties = this.getProperties();
        const output = {};
        const exclude = this.excludeSerializationData();
        let index;
        const length = properties.length;
        for (index = 0; index < length; index++) {
            if (!exclude.includes(properties[index])) {
                output[properties[index]] = this[properties[index]];
            }
        }
        return output;
    }
    /**
     * @param  {string} $prefix value converted to String.
     * @param {boolean} $htmlTag Specify, if output format should be HTML or plain text.
     * @returns String of prefix value and HTML tag.
     */
    ToString($prefix = "", $htmlTag = true) {
        return $prefix + "object type of '" + this.getClassName() + "'";
    }
    toString() {
        return this.ToString("", false);
    }
    /**
     * @returns {number} Returns CRC calculated from data, which represents current object.
     */
    getHash() {
        let cacheMap = [];
        const cacheMapIndex = 0;
        const output = globalThis.Io.Oidis.Commons.Utils.StringUtils
            .getCrc(BaseObject.hashProcessor(this, cacheMap, cacheMapIndex));
        cacheMap = null;
        return output;
    }
    /**
     * Validate object properties for value condition over defined validators. Validation runs by default also for array elements, and
     * this feature could be turned off by noAutoListValidation in model property options to use explicit array validator.
     * @param $property Specify property name, symbol, key or let empty to validate all properties in object.
     * @param $verbose Specify if object validation should print validation errors.
     * @returns Returns true if value(s) are valid or false when not.
     */
    ValidateProperties($property, $verbose = true) {
        return globalThis.Io.Oidis.Commons.Utils.ObjectValidator.IsEmptyOrNull(this.ValidateDeep($property, $verbose));
    }
    /**
     * ValidateDeep is similar to Validate, but it returns list of property symbols of founded issues.
     * @param $property Specify property name, symbol, key or let empty to validate all properties in model.
     * @param $verbose Specify if model validation should print validation errors.
     * @returns Returns empty array if value(s) are valid or findings when not.
     */
    ValidateDeep($property, $verbose = true) {
        let findings = [];
        const ObjectValidator = globalThis.Io.Oidis.Commons.Utils.ObjectValidator;
        const LogIt = globalThis.Io.Oidis.Commons.Utils.LogIt;
        if (!ObjectValidator.IsEmptyOrNull(this._modelProperties)) {
            const StringUtils = globalThis.Io.Oidis.Commons.Utils.StringUtils;
            const Reflection = globalThis.Io.Oidis.Commons.Utils.Reflection;
            const validateElement = ($element, $item, $index) => {
                const symbolSuffix = ObjectValidator.IsSet($index) ? "[" + $index + "]" : "";
                let validationStatus = true;
                let isSubModel = false;
                if (ObjectValidator.IsObject($element) &&
                    Reflection.getInstance().Implements($element, IBaseObject)) {
                    findings = findings.concat($element.ValidateDeep(null, $verbose)
                        .map(($record) => $item.symbol + symbolSuffix + "." + $record));
                    isSubModel = true;
                }
                else if (ObjectValidator.IsArray($element) && !$item.noAutoListValidation) {
                    let index = 0;
                    for (const element of $element) {
                        validateElement(element, $item, index);
                        index++;
                    }
                }
                else {
                    validationStatus = $item.validator.validate($element);
                }
                if (!validationStatus) {
                    if ($verbose) {
                        LogIt.Info(">> object validation for " + this.getClassName() + " " +
                            $item.symbol + symbolSuffix + " failed: " + $element);
                    }
                    if (!isSubModel) {
                        findings.push($item.symbol);
                    }
                }
            };
            for (const item of this._modelProperties) {
                if (ObjectValidator.IsEmptyOrNull($property) ||
                    (StringUtils.ContainsIgnoreCase($property, item.symbol, item.name, item.fieldKey))) {
                    validateElement(this[item.fieldKey], item);
                }
            }
        }
        else {
            LogIt.Warning("Skipping object " + this.getClassName() + " validation: no decorated properties found");
        }
        return findings;
    }
    excludeSerializationData() {
        return ["objectNamespace", "objectClassName"];
    }
    excludeIdentityHashData() {
        return [];
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.Primitives.BaseObject", BaseObject);
//# sourceMappingURL=BaseObject.js.map