import { IdentityConverter } from "../DAO/Converters/IdentityConverter.js";
import { ISchemaOptions } from "../Interfaces/IBaseObject.js";
import { JsonUtils } from "../Utils/JsonUtils.js";
import { ObjectValidator } from "../Utils/ObjectValidator.js";
import { PropertyValidator } from "../Utils/PropertyValidator.js";
/**
 * @param {IPropertyOptions} [$options] Specify property schema options for model property definition.
 * @returns {any} Returns property decorator.
 */
export function Property($options) {
    return function ($target, $propertyKey, $descriptor) {
        if (ObjectValidator.IsEmptyOrNull($target._modelProperties)) {
            $target._modelProperties = [];
        }
        else {
            // copy of array causes that actual property will not be written into base
            // and thus also not into different child of the same base class
            $target._modelProperties = $target._modelProperties.slice();
        }
        if (ObjectValidator.IsEmptyOrNull($target._lastUpdated)) {
            $target._lastUpdated = [];
        }
        const fieldKey = "_" + $propertyKey;
        const options = {
            converter: new IdentityConverter(),
            symbol: $propertyKey.charAt(0).toLowerCase() + $propertyKey.slice(1),
            noJSON: false,
            noResolve: false,
            noSerialize: false,
            validator: new PropertyValidator(),
            noAutoListValidation: false,
            addId: false,
            required: true
        };
        if (!ObjectValidator.IsEmptyOrNull($options)) {
            for (const $item in $options) {
                if ($options.hasOwnProperty($item)) {
                    options[$item] = $options[$item];
                }
            }
        }
        const index = $target._modelProperties.findIndex(($item) => {
            return $item.name === $propertyKey;
        });
        if (index < 0) {
            $target._modelProperties.push({
                name: $propertyKey,
                fieldKey,
                symbol: options.symbol,
                converter: options.converter,
                modifiers: {
                    noJSON: options.noJSON,
                    noResolve: options.noResolve,
                    noSerialize: options.noSerialize
                },
                validator: options.validator,
                noAutoListValidation: options.noAutoListValidation,
                schemaOptions: {
                    default: options.default,
                    addId: options.addId,
                    type: options.type,
                    required: options.required,
                    alias: options.alias
                },
                isInclusion: false
            });
        }
        else {
            const item = $target._modelProperties[index];
            item.symbol = options.symbol;
            item.converter = options.converter;
            item.modifiers.noJSON = options.noJSON;
            item.modifiers.noResolve = options.noResolve;
            item.modifiers.noSerialize = options.noSerialize;
            item.validator = options.validator;
            item.noAutoListValidation = options.noAutoListValidation;
            item.schemaOptions.default = options.default;
            item.schemaOptions.addId = options.addId;
            item.schemaOptions.type = options.type;
            item.schemaOptions.required = options.required;
            item.schemaOptions.alias = options.alias;
        }
        return {
            set($value) {
                if (this.hasOwnProperty(fieldKey) && this[fieldKey] !== $value && !this._lastUpdated.includes(options.symbol)) {
                    this._lastUpdated.push(options.symbol);
                }
                this[fieldKey] = $value;
            },
            get() {
                if (options.symbol === "_id") {
                    if (this.document) {
                        // just dummy call of getter to init schema
                    }
                }
                return this[fieldKey];
            },
            configurable: true,
            enumerable: true
        };
    };
}
/**
 * @param {string} [$shortcut] Specify custom symbolic name for the entity collection.
 * @returns {any} Returns class decorator.
 */
export function Entity($shortcut) {
    return function ($target) {
        $target.__entitySymbolicName = () => {
            return ObjectValidator.IsEmptyOrNull($shortcut) ? $target.ClassName() : $shortcut;
        };
    };
}
export function Resolver($linksOrOptions, $altLinksOrOptions, $options) {
    return function ($target, $propertyKey, $descriptor) {
        if (!globalThis.hasOwnProperty("oidisResolvers")) {
            globalThis.oidisResolvers = [];
        }
        $options = JsonUtils.Extend({
            link: "",
            altLinks: [],
            type: ResolverType.UNIVERSAL,
            scope: ResolverScope.ALL_PROFILES,
            forceRegister: false,
            priority: 1
        }, $options);
        if (ObjectValidator.IsString($linksOrOptions)) {
            $options.link = $linksOrOptions;
        }
        else if (ObjectValidator.IsArray($linksOrOptions)) {
            $options.link = $linksOrOptions[0];
            $options.altLinks = $linksOrOptions;
            $options.altLinks.shift();
        }
        else if (!ObjectValidator.IsEmptyOrNull($linksOrOptions)) {
            JsonUtils.Extend($options, $linksOrOptions);
        }
        if (ObjectValidator.IsArray($altLinksOrOptions)) {
            $options.altLinks = $altLinksOrOptions;
        }
        else if (!ObjectValidator.IsEmptyOrNull($altLinksOrOptions)) {
            JsonUtils.Extend($options, $altLinksOrOptions);
        }
        $target.getLink = () => {
            return $options.link;
        };
        $target.getAltLinks = () => {
            return $options.altLinks;
        };
        globalThis.oidisResolvers.push({
            ClassName: () => {
                return $target.ClassName();
            },
            instance: $target,
            options: $options
        });
    };
}
/**
 * @param {...any} $subclasses Specify subclasses to inject into the decorated class.
 * @returns {any} Returns class decorator.
 */
export function Partial(...$subclasses) {
    return function ($target) {
        $target.prototype.isPartial = true;
        if (!globalThis.hasOwnProperty("oidisPartials")) {
            globalThis.oidisPartials = [];
        }
        globalThis.oidisPartials.push({
            ClassName: () => {
                return $target.ClassName();
            },
            instance: $target,
            subclasses: $subclasses
        });
    };
}
export var ResolverType;
(function (ResolverType) {
    ResolverType[ResolverType["UNIVERSAL"] = 0] = "UNIVERSAL";
    ResolverType[ResolverType["BACKEND_ONLY"] = 1] = "BACKEND_ONLY";
    ResolverType[ResolverType["FRONTEND_ONLY"] = 2] = "FRONTEND_ONLY";
})(ResolverType || (ResolverType = {}));
export var ResolverScope;
(function (ResolverScope) {
    ResolverScope[ResolverScope["ALL_PROFILES"] = 0] = "ALL_PROFILES";
    ResolverScope[ResolverScope["PROD"] = 1] = "PROD";
    ResolverScope[ResolverScope["DEV"] = 2] = "DEV";
})(ResolverScope || (ResolverScope = {}));
// generated-code-start
/* eslint-disable */
export const IPropertyOptions = globalThis.RegisterInterface(["symbol", "noJSON", "noSerialize", "validator", "noAutoListValidation", "converter", "noResolve"], ISchemaOptions);
export const IResolverDescriptor = globalThis.RegisterInterface(["ClassName", "instance", "options"]);
export const IResolverOptions = globalThis.RegisterInterface(["link", "altLinks", "type", "scope", "forceRegister", "priority"]);
export const IPartialDescriptor = globalThis.RegisterInterface(["ClassName", "instance", "subclasses"]);
globalThis.RegisterClass("Io.Oidis.Commons.Primitives.IPropertyOptions", IPropertyOptions);
globalThis.RegisterClass("Io.Oidis.Commons.Primitives.IResolverDescriptor", IResolverDescriptor);
globalThis.RegisterClass("Io.Oidis.Commons.Primitives.IResolverOptions", IResolverOptions);
globalThis.RegisterClass("Io.Oidis.Commons.Primitives.IPartialDescriptor", IPartialDescriptor);
//# sourceMappingURL=Decorators.js.map