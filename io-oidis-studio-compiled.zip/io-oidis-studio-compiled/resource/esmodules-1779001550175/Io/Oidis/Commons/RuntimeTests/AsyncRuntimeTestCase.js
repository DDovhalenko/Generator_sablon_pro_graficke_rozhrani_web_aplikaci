var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { RuntimeTestRunner } from "../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { Echo } from "../Utils/Echo.js";
import { Resolver } from "../Primitives/Decorators.js";
let AsyncRuntimeTestCase = class AsyncRuntimeTestCase extends RuntimeTestRunner {
    testCase01() {
        return ($done) => {
            this.getEventsManager().FireAsynchronousMethod(() => {
                Echo.Printf("test case 01");
                $done();
            }, false, 200);
        };
    }
    testCase02() {
        return ($done) => {
            this.getEventsManager().FireAsynchronousMethod(() => {
                Echo.Printf("test case 02");
                $done();
            }, false, 200);
        };
    }
    before() {
        this.addMethod("dynamic01", () => {
            Echo.Printf("dynamic test 01");
        });
        return ($done) => {
            this.addMethod("dynamic02", () => {
                Echo.Printf("dynamic test 02");
            });
            this.getEventsManager().FireAsynchronousMethod(() => {
                this.addMethod("dynamic03", () => {
                    return ($done) => {
                        this.getEventsManager().FireAsynchronousMethod(() => {
                            Echo.Printf("dynamic test 03");
                            $done();
                        }, 500);
                    };
                });
                Echo.Printf("before");
                $done();
            }, false, 200);
        };
    }
    setUp() {
        return ($done) => {
            this.getEventsManager().FireAsynchronousMethod(() => {
                Echo.Printf("set up");
                $done();
            }, false, 200);
        };
    }
    tearDown() {
        return ($done) => {
            this.getEventsManager().FireAsynchronousMethod(() => {
                Echo.Printf("tear down");
                $done();
            }, false, 200);
        };
    }
    after() {
        return ($done) => {
            this.getEventsManager().FireAsynchronousMethod(() => {
                Echo.Printf("after");
                $done();
            }, false, 200);
        };
    }
};
AsyncRuntimeTestCase = __decorate([
    Resolver("/web/AsyncRuntimeTest")
], AsyncRuntimeTestCase);
export { AsyncRuntimeTestCase };
globalThis.RegisterClass("Io.Oidis.Commons.RuntimeTests.AsyncRuntimeTestCase", AsyncRuntimeTestCase);
//# sourceMappingURL=AsyncRuntimeTestCase.js.map