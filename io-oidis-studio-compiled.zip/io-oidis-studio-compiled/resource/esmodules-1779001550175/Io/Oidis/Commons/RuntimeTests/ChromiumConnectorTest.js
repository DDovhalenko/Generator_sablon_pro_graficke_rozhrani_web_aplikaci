var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { RuntimeTestRunner } from "../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { Echo } from "../Utils/Echo.js";
import { WebServiceClientFactory } from "../WebServiceApi/WebServiceClientFactory.js";
import { Resolver } from "../Primitives/Decorators.js";
let ChromiumConnectorTest = class ChromiumConnectorTest extends RuntimeTestRunner {
    testConnect() {
        Echo.Println("Running test chromium connector");
        const client = WebServiceClientFactory.getClient(WebServiceClientType.CEF_QUERY);
        client.Send({ test: "test" }, ($response) => {
            Echo.Printf($response);
        });
        client.Send({ test: "test1" });
        client.Send({ test: "test2" });
    }
};
ChromiumConnectorTest = __decorate([
    Resolver("/web/ChromiumConnectorTest")
], ChromiumConnectorTest);
export { ChromiumConnectorTest };
globalThis.RegisterClass("Io.Oidis.Commons.RuntimeTests.ChromiumConnectorTest", ChromiumConnectorTest);
//# sourceMappingURL=ChromiumConnectorTest.js.map