var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { EventType } from "../Enums/Events/EventType.js";
import { EventArgs } from "../Events/Args/EventArgs.js";
import { ThreadPool } from "../Events/ThreadPool.js";
import { RuntimeTestRunner } from "../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { Echo } from "../Utils/Echo.js";
import { Resolver } from "../Primitives/Decorators.js";
let EventsManagerTest = class EventsManagerTest extends RuntimeTestRunner {
    testSetEvent() {
        this.getEventsManager().setEvent("test", EventType.ON_COMPLETE, ($eventArgs) => {
            Echo.Print($eventArgs.Owner() + " " + $eventArgs.Type());
        });
        this.getEventsManager().FireEvent("test", EventType.ON_START, new EventArgs());
        this.getEventsManager().FireEvent("test", EventType.ON_COMPLETE, new EventArgs());
    }
    testThreadPool() {
        let index = 1;
        ThreadPool.AddThread("test", "incrementer", ($eventArgs) => {
            Echo.Println(index + ". " + $eventArgs.ToString());
            index++;
            if (index === 15) {
                ThreadPool.RemoveThread("test", "incrementer");
            }
        });
        ThreadPool.Execute();
    }
};
EventsManagerTest = __decorate([
    Resolver("/web/EventsManagerTest")
], EventsManagerTest);
export { EventsManagerTest };
globalThis.RegisterClass("Io.Oidis.Commons.RuntimeTests.EventsManagerTest", EventsManagerTest);
//# sourceMappingURL=EventsManagerTest.js.map