var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { ExceptionsManager } from "../Exceptions/ExceptionsManager.js";
import { RuntimeTestRunner } from "../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { Resolver } from "../Primitives/Decorators.js";
let ExceptionsManagerTest = class ExceptionsManagerTest extends RuntimeTestRunner {
    testSetEvent() {
        ExceptionsManager.Throw("test exception", new Error("test exception message"));
    }
};
ExceptionsManagerTest = __decorate([
    Resolver("/web/ExceptionsManagerTest")
], ExceptionsManagerTest);
export { ExceptionsManagerTest };
globalThis.RegisterClass("Io.Oidis.Commons.RuntimeTests.ExceptionsManagerTest", ExceptionsManagerTest);
//# sourceMappingURL=ExceptionsManagerTest.js.map