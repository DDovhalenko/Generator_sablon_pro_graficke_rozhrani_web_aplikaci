var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { BrowserType } from "../Enums/BrowserType.js";
import { RuntimeTestRunner } from "../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { Echo } from "../Utils/Echo.js";
import { Resolver } from "../Primitives/Decorators.js";
let HttpRequestParserTest = class HttpRequestParserTest extends RuntimeTestRunner {
    object;
    testGetUrl() {
        Echo.Println(this.object.getUrl());
    }
    testGetBaseUrl() {
        Echo.Println(this.object.getBaseUrl());
    }
    testGetHostUrl() {
        Echo.Println(this.object.getHostUrl());
    }
    testGetUrlArgs() {
        Echo.Printf(this.object.getUrlArgs());
    }
    testIsOnServer() {
        Echo.Printf(this.object.IsOnServer());
    }
    testGetBrowserType() {
        Echo.Println(BrowserType[this.object.getBrowserType()]);
    }
    testGetBrowserVersion() {
        Echo.Printf(this.object.getBrowserVersion());
    }
    testGetClientIP() {
        Echo.Println(this.object.getClientIP());
    }
    testGetEtags() {
        Echo.Printf(this.object.getEtags());
    }
    testGetLastModifiedTime() {
        Echo.Println(this.object.getLastModifiedTime());
    }
    testGetScriptPath() {
        Echo.Println(this.object.getScriptPath());
    }
    testGetRelativeDirectory() {
        Echo.Println(this.object.getRelativeDirectory());
    }
    testGetRelativeRoot() {
        Echo.Println(this.object.getRelativeRoot());
    }
    testToString() {
        Echo.Println(this.object.ToString());
    }
    setUp() {
        this.object = this.getRequest();
    }
    tearDown() {
        this.object = null;
    }
};
HttpRequestParserTest = __decorate([
    Resolver("/web/HttpRequestParserTest")
], HttpRequestParserTest);
export { HttpRequestParserTest };
globalThis.RegisterClass("Io.Oidis.Commons.RuntimeTests.HttpRequestParserTest", HttpRequestParserTest);
//# sourceMappingURL=HttpRequestParserTest.js.map