var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { RuntimeTestRunner } from "../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { JsonpFileReader } from "../IOApi/Handlers/JsonpFileReader.js";
import { Echo } from "../Utils/Echo.js";
import { ObjectValidator } from "../Utils/ObjectValidator.js";
import { Resolver } from "../Primitives/Decorators.js";
let JsonpFileReaderTest = class JsonpFileReaderTest extends RuntimeTestRunner {
    constructor() {
        super();
        // this.setMethodFilter("testReadFromString");
    }
    testSuccess() {
        return new Promise(($resolve) => {
            JsonpFileReader.Load("https://hub.oidis.io/connector.config.jsonp", ($data, $filePath) => {
                Echo.Printf("success from {1}: {0}", $data, $filePath);
                this.assertEquals(!ObjectValidator.IsEmptyOrNull($data), true);
                $resolve();
            }, ($eventArgs, $filePath) => {
                Echo.Printf("error from {1}: {0}", $eventArgs, $filePath);
                this.assertEquals(false, true);
                $resolve();
            });
        });
    }
    testError() {
        return ($done) => {
            JsonpFileReader.Load("test/resource/data/Io/Oidis/Commons/InvalidData.jsonp", ($data, $filePath) => {
                Echo.Printf("success from {1}: {0}", $data, $filePath);
                this.assertEquals(false, true);
                $done();
            }, ($eventArgs, $filePath) => {
                Echo.Printf("error from {1}: {0}", $eventArgs, $filePath);
                this.assertEquals(true, true);
                $done();
            });
        };
    }
    testTimeout() {
        return ($done) => {
            JsonpFileReader.Load("https://localhost2.oidis.io/io-oidis-hub/Configuration/" +
                "io-oidis-commons/ValidData2", ($data, $filePath) => {
                Echo.Printf("success from {1}: {0}", $data, $filePath);
                this.assertEquals(false, true);
                $done();
            }, ($eventArgs, $filePath) => {
                Echo.Printf("error from {1}: {0}", $eventArgs, $filePath);
                this.assertEquals(true, true);
                $done();
            });
        };
    }
    testDummy() {
        return ($done) => {
            JsonpFileReader.Load("test/resource/data/Io/Oidis/Commons/ValidData2.jsonp", ($data, $filePath) => {
                Echo.Printf("success from {1}: {0}", $data, $filePath);
                this.assertEquals(!ObjectValidator.IsEmptyOrNull($data), true);
                $done();
            }, ($eventArgs, $filePath) => {
                Echo.Printf("error from {1}: {0}", $eventArgs, $filePath);
                this.assertEquals(false, true);
                $done();
            });
        };
    }
    testReadFromString() {
        return ($done) => {
            JsonpFileReader.LoadString("" +
                "JsonpData(\n" +
                "    {\n" +
                "        \"$interface\": \"IBasePageConfiguration\",\n" +
                "        \"title\": \"Oidis Services v{0}\",\n" +
                "        \"loading\": \"Loading, please wait ...\",\n" +
                "        \"loadingProgress\": \"Progress: {0}%\"\n" +
                "    }\n" +
                ");", ($data) => {
                Echo.Printf("success: {0}", $data);
                this.assertEquals(!ObjectValidator.IsEmptyOrNull($data), true);
                $done();
            }, ($eventArgs) => {
                Echo.Printf("error from: {0}", $eventArgs);
                this.assertEquals(false, true);
                $done();
            });
        };
    }
};
JsonpFileReaderTest = __decorate([
    Resolver("/web/JsonpFileReaderTest"),
    __metadata("design:paramtypes", [])
], JsonpFileReaderTest);
export { JsonpFileReaderTest };
globalThis.RegisterClass("Io.Oidis.Commons.RuntimeTests.JsonpFileReaderTest", JsonpFileReaderTest);
//# sourceMappingURL=JsonpFileReaderTest.js.map