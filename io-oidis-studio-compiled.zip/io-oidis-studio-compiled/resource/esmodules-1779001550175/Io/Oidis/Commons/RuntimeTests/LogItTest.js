var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var LogItTest_1;
/*! ******************************************************************************************************** *
 *
 * Copyright 2021-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { LogSeverity } from "../Enums/LogSeverity.js";
import { RuntimeTestRunner } from "../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { HTMLAdapter } from "../LogProcessor/Adapters/HTMLAdapter.js";
import { Logger } from "../LogProcessor/Logger.js";
import { LogIt } from "../Utils/LogIt.js";
import { Resolver } from "../Primitives/Decorators.js";
class PrintObject {
    toString() {
        return "hello from print object";
    }
}
let LogItTest = LogItTest_1 = class LogItTest extends RuntimeTestRunner {
    AllLevelsTest() {
        const logger = new Logger();
        logger.AddAdapter(new HTMLAdapter());
        // logger.setLevels(LogLevel.ALL, LogSeverity.LOW);
        logger.setModes(true, true);
        // logger.setModes(false, true);
        // logger.setModes(true, false);
        LogIt.Init(logger);
        LogIt.Info("Info message");
        LogIt.Info("Info with severity low", LogSeverity.LOW);
        LogIt.Info("Info with severity medium", LogSeverity.MEDIUM);
        LogIt.Info("Info with severity high", LogSeverity.HIGH);
        LogIt.Info("Info with severity and format {0}", LogSeverity.LOW);
        LogIt.Info("Info with parameter same as severity", 2);
        LogIt.Info("Info with parameter same as severity and format {0}", 2, 1);
        LogIt.Info("Info with parameter {0}", -1);
        LogIt.Info("Info message {0} {1}", true, 1);
        LogIt.Warning("Warn message");
        LogIt.Warning("Warn message {0}", 123);
        LogIt.Error(new Error("report native error"));
        LogIt.Error("Error message");
        LogIt.Error("Error with trace", new Error());
        LogIt.Error("Error with params {0}", true);
        LogIt.Debug("Debug message");
        LogIt.Debug(new LogItTest_1());
        LogIt.Debug("Debug message {0}", true);
        LogIt.Verbose("Verbose message");
        LogIt.Verbose("Verbose message {0}", 1235);
    }
};
LogItTest = LogItTest_1 = __decorate([
    Resolver("/web/LogItTest")
], LogItTest);
export { LogItTest };
globalThis.RegisterClass("Io.Oidis.Commons.RuntimeTests.LogItTest", LogItTest);
//# sourceMappingURL=LogItTest.js.map