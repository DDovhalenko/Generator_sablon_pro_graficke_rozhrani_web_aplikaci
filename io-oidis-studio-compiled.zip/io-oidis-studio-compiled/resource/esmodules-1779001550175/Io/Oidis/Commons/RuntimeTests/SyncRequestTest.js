var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { BaseHttpResolver } from "../HttpProcessor/Resolvers/BaseHttpResolver.js";
import { Echo } from "../Utils/Echo.js";
import { Resolver } from "../Primitives/Decorators.js";
let SyncRequestTest = class SyncRequestTest extends BaseHttpResolver {
    resolver() {
        Echo.Printf(this.getEnvironmentArgs());
        Echo.Printf(this.getRequest());
        Echo.Printf(this.RequestArgs());
    }
};
SyncRequestTest = __decorate([
    Resolver("/web/SynchronousRequestTest")
], SyncRequestTest);
export { SyncRequestTest };
globalThis.RegisterClass("Io.Oidis.Commons.RuntimeTests.SyncRequestTest", SyncRequestTest);
//# sourceMappingURL=SyncRequestTest.js.map