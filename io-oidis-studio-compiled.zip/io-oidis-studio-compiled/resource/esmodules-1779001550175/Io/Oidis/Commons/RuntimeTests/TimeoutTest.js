var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { EventType } from "../Enums/Events/EventType.js";
import { TimeoutManager } from "../Events/TimeoutManager.js";
import { RuntimeTestRunner } from "../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { Echo } from "../Utils/Echo.js";
import { Resolver } from "../Primitives/Decorators.js";
let TimeoutTest = class TimeoutTest extends RuntimeTestRunner {
    TimeoutTest() {
        const startTime = new Date().getTime();
        const testObject = { testValue: false };
        let asyncExecutor = new TimeoutManager();
        for (let x = 0; x < 1000; x++) {
            asyncExecutor.Add(($x) => {
                const asyncExecutor2 = new TimeoutManager();
                for (let y = 0; y <= 100; y++) {
                    asyncExecutor2.Add(($y) => {
                        testObject.testValue = $x * $y % 1;
                        if ($x === 999 && $y === 100) {
                            Echo.Printf("async method finish time " + ((new Date().getTime() - startTime) / 1000));
                        }
                    });
                }
                asyncExecutor2.Execute();
                if ($x % 100 === 0) {
                    Echo.Println(".");
                }
                else {
                    Echo.Print(".");
                }
            });
        }
        this.getEventsManager().setEvent(asyncExecutor.getId(), EventType.ON_START, ($eventArgs) => {
            Echo.Printf("async process start for " + $eventArgs.Owner());
        });
        this.getEventsManager().setEvent(asyncExecutor.getId(), EventType.ON_COMPLETE, ($eventArgs) => {
            Echo.Printf("async process finished for " + $eventArgs.Owner());
            asyncExecutor = null;
        });
        asyncExecutor.Execute();
    }
};
TimeoutTest = __decorate([
    Resolver("/web/TimeoutTest")
], TimeoutTest);
export { TimeoutTest };
globalThis.RegisterClass("Io.Oidis.Commons.RuntimeTests.TimeoutTest", TimeoutTest);
//# sourceMappingURL=TimeoutTest.js.map