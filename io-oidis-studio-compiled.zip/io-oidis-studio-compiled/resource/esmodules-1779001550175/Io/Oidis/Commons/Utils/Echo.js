/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IOHandlerType } from "../Enums/IOHandlerType.js";
import { NewLineType } from "../Enums/NewLineType.js";
import { IOHandlerFactory } from "../IOApi/IOHandlerFactory.js";
import { BaseObject } from "../Primitives/BaseObject.js";
import { Convert } from "./Convert.js";
import { ObjectValidator } from "./ObjectValidator.js";
import { StringUtils } from "./StringUtils.js";
/**
 * Echo class provides static API for handling of browser content.
 */
export class Echo extends BaseObject {
    static stream;
    static output;
    static htmlEnabled;
    /**
     * Execute initialization manually, in case of that, it has not been initialized automatically.
     * @param {string|IOHandler} $targetIdOrHandler Set HTML element ID subscribed to echo or
     * specify IOHandler, which should be used for echo.
     * @param {boolean} $forceInit Reload output handler, if needed.
     * @returns {void}
     */
    static Init($targetIdOrHandler, $forceInit = false) {
        if (!ObjectValidator.IsSet(Echo.output) || $forceInit) {
            if (!ObjectValidator.IsSet($targetIdOrHandler)) {
                Echo.output = IOHandlerFactory.getHandler(IOHandlerType.HTML_ELEMENT, "Content");
            }
            else if (ObjectValidator.IsString($targetIdOrHandler)) {
                Echo.output = IOHandlerFactory.getHandler(IOHandlerType.HTML_ELEMENT, $targetIdOrHandler);
            }
            else {
                Echo.output = $targetIdOrHandler;
            }
            Echo.output.Init();
            Echo.htmlEnabled = Echo.getHandlerType() === IOHandlerType.HTML_ELEMENT;
        }
        if (!ObjectValidator.IsSet(Echo.stream) || $forceInit) {
            Echo.stream = "";
        }
    }
    /**
     * @returns {IOHandlerType} Returns currently used Output handler.
     */
    static getHandlerType() {
        return IOHandlerFactory.getHandlerType(Echo.output);
    }
    /**
     * @param {string} $message Print message text to the screen without any modifications.
     * @param {boolean} [$clearBeforePrint=false] Clean up screen content before print if true,
     * otherwise append message to current content.
     * @returns {void}
     */
    static Print($message, $clearBeforePrint = false) {
        if ($clearBeforePrint) {
            Echo.Clear();
        }
        Echo.save($message);
    }
    /**
     * @param {string|any} $messageOrObject Print text or any type of object to the screen.
     * String message has support of string formatting.
     * @param {...any} $parameters Open-ended args for search in message string, if arg is not typeof string it will
     * be converted to string.
     * @returns {void}
     */
    static Printf($messageOrObject, ...$parameters) {
        if (ObjectValidator.IsSet($parameters) && ObjectValidator.IsString($messageOrObject)) {
            const args = [$messageOrObject];
            let index;
            for (index = 0; index < $parameters.length; index++) {
                args[index + 1] = Convert.ObjectToString($parameters[index], "", Echo.htmlEnabled);
            }
            Echo.Println(StringUtils.Format.apply(String, args));
        }
        else {
            Echo.Println(Convert.ObjectToString($messageOrObject, "", Echo.htmlEnabled));
        }
    }
    /**
     * @param {string} $message Print message to the screen at new line.
     * @returns {void}
     */
    static Println($message) {
        Echo.Print((Echo.htmlEnabled ? NewLineType.HTML : NewLineType.LINUX) + $message);
    }
    /**
     * @param {string} $message Print message with escaped html to the screen at new line.
     * @returns {void}
     */
    static PrintCode($message) {
        $message = StringUtils.Replace($message, "<", "&lt;");
        $message = StringUtils.Replace($message, ">", "&gt;");
        Echo.Println("<pre>" + $message + "</pre>");
    }
    /**
     * Clean up screen content.
     * @returns {void}
     */
    static Clear() {
        Echo.Init();
        Echo.output.Clear();
    }
    /**
     * Clean up screen content and also content stream.
     * @returns {void}
     */
    static ClearAll() {
        Echo.Clear();
        Echo.stream = "";
    }
    /**
     * @returns {string} Returns whole content stream printed by Echo, from last clean up.
     */
    static getStream() {
        return Echo.stream;
    }
    /**
     * @param {Function} $handler Callback, which should be called in time on message print.
     * @returns {void}
     */
    static setOnPrint($handler) {
        Echo.Init();
        Echo.output.setOnPrint($handler);
    }
    static save($message) {
        Echo.Init();
        Echo.stream += $message;
        Echo.output.Print($message);
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.Utils.Echo", Echo);
//# sourceMappingURL=Echo.js.map