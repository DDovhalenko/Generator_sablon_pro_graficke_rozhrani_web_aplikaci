/*! ******************************************************************************************************** *
 *
 * Copyright 2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
const isBrowser = globalThis.isBrowser;
const buildTime = globalThis.buildTime;
const appExceptionHandler = globalThis.appExceptionHandler;
export { isBrowser, buildTime, appExceptionHandler };
//# sourceMappingURL=EnvironmentHelper.js.map