import { ArrayList } from "../Primitives/ArrayList.js";
import { BaseObject } from "../Primitives/BaseObject.js";
import { Convert } from "./Convert.js";
import { isBrowser } from "./EnvironmentHelper.js";
import { LogIt } from "./LogIt.js";
import { ObjectValidator } from "./ObjectValidator.js";
import { StringUtils } from "./StringUtils.js";
export class JsonUtils extends BaseObject {
    /**
     * @param {object} $parent Specify data object, which should be extended.
     * @param {object} $child Specify data object, which should be used for parent override and extend.
     * @returns {object} Returns extended data object.
     */
    static Extend($parent, $child) {
        const extend = ($parent, $child) => {
            let property;
            let value;
            for (property in $child) {
                if ($child.hasOwnProperty(property)) {
                    value = $child[property];
                    if (!$parent.hasOwnProperty(property)) {
                        $parent[property] = value;
                    }
                    else {
                        if (ObjectValidator.IsObject(value) && ObjectValidator.IsObject($parent[property])) {
                            extend($parent[property], value);
                        }
                        else {
                            $parent[property] = value;
                        }
                    }
                }
            }
        };
        if (ObjectValidator.IsEmptyOrNull($parent)) {
            $parent = {};
        }
        if (ObjectValidator.IsEmptyOrNull($child)) {
            $child = {};
        }
        extend($parent, $child);
        return $parent;
    }
    /**
     * @param {object} $source Specify data object, which should be cloned.
     * @returns {object} Returns clone of the source data object based on JSON functionally.
     */
    static Clone($source) {
        if (ObjectValidator.IsEmptyOrNull($source)) {
            return $source;
        }
        return JSON.parse(JSON.stringify($source));
    }
    /**
     * @param {object} $source Specify data object, which should be deeply cloned.
     * @param {boolean} [$withReferences=true] Specify if cloned object should respect properties references.
     * @param {boolean} [$withRefSymbols=true] Specify if referenced properties should be replaced by symbols.
     * @returns {object} Returns deep clone of the source data object based on recursion functions.
     */
    static DeepClone($source, $withReferences = true, $withRefSymbols = true) {
        let cache = [];
        let refs = [];
        let clones = new ArrayList();
        const deepClone = ($source, $clone, $parentKey) => {
            if (ObjectValidator.IsSet($source.hasOwnProperty)) {
                let property;
                let value;
                for (property in $source) {
                    if ($source.hasOwnProperty(property)) {
                        const key = $parentKey + "/" + property;
                        value = $source[property];
                        const cacheIndex = cache.indexOf(value);
                        if (cacheIndex === -1) {
                            if (ObjectValidator.IsNativeArray(value)) {
                                $clone[property] = [];
                                let index;
                                for (index = 0; index < value.length; index++) {
                                    if (ObjectValidator.IsObject(value[index])) {
                                        $clone[property][index] = {};
                                        deepClone(value[index], $clone[property][index], key + "/" + index);
                                    }
                                    else if (ObjectValidator.IsNativeArray(value[index])) {
                                        $clone[property][index] = [];
                                        deepClone(value[index], $clone[property][index], key + "/" + index);
                                    }
                                    else {
                                        $clone[property][index] = value[index];
                                    }
                                }
                            }
                            else if (value instanceof Date) {
                                $clone[property] = new Date(value);
                            }
                            else if (ObjectValidator.IsObject(value)) {
                                cache.push(value);
                                $clone[property] = {};
                                clones.Add({
                                    key,
                                    value: $clone[property]
                                }, cache.length - 1);
                                deepClone(value, $clone[property], key);
                            }
                            else {
                                $clone[property] = value;
                            }
                        }
                        else {
                            $clone[property] = {};
                            refs.push({
                                key,
                                ref: cacheIndex,
                                value: $clone[property]
                            });
                        }
                    }
                }
            }
        };
        const clone = {};
        deepClone($source, clone, "#");
        let index;
        const refsLength = refs.length;
        for (index = 0; index < refsLength; index++) {
            let value;
            try {
                const clone = clones.getItem(refs[index].ref);
                if (!ObjectValidator.IsEmptyOrNull(clone)) {
                    if ($withReferences) {
                        value = clone.value;
                    }
                    else if (!$withRefSymbols) {
                        value = JSON.parse(JSON.stringify(clone.value));
                    }
                    else {
                        value = {
                            $ref: clone.key
                        };
                    }
                }
                else {
                    value = null;
                }
                this.Extend(refs[index].value, value);
            }
            catch (ex) {
                LogIt.Warning("Failed to process reference: " + refs[index].key);
            }
        }
        cache = null;
        refs = null;
        clones = null;
        return clone;
    }
    /**
     * @param {object} $source Specify data object, in which should be resolved properties referenced by symbols.
     * @returns {object} Returns resolved data object.
     */
    static ParseRefSymbols($source) {
        const getRef = ($key) => {
            const keys = StringUtils.Split(StringUtils.Remove($key, "#/"), "/");
            let output = $source;
            let resolved = true;
            keys.forEach(($key) => {
                if (output.hasOwnProperty($key)) {
                    output = output[$key];
                }
                else {
                    resolved = false;
                }
            });
            if (resolved) {
                return output;
            }
            LogIt.Warning("Failed to resolve reference: " + $key);
            return {
                $ref: $key
            };
        };
        const traverse = ($source, $parentKey) => {
            let property;
            let value;
            for (property in $source) {
                if ($source.hasOwnProperty(property)) {
                    value = $source[property];
                    if (ObjectValidator.IsNativeArray(value)) {
                        let index;
                        for (index = 0; index < value.length; index++) {
                            if (ObjectValidator.IsObject(value[index]) || ObjectValidator.IsNativeArray(value[index])) {
                                traverse(value[index], $parentKey + "/" + property + "/" + index);
                            }
                        }
                    }
                    else if (ObjectValidator.IsObject(value)) {
                        if (!ObjectValidator.IsEmptyOrNull(value.$ref)) {
                            $source[property] = getRef(value.$ref);
                        }
                        else {
                            traverse(value, $parentKey + "/" + property);
                        }
                    }
                }
            }
        };
        traverse($source, "#");
        return $source;
    }
    /**
     * @param {object} $source Specify data object, which should be converted to JSONP format.
     * @param {IClassName} [$interface] Specify custom interface for which will be appended by static Data method.
     * @param {IClassName[]} [$imports] Specify array of classes, which will be used as imports for JSONP content.
     * @returns {string} Returns string in JSONP format.
     */
    static ToJsonp($source, $interface, $imports) {
        let imports = "";
        if (!ObjectValidator.IsEmptyOrNull($imports)) {
            $imports.forEach(($import) => {
                imports += "var " + $import.ClassNameWithoutNamespace() + " = " + $import.ClassName() + ";\n";
            });
            imports += "\n";
        }
        let scope;
        if (ObjectValidator.IsEmptyOrNull($interface)) {
            scope = "JsonpData";
        }
        else {
            scope = $interface.ClassName() + ".Data";
        }
        const serialize = ($input, $prefix) => {
            let output = "";
            let property;
            for (property in $input) {
                if ($input.hasOwnProperty(property)) {
                    if (!ObjectValidator.IsEmptyOrNull(output)) {
                        output += ",\n";
                    }
                    if (ObjectValidator.IsObject($input[property])) {
                        output += $prefix + property + ": " + serialize($input[property], $prefix + "   ");
                    }
                    else if (ObjectValidator.IsFunction($input[property])) {
                        output += $prefix + property + ": " + Convert.FunctionToString($input[property]);
                    }
                    else {
                        output += $prefix + property + ": " + $input[property];
                    }
                }
            }
            return "{\n" + output + "\n}";
        };
        return imports + scope + "(" + serialize($source, "    ") + ");\n";
    }
    /**
     * @param {any} $value Specify data object to convert to JSON string.
     * @param {string} [$prefix] Specify prefix for the output string.
     * @param {boolean} [$htmlTag=true] Specify if output format should be HTML or plain text.
     * @returns {string} Returns JSON string representation of the value.
     */
    static ToString($value, $prefix = "", $htmlTag = true) {
        return $prefix + JSON.stringify($value, null, 2);
    }
    /**
     * @param {object} $value Specify data object, which should be sorted by keys. Array items order is untouched only array object
     * internal properties will be sorted.
     * @returns {object} Returns sorted JSON object.
     */
    static Sort($value) {
        let index = 0;
        if (ObjectValidator.IsEmptyOrNull($value)) {
            return $value;
        }
        else if (ObjectValidator.IsSet($value.forEach)) {
            for (index; index < $value.length; index++) {
                $value[index] = this.Sort($value[index]);
            }
            return $value;
        }
        else if (typeof $value !== "object") {
            return $value;
        }
        let keys = Object.keys($value);
        if (keys.length === 0) {
            return $value;
        }
        keys = keys.sort();
        const newObject = {};
        for (index = 0; index < keys.length; index++) {
            newObject[keys[index]] = this.Sort($value[keys[index]]);
        }
        return newObject;
    }
    /**
     * @param {any} $input Specify data object or string to convert to binary buffer.
     * @returns {ArrayBuffer} Returns binary representation of the input with embedded buffer support.
     */
    static ToBuffer($input) {
        const enc = new TextEncoder(); // always utf-8
        if (ObjectValidator.IsString($input)) {
            const output = enc.encode($input);
            if (!isBrowser) {
                return Buffer.from(output);
            }
            return output;
        }
        const buffers = [];
        const outputObject = {};
        const converted = [];
        const copyElement = ($source, $target, $propName) => {
            const isArrayTarget = ObjectValidator.IsArray($target[$propName]);
            if (ObjectValidator.IsEmptyOrNull($source)) {
                const value = ObjectValidator.IsNativeArray($source) ? [] : ObjectValidator.IsString($source) ? "" : null;
                if (isArrayTarget) {
                    $target[$propName].push(value);
                }
                else {
                    $target[$propName] = value;
                }
            }
            else if (ObjectValidator.IsSet($source.ToInterface)) {
                const value = { __instanceOf__: "BaseModel", class: $source.getClassName(), value: $source.ToInterface() };
                if (isArrayTarget) {
                    $target[$propName].push(value);
                }
                else {
                    $target[$propName] = value;
                }
            }
            else if ($source instanceof Date) {
                const value = { __instanceOf__: "Date", value: $source.getTime() };
                if (isArrayTarget) {
                    $target[$propName].push(value);
                }
                else {
                    $target[$propName] = value;
                }
            }
            else if ($source instanceof ArrayBuffer ||
                $source instanceof Uint8Array ||
                !ObjectValidator.IsEmptyOrNull($source.byteLength)) {
                const id = "<__buffer__#" + this.UID() + ">";
                buffers.push({ id, data: $source });
                if (isArrayTarget) {
                    $target[$propName].push(id);
                }
                else {
                    $target[$propName] = id;
                }
            }
            else if (ObjectValidator.IsArray($source)) {
                if (isArrayTarget) {
                    const targetObject = { arrayCopy: [] };
                    $source.forEach(($element) => {
                        copyElement($element, targetObject, "arrayCopy");
                    });
                    $target[$propName].push(targetObject.arrayCopy);
                }
                else {
                    $target[$propName] = [];
                    $source.forEach(($element) => {
                        copyElement($element, $target, $propName);
                    });
                }
            }
            else if (ObjectValidator.IsObject($source) && ObjectValidator.IsSet($source.hasOwnProperty)) {
                if (converted.includes($source)) {
                    if (isArrayTarget) {
                        $target[$propName].push("<__reference__#" + converted.indexOf($source) + ">");
                    }
                    else {
                        $target[$propName] = "<__reference__#" + converted.indexOf($source) + ">";
                    }
                }
                else {
                    const targetElement = {};
                    if (isArrayTarget) {
                        $target[$propName].push(targetElement);
                    }
                    else {
                        $target[$propName] = targetElement;
                    }
                    traverse($source, targetElement);
                }
            }
            else {
                if (isArrayTarget) {
                    $target[$propName].push($source);
                }
                else {
                    $target[$propName] = $source;
                }
            }
        };
        const traverse = ($source, $target) => {
            if (converted.includes($source)) {
                return;
            }
            converted.push($source);
            let property;
            for (property in $source) {
                if ($source.hasOwnProperty(property)) {
                    copyElement($source[property], $target, property);
                }
            }
        };
        traverse($input, outputObject);
        const concat = ($input) => {
            let length = 0;
            for (const item of $input) {
                length += item.byteLength;
            }
            const output = new Uint8Array(length);
            let offset = 0;
            for (const item of $input) {
                const uint8view = new Uint8Array(item.buffer, item.byteOffset, item.byteLength);
                output.set(uint8view, offset);
                offset += uint8view.byteLength;
            }
            return output;
        };
        const inputBuffer = enc.encode(JSON.stringify(outputObject));
        const header = {
            buffers: [],
            dataSize: inputBuffer.byteLength
        };
        const data = [];
        buffers.forEach(($buffer) => {
            header.buffers.push({ id: $buffer.id, size: $buffer.data.byteLength });
            data.push($buffer.data);
        });
        const headerBuffer = enc.encode(JSON.stringify(header));
        const headerSize = new Uint8Array(4);
        const view = new DataView(headerSize.buffer);
        view.setUint32(0, headerBuffer.byteLength);
        const output = concat([headerSize, headerBuffer, inputBuffer].concat(...data));
        if (!isBrowser) {
            return Buffer.from(output);
        }
        return output;
    }
    /**
     * @param {ArrayBuffer} $input Specify binary buffer to convert back to JSON object.
     * @returns {any} Returns deserialized data object from binary buffer.
     */
    static ToJson($input) {
        const dec = new TextDecoder("utf-8");
        let offset = 4;
        const inputBuffer = $input;
        if (!($input instanceof ArrayBuffer) && ObjectValidator.IsSet(inputBuffer.length)) {
            const arrayBuffer = new ArrayBuffer(inputBuffer.length);
            const view = new Uint8Array(arrayBuffer);
            for (let i = 0; i < inputBuffer.length; ++i) {
                view[i] = $input[i];
            }
            $input = arrayBuffer;
        }
        const view = new DataView($input);
        let size = view.getUint32(0);
        let header = null;
        try {
            header = JSON.parse(dec.decode($input.slice(offset, offset + size)));
        }
        catch (ex) {
            // Fallback conversion of non-JSON inputs
            return dec.decode($input);
        }
        offset += size;
        size = header.dataSize;
        const data = JSON.parse(dec.decode($input.slice(offset, offset + size)));
        offset += size;
        const buffers = {};
        header.buffers.forEach(($info) => {
            size = $info.size;
            buffers[$info.id] = $input.slice(offset, offset + size);
            offset += size;
        });
        const references = [];
        const refPaths = [];
        const convert = ($item) => {
            if (ObjectValidator.IsArray($item)) {
                traverse($item);
            }
            else if (ObjectValidator.IsObject($item)) {
                if ($item.hasOwnProperty("__instanceOf__")) {
                    if ($item.__instanceOf__ === "Date") {
                        return new Date($item.value);
                    }
                    else if ($item.__instanceOf__ === "BaseModel") {
                        return $item;
                    }
                    else {
                        LogIt.Warning("Unrecognized type of instance: " + $item.__instanceOf__);
                        return $item.value;
                    }
                }
            }
            else if (ObjectValidator.IsString($item) && StringUtils.PatternMatched("<__buffer__#*>", $item)) {
                return buffers[$item];
            }
            else if (ObjectValidator.IsString($item) && StringUtils.PatternMatched("<__reference__#*>", $item)) {
                return references[refPaths.indexOf($item)];
            }
            return $item;
        };
        const processConvert = ($element) => {
            const converted = convert($element);
            if (!StringUtils.PatternMatched("<__reference__#*>", $element) &&
                ObjectValidator.IsObject(converted) &&
                !ObjectValidator.IsSet(converted.__instanceOf__) &&
                !(converted instanceof Date) && !(converted instanceof ArrayBuffer)) {
                traverse($element);
                return $element;
            }
            else if (!ObjectValidator.IsEmptyOrNull(converted) && converted.hasOwnProperty("__instanceOf__")) {
                return converted.value;
            }
            else {
                return converted;
            }
        };
        const traverse = ($input) => {
            if (ObjectValidator.IsObject($input) &&
                !ObjectValidator.IsSet($input.__instanceOf__) &&
                !references.includes($input)) {
                refPaths.push("<__reference__#" + references.length + ">");
                references.push($input);
            }
            if (ObjectValidator.IsArray($input)) {
                $input.forEach(($element, $index) => {
                    $input[$index] = processConvert($element);
                });
            }
            else {
                let property;
                for (property in $input) {
                    if ($input.hasOwnProperty(property)) {
                        if (ObjectValidator.IsArray($input[property])) {
                            $input[property].forEach(($element, $index) => {
                                $input[property][$index] = processConvert($element);
                            });
                        }
                        else {
                            $input[property] = processConvert($input[property]);
                        }
                    }
                }
            }
        };
        traverse(data);
        return data;
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.Utils.JsonUtils", JsonUtils);
//# sourceMappingURL=JsonUtils.js.map