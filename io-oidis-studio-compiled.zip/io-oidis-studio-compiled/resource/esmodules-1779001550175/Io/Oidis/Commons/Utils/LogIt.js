import { LogSeverity } from "../Enums/LogSeverity.js";
import { Logger } from "../LogProcessor/Logger.js";
import { BaseObject } from "../Primitives/BaseObject.js";
import { ObjectValidator } from "./ObjectValidator.js";
/**
 * LogIt class provides static API for logging to selected output handler.
 */
export class LogIt extends BaseObject {
    static logger;
    /**
     * Execute initialization manually, in case of that, it has not been initialized automatically.
     * @param {Logger|LogLevel} $logger Set processor for handling of log message or specify log level for default processor.
     * @returns {void}
     */
    static Init($logger) {
        if (!ObjectValidator.IsEmptyOrNull($logger)) {
            if (ObjectValidator.IsInteger($logger)) {
                LogIt.getLogger().setLevels($logger, LogSeverity.HIGH);
            }
            else {
                LogIt.logger = $logger;
                LogIt.logger.setTrackBackEntryPoint(LogIt);
            }
        }
    }
    /**
     * @param {LogLevel} $level Set maximal level, which will be allowed for output.
     * @param {LogSeverity} [$severity] Set minimal level, which will be allowed for Info log.
     * @returns {void}
     */
    static setLevel($level, $severity) {
        LogIt.getLogger().setLevels($level, $severity);
    }
    /**
     * Turn off/on print of messages.
     * @returns {void}
     */
    static MuteToggle() {
        LogIt.getLogger().MuteToggle();
    }
    static Info($message, ...$parameters) {
        LogIt.getLogger().Info.apply(LogIt.getLogger(), [$message].concat($parameters)); // eslint-disable-line
    }
    /**
     * Log message at Warning level.
     * @param {string} $message Message which should be logged and may contains format symbols.
     * @param {...any} [$parameters] Open-ended args for formatted message.
     * @returns {void}
     */
    static Warning($message, ...$parameters) {
        LogIt.getLogger().Warning.apply(LogIt.getLogger(), [$message].concat($parameters)); // eslint-disable-line
    }
    static Error($message, ...$parameters) {
        LogIt.getLogger().Error.apply(LogIt.getLogger(), [$message].concat($parameters)); // eslint-disable-line
    }
    static Debug($messageOrObject, ...$parameters) {
        LogIt.getLogger().Debug.apply(LogIt.getLogger(), [$messageOrObject].concat($parameters)); // eslint-disable-line
    }
    /**
     * Log message at Verbose level.
     * @param {string} $message Message which should be logged and contains format symbols.
     * @param {...any} [$parameters] Open-ended args for formatted message.
     * @returns {void}
     */
    static Verbose($message, ...$parameters) {
        LogIt.getLogger().Verbose.apply(LogIt.getLogger(), [$message].concat($parameters)); // eslint-disable-line
    }
    /**
     * @returns {Logger} Returns logger instance singleton.
     */
    static getLogger() {
        if (ObjectValidator.IsEmptyOrNull(LogIt.logger)) {
            LogIt.logger = new Logger();
            LogIt.logger.setTrackBackEntryPoint(LogIt);
        }
        LogIt.getLogger = () => {
            return LogIt.logger;
        };
        return LogIt.logger;
    }
}
globalThis.Io.Oidis.Commons.Utils.LogIt = LogIt;
globalThis.RegisterClass("Io.Oidis.Commons.Utils.LogIt", LogIt);
//# sourceMappingURL=LogIt.js.map