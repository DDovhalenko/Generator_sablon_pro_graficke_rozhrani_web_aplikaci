/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "../Enums/Events/EventType.js";
import { EventsManager } from "../Events/EventsManager.js";
import { TimeoutManager } from "../Events/TimeoutManager.js";
import { ExceptionsManager } from "../Exceptions/ExceptionsManager.js";
import { BaseObject } from "../Primitives/BaseObject.js";
import { Convert } from "./Convert.js";
import { ObjectDecoder } from "./ObjectDecoder.js";
import { ObjectValidator } from "./ObjectValidator.js";
import { Reflection } from "./Reflection.js";
import { StringUtils } from "./StringUtils.js";
/**
 * ObjectEncoder class provides static methods focused on object or string encoding.
 */
export class ObjectEncoder extends BaseObject {
    /**
     * @param {any} $input Object or primitive value, which should be serialized to the string.
     * @param {Function} [$asyncHandler] Specify handler function, which will be asynchronously called,
     * when the serialization is finished.
     * @returns {string|any} Returns string representation of input value, if $asyncHandler has not been specified,
     * otherwise null and full string representation of input value will be returned as $asyncHandler input argument.
     */
    static Serialize($input, $asyncHandler) {
        const classMap = [];
        let classMapSize = 0;
        const asyncManager = new TimeoutManager();
        const getArrayBlock = ($values) => {
            return "a:" + StringUtils.Length($values) + ":" + $values;
        };
        const getObjectBlock = ($values) => {
            return "o:" + StringUtils.Length($values) + ":" + $values;
        };
        const getClassBlock = ($classIndex, $values) => {
            return "c:" + $classIndex + ":" + StringUtils.Length($values) + ":" + $values;
        };
        // eslint-disable-next-line prefer-const
        let serializeAsync;
        const serialize = ($input, $handler, $handlerIndex) => {
            const async = ObjectValidator.IsSet($handler);
            let key;
            let value;
            const keys = [];
            const values = [];
            let items = "";
            let itemsLength;
            let itemIndex = 0;
            let parserIndex = 0;
            /* istanbul ignore else : all required cases are covered */
            if (!ObjectValidator.IsSet($input)) {
                value = "u";
                if (async) {
                    $handler(value, $handlerIndex);
                }
            }
            else if ($input === null) {
                value = "n";
                if (async) {
                    $handler(value, $handlerIndex);
                }
            }
            else if (ObjectValidator.IsBoolean($input)) {
                value = "b:" + ($input ? "1" : "0");
                if (async) {
                    $handler(value, $handlerIndex);
                }
            }
            else if (!ObjectValidator.IsEmptyOrNull($input) && ObjectValidator.IsString($input)) {
                value = "s:" + StringUtils.Length($input) + ":" + $input;
                if (async) {
                    $handler(value, $handlerIndex);
                }
            }
            else if (ObjectValidator.IsInteger($input)) {
                value = "i:" + $input + ";";
                if (async) {
                    $handler(value, $handlerIndex);
                }
            }
            else if (ObjectValidator.IsDouble($input)) {
                value = "d:" + $input + ";";
                if (async) {
                    $handler(value, $handlerIndex);
                }
            }
            else if (ObjectValidator.IsNativeArray($input)) {
                itemsLength = $input.length;
                if (itemsLength > 0) {
                    for (key in $input) {
                        /* istanbul ignore else : bulletproof condition */
                        if ($input.hasOwnProperty(key)) {
                            if (async) {
                                serializeAsync(Convert.StringToInteger(key), ($data, $index) => {
                                    keys[$index] = $data;
                                }, parserIndex);
                                serializeAsync($input[key], ($data, $index) => {
                                    values[$index] = $data;
                                    itemIndex++;
                                    if (itemIndex === itemsLength) {
                                        asyncManager.Add(() => {
                                            for (itemIndex = 0; itemIndex < itemsLength; itemIndex++) {
                                                items += keys[itemIndex] + values[itemIndex];
                                            }
                                            value = getArrayBlock(items);
                                            items = null;
                                            $handler(value, $handlerIndex);
                                        });
                                    }
                                }, parserIndex);
                                parserIndex++;
                            }
                            else {
                                items += serialize(Convert.StringToInteger(key)) + serialize($input[key]);
                            }
                        }
                    }
                }
                else {
                    value = getArrayBlock("");
                    if (async) {
                        $handler(value, $handlerIndex);
                    }
                }
                if (!async) {
                    value = getArrayBlock(items);
                }
            }
            else if (ObjectValidator.IsObject($input)) {
                if (Reflection.getInstance().IsMemberOf($input, BaseObject)) {
                    const className = $input.getClassName();
                    if (!classMap.includes(className)) {
                        classMap[classMapSize] = className;
                        classMapSize++;
                    }
                    const classIndex = classMap.indexOf(className);
                    if (async) {
                        serializeAsync($input.SerializationData(), ($data) => {
                            value = getClassBlock(classIndex, $data);
                            $handler(value, $handlerIndex);
                        });
                    }
                    else {
                        value = serialize($input.SerializationData());
                        value = getClassBlock(classIndex, value);
                    }
                }
                else {
                    itemsLength = 0;
                    for (key in $input) {
                        /* istanbul ignore else : bulletproof condition */
                        if ($input.hasOwnProperty(key)) {
                            itemsLength++;
                        }
                    }
                    if (itemsLength > 0) {
                        for (key in $input) {
                            /* istanbul ignore else : bulletproof condition */
                            if ($input.hasOwnProperty(key)) {
                                if (async) {
                                    serializeAsync(key, ($data, $index) => {
                                        keys[$index] = $data;
                                    }, parserIndex);
                                    serializeAsync($input[key], ($data, $index) => {
                                        values[$index] = $data;
                                        itemIndex++;
                                        if (itemIndex === itemsLength) {
                                            asyncManager.Add(() => {
                                                for (itemIndex = 0; itemIndex < itemsLength; itemIndex++) {
                                                    items += keys[itemIndex] + values[itemIndex];
                                                }
                                                value = getObjectBlock(items);
                                                items = null;
                                                $handler(value, $handlerIndex);
                                            });
                                        }
                                    }, parserIndex);
                                    parserIndex++;
                                }
                                else {
                                    items += serialize(key) + serialize($input[key]);
                                }
                            }
                        }
                    }
                    else {
                        value = getObjectBlock("");
                        if (async) {
                            $handler(value, $handlerIndex);
                        }
                    }
                    if (!async) {
                        value = getObjectBlock(items);
                    }
                }
            }
            else if (ObjectValidator.IsFunction($input)) {
                value = Convert.FunctionToString($input);
                value = StringUtils.Substring(value, StringUtils.IndexOf(value, "(") + 1, StringUtils.Length(value) - 1);
                value = "f:" + StringUtils.Length(value) + ":" + value;
                if (async) {
                    $handler(value, $handlerIndex);
                }
            }
            else if (ObjectValidator.IsEmptyOrNull($input)) {
                value = "e";
                if (async) {
                    $handler(value, $handlerIndex);
                }
            }
            if (!async) {
                return value;
            }
        };
        serializeAsync = ($input, $handler, $handlerIndex) => {
            asyncManager.Add(() => {
                serialize($input, $handler, $handlerIndex);
            });
        };
        if (ObjectValidator.IsSet($asyncHandler)) {
            let output;
            serializeAsync($input, ($data) => {
                output = $data;
            });
            EventsManager.getInstanceSingleton().setEvent(asyncManager.getId(), EventType.ON_COMPLETE, () => {
                if (classMapSize > 0) {
                    const serializedMap = serialize(classMap);
                    output = "m:" + StringUtils.Length(serializedMap) + ":" + serializedMap + output;
                }
                $asyncHandler(output);
            });
            asyncManager.Execute();
            return null;
        }
        else {
            const serialized = serialize($input);
            if (classMapSize > 0) {
                const serializedMap = serialize(classMap);
                return "m:" + StringUtils.Length(serializedMap) + ":" + serializedMap + serialized;
            }
            else {
                return serialized;
            }
        }
    }
    /**
     * @param {string} $input String value, which should be encoded.
     * @returns {string} Returns escaped string, which can be used as http parameter or cookie value.
     */
    static Url($input) {
        return encodeURIComponent($input);
    }
    /**
     * @param {string} $input String value, which should be encoded.
     * @returns {string} Returns string encode at Utf8 format.
     */
    static Utf8($input) {
        if (ObjectValidator.IsEmptyOrNull($input)) {
            return "";
        }
        $input += "";
        let buffer = "";
        let start = 0;
        let end = 0;
        const inputLength = StringUtils.Length($input);
        let index;
        for (index = 0; index < inputLength; index++) {
            let code = StringUtils.getCodeAt($input, index);
            let encoded = "";
            if (code < 128) {
                end++;
            }
            else if (code > 127 && code < 2048) {
                encoded = Convert.UnicodeToString((code >> 6) | 192, (code & 63) | 128);
            }
            else if ((code & 0xF800) !== 0xD800) {
                encoded = Convert.UnicodeToString((code >> 12) | 224, ((code >> 6) & 63) | 128, (code & 63) | 128);
            }
            else {
                if ((code & 0xFC00) !== 0xD800) {
                    ExceptionsManager.Throw("Uft8 encoder", "Unmatched trail surrogate at " + index);
                }
                const surrogateCode = StringUtils.getCodeAt($input, ++index);
                if ((surrogateCode & 0xFC00) !== 0xDC00) {
                    ExceptionsManager.Throw("Uft8 encoder", "Unmatched lead surrogate at " + (index - 1));
                }
                code = ((code & 0x3FF) << 10) + (surrogateCode & 0x3FF) + 0x10000;
                encoded = Convert.UnicodeToString((code >> 18) | 240, ((code >> 12) & 63) | 128, ((code >> 6) & 63) | 128, (code & 63) | 128);
            }
            if (!ObjectValidator.IsEmptyOrNull(encoded)) {
                if (end > start) {
                    buffer += StringUtils.Substring($input, start, end);
                }
                buffer += encoded;
                start = end = index + 1;
            }
        }
        if (end > start) {
            buffer += StringUtils.Substring($input, start, inputLength);
        }
        return buffer;
    }
    /**
     * @param {string} $input String value, which should be encoded.
     * @param {boolean} [$urlSafe=false] Switch output format.
     * @param {boolean} [$normalize=true] Normalize $input value for encoding.
     * @returns {string} Returns string encoded in base64 format, which can be used as http parameter or
     * cookie value in case of, that $urlSafe is true.
     */
    static Base64($input, $urlSafe = false, $normalize = true) {
        if (ObjectValidator.IsEmptyOrNull($input)) {
            return "";
        }
        if ($normalize) {
            $input = ObjectDecoder.Url(this.Url(this.Utf8($input)));
        }
        let encoded = ObjectEncoder.getBase64Encoder()($input);
        if ($urlSafe) {
            encoded = StringUtils.Replace(encoded, "+", "-");
            encoded = StringUtils.Replace(encoded, "/", "_");
            encoded = StringUtils.Replace(encoded, "=", ".");
        }
        return encoded;
    }
    static getBase64Encoder() {
        let encoder;
        if (ObjectValidator.IsSet(window.btoa)) {
            encoder = window.btoa;
        }
        else {
            encoder = ($input) => {
                const b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
                let o1;
                let o2;
                let o3;
                let h1;
                let h2;
                let h3;
                let h4;
                let bits;
                let index = 0;
                let ac = 0;
                const tmp = [];
                const length = StringUtils.Length($input);
                do {
                    o1 = StringUtils.getCodeAt($input, index++);
                    o2 = StringUtils.getCodeAt($input, index++);
                    o3 = StringUtils.getCodeAt($input, index++);
                    bits = o1 << 16 | o2 << 8 | o3;
                    h1 = bits >> 18 & 0x3f;
                    h2 = bits >> 12 & 0x3f;
                    h3 = bits >> 6 & 0x3f;
                    h4 = bits & 0x3f;
                    tmp[ac++] =
                        StringUtils.getCharacterAt(b64, h1) +
                            StringUtils.getCharacterAt(b64, h2) +
                            StringUtils.getCharacterAt(b64, h3) +
                            StringUtils.getCharacterAt(b64, h4);
                } while (index < length);
                const encoded = tmp.join("");
                const r = length % 3;
                return (r ? StringUtils.Substring(encoded, 0, StringUtils.Length(encoded) + r - 3) : encoded) +
                    StringUtils.Substring("===", r || 3, 3);
            };
        }
        ObjectEncoder.getBase64Encoder = () => {
            return encoder;
        };
        return encoder;
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.Utils.ObjectEncoder", ObjectEncoder);
//# sourceMappingURL=ObjectEncoder.js.map