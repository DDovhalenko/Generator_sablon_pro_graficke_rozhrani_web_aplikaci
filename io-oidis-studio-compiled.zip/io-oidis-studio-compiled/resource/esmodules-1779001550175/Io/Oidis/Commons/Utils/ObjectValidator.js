/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { SyntaxConstants } from "../Enums/SyntaxConstants.js";
import { ArrayList } from "../Primitives/ArrayList.js";
import { BaseObject } from "../Primitives/BaseObject.js";
import { StringUtils } from "./StringUtils.js";
/**
 * ObjectValidator class provides static methods focused on object type validations.
 */
export class ObjectValidator extends BaseObject {
    /**
     * @param {any} $input Validate this object or property.
     * @returns {boolean} Returns true, if object or property is defined, otherwise false.
     */
    static IsSet($input) {
        return !SyntaxConstants.UNDEFINED.includes($input);
    }
    /**
     * @param {any} $input Validate this type of object.
     * @returns {boolean} Returns true, if object is empty or null, otherwise false.
     */
    static IsEmptyOrNull($input) {
        if (!this.IsSet($input)) {
            return true;
        }
        if ($input === null || $input === "") {
            return true;
        }
        if (this.IsNativeArray($input)) {
            return $input.length === 0;
        }
        if (typeof $input[SyntaxConstants.IS_EMPTY] === SyntaxConstants.FUNCTION &&
            typeof $input[SyntaxConstants.LENGTH] === SyntaxConstants.FUNCTION) {
            return $input.IsEmpty();
        }
        return false;
    }
    /**
     * @param {any} $input Validate this type of object.
     * @returns {boolean} Returns true, if $input is object, otherwise false.
     */
    static IsObject($input) {
        return $input !== null && typeof $input === SyntaxConstants.OBJECT && !this.IsNativeArray($input);
    }
    /**
     * @param {any} $input Validate this type of object.
     * @returns {boolean} Returns true, if $input is function, otherwise false.
     */
    static IsFunction($input) {
        return this.IsSet($input) && typeof $input === SyntaxConstants.FUNCTION;
    }
    /**
     * @param {any} $input Validate this type of class instance.
     * @returns {boolean} Returns true, if $input is class instance, otherwise false.
     */
    static IsClass($input) {
        return this.IsObject($input) && typeof $input[SyntaxConstants.CLASS_NAME] === SyntaxConstants.FUNCTION;
    }
    /**
     * @param {any} $input Validate this type of object.
     * @returns {boolean} Returns true, if object is type of boolean, otherwise false.
     */
    static IsBoolean($input) {
        return typeof $input === SyntaxConstants.BOOLEAN;
    }
    /**
     * @param {any} $input Validate this type of object.
     * @returns {boolean} Returns true, if object is number, otherwise false.
     */
    static IsDigit($input) {
        if (isNaN($input)) {
            return false;
        }
        if (typeof $input === SyntaxConstants.NUMBER) {
            return true;
        }
        if (!this.IsEmptyOrNull($input)) {
            if (this.IsString($input)) {
                return ($input + "").match(/[a-z]/i) === null && !isNaN(parseInt($input, 10));
            }
        }
        return false;
    }
    /**
     * @param {any} $input Validate this type of object.
     * @returns {boolean} Returns true, if object is integer, otherwise false.
     */
    static IsInteger($input) {
        return this.IsDigit($input) && parseFloat($input) === parseInt($input, 10) && !isNaN($input);
    }
    /**
     * @param {any} $input Validate this type of object.
     * @returns {boolean} Returns true, if object has floating point, otherwise false.
     */
    static IsDouble($input) {
        return this.IsDigit($input) && !this.IsInteger($input);
    }
    /**
     * @param {any} $input Validate this type of object.
     * @returns {boolean} Returns true, if object is type of string, otherwise false.
     */
    static IsString($input) {
        return typeof $input === SyntaxConstants.STRING || $input instanceof StringUtils;
    }
    /**
     * @param {any} $input Validate this type of object.
     * @returns {boolean} Returns true, if object is type of array, otherwise false.
     */
    static IsNativeArray($input) {
        return Array.isArray($input);
    }
    /**
     * @param {any} $input Validate this type of object.
     * @returns {boolean} Returns true, if object is type of native array or instance of ArrayList, otherwise false.
     */
    static IsArray($input) {
        return this.IsNativeArray($input) || $input instanceof ArrayList;
    }
    /**
     * @param {string} $input Validate if string is hex format.
     * @returns {boolean} Returns true, if string represents hexadecimal number, otherwise false.
     */
    static IsHexadecimal($input) {
        if (!this.IsEmptyOrNull($input)) {
            if (($input + "").toLowerCase().indexOf("0x") === 0) {
                $input = ($input + "").slice(2);
            }
            if (($input + "").toLowerCase().indexOf("#") === 0) {
                $input = ($input + "").slice(1);
            }
        }
        return !this.IsEmptyOrNull($input) && !isNaN(parseInt($input, 16));
    }
    /**
     * @param {any} $input Validate this type of object.
     * @returns {boolean} Returns true, if $input is error, otherwise false.
     */
    static IsError($input) {
        return this.IsObject($input) && ($input instanceof Error || this.toType($input) === SyntaxConstants.ERROR);
    }
    static toType($input) {
        return Object.prototype.toString.call($input);
    }
}
globalThis.Io.Oidis.Commons.Utils.ObjectValidator = ObjectValidator;
globalThis.RegisterClass("Io.Oidis.Commons.Utils.ObjectValidator", ObjectValidator);
//# sourceMappingURL=ObjectValidator.js.map