import { BaseObject } from "../Primitives/BaseObject.js";
export class PropertyValidator extends BaseObject {
    /**
     * @param {any} $value Value to validate.
     * @returns {boolean} Returns true if value passes validation.
     */
    validate($value) {
        return true;
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.Utils.PropertyValidator", PropertyValidator);
//# sourceMappingURL=PropertyValidator.js.map