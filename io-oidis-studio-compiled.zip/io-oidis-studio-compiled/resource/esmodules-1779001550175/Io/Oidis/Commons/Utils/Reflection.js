/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { SyntaxConstants } from "../Enums/SyntaxConstants.js";
import { Convert } from "./Convert.js";
import { ObjectValidator } from "./ObjectValidator.js";
import { StringUtils } from "./StringUtils.js";
/**
 * Reflection class provides OOP metadata for classes implemented at Io.Oidis namespace.
 */
export class Reflection {
    static singletonNamespaces = ["Io.Oidis"];
    static namespaceMappings = [];
    static singleton;
    static classNamespace = "";
    static className = "";
    classesList = [];
    classesSize;
    defaultProperties;
    /**
     * @returns {string} Returns class name with namespace in string format.
     */
    static ClassName() {
        return this.classNamespace + "." + this.className;
    }
    /**
     * @returns {string} Returns namespace of the class in string format.
     */
    static NamespaceName() {
        return this.classNamespace;
    }
    /**
     * @returns {string} Returns only the class name without namespace in string format.
     */
    static ClassNameWithoutNamespace() {
        return this.className;
    }
    /**
     * @param {...string[]} $values Specify namespaces, which should be reflected by singleton instance.
     * @returns {void}
     */
    static setInstanceNamespaces(...$values) {
        if (!ObjectValidator.IsEmptyOrNull($values)) {
            this.singletonNamespaces = $values;
        }
    }
    /**
     * @param {...string[]} $values Specify namespaces, which are mapped onto other namespaces
     * @returns {void}
     */
    static setNamespaceMappings(...$values) {
        if (!ObjectValidator.IsEmptyOrNull($values)) {
            this.namespaceMappings = Reflection.flattenNamespaceMappings($values);
        }
    }
    /**
     * @returns {Reflection} Returns class instance singleton.
     */
    static getInstance() {
        if (!ObjectValidator.IsSet(this.singleton)) {
            this.singleton = new Reflection();
        }
        return this.singleton;
    }
    /**
     * @returns {void}
     */
    static Refresh() {
        if (ObjectValidator.IsSet(this.singleton)) {
            delete this.singleton;
            Reflection.getInstance();
        }
    }
    /**
     * @param {string} $className Desired instance's class name, which should be created.
     * @param {object} [$dataObject] Data, which should be passed to the created instance.
     * @returns {any} Returns instance of desired class with defined data.
     */
    static getInstanceOf($className, $dataObject) {
        if (!ObjectValidator.IsSet($dataObject) ||
            (ObjectValidator.IsFunction($dataObject[SyntaxConstants.CLASS_NAME]) &&
                $dataObject[SyntaxConstants.CLASS_NAME]() === $className)) {
            const baseClass = function () {
                // default constructor with empty body
            };
            const thisClass = function () {
                // default constructor with empty body
            };
            /// TODO: validate if this is still possible in ESModule without usage of __proto__?
            baseClass.prototype = Reflection.getInstance().getClass($className).prototype;
            let propertyName;
            for (propertyName in baseClass.prototype) {
                /* istanbul ignore else : bulletproof condition */
                if (ObjectValidator.IsSet(baseClass.prototype[propertyName])) {
                    thisClass.prototype[propertyName] = baseClass.prototype[propertyName];
                }
            }
            thisClass.prototype.constructor = thisClass;
            thisClass.prototype = new baseClass();
            const output = new thisClass();
            if (ObjectValidator.IsSet($dataObject)) {
                for (propertyName in $dataObject) {
                    /* istanbul ignore else : bulletproof condition */
                    if (ObjectValidator.IsSet($dataObject[propertyName])) {
                        output[propertyName] = $dataObject[propertyName];
                    }
                }
            }
            return output;
        }
        return null;
    }
    /**
     * @param {string} [$className] Specify class name for which should be UID generated.
     * @returns {string} Returns unique identifier, based on class name and timestamp.
     */
    static UID($className) {
        if (ObjectValidator.IsEmptyOrNull($className)) {
            $className = this.ClassName();
        }
        return StringUtils.getSha1($className + new Date().getTime() + Math.random() + Math.random() + Math.random());
    }
    /**
     * @param {string} [$value] Specify namespace to normalize
     * @returns {string} Returns namespace normalized according to namespaceMapping inside package.conf.json or private.conf.json
     */
    static NormalizeNamespace($value) {
        let returnVal = $value;
        Reflection.namespaceMappings.forEach(($fallback) => {
            if (StringUtils.StartsWith($value, $fallback.namespace)) {
                returnVal = StringUtils.Replace(returnVal, $fallback.namespace, $fallback.mappedTo);
            }
        });
        return returnVal;
    }
    static isMappedNamespace($namespace) {
        let returnVal = false;
        Reflection.namespaceMappings.forEach(($fallback) => {
            return !(returnVal = StringUtils.StartsWith($namespace, $fallback.namespace));
        });
        return returnVal;
    }
    static flattenNamespaceMappings($mappings) {
        const mappings = [];
        $mappings.forEach(($mapping) => {
            if (ObjectValidator.IsEmptyOrNull($mapping.childNamespaces)) {
                mappings.push({ namespace: $mapping.namespace, mappedTo: $mapping.mappedTo });
            }
            else {
                $mapping.childNamespaces.forEach(($child) => {
                    mappings.push({ namespace: $mapping.namespace + "." + $child, mappedTo: $mapping.mappedTo + "." + $child });
                });
            }
        });
        return mappings;
    }
    constructor() {
        this.classesSize = 0;
        let index;
        for (index = 0; index < Reflection.singletonNamespaces.length; index++) {
            let parentNamespace = Reflection.singletonNamespaces[index];
            let subNamespace = "";
            if (parentNamespace.indexOf(".") !== -1) {
                const namespaces = parentNamespace.split(".");
                parentNamespace = namespaces[0];
                subNamespace = namespaces[1];
            }
            if (ObjectValidator.IsSet(globalThis[parentNamespace])) {
                this.setNamespace(globalThis[parentNamespace], parentNamespace, subNamespace);
            }
        }
        this.defaultProperties = [
            "constructor", "__defineGetter__", "__defineSetter__", "hasOwnProperty", "__lookupGetter__", "__lookupSetter__",
            "isPrototypeOf", "propertyIsEnumerable", "valueOf", "__proto__", "toString", "toLocaleString",
            "length", "name", "prototype"
        ];
        this.resolvePartials();
    }
    /**
     * @returns {string} Returns unique identifier, based on class name and timestamp.
     */
    getUID() {
        return Reflection.UID(this.getClassName());
    }
    /**
     * @param {IBaseObject} [$instance] Object instance for, which should be looked up class name.
     * @returns {string} Returns class name with namespace in string format for the this class instance
     * or for instance of Object, which has been passed as method argument.
     * If class has not been found in reflected namespace, it will returns null.
     */
    getClassName($instance) {
        if (ObjectValidator.IsSet($instance)) {
            let output = null;
            let index;
            for (index = 1; index < this.classesSize; index++) {
                if ($instance instanceof this.getClass(this.classesList[index])) {
                    output = this.classesList[index];
                }
            }
            return output;
        }
        else {
            return this.getClassName(this);
        }
    }
    /**
     * @param {IBaseObject} [$instance] Object instance for, which should be looked up class name.
     * @returns {string} Returns namespace of the class in string format for the this class instance
     * or for instance of Object, which has been passed as method argument.
     * If class has not been found in reflected namespace, it will returns null.
     */
    getNamespaceName($instance) {
        if (!ObjectValidator.IsSet($instance)) {
            $instance = this;
        }
        const fullName = this.getClassName($instance);
        return fullName.substring(0, fullName.lastIndexOf("."));
    }
    /**
     * @param {IBaseObject} [$instance] Object instance for, which should be looked up class name.
     * @returns {string} Returns only the class name without namespace in string format for the this class instance
     * or for instance of Object, which has been passed as method argument.
     * If class has not been found in reflected namespace, it will returns null.
     */
    getClassNameWithoutNamespace($instance) {
        if (!ObjectValidator.IsSet($instance)) {
            $instance = this;
        }
        const fullName = this.getClassName($instance);
        return fullName.substr((this.getNamespaceName($instance) + "").length + 1);
    }
    /**
     * @returns {string[]} Returns list of classes hierarchy for current instance.
     */
    getClassHierarchy() {
        return this.getClassHierarchyOf(this);
    }
    /**
     * @returns {string[]} Returns list of namespaces hierarchy for current instance.
     */
    getNamespaceHierarchy() {
        return this.getNamespaceHierarchyOf(this);
    }
    /**
     * @returns {string[]} Returns list of all mapped classes in looked up namespace.
     */
    getAllClasses() {
        return this.classesList;
    }
    /**
     * @param {string} $className Class name in string format, which should be validated.
     * @returns {boolean} Returns true, if class has been mapped, otherwise false.
     */
    Exists($className) {
        return this.classesList.includes($className);
    }
    /**
     * @param {string} $className Class name in string format, which should be reflected.
     * @returns {any} Returns class object, if class name has been found in namespace, otherwise null.
     */
    getClass($className) {
        const namespaces = $className.split(".");
        let object = null;
        if (namespaces.length > 1 && ObjectValidator.IsSet(globalThis[namespaces[0]])) {
            object = globalThis[namespaces[0]];
            let index;
            for (index = 1; index < namespaces.length; index++) {
                object = object[namespaces[index]];
            }
        }
        return object;
    }
    /**
     * @param {IBaseObject} $instance Object, which should be validated.
     * @param {string|IClassName} $className Class name in string format or as Object, which should be validated as instance type.
     * @returns {boolean} Returns true, if instance is type of $className object.
     */
    IsInstanceOf($instance, $className) {
        if (!ObjectValidator.IsString($className) && ObjectValidator.IsSet($className.ClassName)) {
            $className = $className.ClassName();
        }
        if (ObjectValidator.IsSet($instance.getClassName)) {
            return $className === $instance.getClassName();
        }
        return false;
    }
    /**
     * @param {IBaseObject} $instance Object, which should be validated.
     * @param {string|IClassName} $className Class name in string format or as Object, which should be validated as instance type.
     * @returns {boolean} Returns true, if instance is type of $className object or it's child.
     */
    IsMemberOf($instance, $className) {
        /// TODO: IsMemeberOf should return false if namespace does not exits, but this.getClass can't simply return null
        //        > this needs deeper investigation based on unit tests
        let requiredClass = null;
        if (!ObjectValidator.IsSet($className)) {
            if (ObjectValidator.IsSet($instance.ClassName)) {
                $className = $instance.ClassName();
            }
            else if (ObjectValidator.IsString($instance)) {
                $className = $instance;
            }
            else {
                $className = null;
            }
            if ($className === "Io.Oidis.Commons.Primitives.BaseObject") {
                return true;
            }
            return this.IsMemberOf(this, $className);
        }
        else if (ObjectValidator.IsString($className)) {
            requiredClass = this.getClass($className);
        }
        else {
            requiredClass = $className;
        }
        if (requiredClass === null) {
            return false;
        }
        return $instance instanceof requiredClass;
    }
    /**
     * @param {string | IClassName | IBaseObject} $instanceOrClass Object, which should be inspected.
     * @returns {string[]} Returns list of classes hierarchy for given instance.
     */
    getClassHierarchyOf($instanceOrClass) {
        return this.getHierarchy($instanceOrClass).classes;
    }
    /**
     * @param {string | IClassName | IBaseObject} $instanceOrClass Object, which should be inspected.
     * @returns {string[]} Returns list of namespaces hierarchy for given instance.
     */
    getNamespaceHierarchyOf($instanceOrClass) {
        return this.getHierarchy($instanceOrClass).namespaces;
    }
    /**
     * @param {string|IClassName} $className Class, which should be validated.
     * @param {string|Interface} $interface Interface, which should be reflected by the class.
     * @returns {boolean} Returns true, if class has required interface, otherwise false.
     */
    ClassHasInterface($className, $interface) {
        if (ObjectValidator.IsString($interface)) {
            $interface = this.getClass($interface);
        }
        if (!ObjectValidator.IsEmptyOrNull($interface) &&
            ObjectValidator.IsSet($interface.ClassName) &&
            ObjectValidator.IsSet($interface.NamespaceName) &&
            ObjectValidator.IsSet($interface.ClassNameWithoutNamespace)) {
            if (!$interface.hasOwnProperty("getClassName")) {
                $interface = $interface.prototype;
            }
            if (ObjectValidator.IsSet($interface.getClassName)) {
                let classDeclaration = $className;
                if (ObjectValidator.IsString($className)) {
                    classDeclaration = this.getClass($className);
                }
                const classProperties = [];
                const scanObject = ($object) => {
                    Object.getOwnPropertyNames($object).forEach(($classProperty) => {
                        if (!this.defaultProperties.includes($classProperty) &&
                            !classProperties.includes($classProperty)) {
                            classProperties.push($classProperty);
                        }
                    });
                    if ($object.__proto__) {
                        scanObject($object.__proto__);
                    }
                };
                scanObject(classDeclaration.prototype);
                let classProperty;
                for (classProperty in classDeclaration.prototype) {
                    if (classProperty !== "" &&
                        !this.defaultProperties.includes(classProperty) &&
                        !classProperties.includes(classProperty)) {
                        classProperties.push(classProperty);
                    }
                }
                const requiredProperties = this.getInterfaceProperties($interface);
                const size = requiredProperties.length;
                for (let index = 0; index < size; index++) {
                    if (!classProperties.includes(requiredProperties[index])) {
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }
    /**
     * @param {IBaseObject|Interface|string} $instance Object, which should be validated.
     * @param {(Interface|string)} $className Interface class name in string format or as Object, which should be validated.
     * @returns {boolean} Returns true if the class instance implements $className interface, otherwise false.
     */
    Implements($instance, $className) {
        if (!ObjectValidator.IsSet($className)) {
            if (ObjectValidator.IsString($instance)) {
                $className = this.getClass($instance);
            }
            else if (ObjectValidator.IsSet($instance.ClassName)) {
                $className = $instance;
            }
            $instance = this;
        }
        else if (ObjectValidator.IsString($className)) {
            $className = this.getClass($className);
        }
        if (!ObjectValidator.IsEmptyOrNull($className) &&
            ObjectValidator.IsSet($className.ClassName) &&
            ObjectValidator.IsSet($className.NamespaceName) &&
            ObjectValidator.IsSet($className.ClassNameWithoutNamespace)) {
            const requiredProperties = this.getInterfaceProperties($className);
            const size = requiredProperties.length;
            for (let index = 0; index < size; index++) {
                if (!ObjectValidator.IsSet($instance[requiredProperties[index]])) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
    /**
     * @returns {string[]} Returns string array of all properties in the class instance.
     */
    getProperties() {
        return [];
    }
    /**
     * @returns {string[]} Returns string array of all methods in the class instance.
     */
    getMethods() {
        const output = [];
        Object.getOwnPropertyNames(Object.getPrototypeOf(this)).forEach(($parameter) => {
            if (!output.includes($parameter) && ObjectValidator.IsFunction(this[parameter])) {
                output.push($parameter);
            }
        });
        let parameter;
        for (parameter in this) {
            if (!output.includes(parameter) && ObjectValidator.IsFunction(this[parameter])) {
                output.push(parameter);
            }
        }
        return output;
    }
    /**
     * @returns {number} Returns CRC calculated from data, which represents current object.
     */
    getHash() {
        return StringUtils.getCrc(JSON.stringify(this.classesList));
    }
    /**
     * @param {string|IClassName} $className Class name for validation.
     * @returns {boolean} Returns true if the class instance is type of $className, otherwise false.
     */
    IsTypeOf($className) {
        return this.IsInstanceOf(this, $className);
    }
    /**
     * @returns {object} Returns data suitable for object serialization.
     */
    SerializationData() {
        return { classesList: this.classesList };
    }
    /**
     * @param {string} [$prefix] Specify prefix for the output string.
     * @param {boolean} [$htmlTag=true] Specify if output format should be HTML or plain text.
     * @returns {string} Returns string representation of all reflected classes.
     */
    ToString($prefix, $htmlTag = true) {
        return Convert.ArrayToString(this.classesList, $prefix, $htmlTag);
    }
    /**
     * @returns {string} Returns string representation of all reflected classes.
     */
    toString() {
        return this.ToString();
    }
    /**
     * @returns {boolean} Returns true.
     */
    ValidateProperties() {
        return true;
    }
    /**
     * @param {string} [$property] Specify property name to validate.
     * @param {boolean} [$verbose] Specify if validation should print errors.
     * @returns {string[]} Returns an empty array.
     */
    ValidateDeep($property, $verbose) {
        return [];
    }
    setNamespace($objectHolder, $parentNamespace, $name) {
        let currentNamespace = $parentNamespace;
        if ($name !== null && $name !== "") {
            $objectHolder = $objectHolder[$name];
            currentNamespace = $parentNamespace + "." + $name;
        }
        let parameter;
        for (parameter in $objectHolder) {
            if (typeof $objectHolder[parameter] === SyntaxConstants.OBJECT) {
                let child;
                let isNamespace = false;
                for (child in $objectHolder[parameter]) {
                    /* istanbul ignore else : bulletproof condition */
                    if (ObjectValidator.IsSet($objectHolder[parameter][child])) {
                        if (ObjectValidator.IsFunction($objectHolder[parameter][child])) {
                            const namespace = currentNamespace + "." + parameter.toString();
                            const classNameWithNamespace = namespace + "." + child.toString();
                            /* istanbul ignore else : other than singleton instance can not be created */
                            if (!this.classesList.includes(classNameWithNamespace)) {
                                this.classesList[this.classesSize] = classNameWithNamespace;
                                this.classesSize++;
                            }
                            if (!Reflection.isMappedNamespace(namespace)) {
                                if (ObjectValidator.IsSet($objectHolder[parameter][child].ClassName)) {
                                    $objectHolder[parameter][child].classNamespace = namespace;
                                    $objectHolder[parameter][child].className = child.toString();
                                    if (namespace + "." + child.toString() !== "Io.Oidis.Commons.Utils.Reflection") {
                                        $objectHolder[parameter][child].ClassName = function () {
                                            return this.classNamespace + "." + this.className;
                                        };
                                        $objectHolder[parameter][child].NamespaceName = function () {
                                            return this.classNamespace;
                                        };
                                        $objectHolder[parameter][child].ClassNameWithoutNamespace = function () {
                                            return this.className;
                                        };
                                    }
                                }
                                if (ObjectValidator.IsSet($objectHolder[parameter][child].prototype.getClassName) &&
                                    namespace !== "Io.Oidis.Commons.Environment") {
                                    $objectHolder[parameter][child].prototype.objectNamespace = namespace;
                                    const objectClassName = child.toString();
                                    $objectHolder[parameter][child].prototype.objectClassName = objectClassName;
                                    if (namespace + "." + child.toString() !== "Io.Oidis.Commons.Utils.Reflection") {
                                        $objectHolder[parameter][child].prototype.getClassName = () => {
                                            return namespace + "." + objectClassName;
                                        };
                                        $objectHolder[parameter][child].prototype.getNamespaceName = () => {
                                            return namespace;
                                        };
                                        $objectHolder[parameter][child].prototype.getClassNameWithoutNamespace = () => {
                                            return objectClassName;
                                        };
                                    }
                                }
                            }
                            isNamespace = true;
                        }
                        else if (ObjectValidator.IsObject($objectHolder[parameter][child])) {
                            isNamespace = true;
                        }
                    }
                }
                if (isNamespace) {
                    this.setNamespace($objectHolder, currentNamespace, parameter);
                }
            }
            else if (ObjectValidator.IsFunction($objectHolder[parameter])) {
                if (!this.classesList.includes(currentNamespace + "." + parameter.toString())) {
                    this.classesList[this.classesSize] = currentNamespace + "." + parameter.toString();
                    this.classesSize++;
                }
            }
        }
    }
    getInterfaceProperties($instance) {
        const output = [];
        Object.getOwnPropertyNames($instance).forEach(($property) => {
            if (!this.defaultProperties.includes($property) &&
                $property !== "classNamespace" &&
                $property !== "className" &&
                $property !== "ClassName" &&
                $property !== "NamespaceName" &&
                $property !== "ClassNameWithoutNamespace") {
                if (!output.includes($property)) {
                    output.push($property);
                }
            }
        });
        let property;
        for (property in ($instance)) {
            if (!this.defaultProperties.includes(property) &&
                property !== "classNamespace" &&
                property !== "className" &&
                property !== "ClassName" &&
                property !== "NamespaceName" &&
                property !== "ClassNameWithoutNamespace") {
                if (!output.includes(property)) {
                    output.push(property);
                }
            }
        }
        return output;
    }
    getHierarchy($objectOrClass) {
        const classes = [];
        const namespaces = [];
        const scanObject = ($object) => {
            try {
                if (ObjectValidator.IsSet($object.ClassName)) {
                    const className = $object.ClassName();
                    const namespaceName = $object.NamespaceName();
                    if (!classes.includes(className)) {
                        classes.push(className);
                        if (!namespaces.includes(namespaceName)) {
                            namespaces.push(namespaceName);
                        }
                    }
                }
                if ($object.__proto__) {
                    scanObject($object.__proto__);
                }
            }
            catch (ex) {
                console.error("failed to scan object tree: " + ex.stack); // eslint-disable-line no-console
            }
        };
        if (!ObjectValidator.IsEmptyOrNull($objectOrClass)) {
            let instance = $objectOrClass;
            if (ObjectValidator.IsString($objectOrClass)) {
                instance = this.getClass($objectOrClass);
            }
            else if (ObjectValidator.IsSet($objectOrClass.getClassName)) {
                instance = this.getClass($objectOrClass.getClassName());
            }
            scanObject(instance);
        }
        return {
            classes,
            namespaces
        };
    }
    resolvePartials() {
        if (!globalThis.hasOwnProperty("oidisPartials")) {
            globalThis.oidisPartials = [];
        }
        globalThis.oidisPartials.forEach(($partial) => {
            if (!ObjectValidator.IsEmptyOrNull($partial.subclasses) && !$partial.instance.prototype.isInjected) {
                $partial.subclasses.forEach(($instance) => {
                    if (!ObjectValidator.IsEmptyOrNull($instance.prototype.__partialTarget)) {
                        throw new Error(`Failed to inject partial class "${$instance.prototype.getClassName()}" to "${$partial.instance.prototype.getClassName()}" because it is already injected by "${$instance.prototype.__partialTarget.getClassName()}".`);
                    }
                    $instance.prototype.__partialTarget = $partial.instance.prototype;
                    Object.getOwnPropertyNames($instance.prototype).forEach(($method) => {
                        if (!$partial.instance.prototype.hasOwnProperty($method)) {
                            $partial.instance.prototype[$method] = $instance.prototype[$method];
                        }
                    });
                    Object.getOwnPropertyNames($instance).forEach(($method) => {
                        if (!$partial.instance.hasOwnProperty($method)) {
                            $partial.instance[$method] = $instance[$method];
                        }
                    });
                    $partial.instance.prototype.isInjected = true;
                });
            }
        });
    }
}
globalThis.Io.Oidis.Commons.Utils.Reflection = Reflection;
globalThis.RegisterClass("Io.Oidis.Commons.Utils.Reflection", Reflection);
//# sourceMappingURL=Reflection.js.map