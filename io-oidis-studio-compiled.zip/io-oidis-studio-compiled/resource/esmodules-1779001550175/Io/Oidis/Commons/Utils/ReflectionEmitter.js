/*! ******************************************************************************************************** *
 *
 * Copyright 2022-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
export class ReflectionEmitter {
    static classNamespace = "";
    static className = "";
    /**
     * @returns {string} Returns class name with namespace in string format.
     */
    static ClassName() {
        return this.classNamespace + "." + this.className;
    }
    /**
     * @returns {string} Returns namespace of the class in string format.
     */
    static NamespaceName() {
        return this.classNamespace;
    }
    /**
     * @returns {string} Returns only the class name without namespace in string format.
     */
    static ClassNameWithoutNamespace() {
        return this.className;
    }
    /**
     * @param {string} $namespace Specify fully qualified namespace for the class to register.
     * @param {any} [$class] Specify class to register. If not provided, the class will be dynamically imported.
     * @returns {Promise<void>}
     */
    static async Register($namespace, $class) {
        const target = this.getTargetObject($namespace, $class);
        if (this.IsEmptyOrNull($class)) {
            try {
                const module = await import(target.name);
                Object.entries(module).forEach(([$key, $value]) => target.instance[$key] = $value);
            }
            catch (ex) {
                console.log(ex); // eslint-disable-line no-console
            }
        }
        else {
            target.instance[target.name] = $class;
        }
    }
    /**
     * @param {string} $namespace Specify fully qualified namespace for the class to register.
     * @param {any} $class Specify class to register synchronously.
     * @returns {boolean} Returns true if registration was successful, otherwise false.
     */
    static RegisterSync($namespace, $class) {
        if (!this.IsEmptyOrNull($class)) {
            const target = this.getTargetObject($namespace, $class);
            target.instance[target.name] = $class;
            return true;
        }
        return false;
    }
    static getTargetObject($namespace, $class) {
        const parts = $namespace.split(".");
        const getObject = ($name, $parent) => {
            if (!$parent.hasOwnProperty($name)) {
                $parent[$name] = {};
            }
            return $parent[$name];
        };
        let instance = globalThis;
        for (let index = 0; index < parts.length - 1; index++) {
            instance = getObject(parts[index], instance);
        }
        let name;
        if (!this.IsEmptyOrNull($class)) {
            name = parts[parts.length - 1];
        }
        else {
            name = "./../../../../" + parts.join("/") + ".js";
        }
        return {
            instance,
            name
        };
    }
    static IsEmptyOrNull($input) {
        if (["undefined", undefined].includes($input)) {
            return true;
        }
        return $input === null || $input === "";
    }
}
globalThis.RegisterClass = ($namespace, $class) => {
    return ReflectionEmitter.RegisterSync($namespace, $class);
};
if (globalThis.Io === undefined) {
    globalThis.Io = {
        Oidis: {
            Commons: {
                Events: { ThreadPool: {}, EventsManager: {} },
                Utils: { Reflection: {}, StringUtils: {}, ObjectValidator: {}, LogIt: {} }
            }
        }
    };
}
globalThis.RegisterClass("Io.Oidis.Commons.Utils.ReflectionEmitter", ReflectionEmitter);
//# sourceMappingURL=ReflectionEmitter.js.map