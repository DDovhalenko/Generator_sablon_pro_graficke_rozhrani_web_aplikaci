/*! ******************************************************************************************************** *
 *
 * Copyright 2021-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseObject } from "../Primitives/BaseObject.js";
import { ObjectValidator } from "./ObjectValidator.js";
export class TraceBack extends BaseObject {
    /**
     * @param {number | string} [$offset=3] Specify stack trace offset or type name to search for.
     * @param {boolean} [$infinityTrace=false] Specify if unlimited stack trace should be captured.
     * @returns {ITraceBackEntry} Returns trace back entry with at and from descriptors.
     */
    static CaptureEntry($offset = 3, $infinityTrace = false) {
        let error = {};
        const ErrorClass = Error;
        if (ObjectValidator.IsSet(ErrorClass.prepareStackTrace) && $infinityTrace) {
            const getStack = (belowFn) => {
                const stackTraceLimit = ErrorClass.stackTraceLimit;
                ErrorClass.stackTraceLimit = Infinity;
                const dummyError = {};
                const prepareStackTrace = ErrorClass.prepareStackTrace;
                ErrorClass.prepareStackTrace = ($error, $v8StackTrace) => {
                    return $v8StackTrace;
                };
                ErrorClass.captureStackTrace(dummyError, belowFn || getStack);
                const stackTrace = dummyError.stack;
                ErrorClass.prepareStackTrace = prepareStackTrace;
                ErrorClass.stackTraceLimit = stackTraceLimit;
                return stackTrace;
            };
            error.stack = "Error: dummy trace\n" + getStack().map(($callSite) => {
                return "   at " + $callSite.toString() + "\n";
            });
        }
        else {
            error = new ErrorClass();
        }
        if (ObjectValidator.IsEmptyOrNull(error.stack)) {
            try {
                throw new Error();
            }
            catch (ex) {
                error = ex;
            }
        }
        const traceback = this.Parse(error);
        if (ObjectValidator.IsString($offset)) {
            traceback.forEach(($trace, $index) => {
                if ($trace.getTypeName() === $offset) {
                    $offset = $index + 1;
                }
            });
        }
        if (ObjectValidator.IsString($offset)) {
            $offset = 3;
        }
        const getTraceDescriptor = ($offset) => {
            let output = "undefined";
            if ($offset < traceback.length) {
                const callSite = traceback[$offset];
                output = callSite.getFunctionName();
                if (ObjectValidator.IsEmptyOrNull(output)) {
                    output = callSite.getTypeName();
                }
                if (ObjectValidator.IsEmptyOrNull(output)) {
                    output = "anonymous";
                }
                else if (!ObjectValidator.IsEmptyOrNull(callSite.getFileName())) {
                    output += " " + callSite.getFileName();
                    if (!ObjectValidator.IsEmptyOrNull(callSite.getLineNumber())) {
                        output += ":" + callSite.getLineNumber();
                    }
                    if (!ObjectValidator.IsEmptyOrNull(callSite.getColumnNumber())) {
                        output += ":" + callSite.getColumnNumber();
                    }
                }
            }
            return output;
        };
        const at = getTraceDescriptor($offset);
        let from = "undefined";
        if ($offset < traceback.length) {
            for (let index = $offset + 1; index < traceback.length; index++) {
                from = getTraceDescriptor(index);
                if (at !== from) {
                    break;
                }
            }
        }
        return {
            at,
            from
        };
    }
    /**
     * @returns {StackTraceCallSite[]} Returns parsed stack trace of the current execution point.
     */
    static getTrace() {
        return this.Parse(new Error());
    }
    /**
     * @param {Error} $error Specify error object to parse stack trace from.
     * @returns {StackTraceCallSite[]} Returns parsed stack trace as array of call sites.
     */
    static Parse($error) {
        if (!$error.stack) {
            return [];
        }
        return $error.stack.split("\n").slice(1).map(($line) => {
            if ($line.match(/^\s*[-]{4,}$/)) {
                return new StackTraceCallSite({
                    columnNumber: null,
                    fileName: $line,
                    functionName: null,
                    lineNumber: null,
                    methodName: null,
                    native: null,
                    typeName: null
                });
            }
            const lineMatch = $line.match(/at (?:(.+)\s+\()?(?:(.+?):(\d+)(?::(\d+))?|([^)]+))\)?/);
            if (!lineMatch) {
                return;
            }
            let object = null;
            let method = null;
            let functionName = null;
            let typeName = null;
            let methodName = null;
            const isNative = (lineMatch[5] === "native");
            if (lineMatch[1]) {
                functionName = lineMatch[1];
                let methodStart = functionName.lastIndexOf(".");
                if (functionName[methodStart - 1] === ".") {
                    methodStart--;
                }
                if (methodStart > 0) {
                    object = functionName.substring(0, methodStart);
                    method = functionName.substring(methodStart + 1);
                    const objectEnd = object.indexOf(".Module");
                    if (objectEnd > 0) {
                        functionName = functionName.substring(objectEnd + 1);
                        object = object.substring(0, objectEnd);
                    }
                }
                typeName = null;
            }
            if (method) {
                typeName = object;
                methodName = method;
            }
            if (method === "<anonymous>") {
                methodName = null;
                functionName = null;
            }
            return new StackTraceCallSite({
                columnNumber: parseInt(lineMatch[4], 10) || null,
                fileName: lineMatch[2] || null,
                functionName,
                lineNumber: parseInt(lineMatch[3], 10) || null,
                methodName,
                native: isNative,
                typeName
            });
        }).filter(($callSite) => {
            return !!$callSite;
        });
    }
}
export class StackTraceCallSite extends BaseObject {
    properties;
    constructor($properties) {
        super();
        this.properties = {
            this: null,
            typeName: null,
            functionName: null,
            methodName: null,
            fileName: null,
            lineNumber: null,
            columnNumber: null,
            function: null,
            evalOrigin: null,
            topLevel: false,
            eval: false,
            native: false,
            constructor: false
        };
        for (const property in $properties) {
            if ($properties.hasOwnProperty(property) && this.properties.hasOwnProperty(property)) {
                this.properties[property] = $properties[property];
            }
        }
    }
    /**
     * @returns {string} Returns the value of this for the call site.
     */
    getThis() {
        return this.properties.this;
    }
    /**
     * @returns {string} Returns the type name of the call site.
     */
    getTypeName() {
        return this.properties.typeName;
    }
    /**
     * @returns {string} Returns the function name of the call site.
     */
    getFunctionName() {
        return this.properties.functionName;
    }
    /**
     * @returns {string} Returns the method name of the call site.
     */
    getMethodName() {
        return this.properties.methodName;
    }
    /**
     * @returns {string} Returns the file name of the call site.
     */
    getFileName() {
        return this.properties.fileName;
    }
    /**
     * @returns {string} Returns the line number of the call site.
     */
    getLineNumber() {
        return this.properties.lineNumber;
    }
    /**
     * @returns {string} Returns the column number of the call site.
     */
    getColumnNumber() {
        return this.properties.columnNumber;
    }
    /**
     * @returns {string} Returns the eval origin of the call site.
     */
    getEvalOrigin() {
        return this.properties.evalOrigin;
    }
    /**
     * @returns {string} Returns the function reference of the call site.
     */
    getFunction() {
        return this.properties.function;
    }
    /**
     * @returns {boolean} Returns true if the call site is at top level.
     */
    IsTopLevel() {
        return this.properties.topLevel;
    }
    /**
     * @returns {boolean} Returns true if the call site originates from eval.
     */
    IsEval() {
        return this.properties.eval;
    }
    /**
     * @returns {boolean} Returns true if the call site is native.
     */
    IsNative() {
        return this.properties.native;
    }
    /**
     * @returns {boolean} Returns true if the call site is a constructor call.
     */
    IsConstructor() {
        return this.properties.constructor;
    }
    /**
     * @returns {string} Returns JSON string representation of call site properties.
     */
    toString() {
        return JSON.stringify(this.properties);
    }
}
// generated-code-start
export const ITraceBackEntry = globalThis.RegisterInterface(["at", "from"]);
globalThis.RegisterClass("Io.Oidis.Commons.Utils.TraceBack", TraceBack);
globalThis.RegisterClass("Io.Oidis.Commons.Utils.StackTraceCallSite", StackTraceCallSite);
globalThis.RegisterClass("Io.Oidis.Commons.Utils.ITraceBackEntry", ITraceBackEntry);
//# sourceMappingURL=TraceBack.js.map