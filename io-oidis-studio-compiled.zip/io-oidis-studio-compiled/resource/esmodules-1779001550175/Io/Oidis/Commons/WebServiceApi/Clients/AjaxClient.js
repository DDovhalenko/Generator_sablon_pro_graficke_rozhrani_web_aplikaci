/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpMethodType } from "../../Enums/HttpMethodType.js";
import { EventsManager } from "../../Events/EventsManager.js";
import { BaseWebServiceClient } from "./BaseWebServiceClient.js";
/**
 * AjaxClient class provides asynchronous http client for bidirectional communication with REST services on same origin.
 */
export class AjaxClient extends BaseWebServiceClient {
    sync;
    /**
     * @param {WebServiceConfiguration} $configuration Specify client-server communication parameters
     * @param {boolean} [$synchronous=false] Specify if client-server communication should be synchronous
     */
    constructor($configuration, $synchronous = false) {
        super($configuration);
        this.sync = $synchronous;
    }
    /**
     * @returns {void}
     */
    StartCommunication() {
        if (this.clientInstance() === null) {
            this.getConfiguration().Load(() => {
                try {
                    this.clientInstance(new XMLHttpRequest());
                }
                catch (ex) {
                    try {
                        this.clientInstance(new ActiveXObject("Msxml2.XMLHTTP"));
                    }
                    catch (ex) {
                        try {
                            this.clientInstance(new ActiveXObject("Microsoft.XMLHTTP"));
                        }
                        catch (ex) {
                            this.throwError(ex);
                        }
                    }
                }
                super.StartCommunication();
            }, () => {
                this.throwError("Unable to load client configuration from: " + this.getConfiguration().getSource());
            });
        }
    }
    clientInstance($value) {
        return super.clientInstance($value);
    }
    sendRequest($data) {
        const client = this.clientInstance();
        client.open(HttpMethodType.POST, this.getServerUrl(), this.sync);
        client.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        client.setRequestHeader("charset", "UTF-8");
        if (!this.sync) {
            client.onreadystatechange = () => {
                this.onResponse();
            };
            client.send("jsonData=" + $data);
        }
        else {
            client.send("jsonData=" + $data);
            this.onResponse();
        }
    }
    onResponse() {
        try {
            const client = this.clientInstance();
            if (client.readyState === 4 || this.sync) {
                if (client.status === 200 || client.status === 500) {
                    const responseText = client.responseText;
                    if (!this.sync) {
                        EventsManager.getInstanceSingleton().FireAsynchronousMethod(() => {
                            this.responseResolver(responseText);
                        }, false);
                    }
                    else {
                        this.responseResolver(responseText);
                    }
                    super.onResponse();
                }
                else if (client.status === 0) {
                    this.throwError("Connection has been lost.");
                }
                else {
                    this.throwError("Data transfer failure with status " + client.status + ": " + client.statusText);
                }
            }
        }
        catch (ex) {
            this.throwError(ex);
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.WebServiceApi.Clients.AjaxClient", AjaxClient);
//# sourceMappingURL=AjaxClient.js.map