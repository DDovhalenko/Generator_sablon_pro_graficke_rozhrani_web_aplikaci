/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { WebServiceClientEventType } from "../../Enums/Events/WebServiceClientEventType.js";
import { ErrorEventArgs } from "../../Events/Args/ErrorEventArgs.js";
import { EventsManager } from "../../Events/EventsManager.js";
import { ArrayList } from "../../Primitives/ArrayList.js";
import { BaseObject } from "../../Primitives/BaseObject.js";
import { Convert } from "../../Utils/Convert.js";
import { LogIt } from "../../Utils/LogIt.js";
import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { DataFormatType } from "../../Enums/DataFormatType.js";
import { ObjectEncoder } from "../../Utils/ObjectEncoder.js";
import { Loader } from "../../Loader.js";
/**
 * BaseWebServiceClient class provides general http client for bidirectionl communication with web services.
 */
export class BaseWebServiceClient extends BaseObject {
    requiredFormat;
    configuration;
    client;
    isRunning;
    timeoutId;
    requestSend;
    requestsBuffer;
    responseBuffer;
    requestFormatter;
    responseFormatter;
    /**
     * @param {WebServiceConfiguration} $configuration Specify client-server communication parameters
     */
    constructor($configuration) {
        super();
        this.configuration = $configuration;
        this.client = null;
        this.isRunning = false;
        this.requestSend = false;
        this.requestsBuffer = new ArrayList();
        this.responseBuffer = {};
        this.requestFormatter = ($data) => {
            // default request data formatter will not effect data
        };
        this.responseFormatter = ($data, $owner, $onSuccess, $onError) => {
            $onSuccess($data);
        };
        this.requiredFormat = Loader.getInstance().getEnvironmentArgs().getProjectConfig().lcpConfig.format;
    }
    /**
     * @returns {number} Returns client's id, which can be used for events handling.
     */
    getId() {
        return this.configuration.getId();
    }
    /**
     * @returns {string} Returns target service url.
     */
    getServerUrl() {
        return this.configuration.getServerUrl();
    }
    /**
     * @param {Function} $handler Specify async handler for handling of server path data.
     * @returns {void}
     */
    getServerPath($handler) {
        return this.configuration.Load(() => {
            $handler(this.configuration.ServerLocation());
        }, () => {
            this.throwError("Unable to get server path from configuration: " + this.configuration.getSource());
        });
    }
    /**
     * @returns {string} Returns target service version.
     */
    getServerVersion() {
        return this.configuration.Version();
    }
    /**
     * @returns {IWebServiceClientEvents} Returns events manager interface.
     */
    getEvents() {
        return {
            OnClose: ($eventHandler) => {
                EventsManager.getInstanceSingleton().setEvent("" + this.getId(), WebServiceClientEventType.ON_CLOSE, $eventHandler);
            },
            OnError: ($eventHandler) => {
                EventsManager.getInstanceSingleton().setEvent("" + this.getId(), WebServiceClientEventType.ON_ERROR, $eventHandler);
            },
            OnStart: ($eventHandler) => {
                EventsManager.getInstanceSingleton().setEvent("" + this.getId(), WebServiceClientEventType.ON_START, $eventHandler);
            },
            OnTimeout: ($eventHandler) => {
                EventsManager.getInstanceSingleton().setEvent("" + this.getId(), WebServiceClientEventType.ON_TIMEOUT, $eventHandler);
            }
        };
    }
    /**
     * Start Communication with target service
     * @returns {void}
     */
    StartCommunication() {
        if (!this.isRunning) {
            this.isRunning = true;
            this.requestSend = false;
            LogIt.Info("Started " + this.getClassNameWithoutNamespace() + " communication with server " + this.getServerUrl());
            EventsManager.getInstanceSingleton().FireEvent("" + this.getId(), WebServiceClientEventType.ON_START);
            this.nextRequest();
        }
    }
    /**
     * Stop Communication with target service
     * @returns {void}
     */
    StopCommunication() {
        if (this.isRunning) {
            this.client = null;
            this.isRunning = false;
            EventsManager.getInstanceSingleton().FireEvent("" + this.getId(), WebServiceClientEventType.ON_CLOSE);
        }
    }
    /**
     * @returns {boolean} Returns true, if communication with target service is live, otherwise false.
     */
    CommunicationIsRunning() {
        return this.isRunning;
    }
    /**
     * @param {any} $data Specify request command.
     * @param {IWebServiceResponseHandler} [$handler] Specify response handler.
     * @returns {void}
     */
    Send($data, $handler) {
        if (!ObjectValidator.IsSet($handler)) {
            $handler = null;
        }
        this.requestsBuffer.Add({ data: $data, handler: $handler });
        if (!this.CommunicationIsRunning()) {
            this.StartCommunication();
        }
        else if (this.requestsBuffer.Length() === 1) {
            this.nextRequest();
        }
    }
    /**
     * @param {Function} $formatter Specify request formatter function
     * @returns {void}
     */
    setRequestFormatter($formatter) {
        if (!ObjectValidator.IsEmptyOrNull($formatter)) {
            this.requestFormatter = $formatter;
        }
    }
    /**
     * @param {Function} $formatter Specify response formatter function
     * @returns {void}
     */
    setResponseFormatter($formatter) {
        if (!ObjectValidator.IsEmptyOrNull($formatter)) {
            this.responseFormatter = $formatter;
        }
    }
    /**
     * @returns {string} Returns string representation of this web service client.
     */
    toString() {
        return "WebServiceClient(" + this.getId() + ")";
    }
    getConfiguration() {
        return this.configuration;
    }
    clientInstance($value) {
        if (ObjectValidator.IsSet($value)) {
            this.client = $value;
        }
        return this.client;
    }
    sendRequest($data) {
        // place holder for handling of data, which should be send
    }
    onResponse($eventData) {
        if (this.requestSend) {
            this.requestSend = false;
            if (ObjectValidator.IsSet(this.timeoutId)) {
                clearTimeout(this.timeoutId);
            }
            this.requestsBuffer.RemoveAt(0);
            this.nextRequest();
        }
    }
    responseResolver($data) {
        if (!ObjectValidator.IsEmptyOrNull($data)) {
            if (ObjectValidator.IsString($data) || ObjectValidator.IsObject($data)) {
                let response;
                if (ObjectValidator.IsString($data)) {
                    try {
                        response = JSON.parse($data);
                    }
                    catch (ex) {
                        response = $data;
                    }
                }
                else {
                    response = $data;
                }
                this.responseFormatter(response, this, ($value, $key) => {
                    if (!ObjectValidator.IsSet($key)) {
                        $key = 0;
                    }
                    if (this.responseBuffer.hasOwnProperty($key)) {
                        this.responseBuffer[$key]($value);
                        if ($value.hasOwnProperty("keepAlive") && !$value.keepAlive) {
                            delete this.responseBuffer[$key];
                        }
                        else {
                            // TODO: if not defined it can lead to mem leak but only in situation when communicating with older hub
                            //       > possible detection of Forwarding protocol may reduce this issue
                        }
                    }
                }, ($message) => {
                    this.throwError($message);
                });
            }
            else {
                this.throwError("Unsupported response data type \"" + Convert.ToType($data) + "\".");
            }
        }
        else {
            this.throwError("Data transfer failure.");
        }
    }
    resetTimeout() {
        if (ObjectValidator.IsSet(this.timeoutId)) {
            clearTimeout(this.timeoutId);
        }
        this.timeoutId = setTimeout(() => {
            try {
                EventsManager.getInstanceSingleton().FireEvent("" + this.getId(), WebServiceClientEventType.ON_TIMEOUT);
            }
            catch (ex) {
                this.throwError(ex);
            }
        }, this.configuration.TimeoutLimit());
    }
    throwError($message) {
        const eventArgs = new ErrorEventArgs($message);
        eventArgs.Owner(this);
        LogIt.Debug(this.getClassName() + " error: " + eventArgs.Message());
        EventsManager.getInstanceSingleton().FireEvent("" + this.getId(), WebServiceClientEventType.ON_ERROR, eventArgs);
    }
    prepareDataForTransport($data) {
        if (ObjectValidator.IsString($data.value)) {
            return $data.value;
        }
        if ($data.value.format === DataFormatType.JSON && !this.getConfiguration().Accept().includes($data.value.format)) {
            $data.value.format = DataFormatType.BASE64;
        }
        if ($data.value.format === DataFormatType.BASE64 ||
            $data.value.format === DataFormatType.UTF8) {
            if (!ObjectValidator.IsString($data.value.data)) {
                if (!ObjectValidator.IsString($data.value.data.args)) {
                    $data.value.data.args = ObjectEncoder.Base64(JSON.stringify($data.value.data.args));
                }
                $data.value.data = ObjectEncoder.Base64(JSON.stringify($data.value.data));
            }
        }
        return JSON.stringify($data.value);
    }
    nextRequest() {
        if (!this.requestsBuffer.IsEmpty() && this.isRunning) {
            this.requestSend = true;
            try {
                const buffer = this.requestsBuffer.getFirst();
                const data = { value: buffer.data, key: -1 };
                this.requestFormatter(data);
                if (!ObjectValidator.IsEmptyOrNull(buffer.handler)) {
                    this.responseBuffer[data.key] = buffer.handler;
                }
                this.resetTimeout();
                const accepted = this.getConfiguration().Accept();
                if (this.requiredFormat !== DataFormatType.AUTO && !accepted.includes(this.requiredFormat)) {
                    this.throwError(new Error("Communication skipped: required format " + this.requiredFormat +
                        " is not supported by target service. Please use one of the following: " + accepted.join(", ")));
                }
                else {
                    this.sendRequest(this.prepareDataForTransport(data));
                }
            }
            catch (ex) {
                this.throwError(ex);
            }
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.WebServiceApi.Clients.BaseWebServiceClient", BaseWebServiceClient);
//# sourceMappingURL=BaseWebServiceClient.js.map