import { ArrayList } from "../../Primitives/ArrayList.js";
import { Echo } from "../../Utils/Echo.js";
import { WebServiceConfiguration } from "../WebServiceConfiguration.js";
import { BaseWebServiceClient } from "./BaseWebServiceClient.js";
/**
 * CefQueryClient class provides client for bidirectional cross-origin communication with web sockets services.
 */
export class CefQueryClient extends BaseWebServiceClient {
    requestIds;
    constructor() {
        super(new WebServiceConfiguration());
        this.requestIds = new ArrayList();
    }
    StartCommunication() {
        if (this.clientInstance() === null) {
            this.clientInstance(window.cefQuery);
            try {
                super.StartCommunication();
            }
            catch (ex) {
                this.throwError(ex);
            }
        }
    }
    StopCommunication() {
        try {
            this.requestIds.foreach(($id) => {
                window.cefQueryCancel($id);
            });
            super.StopCommunication();
        }
        catch (ex) {
            this.throwError(ex);
        }
    }
    clientInstance($value) {
        return super.clientInstance($value);
    }
    sendRequest($data) {
        const client = this.clientInstance();
        try {
            this.requestIds.Add(client.apply(this, [
                {
                    onFailure: ($code, $message) => {
                        this.throwError($message);
                    },
                    onSuccess: ($response) => {
                        this.onResponse($response);
                    },
                    persistent: true,
                    request: $data
                }
            ]));
        }
        catch (ex) {
            Echo.Printf(ex.message);
            this.throwError(ex);
        }
    }
    onResponse($message) {
        try {
            if ($message === "OK") {
                super.onResponse($message);
            }
            else {
                this.responseResolver($message);
            }
        }
        catch (ex) {
            this.throwError(ex);
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.WebServiceApi.Clients.CefQueryClient", CefQueryClient);
//# sourceMappingURL=CefQueryClient.js.map