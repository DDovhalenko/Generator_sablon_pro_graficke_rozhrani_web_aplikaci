/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "../../Enums/Events/EventType.js";
import { GeneralEventOwner } from "../../Enums/Events/GeneralEventOwner.js";
import { EventsManager } from "../../Events/EventsManager.js";
import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { BaseWebServiceClient } from "./BaseWebServiceClient.js";
/**
 * PostMessageClient class provides asynchronous http client for bidirectional cross-origin
 * communication with REST services.
 */
export class PostMessageClient extends BaseWebServiceClient {
    /**
     * @param {WebServiceConfiguration} $configuration Specify client-server communication parameters
     */
    constructor($configuration) {
        super($configuration);
        this.getEvents().OnTimeout(() => {
            this.StopCommunication();
        });
    }
    StartCommunication() {
        if (this.clientInstance() === null) {
            this.getConfiguration().Load(() => {
                const client = this.clientInstance(document.createElement("iframe"));
                document.body.appendChild(client);
                client.contentWindow.name = "PostMessageConnector" + this.getId();
                EventsManager.getInstanceSingleton().setEvent(GeneralEventOwner.WINDOW, EventType.ON_MESSAGE, ($eventArgs) => {
                    this.onResponse($eventArgs.NativeEventArgs());
                });
                let isLoaded = false;
                client.onload = () => {
                    try {
                        if (!isLoaded) {
                            isLoaded = true;
                            super.StartCommunication();
                        }
                    }
                    catch (ex) {
                        this.throwError(ex);
                    }
                };
                this.resetTimeout();
                client.src = this.getServerUrl();
            }, () => {
                this.throwError("Unable to load client configuration from: " + this.getConfiguration().getSource());
            });
        }
    }
    StopCommunication() {
        const client = this.clientInstance();
        if (client !== null) {
            if (!ObjectValidator.IsEmptyOrNull(client) && !ObjectValidator.IsEmptyOrNull(client.parentNode)) {
                client.parentNode.removeChild(client);
            }
            super.StopCommunication();
        }
    }
    clientInstance($value) {
        return super.clientInstance($value);
    }
    sendRequest($data) {
        this.clientInstance().contentWindow.postMessage($data, this.getServerUrl());
    }
    onResponse($event) {
        try {
            if (this.CommunicationIsRunning()) {
                const eventData = $event.data;
                EventsManager.getInstanceSingleton().FireAsynchronousMethod(() => {
                    this.responseResolver(eventData);
                }, false);
                super.onResponse();
            }
        }
        catch (ex) {
            this.throwError(ex);
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.WebServiceApi.Clients.PostMessageClient", PostMessageClient);
//# sourceMappingURL=PostMessageClient.js.map