/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { DataFormatType } from "../../Enums/DataFormatType.js";
import { JsonUtils } from "../../Utils/JsonUtils.js";
import { LogIt } from "../../Utils/LogIt.js";
import { ObjectValidator } from "../../Utils/ObjectValidator.js";
import { Property } from "../../Utils/Property.js";
import { StringUtils } from "../../Utils/StringUtils.js";
import { BaseWebServiceClient } from "./BaseWebServiceClient.js";
/**
 * WebSocketsClient class provides client for bidirectional cross-origin communication with web sockets services.
 */
export class WebSocketsClient extends BaseWebServiceClient {
    maxReconnectsCount;
    reconnectCounter;
    communicationThread;
    stopped;
    constructor($configuration) {
        super($configuration);
        this.maxReconnectsCount = -1;
        this.reconnectCounter = 0;
        this.communicationThread = null;
        this.stopped = false;
    }
    getServerUrl() {
        if (this.getConfiguration().ServerPort() === 443 && this.getConfiguration().ServerProtocol() !== "wss") {
            this.getConfiguration().ServerProtocol("wss");
        }
        if (!StringUtils.Contains(this.getConfiguration().ServerProtocol(), "ws")) {
            this.getConfiguration().ServerProtocol("ws");
        }
        let url = this.getConfiguration().ServerProtocol() + "://" + this.getConfiguration().ServerAddress();
        if (this.getConfiguration().ServerPort() !== 80) {
            url += ":" + this.getConfiguration().ServerPort();
        }
        return url + "/";
    }
    /**
     * @returns {string} Returns base path used for application scope on server.
     */
    getServerBase() {
        let protocol = this.getConfiguration().ServerBase();
        if (StringUtils.StartsWith(protocol, "/")) {
            protocol = StringUtils.Substring(protocol, 1);
        }
        if (StringUtils.EndsWith(protocol, "/")) {
            protocol = StringUtils.Substring(protocol, 0, StringUtils.Length(protocol) - 1);
        }
        return protocol;
    }
    /**
     * @param {number} $value Specify maximum count of reconnect attempts. Value -1 means infinitive reconnection.
     * @returns {number} Returns count of maximum attempts for client-server reconnect.
     */
    MaxReconnectsCount($value) {
        if ($value === -1) {
            return this.maxReconnectsCount = $value;
        }
        return this.maxReconnectsCount = Property.PositiveInteger(this.maxReconnectsCount, $value);
    }
    StartCommunication() {
        this.stopped = false;
        if (this.clientInstance() === null) {
            const errorHandler = ($message) => {
                this.reconnectCounter = 0;
                this.throwError($message);
            };
            const clearThread = () => {
                if (!ObjectValidator.IsEmptyOrNull(this.communicationThread)) {
                    clearTimeout(this.communicationThread);
                }
                this.communicationThread = null;
            };
            let isFirstInit = true;
            const getClient = ($reconnect = true) => {
                if (isFirstInit) {
                    isFirstInit = false;
                    LogIt.Info("Init WebSockets client for: {0}", this.getConfiguration().getSource());
                }
                if (!this.stopped && (this.maxReconnectsCount === -1 ||
                    (this.maxReconnectsCount === 0 && this.reconnectCounter === 0) ||
                    this.reconnectCounter < this.maxReconnectsCount)) {
                    if (ObjectValidator.IsEmptyOrNull(this.communicationThread)) {
                        this.communicationThread = setTimeout(() => {
                            try {
                                this.getConfiguration().Load(() => {
                                    clearThread();
                                    let client;
                                    if (ObjectValidator.IsEmptyOrNull(this.getServerBase())) {
                                        client = this.clientInstance(new WebSocket(this.getServerUrl()));
                                    }
                                    else {
                                        client = this.clientInstance(new WebSocket(this.getServerUrl(), this.getServerBase()));
                                    }
                                    client.binaryType = "arraybuffer";
                                    client.onopen = () => {
                                        try {
                                            super.StartCommunication();
                                            this.reconnectCounter = 0;
                                        }
                                        catch (ex) {
                                            this.throwError(ex);
                                        }
                                    };
                                    client.onclose = () => {
                                        try {
                                            if (this.CommunicationIsRunning()) {
                                                super.StopCommunication();
                                                this.reconnectCounter = 0;
                                            }
                                            else if (client.readyState === WebSocket.CLOSED) {
                                                getClient();
                                            }
                                            else {
                                                errorHandler("Server is not running at: " + this.getServerUrl());
                                            }
                                        }
                                        catch (ex) {
                                            this.throwError(ex);
                                        }
                                    };
                                    client.onmessage = ($event) => {
                                        this.onResponse($event);
                                    };
                                    client.onerror = () => {
                                        if (this.CommunicationIsRunning() &&
                                            client.readyState !== WebSocket.CONNECTING &&
                                            client.readyState !== WebSocket.OPEN &&
                                            client.readyState !== WebSocket.CLOSING &&
                                            client.readyState !== WebSocket.CLOSED) {
                                            errorHandler("Unrecognized client error: " + client.readyState);
                                        }
                                        else if (client.readyState === WebSocket.CLOSED) {
                                            getClient();
                                        }
                                        else {
                                            this.StopCommunication();
                                        }
                                    };
                                }, () => {
                                    clearThread();
                                    if (!this.CommunicationIsRunning()) {
                                        getClient();
                                    }
                                    else {
                                        errorHandler("Unable to load client configuration from: " +
                                            this.getConfiguration().getSource());
                                    }
                                });
                            }
                            catch (ex) {
                                clearThread();
                                this.throwError(ex);
                            }
                        }, $reconnect ? 100 : 0);
                        this.reconnectCounter++;
                    }
                }
                else if (this.maxReconnectsCount > 0) {
                    errorHandler("Max reconnection count " + this.maxReconnectsCount + " has been reached.");
                }
                else if (this.maxReconnectsCount === 0 && this.reconnectCounter > 0 &&
                    ObjectValidator.IsEmptyOrNull(this.communicationThread)) {
                    errorHandler("Server is not running at: " + this.getServerUrl());
                }
            };
            getClient(false);
        }
    }
    StopCommunication() {
        this.stopped = true;
        try {
            const client = this.clientInstance();
            if (!ObjectValidator.IsEmptyOrNull(client)) {
                client.close();
            }
            super.StopCommunication();
        }
        catch (ex) {
            this.throwError(ex);
        }
    }
    clientInstance($value) {
        return super.clientInstance($value);
    }
    sendRequest($data) {
        const client = this.clientInstance();
        try {
            setTimeout(() => {
                try {
                    if (client.readyState === WebSocket.OPEN) {
                        client.send($data);
                    }
                    else {
                        this.throwError("Unable to send data to socket server: connection not open to " + this.getServerUrl());
                    }
                }
                catch (ex) {
                    this.throwError(ex);
                }
            });
        }
        catch (ex) {
            if (!ObjectValidator.IsEmptyOrNull(client)) {
                if (client.readyState === WebSocket.CLOSED || client.readyState === WebSocket.CLOSING) {
                    this.throwError("Unable to connect to socket server: " + this.getServerUrl());
                }
                else if (client.readyState === WebSocket.CONNECTING) {
                    this.throwError("Connecting to socket server: " + this.getServerUrl());
                }
                else {
                    this.throwError(ex);
                }
            }
            else {
                this.throwError(ex);
            }
        }
    }
    onResponse($event) {
        try {
            if ($event.data === "OK") {
                super.onResponse($event);
            }
            else if (ObjectValidator.IsString($event.data)) {
                this.responseResolver($event.data);
            }
            else if (ObjectValidator.IsObject($event.data) && ObjectValidator.IsSet($event.data.id)) {
                this.responseResolver($event.data);
            }
            else {
                this.responseResolver(JsonUtils.ToJson($event.data));
            }
        }
        catch (ex) {
            this.throwError(ex);
        }
    }
    prepareDataForTransport($data) {
        if (this.getConfiguration().Accept().includes(DataFormatType.BINARY) &&
            ($data.value.format === DataFormatType.JSON || $data.value.format === DataFormatType.BINARY)) {
            return JsonUtils.ToBuffer($data.value);
        }
        return super.prepareDataForTransport($data);
    }
}
globalThis.RegisterClass("Io.Oidis.Commons.WebServiceApi.Clients.WebSocketsClient", WebSocketsClient);
//# sourceMappingURL=WebSocketsClient.js.map