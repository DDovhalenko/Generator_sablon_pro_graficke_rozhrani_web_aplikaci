/*! ******************************************************************************************************** *
 *
 * Copyright 2021-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { ElementManager } from "../../Utils/ElementManager.js";
import { GuiCommons } from "./GuiCommons.js";
/**
 * Bootstrap-integrated base panel class. Extends GuiCommons with visibility control
 * that synchronizes the panel's visible state with the DOM element via ElementManager
 * show/hide operations.
 */
export class BasePanel extends GuiCommons {
    /**
     * Gets or sets the visibility state of the panel. When setting, also shows or hides
     * the panel's DOM element through ElementManager.
     * @param {boolean} [$value] Optional boolean to set the visibility state.
     * @returns {boolean} The current visibility state.
     */
    Visible($value) {
        const visible = super.Visible($value);
        if (ObjectValidator.IsSet($value)) {
            if (visible) {
                ElementManager.Show(this.InstanceOwner());
            }
            else {
                ElementManager.Hide(this.InstanceOwner());
            }
        }
        return visible;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Bootstrap.Primitives.BasePanel", BasePanel);
//# sourceMappingURL=BasePanel.js.map