import { BaseObject } from "./../../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Loader } from "../../Loader.js";
/**
 * Base controller class for Bootstrap panels. Manages the lifecycle of a panel instance
 * including processing, data fetching, access validation, and parent-child relationships.
 * Provides access to environment args, HTTP manager, and events manager from the Loader.
 * @template Panel The panel type this controller manages, defaults to BasePanel.
 */
export class BasePanelController extends BaseObject {
    panelInstance;
    environment;
    httpManager;
    eventsManager;
    processed;
    parent;
    requestArgs;
    constructor($instance) {
        super();
        this.panelInstance = $instance;
        this.environment = Loader.getInstance().getEnvironmentArgs();
        this.httpManager = Loader.getInstance().getHttpManager();
        this.eventsManager = Loader.getInstance().getHttpResolver().getEvents();
        this.processed = false;
        this.parent = null;
        this.requestArgs = null;
    }
    /**
     * Executes the controller's resolver logic for the associated panel. Skips processing
     * if already processed unless force is specified.
     * @param {boolean} [$force] When true, forces re-processing even if already processed.
     * @returns {Promise<void>}
     */
    async Process($force) {
        if (!this.processed || $force) {
            this.processed = true;
            try {
                await this.resolver(this.panelInstance);
            }
            catch (ex) {
                LogIt.Error(ex);
            }
        }
        else {
            LogIt.Warning("Processing of {0} skipped. Try to use Process with $force=true.", this.getClassName());
        }
    }
    /**
     * Hook method for pre-loading data before the panel is rendered. Override in
     * subclasses for speed optimization by fetching data in advance.
     * @param {...any[]} $args Variable arguments passed to the data fetch operation.
     * @returns {Promise<void>}
     */
    async FetchData(...$args) {
        // this method should be used for speed optimization
    }
    /**
     * Sets the parent instance for this controller.
     * @param {any} $instance The parent instance to assign.
     * @returns {void}
     */
    setParent($instance) {
        this.parent = $instance;
    }
    /**
     * Gets or sets the HTTP request event arguments associated with this controller.
     * @param {HttpRequestEventArgs} [$value] Optional value to set as the request arguments.
     * @returns {HttpRequestEventArgs} The current HTTP request event arguments.
     */
    RequestArgs($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.requestArgs = $value;
        }
        return this.requestArgs;
    }
    /**
     * Validates whether the current user has access to this panel. Override in subclasses
     * to implement custom access control logic. Returns true by default.
     * @returns {Promise<boolean>} Resolves to true if access is granted, false otherwise.
     */
    async AccessValidator() {
        return true;
    }
    async beforeLoad($instance) {
        // override this method for ability to access initiated panel instance before it is shown
    }
    getInstanceOwner() {
        return this.panelInstance;
    }
    getParent() {
        return this.parent;
    }
    async resolver($instance) {
        // override this method for ability to execute implementation in correct order
    }
    getHttpManager() {
        return this.httpManager;
    }
    getEnvironmentArgs() {
        return this.environment;
    }
    getEventsManager() {
        return this.eventsManager;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Bootstrap.Primitives.BasePanelController", BasePanelController);
//# sourceMappingURL=BasePanelController.js.map