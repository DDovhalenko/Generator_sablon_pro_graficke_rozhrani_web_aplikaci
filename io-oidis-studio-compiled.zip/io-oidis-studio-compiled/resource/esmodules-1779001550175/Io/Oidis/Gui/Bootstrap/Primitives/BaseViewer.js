/*! ******************************************************************************************************** *
 *
 * Copyright 2021-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ExceptionsManager } from "./../../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { BaseViewerLayerType } from "../../Enums/BaseViewerLayerType.js";
import { CommonGuiViewer } from "../../Primitives/BaseViewer.js";
import { ElementManager } from "../../Utils/ElementManager.js";
import { bootstrap } from "../../Utils/EnvironmentHelper.js";
import { AbstractGuiObject } from "./GuiCommons.js";
/**
 * Bootstrap-integrated base viewer class. Extends CommonGuiViewer with Bootstrap-specific
 * rendering, test mode support with sidebar test buttons, and viewer arguments handling
 * with hash-based change detection to avoid redundant implementation preparation.
 */
export class BaseViewer extends CommonGuiViewer {
    argsHash;
    /**
     * Returns the DOM element used as the render target for test mode sidebar content.
     * Caches the result after the first successful lookup.
     * @returns {HTMLElement} The test content sidebar element.
     */
    static getTestRenderTarget() {
        const element = ElementManager.getElement("TestContentSideBar");
        if (!ObjectValidator.IsEmptyOrNull(element)) {
            this.getTestRenderTarget = () => {
                return element;
            };
        }
        return element;
    }
    constructor($args) {
        super($args);
        this.argsHash = null;
    }
    /**
     * Gets or sets the viewer arguments. When setting, triggers PrepareImplementation
     * if the arguments hash has changed, ensuring the viewer is re-prepared only when needed.
     * @param {BaseViewerArgs} [$args] Optional viewer arguments to set.
     * @returns {BaseViewerArgs} The current viewer arguments.
     */
    ViewerArgs($args) {
        if (!ObjectValidator.IsEmptyOrNull($args) && !ObjectValidator.IsString($args)) {
            super.ViewerArgs($args);
            const instance = this.getInstance();
            if (!ObjectValidator.IsEmptyOrNull(instance)) {
                const newHash = $args.getHash();
                if (this.argsHash !== newHash) {
                    this.argsHash = newHash;
                    this.PrepareImplementation();
                }
            }
        }
        return super.ViewerArgs($args);
    }
    /**
     * Prepares the viewer implementation by applying viewer arguments, invoking lifecycle
     * hooks (beforeLoad, afterLoad), and setting up either normal or test mode rendering
     * including test subscriber processing and test button generation.
     * @returns {void}
     */
    PrepareImplementation() {
        const args = super.ViewerArgs();
        const instance = this.getInstance();
        const testButtons = this.getTestButtons();
        if (!ObjectValidator.IsEmptyOrNull(instance)) {
            if (!ObjectValidator.IsEmptyOrNull(args)) {
                if (!args.Visible()) {
                    instance.Visible(false);
                }
                this.argsHandler(instance, args);
            }
            this.setLayer(BaseViewerLayerType.DEFAULT);
            this.beforeLoad(instance, args);
            instance.getEvents().setOnComplete(() => {
                this.afterLoad(instance, args);
            });
        }
        if (this.TestModeEnabled()) {
            testButtons.Clear();
            if (!ObjectValidator.IsEmptyOrNull(this.getTestSubscriber())) {
                const testProcessor = new (this.getTestSubscriber())();
                testProcessor.setOwner(this);
                this.testContent(testProcessor.Process());
            }
            let testImplementationAppend = this.testImplementation(instance, args);
            if (!ObjectValidator.IsSet(testImplementationAppend)) {
                testImplementationAppend = "";
            }
            this.testContent(this.testContent() + testImplementationAppend);
            testButtons.foreach(($button) => {
                this.testContent(this.testContent() + $button.getContent().toString());
            });
        }
        else {
            this.testContent("");
            this.normalImplementation(instance, args);
        }
        if ((!this.TestModeEnabled() && ObjectValidator.IsEmptyOrNull(instance)) ||
            (this.TestModeEnabled() &&
                ObjectValidator.IsEmptyOrNull(instance) && ObjectValidator.IsEmptyOrNull(this.testContent()))) {
            ExceptionsManager.Throw(this.getClassName(), "Class '" + this.getClassName() + "' does not contains valid implementation for current view mode.");
        }
    }
    /**
     * Renders the viewer's test content output and registers test button event handlers.
     * @returns {string} The rendered test content HTML string, or empty string if no test content.
     */
    Show() {
        let output = "";
        if (!ObjectValidator.IsEmptyOrNull(this.testContent())) {
            output += this.testContent();
            setTimeout(() => {
                this.getTestButtons().foreach(($button) => {
                    $button.Register();
                });
            });
        }
        return output;
    }
    /**
     * @returns {GuiCommons} Returns GUI object instance held by this viewer.
     */
    getInstance() {
        return super.getInstance();
    }
    setInstance($value) {
        super.setInstance($value);
    }
    beforeLoad($instance, $args) {
        super.beforeLoad($instance, $args);
    }
    afterLoad($instance, $args) {
        super.afterLoad($instance, $args);
    }
    layerHandler($layer, $instance) {
        super.layerHandler($layer, $instance);
    }
    argsHandler($instance, $args) {
        super.argsHandler($instance, $args);
    }
    normalImplementation($instance, $args) {
        super.normalImplementation($instance, $args);
    }
    testImplementation($instance, $args) {
        return super.testImplementation($instance, $args);
    }
    addTestButton($text, $onClick, $hideSideBar = true) {
        const button = new AbstractGuiObject($text);
        button.getEvents().setOnClick($onClick);
        if ($hideSideBar) {
            button.getEvents().setOnClick(() => {
                bootstrap.Offcanvas.getInstance(BaseViewer.getTestRenderTarget()).hide();
            });
        }
        this.getTestButtons().Add(button);
    }
    getTestButtons() {
        return super.getTestButtons();
    }
    excludeCacheData() {
        return super.excludeCacheData().concat(["argsHash"]);
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Bootstrap.Primitives.BaseViewer", BaseViewer);
//# sourceMappingURL=BaseViewer.js.map