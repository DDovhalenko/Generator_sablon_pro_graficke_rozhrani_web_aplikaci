import { BaseObject } from "./../../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
import { Reflection } from "./../../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { EventType } from "../../Enums/Events/EventType.js";
import { ElementEventsManager } from "../../Events/ElementEventsManager.js";
import { EventsManager } from "../../Events/EventsManager.js";
import { Loader } from "../../Loader.js";
import { ElementManager } from "../../Utils/ElementManager.js";
import { bootstrap } from "../../Utils/EnvironmentHelper.js";
import { Convert } from "./../../../../../Io/Oidis/Commons/Utils/Convert.js";
/**
 * Core GUI object class that provides the foundational infrastructure for all Bootstrap-based
 * GUI components. Manages DOM element binding, parent-child relationships, visibility, enabled
 * state, event subscription, rendering lifecycle, and lazy loading. All GUI primitives and
 * panels extend this class.
 */
export class GuiCommons extends BaseObject {
    id;
    instance;
    children;
    parent;
    events;
    loaded;
    registered;
    completed;
    isWrapper;
    visible;
    enabled;
    active;
    data;
    environment;
    httpManager;
    lazyLoad;
    /**
     * Returns the main page content holder DOM element used as the default render target
     * for GUI components. Caches the result after the first successful lookup.
     * @returns {HTMLElement} The page content holder element.
     */
    static getRenderTarget() {
        const element = ElementManager.getElement("PageContentHolder", true);
        if (!ObjectValidator.IsEmptyOrNull(element) && element instanceof Element) {
            this.getRenderTarget = () => {
                return element;
            };
        }
        return element;
    }
    constructor() {
        super();
        this.id = this.getUID();
        this.instance = null;
        this.children = {};
        this.parent = null;
        this.loaded = false;
        this.registered = false;
        this.completed = false;
        this.isWrapper = false;
        this.visible = true;
        this.enabled = true;
        this.active = false;
        this.data = null;
        this.environment = Loader.getInstance().getEnvironmentArgs();
        this.httpManager = Loader.getInstance().getHttpManager();
        this.lazyLoad = false;
    }
    /**
     * Returns the unique identifier of this GUI object, generated from the object's UID.
     * @returns {string} The unique identifier string.
     */
    Id() {
        return this.id;
    }
    /**
     * Gets or sets the lazy load flag. When enabled, the component's rendering is deferred
     * and not automatically triggered during parent rendering.
     * @param {boolean} [$value] Optional boolean to set the lazy load state.
     * @returns {boolean} The current lazy load state.
     */
    WithLazyLoad($value) {
        return this.lazyLoad = Property.Boolean(this.lazyLoad, $value);
    }
    /**
     * Sets the inner HTML content of this GUI object's DOM element.
     * @param {string} $value The HTML content string to set.
     * @returns {void}
     */
    Content($value) {
        ElementManager.setInnerHtml(this.instance, $value);
    }
    /**
     * Clears the inner HTML content and removes all registered child component references
     * if the component has been fully completed.
     * @returns {void}
     */
    Clear() {
        this.Content("");
        if (this.completed) {
            for (const item of Object.keys(this.children)) {
                delete this[item];
                delete this.children[item];
            }
        }
    }
    /**
     * Gets or sets the owning DOM element instance for this GUI object. When setting,
     * resolves string IDs to actual DOM elements and clears the data-oidis-bind attribute.
     * @param {any} [$value] Optional DOM element or element ID string to set as the instance owner.
     * @returns {any} The current owning DOM element.
     */
    InstanceOwner($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.instance = $value;
            if (ObjectValidator.IsString(this.instance)) {
                const element = ElementManager.getElement(this.instance);
                if (!ObjectValidator.IsEmptyOrNull(element)) {
                    this.instance = element;
                }
            }
            if (!ObjectValidator.IsEmptyOrNull(this.instance) && !ObjectValidator.IsEmptyOrNull(this.instance.dataset)) {
                delete this.instance.dataset.oidisBind;
            }
        }
        return this.instance;
    }
    /**
     * Gets or sets the parent GUI component of this object.
     * @param {GuiCommons} [$value] Optional parent component to set.
     * @returns {GuiCommons} The current parent component.
     */
    Parent($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.parent = $value;
        }
        return this.parent;
    }
    /**
     * Gets or sets arbitrary data associated with this GUI object.
     * @param {any} [$value] Optional data value to set.
     * @returns {any} The current data value.
     */
    Data($value) {
        if (ObjectValidator.IsSet($value)) {
            this.data = $value;
        }
        return this.data;
    }
    toString() {
        return this.Id();
    }
    /**
     * Returns the element events manager for this GUI object. Creates and initializes
     * the manager on first call, and subscribes it to the DOM element if the component
     * is already completed. Subsequent calls return the cached instance.
     * @returns {ElementEventsManager} The element events manager.
     */
    getEvents() {
        this.events = new ElementEventsManager(this);
        if (this.completed) {
            this.registered = true;
            this.events.Subscribe(this.InstanceOwner());
        }
        this.getEvents = () => {
            return this.events;
        };
        return this.events;
    }
    /**
     * Registers this GUI object and all its children by resolving DOM element bindings,
     * subscribing event handlers, and firing the ON_COMPLETE lifecycle event when
     * the component has been loaded but not yet completed.
     * @returns {void}
     */
    Register() {
        for (const name in this.children) {
            if (this.children.hasOwnProperty(name)) {
                const component = this[this.children[name]];
                if (ObjectValidator.IsObject(component)) {
                    component.Register();
                }
                else {
                    LogIt.Warning("{0} was declared but instance is missing. Did you miss it in constructor?", this.getClassName() + "." + this.children[name]);
                }
            }
        }
        if (ObjectValidator.IsString(this.instance)) {
            this.InstanceOwner(ElementManager.getElement(this.instance));
            this.syncInputDOM(this.instance);
        }
        if (!ObjectValidator.IsEmptyOrNull(this.events) && !this.registered) {
            this.registered = true;
            this.events.Subscribe(this.InstanceOwner());
        }
        if (this.loaded && !this.completed) {
            this.completed = true;
            EventsManager.getInstanceSingleton().FireEvent(this, EventType.ON_COMPLETE);
        }
    }
    /**
     * Gets or sets the enabled state of this GUI object. When setting, adds or removes
     * the "disabled" CSS class on the DOM element.
     * @param {boolean} [$value] Optional boolean to set the enabled state.
     * @returns {boolean} The current enabled state.
     */
    Enabled($value) {
        this.enabled = Property.Boolean(this.enabled, $value);
        if (ObjectValidator.IsSet($value)) {
            this.setAttribute(!this.enabled, "disabled");
        }
        return this.enabled;
    }
    /**
     * Gets or sets the active state of this GUI object. When setting, adds or removes
     * the "active" CSS class on the DOM element.
     * @param {boolean} [$value] Optional boolean to set the active state.
     * @returns {boolean} The current active state.
     */
    Active($value) {
        this.active = Property.Boolean(this.active, $value);
        if (ObjectValidator.IsSet($value)) {
            this.setAttribute(this.active, "active");
        }
        return this.active;
    }
    /**
     * Gets or sets the visibility state of this GUI object. When setting, toggles
     * the "invisible" and "d-none" CSS classes on the DOM element.
     * @param {boolean} [$value] Optional boolean to set the visibility state.
     * @returns {boolean} The current visibility state.
     */
    Visible($value) {
        this.visible = Property.Boolean(this.visible, $value);
        if (ObjectValidator.IsSet($value)) {
            this.setAttribute(!this.visible, "invisible");
            this.setAttribute(!this.visible, "d-none");
        }
        return this.visible;
    }
    /**
     * Renders this GUI object and all its non-lazy-loaded children into the DOM.
     * Determines the appropriate parent element, appends the generated DOM, resolves
     * data-oidis-bind attributes, fires ON_LOAD lifecycle event, and calls Register.
     * @returns {void}
     */
    Render() {
        let element = this.getDOM();
        if (!ObjectValidator.IsEmptyOrNull(element.innerHTML) && !this.isWrapper) {
            let parent;
            if (ObjectValidator.IsEmptyOrNull(this.Parent())) {
                parent = GuiCommons.getRenderTarget();
            }
            else if (this.IsMemberOf("Io.Oidis.Gui.Bootstrap.Primitives.BasePanel")) {
                this.Clear();
                parent = this.InstanceOwner();
            }
            else {
                if (ObjectValidator.IsEmptyOrNull(this.Parent().InstanceOwner())) {
                    this.Parent().InstanceOwner(this.Parent().getDOM());
                }
                parent = this.Parent().InstanceOwner();
            }
            if (!ObjectValidator.IsEmptyOrNull(parent)) {
                if (element.isTemplate) {
                    while (element.firstChild) {
                        parent.appendChild(element.firstChild);
                    }
                    element = parent;
                    if (!ObjectValidator.IsEmptyOrNull(element)) {
                        this.getDOM = () => {
                            return element;
                        };
                    }
                }
                else {
                    parent.appendChild(element);
                }
            }
            else {
                LogIt.Warning("Parent element has not been found for: {0}", this.getClassName());
            }
        }
        for (const name in this.children) {
            if (this.children.hasOwnProperty(name)) {
                const component = this[this.children[name]];
                component.Parent(this);
                if (ObjectValidator.IsObject(component) && !component.WithLazyLoad()) {
                    component.Render();
                }
            }
        }
        this.syncInputDOM(this.instance);
        this.InstanceOwner(this.instance);
        if (ObjectValidator.IsObject(this.instance) && !this.loaded) {
            this.loaded = true;
            EventsManager.getInstanceSingleton().FireEvent(this, EventType.ON_LOAD);
        }
        this.Register();
    }
    /**
     * Dynamically adds a child GUI component to this object. Handles both panel and
     * non-panel children differently: panels get a wrapper container and are rendered
     * immediately, while other components are appended to the DOM and registered.
     * @param {GuiCommons} $element The child GUI component to add.
     * @returns {void}
     */
    AddChild($element) {
        const isPanel = Reflection.getInstance().IsMemberOf($element, "Io.Oidis.Gui.Bootstrap.Primitives.BasePanel");
        if (!Reflection.getInstance().IsMemberOf($element, GuiCommons.ClassName())) {
            throw new Error("Invalid child element type: " + Convert.ToType($element));
        }
        this.children[$element.Id()] = $element.Id();
        this[$element.Id()] = $element;
        if (!isPanel) {
            $element.Parent(this);
        }
        else {
            $element.parent = null;
        }
        const dom = !ObjectValidator.IsObject(this.InstanceOwner()) ? this.getDOM() : this.InstanceOwner();
        let owner = dom;
        if (owner.isTemplate) {
            if (owner.tagName.toUpperCase() === "TABLE" && owner.childElementCount === 1) {
                owner = owner.firstChild;
            }
        }
        const childDom = $element.getDOM();
        if (isPanel) {
            const container = document.createElement("div");
            if (!$element.Visible()) {
                container.classList.add("d-none");
            }
            owner.appendChild(container);
            $element.InstanceOwner(container);
            $element.Parent(this);
            $element.WithLazyLoad(false);
            $element.Render();
        }
        else {
            if (!ObjectValidator.IsEmptyOrNull(childDom.innerHTML)) {
                if (childDom.isTemplate) {
                    let firstChild = null;
                    while (childDom.firstChild) {
                        if (firstChild === null) {
                            firstChild = childDom.firstChild;
                        }
                        owner.appendChild(childDom.firstChild);
                    }
                    if (firstChild !== null && ObjectValidator.IsEmptyOrNull($element.InstanceOwner())) {
                        this.syncInputDOM(firstChild);
                        $element.InstanceOwner(firstChild);
                    }
                    if (!ObjectValidator.IsEmptyOrNull(dom)) {
                        $element.getDOM = () => {
                            return dom;
                        };
                    }
                }
                else {
                    owner.appendChild(childDom);
                }
            }
            if (ObjectValidator.IsObject($element.InstanceOwner()) && !$element.loaded) {
                $element.loaded = true;
                EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_LOAD);
            }
            this.Register();
        }
    }
    /**
     * Replaces an existing child component with a new one in the DOM and internal
     * children registry. The old child's DOM element is removed and replaced by the
     * new child's DOM content.
     * @param {GuiCommons} $old The existing child component to replace.
     * @param {GuiCommons} $new The new child component to insert.
     * @returns {void}
     */
    SwapChild($old, $new) {
        if ($old.Parent() === this) {
            this.children[$new.Id()] = this.children[$old.Id()];
            delete this.children[$old.Id()];
            this[this.children[$new.Id()]] = $new;
            $new.Parent(this);
            const dom = $old.InstanceOwner();
            const childDom = $new.getDOM();
            let swapped = false;
            let owner = null;
            try {
                if (childDom.isTemplate) {
                    owner = childDom.firstChild;
                    while (childDom.lastChild) {
                        dom.parentNode.insertBefore(childDom.lastChild, dom);
                    }
                }
                else {
                    owner = childDom;
                    dom.parentNode.insertBefore(childDom, dom);
                }
                swapped = true;
            }
            catch (ex) {
                LogIt.Error("SwapChild failed", ex);
            }
            if (swapped) {
                dom.parentNode.removeChild(dom);
                if (owner !== null && ObjectValidator.IsEmptyOrNull($new.InstanceOwner())) {
                    this.syncInputDOM(owner);
                    $new.InstanceOwner(owner);
                }
                if (ObjectValidator.IsObject($new.InstanceOwner()) && !$new.loaded) {
                    $new.loaded = true;
                    EventsManager.getInstanceSingleton().FireEvent($new, EventType.ON_LOAD);
                }
                this.Register();
            }
        }
    }
    /**
     * Returns an array of all direct child GUI components registered to this object.
     * @returns {GuiCommons[]} Array of child GUI components.
     */
    getChildList() {
        return Object.keys(this.children).map(($item) => this[this.children[$item]]);
    }
    /**
     * Associates an HTML label element with this GUI object's input DOM element
     * by setting the "for" attribute on the label.
     * @param {GuiCommons} $value The GUI component whose instance owner is a label element.
     * @returns {void}
     */
    AssignLabel($value) {
        if (!this.registerLabel($value.InstanceOwner())) {
            LogIt.Warning("Failed to assign Label for " + this.Id() + " element: target must be valid HTML <label> element");
        }
    }
    innerCode() {
        return "";
    }
    innerHtml() {
        return "";
    }
    setAttribute($value, $keyword) {
        if (ObjectValidator.IsObject(this.instance)) {
            try {
                if ($value) {
                    this.instance.classList.add($keyword);
                }
                else {
                    this.instance.classList.remove($keyword);
                }
            }
            catch (ex) {
                LogIt.Warning("ClassList modification failure for " + this.Id() + ". Fallback to ElementManager.");
                const currentClass = this.instance.className;
                if (!ObjectValidator.IsEmptyOrNull(currentClass) && currentClass !== $keyword) {
                    $keyword = " " + $keyword;
                }
                if ($value) {
                    if (!StringUtils.Contains(currentClass, $keyword)) {
                        ElementManager.setClassName(this.instance, currentClass + $keyword);
                    }
                }
                else {
                    ElementManager.setClassName(this.instance, StringUtils.Remove(currentClass, $keyword));
                }
            }
        }
    }
    getContent() {
        const code = this.innerCode();
        const html = this.innerHtml();
        const content = {
            code,
            html,
            toString: () => {
                return code + html;
            }
        };
        this.getContent = () => {
            return content;
        };
        return content;
    }
    getDOMTemplateType() {
        const content = this.getContent().html.trim();
        if (StringUtils.StartsWith(content, "<tr")) {
            return "tbody";
        }
        else if (StringUtils.StartsWith(content, "<tbody")) {
            return "table";
        }
        return "span";
    }
    getDOM() {
        const dom = document.createElement(this.getDOMTemplateType());
        dom.isTemplate = true;
        const content = this.getContent().toString();
        if (!ObjectValidator.IsEmptyOrNull(content)) {
            let hasBindThis = StringUtils.Contains(content, `data-oidis-bind="${this.Id()}"`, `data-oidis-bind='${this.Id()}'`);
            if (this.IsMemberOf("Io.Oidis.Gui.Bootstrap.Primitives.BasePanel") && ObjectValidator.IsEmptyOrNull(this.Parent())) {
                dom.insertAdjacentHTML("beforeend", `
                <section data-oidis-bind="${this}" class="${(StringUtils.Remove(this.getNamespaceName(), "."))}">
                <section class="${(StringUtils.Remove(this.getClassNameWithoutNamespace(), "."))}">
                    ${content}
                </section>
                </section>`);
                hasBindThis = true;
            }
            else {
                dom.insertAdjacentHTML("beforeend", content);
            }
            const reflection = Reflection.getInstance();
            this.getProperties().forEach(($name) => {
                if (reflection.IsMemberOf(this[$name], GuiCommons) && $name !== "parent") {
                    this.children[this[$name].Id()] = $name;
                }
            });
            const elements = dom.querySelectorAll("[data-oidis-bind]");
            for (const element of elements) {
                const id = element.dataset.oidisBind;
                if (id === "undefined") {
                    LogIt.Warning(this.getClassName() + " contains binding for uninitialized components.");
                }
                else if (id === this.Id()) {
                    this.InstanceOwner(element);
                }
                else if (!ObjectValidator.IsEmptyOrNull(this.children)) {
                    const name = this.children[id];
                    if (!ObjectValidator.IsEmptyOrNull(name)) {
                        const component = this[name];
                        if (!ObjectValidator.IsEmptyOrNull(component)) {
                            let generate = ObjectValidator.IsEmptyOrNull(element.innerHTML);
                            if (element instanceof HTMLInputElement) {
                                generate = false;
                            }
                            if ((!ObjectValidator.IsEmptyOrNull(component.Parent()) && component.Parent().isWrapper) || this.isWrapper) {
                                generate = false;
                            }
                            if (generate) {
                                const componentDom = component.getDOM();
                                if (!ObjectValidator.IsEmptyOrNull(componentDom.innerHTML)) {
                                    if (componentDom.isTemplate) {
                                        while (componentDom.firstChild) {
                                            element.appendChild(componentDom.firstChild);
                                        }
                                    }
                                }
                            }
                            else {
                                component.isWrapper = true;
                            }
                            component.syncInputDOM(element);
                            component.InstanceOwner(element);
                            component.Parent(this);
                        }
                    }
                }
            }
            if (!hasBindThis) {
                if (dom.children.length === 1) {
                    this.InstanceOwner(dom.children[0]);
                }
                else if (dom.children.length > 1) {
                    LogIt.Warning(this.getClassName() + " contains multiple root DOM children nodes. This is not supported, single node " +
                        "should be used instead or explicitly define data-oidis-bind=\"this\" for one of the children element.");
                }
            }
            dom.querySelectorAll("[data-bs-toggle=\"tooltip\"]").forEach(($element) => {
                new bootstrap.Tooltip($element);
            });
        }
        if (!ObjectValidator.IsEmptyOrNull(dom)) {
            this.getDOM = () => {
                return dom;
            };
        }
        return dom;
    }
    getInputDOM() {
        const dom = document.createElement("input");
        this.getInputDOM = () => {
            return dom;
        };
        return dom;
    }
    registerLabel($target) {
        if (!ObjectValidator.IsEmptyOrNull($target) && $target.nodeName.toLowerCase() === "label") {
            this.getInputDOM().id = this.getClassNameWithoutNamespace() + "_" + this.Id();
            $target.setAttribute("for", this.getInputDOM().id);
            return true;
        }
        return false;
    }
    getHttpManager() {
        return this.httpManager;
    }
    getEnvironmentArgs() {
        return this.environment;
    }
    syncInputDOM($target) {
        if (!ObjectValidator.IsEmptyOrNull($target) && ObjectValidator.IsSet($target.value)) {
            if ($target.value !== this.getInputDOM().value) {
                $target.value = this.getInputDOM().value;
            }
            if (this.getInputDOM().nodeName.toLowerCase() === "input") {
                this.registerLabel(this.getInputDOM().nextElementSibling);
            }
            this.getInputDOM = () => {
                return $target;
            };
        }
    }
}
/**
 * Simple GUI button component used primarily for test mode sidebar buttons. Renders
 * a Bootstrap primary button with the specified text label and data-oidis-bind attribute.
 */
export class AbstractGuiObject extends GuiCommons {
    text;
    constructor($text) {
        super();
        this.text = $text;
    }
    innerHtml() {
        return `<button data-oidis-bind="${this}" class="btn btn-primary d-block" type="button" style="margin-bottom: 10px;">${this.text}</button>`;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Bootstrap.Primitives.GuiCommons", GuiCommons);
globalThis.RegisterClass("Io.Oidis.Gui.Bootstrap.Primitives.AbstractGuiObject", AbstractGuiObject);
//# sourceMappingURL=GuiCommons.js.map