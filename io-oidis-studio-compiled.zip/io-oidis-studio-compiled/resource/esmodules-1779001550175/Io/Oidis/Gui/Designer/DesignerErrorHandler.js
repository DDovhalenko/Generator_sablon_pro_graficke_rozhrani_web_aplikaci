/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ExceptionsManager } from "./../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { AsyncHttpResolver } from "./../../../../Io/Oidis/Commons/HttpProcessor/Resolvers/AsyncHttpResolver.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { DesignerTaskType } from "../Enums/DesignerTaskType.js";
import { HttpRequestConstants } from "../Enums/HttpRequestConstants.js";
/**
 * DesignerErrorHandler class provides redirection of exceptions handling to the GUI Designer layer.
 */
export class DesignerErrorHandler extends AsyncHttpResolver {
    exceptionsList;
    argsHandler($GET, $POST) {
        if (ObjectValidator.IsEmptyOrNull(this.exceptionsList)) {
            if ($POST.KeyExists(HttpRequestConstants.EXCEPTIONS_LIST)) {
                this.exceptionsList = $POST.getItem(HttpRequestConstants.EXCEPTIONS_LIST);
            }
            else {
                this.exceptionsList = new ArrayList();
            }
        }
    }
    getExceptionsList() {
        return this.exceptionsList;
    }
    resolver() {
        try {
            Echo.ClearAll();
            this.sendData({
                data: Echo.getStream(),
                task: DesignerTaskType.ECHO
            });
            this.sendData({
                data: this.getExceptionsList().ToString(),
                task: DesignerTaskType.FAIL
            });
        }
        catch (ex) {
            try {
                this.sendData({
                    data: ex.message,
                    task: DesignerTaskType.FAIL
                });
            }
            catch (ex) {
                ExceptionsManager.HandleException(ex);
            }
        }
    }
    sendData($data) {
        try {
            window.parent.postMessage($data, "*");
        }
        catch (ex) {
            window.parent.postMessage({
                data: "Failed to send designer data: " + ex.message,
                task: DesignerTaskType.FAIL
            }, "*");
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Designer.DesignerErrorHandler", DesignerErrorHandler);
//# sourceMappingURL=DesignerErrorHandler.js.map