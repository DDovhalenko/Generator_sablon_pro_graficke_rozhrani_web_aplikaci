var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BuilderConnector } from "./../../../../Io/Oidis/Commons/Connectors/BuilderConnector.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Commons/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { Convert } from "./../../../../Io/Oidis/Commons/Utils/Convert.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ObjectDecoder } from "./../../../../Io/Oidis/Commons/Utils/ObjectDecoder.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { DesignerProtocolConstants } from "../Enums/DesignerProtocolConstants.js";
import { DesignerTaskType } from "../Enums/DesignerTaskType.js";
import { EventType } from "../Enums/Events/EventType.js";
import { GuiCommonsArgType } from "../Enums/GuiCommonsArgType.js";
import { GuiOptionType } from "../Enums/GuiOptionType.js";
import { HttpRequestConstants } from "../Enums/HttpRequestConstants.js";
import { DrawGuiObject } from "../HttpProcessor/Resolvers/DrawGuiObject.js";
import { RuntimeTestRunner as GuiRuntimeTestRunner } from "../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { IBaseViewer } from "../Interfaces/Primitives/IBaseViewer.js";
import { IFormsObject } from "../Interfaces/Primitives/IFormsObject.js";
import { IGuiCommons } from "../Interfaces/Primitives/IGuiCommons.js";
import { BasePanel } from "../Primitives/BasePanel.js";
import { BasePanelViewer } from "../Primitives/BasePanelViewer.js";
import { GuiCommons } from "../Primitives/GuiCommons.js";
import { GuiElement } from "../Primitives/GuiElement.js";
import { ElementManager } from "../Utils/ElementManager.js";
import { StaticPageContentManager } from "../Utils/StaticPageContentManager.js";
import { WindowManager } from "../Utils/WindowManager.js";
import { ViewerManager } from "../ViewerManager.js";
import { BlankPanelViewer } from "./BlankPanelViewer.js";
import { DesignerElement } from "./DesignerElement.js";
import { DesignerErrorHandler } from "./DesignerErrorHandler.js";
import { Resolver, ResolverScope } from "./../../../../Io/Oidis/Commons/Primitives/Decorators.js";
/**
 * DesignerRunner class provides handling of requests for rendering of GUI objects with focus on GUI Designer needs.
 */
let DesignerRunner = class DesignerRunner extends DrawGuiObject {
    /**
     * @param {string} [$value] Object class name in string format, which should be used by the designer.
     * @returns {string} Returns object class name.
     */
    ObjectClassName($value) {
        if (ObjectValidator.IsEmptyOrNull($value)) {
            if (!ObjectValidator.IsSet(this.objectName)) {
                this.objectName = this.getRequest().getScriptPath();
                this.objectName = StringUtils.Remove(this.objectName, "/" + HttpRequestConstants.TEST_MODE);
                this.objectName = StringUtils.Remove(this.objectName, "/" + HttpRequestConstants.FORCE_REFRESH);
                this.objectName = StringUtils.Substring(this.objectName, StringUtils.IndexOf(this.objectName, "design/") + 7, StringUtils.Length(this.objectName));
                this.objectName = StringUtils.Replace(this.objectName, "/", ".");
            }
        }
        else {
            this.objectName = Property.String(this.objectName, $value);
        }
        return this.objectName;
    }
    /**
     * Execute implementation.
     * @returns {void}
     */
    Process() {
        Echo.ClearAll();
        this.resolver();
    }
    testMode() {
        return true;
    }
    refresh() {
        return true;
    }
    includeChildren() {
        return true;
    }
    navigator() {
        return "";
    }
    resolver() {
        this.overrideResolver("/ServerError/Exception/{" + HttpRequestConstants.EXCEPTION_TYPE + "}", DesignerErrorHandler);
        const connector = BuilderConnector.Connect();
        connector.getEvents().OnError(($args) => {
            Echo.Println($args.Message());
        });
        const errorHandler = ($message) => {
            this.fireOnBuild("fail");
            Echo.Println($message);
        };
        connector.getEvents().OnStart(() => {
            connector.getEvents().OnBuildStart(() => {
                this.fireOnBuild("start");
            });
            connector.getEvents().OnBuildComplete(() => {
                this.fireOnBuild("complete");
            });
            connector.getEvents().OnFail(errorHandler);
            connector.getEvents().OnWarning(errorHandler);
        });
        connector.getEvents().OnMessage(($data) => {
            Echo.Println($data);
        });
        if (!ObjectValidator.IsEmptyOrNull(this.ObjectClassName())) {
            GuiCommons.GuiElementClass(DesignerElement);
            const reflection = Reflection.getInstance();
            const newObjectsMap = new ArrayList();
            let viewer;
            let instance = null;
            const instanceMap = new ArrayList();
            const getInstance = () => {
                if (ObjectValidator.IsEmptyOrNull(viewer)) {
                    viewer = ViewerManager.getLoadedViewers().getItem(this.loadGuiObject().getId());
                    instance = viewer.getInstance();
                }
            };
            const variableNameExists = ($name) => {
                let index;
                if (!ObjectValidator.IsEmptyOrNull(instance)) {
                    const properties = instance.getProperties();
                    for (index = 0; index < properties.length; index++) {
                        if (properties[index] === $name) {
                            return true;
                        }
                    }
                }
                for (index = 0; index < newObjectsMap.Length(); index++) {
                    if (newObjectsMap.getItem(index)[DesignerProtocolConstants.VARIABLE_NAME] === $name) {
                        return true;
                    }
                }
                return false;
            };
            const getInstanceMap = ($element) => {
                const elements = this.guiManager.getAll();
                instanceMap.Clear();
                let elementMap = $element.getInnerHtmlMap().getMap();
                let position = instance.getScreenPosition();
                const size = instance.getSize();
                const dataLookup = ($data) => {
                    $data.forEach(($item) => {
                        if (ObjectValidator.IsSet($item.name)) {
                            instanceMap.Add($item.name, $item.id);
                            let position;
                            if (elements.KeyExists($item.id)) {
                                const guiElement = elements.getItem($item.id);
                                position = guiElement.getScreenPosition();
                                const size = guiElement.getSize();
                                $item.top = position.Top();
                                $item.left = position.Left();
                                $item.width = size.Width();
                                $item.height = size.Height();
                            }
                        }
                        else if (ElementManager.Exists($item.id)) {
                            const htmlElement = ElementManager.getElement($item.id);
                            position = ElementManager.getAbsoluteOffset(htmlElement);
                            $item.top = position.Top();
                            $item.left = position.Left();
                            $item.width = htmlElement.offsetWidth;
                            $item.height = htmlElement.offsetHeight;
                        }
                        if (ObjectValidator.IsSet($item.map)) {
                            dataLookup($item.map);
                        }
                    });
                };
                elementMap = [
                    {
                        height: size.Height(),
                        id: $element.Id(),
                        left: position.Left(),
                        map: elementMap,
                        name: DesignerProtocolConstants.ROOT_ELEMENT_VARIABLE,
                        top: position.Top(),
                        type: DesignerProtocolConstants.GUI_OBJECT,
                        width: size.Width()
                    }
                ];
                dataLookup(elementMap);
                this.sendData({
                    data: elementMap,
                    task: DesignerTaskType.GET_INSTANCE_MAP
                });
            };
            const getBlankInstanceMap = () => {
                const map = [];
                newObjectsMap.foreach(($element) => {
                    const position = $element.getScreenPosition();
                    const size = $element.getSize();
                    map.push({
                        height: size.Height(),
                        id: $element.Id(),
                        left: position.Left(),
                        name: $element[DesignerProtocolConstants.VARIABLE_NAME],
                        top: position.Top(),
                        type: DesignerProtocolConstants.GUI_OBJECT,
                        width: size.Width()
                    });
                });
                this.sendData({
                    data: map,
                    task: DesignerTaskType.GET_INSTANCE_MAP
                });
            };
            const markRootElement = () => {
                getInstance();
                if (!ObjectValidator.IsEmptyOrNull(instance) && instance.IsMemberOf(BasePanel)) {
                    const args = instance.getArgs();
                    args.push({
                        name: DesignerProtocolConstants.VARIABLE_NAME,
                        type: GuiCommonsArgType.TEXT,
                        value: DesignerProtocolConstants.ROOT_ELEMENT_VARIABLE
                    });
                    this.fireShowProperties(instance.Id(), args);
                    const position = instance.getScreenPosition();
                    const size = instance.getSize();
                    this.fireMarkItem({
                        draggable: false,
                        height: size.Height(),
                        id: instance.Id(),
                        left: position.Left(),
                        resizeable: true,
                        top: position.Top(),
                        width: size.Width()
                    });
                }
            };
            const moveElement = ($elementId, $top, $left) => {
                const element = this.guiManager.getAll().getItem($elementId);
                let wrapperPosition;
                if (!ObjectValidator.IsEmptyOrNull(element)) {
                    wrapperPosition = ElementManager.getScreenPosition(ElementManager.getElement($elementId).parentElement.parentElement);
                    const contentElement = ElementManager.getElement(element.guiContentId());
                    element.setPosition($top - wrapperPosition.Top() - contentElement.offsetTop, $left - wrapperPosition.Left() - contentElement.offsetLeft);
                }
                else if (ElementManager.Exists($elementId)) {
                    const positionType = ElementManager.getCssValue($elementId, "position");
                    if (ObjectValidator.IsEmptyOrNull(positionType) ||
                        positionType === "static" ||
                        positionType === "relative") {
                        if (positionType !== "relative") {
                            ElementManager.setCssProperty($elementId, "position", "relative");
                        }
                    }
                    wrapperPosition = ElementManager.getScreenPosition(ElementManager.getElement($elementId).parentElement);
                    ElementManager.setCssProperty($elementId, "top", $top - wrapperPosition.Top());
                    ElementManager.setCssProperty($elementId, "left", $left - wrapperPosition.Left());
                }
            };
            WindowManager.getEvents().setOnMessage(($eventArgs) => {
                const data = $eventArgs.NativeEventArgs().data;
                let elementId;
                let element;
                let htmlElement;
                switch (data.task) {
                    case DesignerTaskType.RELOAD:
                        this.getHttpManager().Reload();
                        break;
                    case DesignerTaskType.BUILD:
                        connector.Send("Cmd", {
                            args: ["build", "dev", "--skip-test"],
                            cmd: "wui"
                        });
                        break;
                    case DesignerTaskType.ADD_ITEM:
                        // eslint-disable-next-line no-case-declarations
                        const addItemData = data.data;
                        elementId = addItemData.id;
                        if (reflection.Exists(elementId)) {
                            Echo.Printf("Add item: {0}", elementId);
                            getInstance();
                            const newObjectClass = reflection.getClass(elementId);
                            let newObject;
                            if (reflection.ClassHasInterface(newObjectClass, BasePanelViewer.ClassName())) {
                                const newViewer = new newObjectClass(newObjectClass.getTestViewerArgs());
                                newViewer.PrepareImplementation();
                                newViewer.getInstance().getChildPanelList().foreach(($child) => {
                                    $child.PrepareImplementation();
                                });
                                newObject = newViewer.getInstance();
                            }
                            else {
                                newObject = new newObjectClass();
                            }
                            newObject.getGuiOptions().Add(GuiOptionType.ALL);
                            let variableName = newObject.getClassNameWithoutNamespace();
                            variableName = StringUtils.ToLowerCase(StringUtils.Substring(variableName, 0, 1)) +
                                StringUtils.Substring(variableName, 1);
                            let variableIncrement = 1;
                            while (variableNameExists(variableName + variableIncrement)) {
                                variableIncrement++;
                            }
                            newObject[DesignerProtocolConstants.VARIABLE_NAME] = variableName + variableIncrement;
                            let addToPanel = false;
                            let target;
                            let positionType = "fixed";
                            if (!ObjectValidator.IsEmptyOrNull(instance)) {
                                if (instance.IsMemberOf(BasePanel)) {
                                    addToPanel = true;
                                    instance.AddChild(newObject, newObject[DesignerProtocolConstants.VARIABLE_NAME]);
                                    positionType = "relative"; // eslint-disable-line @typescript-eslint/no-unused-vars
                                }
                                else {
                                    newObject.Parent(instance);
                                    target = ElementManager.getElement(instance).parentElement.parentElement.parentElement;
                                }
                            }
                            else {
                                target = ElementManager.getElement("Content");
                            }
                            if (!ObjectValidator.IsEmptyOrNull(addItemData.top)) {
                                newObject.getEvents().setOnComplete(() => {
                                    moveElement(newObject.Id(), addItemData.top, addItemData.left);
                                });
                            }
                            newObjectsMap.Add(newObject);
                            if (!addToPanel) {
                                newObject.InstanceOwner(viewer);
                                newObject.Visible(false);
                                target.appendChild(new GuiElement().Add(newObject).ToDOMElement(StringUtils.NewLine(false)));
                                newObject.Visible(true);
                            }
                            if (!ObjectValidator.IsEmptyOrNull(instance)) {
                                if (!addToPanel) {
                                    instance[newObject[DesignerProtocolConstants.VARIABLE_NAME]] = newObject;
                                    instance.getChildElements().Add(newObject, newObject.Id());
                                    instance.getInnerHtmlMap().Add(newObject);
                                }
                                getInstanceMap(instance);
                            }
                            else {
                                getBlankInstanceMap();
                            }
                        }
                        else {
                            Echo.Printf("Required item class does not exist: {0}", elementId);
                        }
                        break;
                    case DesignerTaskType.DELETE_ITEM:
                        elementId = data.data.id;
                        element = this.guiManager.getAll().getItem(elementId);
                        Echo.Printf("Delete: {0}", elementId);
                        htmlElement = null;
                        if (!ObjectValidator.IsEmptyOrNull(element)) {
                            element.Visible(false);
                            newObjectsMap.RemoveAt(newObjectsMap.IndexOf(element));
                            htmlElement = ElementManager.getElement(elementId).parentElement.parentElement;
                            this.guiManager.Clear(element);
                        }
                        else if (ElementManager.Exists(elementId)) {
                            htmlElement = ElementManager.getElement(elementId);
                        }
                        if (!ObjectValidator.IsEmptyOrNull(htmlElement)) {
                            htmlElement.parentElement.removeChild(htmlElement);
                            ElementManager.CleanElementCache(elementId);
                        }
                        break;
                    case DesignerTaskType.ITEM_EXISTS:
                        getInstance();
                        this.fireItemExists(elementId, variableNameExists(data.data));
                        break;
                    case DesignerTaskType.SELECT_ROOT_ITEM:
                        markRootElement();
                        break;
                    case DesignerTaskType.SELECT_ITEM:
                        elementId = data.data;
                        element = this.guiManager.getAll().getItem(elementId);
                        let args; // eslint-disable-line no-case-declarations
                        if (!ObjectValidator.IsEmptyOrNull(element)) {
                            args = element.getArgs();
                            args.push({
                                name: DesignerProtocolConstants.VARIABLE_NAME,
                                type: GuiCommonsArgType.TEXT,
                                value: instanceMap.getItem(elementId)
                            });
                            this.fireShowProperties(elementId, args);
                            const position = element.getScreenPosition();
                            const size = element.getSize();
                            this.fireMarkItem({
                                draggable: ObjectValidator.IsEmptyOrNull(instance) ||
                                    (!ObjectValidator.IsEmptyOrNull(instance) && elementId !== instance.Id()),
                                height: size.Height(),
                                id: elementId,
                                left: position.Left(),
                                resizeable: true,
                                top: position.Top(),
                                width: size.Width()
                            });
                        }
                        else if (ElementManager.Exists(elementId)) {
                            args = [
                                {
                                    name: "Id",
                                    type: GuiCommonsArgType.TEXT,
                                    value: elementId
                                },
                                {
                                    name: DesignerProtocolConstants.VARIABLE_NAME,
                                    type: GuiCommonsArgType.TEXT,
                                    value: DesignerProtocolConstants.HTML_ELEMENT_VARIABLE
                                },
                                {
                                    name: "StyleClassName",
                                    type: GuiCommonsArgType.TEXT,
                                    value: ""
                                },
                                {
                                    name: "Visible",
                                    type: GuiCommonsArgType.BOOLEAN,
                                    value: true
                                }
                            ];
                            this.fireShowProperties(elementId, args);
                            htmlElement = ElementManager.getElement(elementId);
                            const position = ElementManager.getAbsoluteOffset(htmlElement);
                            this.fireMarkItem({
                                draggable: true,
                                height: htmlElement.offsetHeight,
                                id: elementId,
                                left: position.Left(),
                                resizeable: true,
                                top: position.Top(),
                                width: htmlElement.offsetWidth
                            });
                        }
                        break;
                    case DesignerTaskType.MOVE_ITEM:
                        // eslint-disable-next-line no-case-declarations
                        const moveItemData = data.data;
                        moveElement(moveItemData.id, moveItemData.top, moveItemData.left);
                        break;
                    case DesignerTaskType.GET_INSTANCE_MAP:
                        if (!ObjectValidator.IsEmptyOrNull(instance)) {
                            getInstanceMap(instance);
                        }
                        else {
                            getBlankInstanceMap();
                        }
                        break;
                    case DesignerTaskType.SET_PROPERTY:
                        // eslint-disable-next-line no-case-declarations
                        const setItemData = data.data;
                        elementId = setItemData.id;
                        getInstance();
                        Echo.Printf("Set item: {0}[{1}] - {2}", elementId, setItemData.name, setItemData.value);
                        element = this.guiManager.getAll().getItem(elementId);
                        if (!ObjectValidator.IsEmptyOrNull(element)) {
                            if (setItemData.name === DesignerProtocolConstants.VARIABLE_NAME) {
                                if (!variableNameExists(setItemData.value)) {
                                    element[DesignerProtocolConstants.VARIABLE_NAME] = setItemData.value;
                                }
                                else {
                                    this.fireItemExists(elementId, true);
                                }
                            }
                            else {
                                element.setArg(setItemData, true);
                            }
                        }
                        else if (ElementManager.Exists(elementId)) {
                            if (setItemData.name === "Visible") {
                                if (setItemData.value) {
                                    ElementManager.Show(elementId);
                                }
                                else {
                                    ElementManager.Hide(elementId);
                                }
                            }
                            else {
                                ElementManager.setCssProperty(elementId, setItemData.name, setItemData.type === GuiCommonsArgType.NUMBER ?
                                    Convert.StringToInteger(setItemData.value) : setItemData.value);
                            }
                        }
                        break;
                    case DesignerTaskType.SET_SIZE:
                        // eslint-disable-next-line no-case-declarations
                        const sizeItemData = data.data;
                        const value = sizeItemData.zoom; // eslint-disable-line no-case-declarations
                        ElementManager.setZoom(document.body, 100);
                        ElementManager.setZoom("Designer_Background", 100);
                        ElementManager.setZoom(document.body, value);
                        if (value <= 100) {
                            const newWidth = Convert.ToFixed(sizeItemData.width * 100 / value, 0);
                            const newHeight = Convert.ToFixed(sizeItemData.height * 100 / value, 0);
                            ElementManager.setWidth(document.body, newWidth);
                            ElementManager.setHeight("Designer_Background", newHeight);
                        }
                        break;
                    default:
                        Echo.Println("Unrecognized Designer task: \"" + data.task + "\"");
                        break;
                }
            });
            WindowManager.getEvents().setOnDoubleClick(markRootElement);
            WindowManager.getEvents().setOnLoad(() => {
                Echo.setOnPrint(($message) => {
                    this.sendData({
                        data: $message,
                        task: DesignerTaskType.ECHO
                    });
                });
                StaticPageContentManager.BodyAppend("<div guiType=\"DeveloperCorner\" class=\"DeveloperCorner\">" +
                    "   <div class=\"Designer\">" +
                    "       <div id=\"Designer_Background\" class=\"Background\"></div>" +
                    "   </div>" +
                    "</div>");
                ElementManager.setHeight("Designer_Background", WindowManager.getSize().Height());
                if (ObjectValidator.IsEmptyOrNull(viewer)) {
                    getInstance();
                    if (!ObjectValidator.IsEmptyOrNull(instance)) {
                        instance.getEvents().setOnComplete(($eventArgs) => {
                            getInstanceMap($eventArgs.Owner());
                            this.fireEvent(EventType.ON_LOAD, "root");
                        });
                    }
                }
                this.fireEvent(EventType.ON_LOAD, "body");
            });
            super.resolver();
        }
        else {
            const host = this.getRequest().getHostUrl();
            const reflection = Reflection.getInstance();
            const allClasses = reflection.getAllClasses();
            let index;
            const projectMap = {
                blankViewer: host + BlankPanelViewer.CallbackLink(),
                guiObjects: {
                    components: {
                        names: []
                    },
                    panels: {
                        names: []
                    },
                    userControls: {
                        names: []
                    }
                },
                host,
                runtimeTests: {
                    links: [],
                    names: []
                },
                viewers: {
                    links: [],
                    names: []
                }
            };
            for (index = 0; index < allClasses.length; index++) {
                const className = allClasses[index];
                if (className !== RuntimeTestRunner.ClassName() &&
                    className !== GuiRuntimeTestRunner.ClassName() &&
                    !reflection.ClassHasInterface(className, BasePanel.ClassName())) {
                    const classObject = reflection.getClass(className);
                    if (reflection.ClassHasInterface(className, IBaseViewer)) {
                        if (StringUtils.Contains(className, "RuntimeTests")) {
                            projectMap.runtimeTests.names.push(className);
                            projectMap.runtimeTests.links.push(host + classObject.CallbackLink());
                        }
                        else {
                            projectMap.viewers.names.push(className);
                            projectMap.viewers.links.push(host + classObject.CallbackLink());
                        }
                        projectMap.guiObjects.panels.names.push(className);
                    }
                    else if (reflection.ClassHasInterface(className, RuntimeTestRunner.ClassName())) {
                        projectMap.runtimeTests.names.push(className);
                        const linkName = "/" + HttpRequestConstants.RUNTIME_TEST + "/" +
                            StringUtils.Replace(className, ".", "/");
                        this.registerResolver(linkName, classObject);
                        projectMap.runtimeTests.links.push(host + "#" + linkName);
                    }
                    else if (reflection.ClassHasInterface(className, GuiRuntimeTestRunner.ClassName())) {
                        projectMap.runtimeTests.names.push(className);
                        projectMap.runtimeTests.links.push(host + "#" + classObject.CallbackLink());
                    }
                    else if (reflection.ClassHasInterface(className, IFormsObject)) {
                        projectMap.guiObjects.userControls.names.push(className);
                    }
                    else if (reflection.ClassHasInterface(className, IGuiCommons)) {
                        projectMap.guiObjects.components.names.push(className);
                    }
                }
            }
            StaticPageContentManager.Clear();
            this.sendData({
                data: projectMap,
                task: DesignerTaskType.GET_PROJECT_MAP
            });
            WindowManager.getEvents().setOnMessage(($eventArgs) => {
                const data = $eventArgs.NativeEventArgs().data;
                const fileSystemRequestHandler = ($taskType, $apiName, $data) => {
                    connector.Send("FileSystem", {
                        type: $apiName,
                        value: $data
                    }, ($data) => {
                        this.sendData({
                            data: JSON.parse(ObjectDecoder.Base64($data.data)),
                            task: $taskType
                        });
                    });
                };
                const task = data.task;
                switch (task) {
                    case DesignerTaskType.GET_FILESYSTEM_PATH:
                        fileSystemRequestHandler(task, "getPath", data.data);
                        break;
                    case DesignerTaskType.GET_FILESYSTEM_DIRECTORY:
                        fileSystemRequestHandler(task, "getDirectory", data.data);
                        break;
                    default:
                        Echo.Println("Unrecognized Designer task: \"" + task + "\"");
                        break;
                }
            });
        }
    }
    sendData($data) {
        try {
            window.parent.postMessage($data, "*");
        }
        catch (ex) {
            window.parent.postMessage({
                data: "Failed to send designer data: " + ex.message,
                task: DesignerTaskType.FAIL
            }, "*");
        }
    }
    fireEvent($type, $args) {
        this.sendData({
            data: {
                args: $args,
                type: $type
            },
            task: DesignerTaskType.EVENT
        });
    }
    fireOnBuild($type) {
        this.fireEvent("onBuild", $type);
    }
    fireItemExists($elementId, $value) {
        this.sendData({
            data: {
                id: $elementId,
                name: "Exists",
                type: GuiCommonsArgType.BOOLEAN,
                value: $value
            },
            task: DesignerTaskType.ITEM_EXISTS
        });
    }
    fireShowProperties($elementId, $properties) {
        this.sendData({
            data: {
                id: $elementId,
                value: $properties
            },
            task: DesignerTaskType.SHOW_PROPERTIES
        });
    }
    fireMarkItem($data) {
        this.sendData({
            data: $data,
            task: DesignerTaskType.MARK_ITEM
        });
    }
};
DesignerRunner = __decorate([
    Resolver(["/design/**/*", "design/"], { scope: ResolverScope.DEV })
], DesignerRunner);
export { DesignerRunner };
globalThis.RegisterClass("Io.Oidis.Gui.Designer.DesignerRunner", DesignerRunner);
//# sourceMappingURL=DesignerRunner.js.map