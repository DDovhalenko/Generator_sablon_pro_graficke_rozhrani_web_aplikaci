/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BasePropagableEnum } from "./BasePropagableEnum.js";
export class Alignment extends BasePropagableEnum {
    static CENTER = "Center";
    static TOP = "Top";
    static TOP_RIGHT = "TopRight";
    static RIGHT = "Right";
    static BOTTOM_RIGHT = "BottomRight";
    static BOTTOM = "Bottom";
    static BOTTOM_LEFT = "BottomLeft";
    static LEFT = "Left";
    static TOP_LEFT = "TopLeft";
    static CENTER_PROPAGATED = "CenterPropagated";
    static TOP_PROPAGATED = "TopPropagated";
    static TOP_RIGHT_PROPAGATED = "TopRightPropagated";
    static RIGHT_PROPAGATED = "RightPropagated";
    static BOTTOM_RIGHT_PROPAGATED = "BottomRightPropagated";
    static BOTTOM_PROPAGATED = "BottomPropagated";
    static BOTTOM_LEFT_PROPAGATED = "BottomLeftPropagated";
    static LEFT_PROPAGATED = "LeftPropagated";
    static TOP_LEFT_PROPAGATED = "TopLeftPropagated";
    /**
     * @returns {string} Returns prefix for Alignment enum value.
     */
    static getPrefix() {
        return "Align";
    }
    /**
     * @returns {string} Returns default Alignment enum value.
     */
    static getDefaultValue() {
        return Alignment.TOP_LEFT;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Enums.Alignment", Alignment);
//# sourceMappingURL=Alignment.js.map