/*! ******************************************************************************************************** *
 *
 * Copyright 2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "./../../../../Io/Oidis/Commons/Primitives/BaseEnum.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
/**
 * BasePropagableEnum class provides base functionality for enums with value propagation from parent to child elements.
 */
export class BasePropagableEnum extends BaseEnum {
    /**
     * @param {BasePropagableEnum} $parentValue Specify parent value.
     * @param {BasePropagableEnum} $childValue Specify child value.
     * @returns {BasePropagableEnum} Returns propagated value, if propagation has been allowed, otherwise default value is returned.
     */
    static PriorityValue($parentValue, $childValue) {
        const thisClass = Reflection.getInstance().getClass(this.ClassName());
        if (!ObjectValidator.IsEmptyOrNull($childValue)) {
            return $childValue;
        }
        else if (!ObjectValidator.IsEmptyOrNull($parentValue) && thisClass.IsPropagated($parentValue)) {
            return $parentValue;
        }
        return thisClass.getDefaultValue();
    }
    /**
     * @param {BasePropagableEnum} $value Specify value, which should be normalized.
     * @returns {string} Returns normalized BasePropagableEnum value.
     */
    static Normalize($value) {
        const thisClass = Reflection.getInstance().getClass(this.ClassName());
        if (thisClass.Contains($value)) {
            return StringUtils.Remove($value.toString(), "Propagated");
        }
        return thisClass.getDefaultValue();
    }
    /**
     * @param {BasePropagableEnum} $value Specify value for, which should be generated CSS style class.
     * @param {string} $initialClass Specify initial class which should be modified.
     * @returns {string} Returns CSS style class for specified BasePropagableEnum value.
     */
    static StyleClassName($value, $initialClass) {
        const thisClass = Reflection.getInstance().getClass(this.ClassName());
        const classPrefix = ObjectValidator.IsEmptyOrNull($initialClass) ? "" : $initialClass
            .replace(new RegExp(`\\s*${thisClass.getPrefix()}([a-zA-Z])*`, "g"), "");
        const normalizedPrefix = ObjectValidator.IsEmptyOrNull(classPrefix) ? "" : classPrefix + " ";
        if (thisClass.Contains($value)) {
            return normalizedPrefix + thisClass.getPrefix() + thisClass.Normalize($value);
        }
        return normalizedPrefix + thisClass.getDefaultValue();
    }
    /**
     * @param {BasePropagableEnum} $value Specify value, which should be validated.
     * @returns {boolean} Returns true if BasePropagableEnum value is propagated, otherwise false.
     */
    static IsPropagated($value) {
        const thisClass = Reflection.getInstance().getClass(this.ClassName());
        if (thisClass.Contains($value)) {
            return StringUtils.Contains($value.toString(), "Propagated");
        }
        return false;
    }
    /**
     * @returns {string} Returns prefix for BasePropagableEnum enum value.
     */
    static getPrefix() {
        return "";
    }
    /**
     * @returns {string} Returns default BasePropagableEnum enum value.
     */
    static getDefaultValue() {
        return "";
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Enums.BasePropagableEnum", BasePropagableEnum);
//# sourceMappingURL=BasePropagableEnum.js.map