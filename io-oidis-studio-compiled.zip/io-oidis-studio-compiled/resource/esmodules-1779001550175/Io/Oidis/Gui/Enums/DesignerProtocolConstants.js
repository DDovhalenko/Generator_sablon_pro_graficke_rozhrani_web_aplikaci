/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "./../../../../Io/Oidis/Commons/Primitives/BaseEnum.js";
export class DesignerProtocolConstants extends BaseEnum {
    static ROOT_ELEMENT_VARIABLE = "!__ROOT_ELEMENT__";
    static HTML_ELEMENT_VARIABLE = "!__HTML_ELEMENT__";
    static VARIABLE_NAME = "__VariableName";
    static DESIGNER_ELEMENT = "DesignerElement";
    static HTML_ELEMENT = "HtmlElement";
    static GUI_ELEMENT = "GuiElement";
    static GUI_OBJECT = "GuiObject";
}
globalThis.RegisterClass("Io.Oidis.Gui.Enums.DesignerProtocolConstants", DesignerProtocolConstants);
//# sourceMappingURL=DesignerProtocolConstants.js.map