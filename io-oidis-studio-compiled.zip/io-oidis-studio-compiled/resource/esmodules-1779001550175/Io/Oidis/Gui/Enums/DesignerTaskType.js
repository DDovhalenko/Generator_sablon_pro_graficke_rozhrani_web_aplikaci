/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "./../../../../Io/Oidis/Commons/Primitives/BaseEnum.js";
export class DesignerTaskType extends BaseEnum {
    static RELOAD = "Reload";
    static BUILD = "Build";
    static ADD_ITEM = "AddItem";
    static DELETE_ITEM = "DeleteItem";
    static ITEM_EXISTS = "ItemExists";
    static SELECT_ROOT_ITEM = "SelectRootItem";
    static SELECT_ITEM = "SelectItem";
    static MOVE_ITEM = "MoveItem";
    static SET_SIZE = "SetSize";
    static SET_PROPERTY = "SetProperty";
    static SHOW_PROPERTIES = "ShowProperties";
    static MARK_ITEM = "MarkItem";
    static GET_PROJECT_MAP = "GetProjectMap";
    static GET_INSTANCE_MAP = "GetInstanceMap";
    static ECHO = "Echo";
    static EVENT = "Event";
    static FAIL = "Fail";
    static GET_FILESYSTEM_PATH = "GetFileSystemPath";
    static GET_FILESYSTEM_DIRECTORY = "GetFileSystemDirectory";
}
globalThis.RegisterClass("Io.Oidis.Gui.Enums.DesignerTaskType", DesignerTaskType);
//# sourceMappingURL=DesignerTaskType.js.map