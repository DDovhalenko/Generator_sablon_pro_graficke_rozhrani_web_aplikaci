/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "./../../../../Io/Oidis/Commons/Primitives/BaseEnum.js";
export class DirectionType extends BaseEnum {
    static UP = "Up";
    static DOWN = "Down";
    static LEFT = "Left";
    static RIGHT = "Right";
}
globalThis.RegisterClass("Io.Oidis.Gui.Enums.DirectionType", DirectionType);
//# sourceMappingURL=DirectionType.js.map