/*! ******************************************************************************************************** *
 *
 * Copyright 2020-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "./EventType.js";
export class AudioEventType extends EventType {
    static ON_STOP = "OnStop";
    static ON_PLAY = "OnPlay";
    static ON_PAUSE = "OnPause";
    static ON_MUTE = "OnMute";
    static ON_UNMUTE = "OnUnmute";
    static ON_OPEN = "OnOpen";
}
globalThis.RegisterClass("Io.Oidis.Gui.Enums.Events.AudioEventType", AudioEventType);
//# sourceMappingURL=AudioEventType.js.map