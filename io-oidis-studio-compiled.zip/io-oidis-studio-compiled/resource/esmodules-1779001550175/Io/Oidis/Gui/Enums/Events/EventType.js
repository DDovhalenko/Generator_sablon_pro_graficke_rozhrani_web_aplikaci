/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType as Parent } from "./../../../../../Io/Oidis/Commons/Enums/Events/EventType.js";
export class EventType extends Parent {
    static ON_SHOW = "onshow";
    static ON_HIDE = "onhide";
    static ON_FOCUS = "onfocus";
    static ON_BLUR = "onblur";
    static ON_KEY_PRESS = "onkeypress";
    static ON_KEY_DOWN = "onkeydown";
    static ON_KEY_UP = "onkeyup";
    static ON_CLICK = "onclick";
    static ON_DOUBLE_CLICK = "ondblclick";
    static ON_RIGHT_CLICK = "onrightclick";
    static ON_MOUSE_OVER = "onmouseover";
    static ON_MOUSE_OUT = "onmouseout";
    static ON_MOUSE_DOWN = "onmousedown";
    static ON_MOUSE_UP = "onmouseup";
    static ON_MOUSE_MOVE = "onmousemove";
    static ON_TOUCH_START = "ontouchstart";
    static ON_TOUCH_END = "ontouchend";
    static ON_TOUCH_MOVE = "ontouchmove";
    static BEFORE_RESIZE = "beforeResize";
    static ON_RESIZE = "onresize";
    static ON_RESIZE_START = "onresizeStart";
    static ON_RESIZE_CHANGE = "onresizeChange";
    static ON_RESIZE_COMPLETE = "onresizeComplete";
    static ON_DRAG = "ondrag";
    static ON_DRAG_START = "ondragStart";
    static ON_DRAG_CHANGE = "ondragChange";
    static ON_DRAG_COMPLETE = "ondragComplete";
    static ON_DRAG_OVER = "ondragover";
    static ON_SCROLL = "onscroll";
    static ON_VERTICAL_SCROLL = "onverticalscroll";
    static ON_HORIZONTAL_SCROLL = "onhorizontalscroll";
    static ON_DROP = "ondrop";
    static ON_SELECT = "onselect";
}
globalThis.RegisterClass("Io.Oidis.Gui.Enums.Events.EventType", EventType);
//# sourceMappingURL=EventType.js.map