/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BasePropagableEnum } from "./BasePropagableEnum.js";
export class FitToParent extends BasePropagableEnum {
    static NONE = "None";
    static FULL = "Full";
    static VERTICAL = "Vertical";
    static HORIZONTAL = "Horizontal";
    /**
     * @returns {string} Returns prefix for BasePropagableEnum enum value.
     */
    static getPrefix() {
        return "FitToParent";
    }
    /**
     * @returns {string} Returns default BasePropagableEnum enum value.
     */
    static getDefaultValue() {
        return FitToParent.NONE;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Enums.FitToParent", FitToParent);
//# sourceMappingURL=FitToParent.js.map