/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "./../../../../Io/Oidis/Commons/Primitives/BaseEnum.js";
export class GeneralCssNames extends BaseEnum {
    static GUI_SELECTOR = "GuiSelector";
    static GUI_FIXED_HOLDER = "GuiFixedHolder";
    static BACKGROUND = "Background";
    static FOREGROUND = "Foreground";
    static TOP = "Top";
    static MIDDLE = "Middle";
    static BOTTOM = "Bottom";
    static LEFT = "Left";
    static CENTER = "Center";
    static RIGHT = "Right";
    static ON = "On";
    static OFF = "Off";
    static ACTIVE = "Active";
    static ENABLE = "Enable";
    static DISABLE = "Disable";
    static ERROR = "Error";
    static HIDDEN = "Hidden";
    static READONLY = "ReadOnly";
    static TEXT = "Text";
    static ICON = "Icon";
    static SPLITTER = "Splitter";
    static ROW = "GuiRow";
    static COLUMN = "GuiCol";
    static PADDING_BEFORE = "Before";
    static PADDING_AFTER = "After";
    static DNONE = "d-none";
}
export class GeneralCSS extends GeneralCssNames {
}
globalThis.RegisterClass("Io.Oidis.Gui.Enums.GeneralCssNames", GeneralCssNames);
globalThis.RegisterClass("Io.Oidis.Gui.Enums.GeneralCSS", GeneralCSS);
//# sourceMappingURL=GeneralCssNames.js.map