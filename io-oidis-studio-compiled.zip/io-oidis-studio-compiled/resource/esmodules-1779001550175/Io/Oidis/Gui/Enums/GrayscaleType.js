/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
export var GrayscaleType;
(function (GrayscaleType) {
    GrayscaleType[GrayscaleType["DEFAULT"] = 0] = "DEFAULT";
    GrayscaleType[GrayscaleType["AVERAGE"] = 1] = "AVERAGE";
    GrayscaleType[GrayscaleType["LUMINANCE"] = 2] = "LUMINANCE";
})(GrayscaleType || (GrayscaleType = {}));
//# sourceMappingURL=GrayscaleType.js.map