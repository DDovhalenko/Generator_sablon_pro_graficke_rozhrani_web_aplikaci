/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
export var GuiOptionType;
(function (GuiOptionType) {
    GuiOptionType[GuiOptionType["ALL"] = 0] = "ALL";
    GuiOptionType[GuiOptionType["TOOL_TIP"] = 1] = "TOOL_TIP";
    GuiOptionType[GuiOptionType["DISABLE"] = 2] = "DISABLE";
    GuiOptionType[GuiOptionType["ACTIVED"] = 3] = "ACTIVED";
    GuiOptionType[GuiOptionType["SELECTED"] = 4] = "SELECTED";
    GuiOptionType[GuiOptionType["SCROLLABLE"] = 5] = "SCROLLABLE";
})(GuiOptionType || (GuiOptionType = {}));
//# sourceMappingURL=GuiOptionType.js.map