/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpRequestConstants as Parent } from "./../../../../Io/Oidis/Commons/Enums/HttpRequestConstants.js";
export class HttpRequestConstants extends Parent {
    static RUNTIME_TEST = "RuntimeTest";
    static TEST_MODE = "TestMode";
    static FORCE_REFRESH = "ForceRefresh";
    static HIDE_CHILDREN = "HideChildren";
    static ELEMENT_INSTANCE = "Element";
}
globalThis.RegisterClass("Io.Oidis.Gui.Enums.HttpRequestConstants", HttpRequestConstants);
//# sourceMappingURL=HttpRequestConstants.js.map