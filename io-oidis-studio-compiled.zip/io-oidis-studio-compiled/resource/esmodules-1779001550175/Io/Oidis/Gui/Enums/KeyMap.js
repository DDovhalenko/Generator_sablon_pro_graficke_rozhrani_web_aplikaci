/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
export var KeyMap;
(function (KeyMap) {
    KeyMap[KeyMap["F2"] = 113] = "F2";
    KeyMap[KeyMap["F4"] = 115] = "F4";
    KeyMap[KeyMap["F5"] = 116] = "F5";
    KeyMap[KeyMap["TAB"] = 9] = "TAB";
    KeyMap[KeyMap["BACKSPACE"] = 8] = "BACKSPACE";
    KeyMap[KeyMap["LEFT_ARROW"] = 37] = "LEFT_ARROW";
    KeyMap[KeyMap["RIGHT_ARROW"] = 39] = "RIGHT_ARROW";
    KeyMap[KeyMap["DOWN_ARROW"] = 40] = "DOWN_ARROW";
    KeyMap[KeyMap["UP_ARROW"] = 38] = "UP_ARROW";
    KeyMap[KeyMap["DELETE"] = 46] = "DELETE";
    KeyMap[KeyMap["A"] = 97] = "A";
    KeyMap[KeyMap["C"] = 99] = "C";
    KeyMap[KeyMap["F"] = 70] = "F";
    KeyMap[KeyMap["V"] = 118] = "V";
    KeyMap[KeyMap["X"] = 120] = "X";
    KeyMap[KeyMap["ZERO"] = 48] = "ZERO";
    KeyMap[KeyMap["NINE"] = 57] = "NINE";
    KeyMap[KeyMap["COMMA"] = 44] = "COMMA";
    KeyMap[KeyMap["DOT"] = 46] = "DOT";
    KeyMap[KeyMap["PLUS"] = 43] = "PLUS";
    KeyMap[KeyMap["MINUS"] = 45] = "MINUS";
    KeyMap[KeyMap["SPACE"] = 32] = "SPACE";
    KeyMap[KeyMap["ESC"] = 27] = "ESC";
    KeyMap[KeyMap["ENTER"] = 13] = "ENTER";
    KeyMap[KeyMap["END"] = 35] = "END";
    KeyMap[KeyMap["HOME"] = 36] = "HOME";
})(KeyMap || (KeyMap = {}));
//# sourceMappingURL=KeyMap.js.map