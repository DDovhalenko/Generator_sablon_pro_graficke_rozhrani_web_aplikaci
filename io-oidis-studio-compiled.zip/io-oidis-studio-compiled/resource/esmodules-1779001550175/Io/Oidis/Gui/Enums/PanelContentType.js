/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
export var PanelContentType;
(function (PanelContentType) {
    PanelContentType[PanelContentType["HIDDEN"] = 0] = "HIDDEN";
    PanelContentType[PanelContentType["WITH_ELEMENT_WRAPPER"] = 1] = "WITH_ELEMENT_WRAPPER";
    PanelContentType[PanelContentType["WITHOUT_ELEMENT_WRAPPER"] = 2] = "WITHOUT_ELEMENT_WRAPPER";
    PanelContentType[PanelContentType["ASYNC_LOADER"] = 3] = "ASYNC_LOADER";
})(PanelContentType || (PanelContentType = {}));
//# sourceMappingURL=PanelContentType.js.map