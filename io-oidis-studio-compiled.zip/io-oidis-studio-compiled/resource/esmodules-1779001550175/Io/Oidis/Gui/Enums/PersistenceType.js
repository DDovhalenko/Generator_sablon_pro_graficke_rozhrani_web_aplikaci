/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { PersistenceType as Parent } from "./../../../../Io/Oidis/Commons/Enums/PersistenceType.js";
export class PersistenceType extends Parent {
    static GUI_COMMONS = "guicommons";
    static VIEWER = "viewer";
    static AUTOFILL = "autofill";
    static FORM_VALUES = "formvalues";
    static ERROR_FLAGS = "errorflags";
}
globalThis.RegisterClass("Io.Oidis.Gui.Enums.PersistenceType", PersistenceType);
//# sourceMappingURL=PersistenceType.js.map