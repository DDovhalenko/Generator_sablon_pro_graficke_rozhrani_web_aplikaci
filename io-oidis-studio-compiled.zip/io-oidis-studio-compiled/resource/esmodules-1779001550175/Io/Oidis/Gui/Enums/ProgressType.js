/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "./../../../../Io/Oidis/Commons/Primitives/BaseEnum.js";
export class ProgressType extends BaseEnum {
    static LINEAR = "valueProgressLinear";
    static SLOW_START = "valueProgressSlowStart";
    static FAST_START = "valueProgressFastStart";
    static SLOW_END = "valueProgressSlowEnd";
    static FAST_END = "valueProgressFastEnd";
    static SLOW_TAILS = "valueProgressSlowTails";
    static FAST_TAILS = "valueProgressFastTails";
}
globalThis.RegisterClass("Io.Oidis.Gui.Enums.ProgressType", ProgressType);
//# sourceMappingURL=ProgressType.js.map