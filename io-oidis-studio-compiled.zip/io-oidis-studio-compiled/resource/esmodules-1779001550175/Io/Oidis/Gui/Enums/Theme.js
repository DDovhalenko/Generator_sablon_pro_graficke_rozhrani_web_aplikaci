/*! ******************************************************************************************************** *
 *
 * Copyright 2025-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BasePropagableEnum } from "./BasePropagableEnum.js";
export class Theme extends BasePropagableEnum {
    static LIGHT = "light";
    static DARK = "dark";
    static AUTO = "auto";
    /**
     * @returns {string} Returns default Theme enum value.
     */
    static getDefaultValue() {
        return Theme.LIGHT;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Enums.Theme", Theme);
//# sourceMappingURL=Theme.js.map