/*! ******************************************************************************************************** *
 *
 * Copyright 2019 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BasePropagableEnum } from "./BasePropagableEnum.js";
export class VisibilityStrategy extends BasePropagableEnum {
    static NONE = "None";
    static COLLAPSE_EMPTY = "CollapseEmpty";
    static COLLAPSE_EMPTY_PROPAGATED = "CollapseEmptyPropagated";
    /**
     * @returns {string} Returns default VisibilityStrategy enum value.
     */
    static getDefaultValue() {
        return VisibilityStrategy.NONE;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Enums.VisibilityStrategy", VisibilityStrategy);
//# sourceMappingURL=VisibilityStrategy.js.map