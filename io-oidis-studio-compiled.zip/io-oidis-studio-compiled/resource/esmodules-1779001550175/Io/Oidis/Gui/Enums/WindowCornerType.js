/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
export var WindowCornerType;
(function (WindowCornerType) {
    WindowCornerType[WindowCornerType["TOP_LEFT"] = 0] = "TOP_LEFT";
    WindowCornerType[WindowCornerType["TOP_RIGHT"] = 1] = "TOP_RIGHT";
    WindowCornerType[WindowCornerType["BOTTOM_LEFT"] = 2] = "BOTTOM_LEFT";
    WindowCornerType[WindowCornerType["BOTTOM_RIGHT"] = 3] = "BOTTOM_RIGHT";
})(WindowCornerType || (WindowCornerType = {}));
//# sourceMappingURL=WindowCornerType.js.map