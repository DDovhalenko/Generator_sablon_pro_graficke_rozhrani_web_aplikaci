import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { HttpRequestConstants } from "../Enums/HttpRequestConstants.js";
import { BaseErrorPage } from "./BaseErrorPage.js";
export class Http301MovedPage extends BaseErrorPage {
    link;
    argsHandler($GET, $POST) {
        this.link = "";
        if ($POST.KeyExists(HttpRequestConstants.HTTP301_LINK)) {
            this.link = $POST.getItem(HttpRequestConstants.HTTP301_LINK);
        }
    }
    // protected getFaviconSource() : string {
    //     return "resource/graphics/Io/Oidis/Gui/MovedIcon.ico";
    // }
    getPageTitle() {
        return "Oidis - HTTP 301";
    }
    getMessageHeader() {
        return "HTTP status 301";
    }
    getMessageBody() {
        return "File has been moved. New address is:" + StringUtils.NewLine() +
            "<a href=\"#" + this.link + "\">" + this.getRequest().getHostUrl() + "#" + this.link + "</a>";
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.ErrorPages.Http301MovedPage", Http301MovedPage);
//# sourceMappingURL=Http301MovedPage.js.map