import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { HttpRequestConstants } from "../Enums/HttpRequestConstants.js";
import { BaseErrorPage } from "./BaseErrorPage.js";
export class Http404NotFoundPage extends BaseErrorPage {
    filePath;
    argsHandler($GET, $POST) {
        this.filePath = "";
        if ($POST.KeyExists(HttpRequestConstants.HTTP404_FILE_PATH)) {
            this.filePath = $POST.getItem(HttpRequestConstants.HTTP404_FILE_PATH);
        }
    }
    getPageTitle() {
        return "Oidis - HTTP 404";
    }
    getMessageHeader() {
        return "HTTP status 404";
    }
    getMessageBody() {
        if (!ObjectValidator.IsEmptyOrNull(this.filePath)) {
            return "File has not been found. Required file path is:" + StringUtils.NewLine() +
                "<a href=\"" + this.filePath + "\">" + this.filePath + "</a>";
        }
        return "File has not been found.";
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.ErrorPages.Http404NotFoundPage", Http404NotFoundPage);
//# sourceMappingURL=Http404NotFoundPage.js.map