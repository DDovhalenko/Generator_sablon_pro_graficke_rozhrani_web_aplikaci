/*! ******************************************************************************************************** *
 *
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { Exception } from "./../../../../Io/Oidis/Commons/Exceptions/Type/Exception.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
/**
 * AnimationThreadPool class provides animation scheduling.
 */
export class AnimationThreadPool extends BaseObject {
    static threadId;
    /**
     * @param {string} $owner Specify thread owner.
     * @param {string} $type Specify type of thread.
     * @returns {boolean} Returns true, if specified thread is running, otherwise false.
     */
    static IsRunning($owner, $type) {
        return AnimationThreadPool.getEvents().Exists($owner, $type);
    }
    /**
     * @param {string} $owner Specify thread owner.
     * @param {string} $type Specify type of thread.
     * @param {IEventsHandler} [$handler] Function suitable for handling of the thread.
     * @param {IEventArgs} [$args] Specify initial thread args.
     * @returns {void}
     */
    static AddThread($owner, $type, $handler, $args) {
        AnimationThreadPool.getEvents().setEvent($owner, $type, $handler, $args);
    }
    /**
     * @param {string} $owner Specify thread owner.
     * @param {string} $type Specify type of thread.
     * @param {IEventArgs} $args Specify current thread args.
     * @returns {void}
     */
    static setThreadArgs($owner, $type, $args) {
        AnimationThreadPool.getEvents().setEventArgs($owner, $type, $args);
    }
    /**
     * @param {string} $owner Specify thread owner.
     * @param {string} $type Specify type of thread, which should be removed.
     * @returns {void}
     */
    static RemoveThread($owner, $type) {
        AnimationThreadPool.getEvents().Clear($owner, $type);
    }
    /**
     * Fire execution of all registered threads.
     * @returns {void}
     */
    static Execute() {
        if (ObjectValidator.IsEmptyOrNull(AnimationThreadPool.threadId)) {
            AnimationThreadPool.startLoop();
        }
    }
    /**
     * Stop execution of all registered threads.
     * @returns {void}
     */
    static Clear() {
        if (this.IsSupported()) {
            AnimationThreadPool.Clear = () => {
                window.cancelAnimationFrame(AnimationThreadPool.threadId);
                AnimationThreadPool.threadId = null;
                AnimationThreadPool.getEvents().Clear();
            };
            AnimationThreadPool.Clear();
        }
        else {
            // eslint-disable-next-line @typescript-eslint/only-throw-error
            throw new Exception(AnimationThreadPool.ClassName() + " is not supported in this execution environment.");
        }
    }
    /**
     * @returns {boolean} Returns true, if current environment is supported, otherwise false.
     */
    static IsSupported() {
        return ObjectValidator.IsSet(window.requestAnimationFrame);
    }
    static startLoop() {
        if (this.IsSupported()) {
            const events = AnimationThreadPool.getEvents();
            AnimationThreadPool.startLoop = () => {
                if (!events.getAll().IsEmpty()) {
                    AnimationThreadPool.threadId = window.requestAnimationFrame(() => {
                        const owners = events.getAll().getKeys();
                        let ownerIndex;
                        let typeIndex;
                        for (ownerIndex = 0; ownerIndex < owners.length; ownerIndex++) {
                            const types = events.getAll().getItem(owners[ownerIndex]).getKeys();
                            for (typeIndex = 0; typeIndex < types.length; typeIndex++) {
                                events.FireEvent(owners[ownerIndex], types[typeIndex], false);
                            }
                        }
                        AnimationThreadPool.startLoop();
                    });
                }
                else {
                    AnimationThreadPool.threadId = null;
                }
            };
            return AnimationThreadPool.startLoop();
        }
        else {
            // eslint-disable-next-line @typescript-eslint/only-throw-error
            throw new Exception(AnimationThreadPool.ClassName() + " is not supported in this execution environment.");
        }
    }
    static getEvents() {
        const instance = new globalThis.Io.Oidis.Gui.Events.EventsManager();
        this.getEvents = () => {
            return instance;
        };
        return instance;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Events.AnimationThreadPool", AnimationThreadPool);
//# sourceMappingURL=AnimationThreadPool.js.map