/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventArgs } from "./../../../../../Io/Oidis/Commons/Events/Args/EventArgs.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
/**
 * DirectoryBrowserEventArgs class provides args connected with usage of DirectoryBrowser.
 */
export class DirectoryBrowserEventArgs extends EventArgs {
    value;
    /**
     * @param {IDirectoryBrowser} [$value] Specified object, which owns current args
     * @returns {IDirectoryBrowser} Returns event args owner object.
     */
    Owner($value) {
        return super.Owner($value);
    }
    /**
     * @param {string} [$value] Set current selected item value.
     * @returns {string} Returns value of currently selected item.
     */
    Value($value) {
        return this.value = Property.String(this.value, $value);
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Events.Args.DirectoryBrowserEventArgs", DirectoryBrowserEventArgs);
//# sourceMappingURL=DirectoryBrowserEventArgs.js.map