/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventArgs } from "./../../../../../Io/Oidis/Commons/Events/Args/EventArgs.js";
import { Convert } from "./../../../../../Io/Oidis/Commons/Utils/Convert.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
/**
 * KeyEventArgs class provides args connected with keyboard events.
 */
export class KeyEventArgs extends EventArgs {
    /**
     * @param {KeyboardEvent} [$eventArgs] Specify native key event args provided by native key handler
     */
    constructor($eventArgs) {
        super();
        this.NativeEventArgs($eventArgs);
    }
    /**
     * @param {KeyboardEvent} [$value] If specified, set event args of native event.
     * @returns {KeyboardEvent} Returns native event args provided by native event handler.
     */
    NativeEventArgs($value) {
        return super.NativeEventArgs($value);
    }
    /**
     * @returns {number} Returns number representation of pressed key, if native event has been provided, otherwise null.
     */
    getKeyCode() {
        const nativeEvent = this.NativeEventArgs();
        if (ObjectValidator.IsSet(nativeEvent)) {
            /* eslint-disable @typescript-eslint/no-deprecated -- polyfill: no modern equivalent for numeric key codes */
            return ObjectValidator.IsSet(nativeEvent.keyCode) && nativeEvent.keyCode !== 0 ?
                nativeEvent.keyCode : nativeEvent.charCode;
            /* eslint-enable @typescript-eslint/no-deprecated */
        }
        return null;
    }
    /**
     * @returns {string} Returns string representation of pressed key, if native event has been provided, otherwise null.
     */
    getKeyChar() {
        const nativeEvent = this.NativeEventArgs();
        if (ObjectValidator.IsSet(nativeEvent)) {
            if (ObjectValidator.IsSet(nativeEvent.key) && nativeEvent.key.length === 1) {
                if (nativeEvent.shiftKey) {
                    return nativeEvent.key;
                }
                return StringUtils.ToLowerCase(nativeEvent.key);
            }
            const code = this.getKeyCode();
            if (!ObjectValidator.IsEmptyOrNull(code)) {
                const specialCharTable = {
                    "#96": "0", "#97": "1", "#98": "2", "#99": "3", "#100": "4", "#101": "5", "#102": "6",
                    "#103": "7", "#104": "8", "#105": "9", "#106": "*", "#107": "+", "#109": "-", "#110": ".",
                    "#111": "/", "#173": "-", "#186": ";", "#187": "=", "#188": ",", "#190": ".", "#191": "/",
                    "#192": "`", "#219": "[", "#220": "\\", "#221": "]", "#222": "'"
                };
                if (specialCharTable.hasOwnProperty("#" + code)) {
                    return specialCharTable["#" + code];
                }
                if (nativeEvent.shiftKey) {
                    return Convert.UnicodeToString(code);
                }
                return StringUtils.ToLowerCase(Convert.UnicodeToString(code));
            }
        }
        return null;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Events.Args.KeyEventArgs", KeyEventArgs);
//# sourceMappingURL=KeyEventArgs.js.map