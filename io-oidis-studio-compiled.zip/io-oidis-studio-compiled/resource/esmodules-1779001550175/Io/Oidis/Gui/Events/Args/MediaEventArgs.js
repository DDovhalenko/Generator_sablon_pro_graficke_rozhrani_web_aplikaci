/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventArgs } from "./../../../../../Io/Oidis/Commons/Events/Args/EventArgs.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
/**
 * Carries event data related to media playback events, including an associated message.
 */
export class MediaEventArgs extends EventArgs {
    message;
    constructor() {
        super();
        this.message = "";
    }
    /**
     * @param {string} [$value] Set media event message text.
     * @returns {string} Returns the media event message text.
     */
    EventMessage($value) {
        return this.message = Property.String(this.message, $value);
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Events.Args.MediaEventArgs", MediaEventArgs);
//# sourceMappingURL=MediaEventArgs.js.map