/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
import { MoveEventArgs } from "./MoveEventArgs.js";
/**
 * ResizeBarEventArgs class provides args connected with resizing by ResizeBar type of element.
 */
export class ResizeBarEventArgs extends MoveEventArgs {
    resizeType;
    resizeDistanceX;
    resizeDistanceY;
    constructor($eventArgs) {
        super($eventArgs);
        this.resizeDistanceX = super.getDistanceX();
        this.resizeDistanceY = super.getDistanceY();
    }
    /**
     * @param {MouseEvent} [$value] If specified, set event args of native event and recalculate resize distances.
     * @returns {MouseEvent} Returns native event args provided by native event handler.
     */
    NativeEventArgs($value) {
        const args = super.NativeEventArgs($value);
        if (ObjectValidator.IsSet($value)) {
            this.resizeDistanceX = super.getDistanceX();
            this.resizeDistanceY = super.getDistanceY();
        }
        return args;
    }
    /**
     * @param {ResizeableType} [$type] Specify type of resize direction.
     * @returns {number} Returns type of resize direction.
     */
    ResizeableType($type) {
        if (ObjectValidator.IsSet($type)) {
            this.resizeType = $type;
        }
        return this.resizeType;
    }
    /**
     * @returns {number} Returns distance from last mouse horizontal position.
     */
    getDistanceX() {
        return this.resizeDistanceX;
    }
    /**
     * @param {number} [$value] Specify value of the horizontal distance.
     * @returns {number} Returns distance from last mouse horizontal position.
     */
    DistanceX($value) {
        this.resizeDistanceX = Property.Integer(this.resizeDistanceX, $value);
        return this.getDistanceX();
    }
    /**
     * @returns {number} Returns distance from last mouse vertical position.
     */
    getDistanceY() {
        return this.resizeDistanceY;
    }
    /**
     * @param {number} [$value] Specify value of the vertical distance.
     * @returns {number} Returns distance from last mouse horizontal position.
     */
    DistanceY($value) {
        this.resizeDistanceY = Property.Integer(this.resizeDistanceY, $value);
        return this.getDistanceY();
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Events.Args.ResizeBarEventArgs", ResizeBarEventArgs);
//# sourceMappingURL=ResizeBarEventArgs.js.map