/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventArgs } from "./../../../../../Io/Oidis/Commons/Events/Args/EventArgs.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
import { DirectionType } from "../../Enums/DirectionType.js";
/**
 * ScrollEventArgs class provides args connected with usage of scrollbars.
 */
export class ScrollEventArgs extends EventArgs {
    orientationType;
    directionType;
    position;
    /**
     * @param {OrientationType} [$value] Set scrolling orientation.
     * @returns {OrientationType} Returns scrollbar orientation.
     */
    OrientationType($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.orientationType = $value;
        }
        return this.orientationType;
    }
    /**
     * @param {DirectionType} [$value] Set scrolling direction.
     * @returns {DirectionType} Returns scrollbar direction.
     */
    DirectionType($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            if ($value === DirectionType.RIGHT) {
                $value = DirectionType.DOWN;
            }
            else if ($value === DirectionType.LEFT) {
                $value = DirectionType.UP;
            }
            this.directionType = $value;
        }
        return this.directionType;
    }
    /**
     * @param {number} [$value] Set current scrollbar position. Position should be in range <0;100>.
     * @returns {number} Returns current scrollbar position.
     */
    Position($value) {
        if (ObjectValidator.IsSet($value)) {
            if ($value > 0 && $value < 1) {
                $value = $value * 100;
            }
            if ($value < 0) {
                $value = 0;
            }
            if ($value > 100) {
                $value = 100;
            }
        }
        return this.position = Property.PositiveInteger(this.position, $value, 0, 100);
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Events.Args.ScrollEventArgs", ScrollEventArgs);
//# sourceMappingURL=ScrollEventArgs.js.map