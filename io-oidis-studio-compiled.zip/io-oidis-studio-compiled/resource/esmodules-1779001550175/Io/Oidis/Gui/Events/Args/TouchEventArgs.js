/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventArgs } from "./../../../../../Io/Oidis/Commons/Events/Args/EventArgs.js";
/**
 * TouchEventArgs class provides args connected with touch events.
 */
export class TouchEventArgs extends EventArgs {
    /**
     * @param {TouchEvent} [$eventArgs] Specify native touch event args provided by native touch handler
     */
    constructor($eventArgs) {
        super();
        this.NativeEventArgs($eventArgs);
    }
    /**
     * @param {TouchEvent} [$value] If specified, set event args of native touch event.
     * @returns {TouchEvent} Returns native touch event args provided by native event handler.
     */
    NativeEventArgs($value) {
        return super.NativeEventArgs($value);
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Events.Args.TouchEventArgs", TouchEventArgs);
//# sourceMappingURL=TouchEventArgs.js.map