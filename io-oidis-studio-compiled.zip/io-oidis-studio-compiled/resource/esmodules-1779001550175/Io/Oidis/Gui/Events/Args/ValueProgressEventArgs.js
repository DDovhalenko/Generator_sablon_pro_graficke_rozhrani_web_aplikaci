/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "./../../../../../Io/Oidis/Commons/Enums/Events/EventType.js";
import { ProgressEventArgs } from "./../../../../../Io/Oidis/Commons/Events/Args/ProgressEventArgs.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
import { DirectionType } from "../../Enums/DirectionType.js";
import { ProgressType } from "../../Enums/ProgressType.js";
import { UnitType } from "../../Enums/UnitType.js";
/**
 * ValueProgressEventArgs class provides args connected with change of some value.
 */
export class ValueProgressEventArgs extends ProgressEventArgs {
    ownerId;
    directionType;
    startEventType;
    changeEventType;
    completeEventType;
    step;
    progressType;
    timeStamp;
    floatValue;
    stepUnitType;
    /**
     * @param {string} $id Set value progress args owner id.
     */
    constructor($id) {
        super();
        this.OwnerId($id);
        this.directionType = DirectionType.UP;
        this.startEventType = $id + "_" + EventType.ON_START;
        this.changeEventType = $id + "_" + EventType.ON_CHANGE;
        this.completeEventType = $id + "_" + EventType.ON_COMPLETE;
        this.progressType = ProgressType.LINEAR;
        this.step = 1;
        this.timeStamp = 0;
        this.floatValue = super.CurrentValue();
        this.stepUnitType = UnitType.PX;
    }
    /**
     * @param {string} [$value] Set args owner id.
     * @returns {string} Returns owner id of current args instance.
     */
    OwnerId($value) {
        return this.ownerId = Property.String(this.ownerId, $value);
    }
    /**
     * @param {DirectionType} [$value] Set type of direction in, which should be value changed.
     * Allowed is UP or DOWN direction.
     * @returns {DirectionType} Returns direction type of value change.
     */
    DirectionType($value) {
        if (!ObjectValidator.IsEmptyOrNull($value) &&
            ($value === DirectionType.DOWN || $value === DirectionType.UP)) {
            this.directionType = $value;
        }
        return this.directionType;
    }
    /**
     * @param {string} [$value] Set type of event, which should be fired at start time of value change.
     * @returns {string} Returns event type, which will be fired at start time of value change.
     */
    StartEventType($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.startEventType = $value;
        }
        return this.startEventType;
    }
    /**
     * @param {string} [$value] Set type of event, which should be fired at time of value change.
     * @returns {string} Returns event type, which will be fired at time of value change.
     */
    ChangeEventType($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.changeEventType = $value;
        }
        return this.changeEventType;
    }
    /**
     * @param {string} [$value] Set type of event, which should be fired, when value change is finished.
     * @returns {string} Returns event type, which will be fired, when value change is finished.
     */
    CompleteEventType($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.completeEventType = $value;
        }
        return this.completeEventType;
    }
    /**
     * @param {number} [$value] Set average progress rate per time step (e.g. per 10ms)
     * @returns {number} Returns average progress rate per time step (e.g. per 10ms)
     */
    Step($value) {
        return this.step = ObjectValidator.IsSet($value) ? $value : this.step;
    }
    /**
     * @param {number} [$value] Set average progress rate per time step (e.g. per 10ms)
     * @returns {number} Returns average progress rate per time step (e.g. per 10ms)
     */
    StepUnitType($value) {
        return this.stepUnitType = ObjectValidator.IsSet($value) ? $value : this.stepUnitType;
    }
    /**
     * @param {ProgressType} [$value] Set type of algorithm, which should be used for change of value.
     * @returns {ProgressType} Returns type of algorithm, which is used for change of value.
     */
    ProgressType($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.progressType = $value;
        }
        return this.progressType;
    }
    /**
     * @param {number} [$value] Set timestamp.
     * @returns {number} Returns timestamp.
     */
    TimeStamp($value) {
        return this.timeStamp = ObjectValidator.IsSet($value) ? $value : this.timeStamp;
    }
    /**
     * @param {number} [$value] Set current value of change.
     * @returns {number} Returns number value of current change.
     */
    CurrentValue($value) {
        const value = super.CurrentValue($value);
        if (ObjectValidator.IsSet($value)) {
            this.FloatValue(value);
        }
        return value;
    }
    /**
     * @param {number} [$value] Set float current value of change.
     * @returns {number} Returns number value of float current change.
     */
    FloatValue($value) {
        if (ObjectValidator.IsSet($value)) {
            super.CurrentValue($value);
            this.floatValue = $value;
        }
        return this.floatValue;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Events.Args.ValueProgressEventArgs", ValueProgressEventArgs);
//# sourceMappingURL=ValueProgressEventArgs.js.map