/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventArgs } from "./../../../../Io/Oidis/Commons/Events/Args/EventArgs.js";
import { ExceptionsManager } from "./../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { IllegalArgumentException } from "./../../../../Io/Oidis/Commons/Exceptions/Type/IllegalArgumentException.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { AudioEventType } from "../Enums/Events/AudioEventType.js";
import { BasePanelHolderEventType } from "../Enums/Events/BasePanelHolderEventType.js";
import { DialogEventType } from "../Enums/Events/DialogEventType.js";
import { DirectoryBrowserEventType } from "../Enums/Events/DirectoryBrowserEventType.js";
import { EventType } from "../Enums/Events/EventType.js";
import { ScrollBarEventType } from "../Enums/Events/ScrollBarEventType.js";
import { VideoEventType } from "../Enums/Events/VideoEventType.js";
import { GuiObjectManager } from "../GuiObjectManager.js";
import { Loader } from "../Loader.js";
import { ElementManager } from "../Utils/ElementManager.js";
import { MouseEventArgs } from "./Args/MouseEventArgs.js";
import { EventsManager } from "./EventsManager.js";
/**
 * ElementEventsManager class provides handling of native events subscribed to HTML elements.
 */
export class ElementEventsManager extends BaseObject {
    globalEvents;
    localEvents;
    owner;
    eventsList;
    subscriber;
    isSubscribed;
    /**
     * @param {string|IGuiCommons} [$owner] Set events owner id.
     * @param {string} [$subscriber] Set events subscriber id.
     */
    constructor($owner, $subscriber) {
        super();
        this.eventsList = new ArrayList();
        this.globalEvents = EventsManager.getInstanceSingleton();
        this.localEvents = new EventsManager();
        if (ObjectValidator.IsSet($owner)) {
            this.owner = $owner;
        }
        this.subscriber = null;
        this.Subscriber($subscriber);
        this.isSubscribed = false;
    }
    /**
     * @returns {string} Returns element id of the events owner, if owner has been set, otherwise null.
     */
    getOwner() {
        if (ObjectValidator.IsEmptyOrNull(this.owner)) {
            return null;
        }
        else if (ObjectValidator.IsSet(this.owner.Id)) {
            return this.owner.Id();
        }
        else {
            return this.owner;
        }
    }
    /**
     * @param {string} [$value] Set element id of the events subscriber.
     * @returns {string} Returns element id of the events subscriber, if subscriber has been set, otherwise null.
     */
    Subscriber($value) {
        if (ObjectValidator.IsSet($value)) {
            this.subscriber = Property.NullString($value);
        }
        return this.subscriber;
    }
    /**
     * @param {string} $type Validate this type of event.
     * @returns {boolean} Returns true, if event type has been registered, otherwise false.
     */
    Exists($type) {
        return this.eventsList.KeyExists($type);
    }
    /**
     * @returns {ArrayList<ArrayList<IEventsHandler>>} Returns list of all registered events.
     */
    getAll() {
        return this.eventsList;
    }
    /**
     * @param {string} $type Subscribe handler to this type of event.
     * @param {IEventsHandler} $handler Function suitable for handling of the event.
     * @returns {void}
     */
    setEvent($type, $handler) {
        if (!ObjectValidator.IsEmptyOrNull($type)) {
            if (!this.Exists($type)) {
                this.eventsList.Add(new ArrayList(), $type);
            }
            this.eventsList.getItem($type).Add($handler, StringUtils.getSha1($handler.toString()));
        }
        else {
            ExceptionsManager.Throw(this.getClassName(), new IllegalArgumentException("Event type can not be null."));
        }
    }
    /**
     * @param {Function} $handler Function suitable for handling of the event.
     * @param {boolean} [$clearBefore=true] Clean up currently running thread with same handler.
     * @param {number} [$waitForMilliseconds] Specify wait time before execution of the handler in milliseconds.
     * @returns {number} Returns thread number allocated for asynchronous execution.
     */
    FireAsynchronousMethod($handler, $clearBefore, $waitForMilliseconds) {
        return this.localEvents.FireAsynchronousMethod($handler, $clearBefore, $waitForMilliseconds);
    }
    /**
     * @param {string} $type Event type of subscribed handler.
     * @param {IEventsHandler} $handler Handler, which should be removed.
     * @returns {void}
     */
    RemoveHandler($type, $handler) {
        if (this.Exists($type)) {
            const handlers = this.eventsList.getItem($type);
            const handlerName = StringUtils.getSha1($handler.toString());
            if (handlers.KeyExists(handlerName)) {
                handlers.RemoveAt(handlers.getKeys().indexOf(handlerName));
            }
        }
    }
    /**
     * Clear all events, if event type has not been specified.
     * Clear subset of events subscribed to event type, if type has been specified.
     * @param {string} [$type] Specify desired type of event.
     * @returns {void}
     */
    Clear($type) {
        if (!this.isSubscribed) {
            this.eventsList.foreach(($handlers, $key) => {
                if (!ObjectValidator.IsSet($type) || $type === $key) {
                    $handlers.Clear();
                }
            });
        }
        else {
            if (ObjectValidator.IsSet($type)) {
                this.eventsList.RemoveAt(this.eventsList.getKeys().indexOf($type));
            }
            else {
                this.eventsList.Clear();
            }
        }
    }
    Subscribe($targetId, $force = false) {
        if (Loader.getInstance().getEnvironmentArgs().HtmlOutputAllowed()) {
            setTimeout(() => {
                try {
                    if (ObjectValidator.IsBoolean($targetId)) {
                        $force = $targetId;
                        $targetId = null;
                    }
                    const target = this.getTarget($targetId, $force);
                    if (!ObjectValidator.IsEmptyOrNull(target)) {
                        const manager = GuiObjectManager.getInstanceSingleton();
                        const reflection = Reflection.getInstance();
                        this.eventsList.foreach(($handlers, $key) => {
                            if (ObjectValidator.IsSet(target[$key])) {
                                target[$key] = ($args) => {
                                    try {
                                        const handlerArgs = new EventArgs();
                                        handlerArgs.Owner(this.owner);
                                        if (ObjectValidator.IsSet($args)) {
                                            handlerArgs.NativeEventArgs($args);
                                        }
                                        else {
                                            // eslint-disable-next-line @typescript-eslint/no-deprecated
                                            handlerArgs.NativeEventArgs(event);
                                        }
                                        handlerArgs.Type($key);
                                        $handlers.foreach(($handler) => {
                                            $handler(handlerArgs, manager, reflection);
                                        });
                                    }
                                    catch (ex) {
                                        ExceptionsManager.HandleException(ex);
                                    }
                                };
                                this.isSubscribed = true;
                            }
                        });
                    }
                }
                catch (ex) {
                    ExceptionsManager.HandleException(ex);
                }
            });
        }
    }
    ToString($prefix = "", $htmlTag = true) {
        let output = "Registered events list:";
        if ($htmlTag) {
            output = "<b>" + output + "</b>";
        }
        output = $prefix + output + StringUtils.NewLine($htmlTag);
        this.eventsList.foreach(($value, $type) => {
            output += $prefix + StringUtils.Tab(1, $htmlTag) + "[\"" + $type + "\"]" +
                " hooked handlers count: " + $value.Length() + StringUtils.NewLine($htmlTag);
        });
        return output;
    }
    toString() {
        return this.ToString();
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnStart($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_START, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setBeforeLoad($handler) {
        this.globalEvents.setEvent(this.owner, EventType.BEFORE_LOAD, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnLoad($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_LOAD, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnComplete($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_COMPLETE, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnShow($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_SHOW, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnHide($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_HIDE, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnFocus($handler) {
        if (this.targetIsInputElement()) {
            this.setEvent(EventType.ON_FOCUS, $handler);
        }
        else {
            this.globalEvents.setEvent(this.owner, EventType.ON_FOCUS, $handler);
        }
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnBlur($handler) {
        if (this.targetIsInputElement()) {
            this.setEvent(EventType.ON_BLUR, $handler);
        }
        else {
            this.globalEvents.setEvent(this.owner, EventType.ON_BLUR, $handler);
        }
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnMouseOver($handler) {
        this.setEvent(EventType.ON_MOUSE_OVER, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnMouseOut($handler) {
        this.setEvent(EventType.ON_MOUSE_OUT, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnMouseMove($handler) {
        this.setEvent(EventType.ON_TOUCH_MOVE, this.getTouchHandler($handler));
        this.setEvent(EventType.ON_MOUSE_MOVE, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnMouseDown($handler) {
        this.setEvent(EventType.ON_TOUCH_START, this.getTouchHandler($handler));
        this.setEvent(EventType.ON_MOUSE_DOWN, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnMouseUp($handler) {
        this.setEvent(EventType.ON_TOUCH_END, this.getTouchHandler($handler));
        this.setEvent(EventType.ON_MOUSE_UP, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnClick($handler) {
        this.setEvent(EventType.ON_CLICK, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnDoubleClick($handler) {
        this.setEvent(EventType.ON_DOUBLE_CLICK, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnChange($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_CHANGE, $handler);
    }
    /**
     * @param {IResizeEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setBeforeResize($handler) {
        this.globalEvents.setEvent(this.owner, EventType.BEFORE_RESIZE, $handler);
    }
    /**
     * @param {IResizeEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnResize($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_RESIZE, $handler);
    }
    /**
     * @param {IResizeBarEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnResizeStart($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_RESIZE_START, $handler);
    }
    /**
     * @param {IResizeBarEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnResizeChange($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_RESIZE_CHANGE, $handler);
    }
    /**
     * @param {IResizeBarEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnResizeComplete($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_RESIZE_COMPLETE, $handler);
    }
    /**
     * @param {IDragBarEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnDragStart($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_DRAG_START, $handler);
    }
    /**
     * @param {IDragBarEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnDrag($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_DRAG, $handler);
    }
    /**
     * @param {IDragBarEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnDragChange($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_DRAG_CHANGE, $handler);
    }
    /**
     * @param {IDragBarEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnDragComplete($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_DRAG_COMPLETE, $handler);
    }
    /**
     * @param {IScrollEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnScroll($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_SCROLL, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnOpen($handler) {
        this.globalEvents.setEvent(this.owner, DialogEventType.ON_OPEN, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnClose($handler) {
        this.globalEvents.setEvent(this.owner, DialogEventType.ON_CLOSE, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setBeforeOpen($handler) {
        this.globalEvents.setEvent(this.owner, BasePanelHolderEventType.BEFORE_OPEN, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setBeforeClose($handler) {
        this.globalEvents.setEvent(this.owner, BasePanelHolderEventType.BEFORE_CLOSE, $handler);
    }
    /**
     * @param {IDirectoryBrowserEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnPathRequest($handler) {
        this.globalEvents.setEvent(this.owner, DirectoryBrowserEventType.ON_PATH_REQUEST, $handler);
    }
    /**
     * @param {IDirectoryBrowserEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnDirectoryRequest($handler) {
        this.globalEvents.setEvent(this.owner, DirectoryBrowserEventType.ON_DIRECTORY_REQUEST, $handler);
    }
    /**
     * @param {IDirectoryBrowserEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnCreateDirectoryRequest($handler) {
        this.globalEvents.setEvent(this.owner, DirectoryBrowserEventType.ON_CREATE_DIRECTORY_REQUEST, $handler);
    }
    /**
     * @param {IDirectoryBrowserEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnRenameRequest($handler) {
        this.globalEvents.setEvent(this.owner, DirectoryBrowserEventType.ON_RENAME_REQUEST, $handler);
    }
    /**
     * @param {IDirectoryBrowserEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnDeleteRequest($handler) {
        this.globalEvents.setEvent(this.owner, DirectoryBrowserEventType.ON_DELETE_REQUEST, $handler);
    }
    /**
     * @param {IScrollEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnArrow($handler) {
        this.globalEvents.setEvent(this.owner, ScrollBarEventType.ON_ARROW, $handler);
    }
    /**
     * @param {IScrollEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnButton($handler) {
        this.globalEvents.setEvent(this.owner, ScrollBarEventType.ON_BUTTON, $handler);
    }
    /**
     * @param {IScrollEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnTracker($handler) {
        this.globalEvents.setEvent(this.owner, ScrollBarEventType.ON_TRACKER, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnSelect($handler) {
        this.globalEvents.setEvent(this.owner, EventType.ON_SELECT, $handler);
    }
    /**
     * @param {IMediaEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnFullscreenEnd($handler) {
        this.globalEvents.setEvent(this.owner, VideoEventType.ON_FULLSCREEN_END, $handler);
    }
    /**
     * @param {IMediaEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnFullscreenStart($handler) {
        this.globalEvents.setEvent(this.owner, VideoEventType.ON_FULLSCREEN_START, $handler);
    }
    /**
     * @param {IMediaEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnMute($handler) {
        this.globalEvents.setEvent(this.owner, AudioEventType.ON_MUTE, $handler);
    }
    /**
     * @param {IMediaEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnPause($handler) {
        this.globalEvents.setEvent(this.owner, AudioEventType.ON_PAUSE, $handler);
    }
    /**
     * @param {IMediaEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnPlay($handler) {
        this.globalEvents.setEvent(this.owner, AudioEventType.ON_PLAY, $handler);
    }
    /**
     * @param {IMediaEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnStop($handler) {
        this.globalEvents.setEvent(this.owner, AudioEventType.ON_STOP, $handler);
    }
    /**
     * @param {IMediaEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnUnmute($handler) {
        this.globalEvents.setEvent(this.owner, AudioEventType.ON_UNMUTE, $handler);
    }
    excludeSerializationData() {
        const exclude = super.excludeSerializationData();
        if (!ObjectValidator.IsString(this.owner)) {
            exclude.push("owner");
        }
        return exclude;
    }
    targetIsInputElement() {
        const target = !ObjectValidator.IsEmptyOrNull(this.subscriber) ? this.subscriber : this.owner;
        if (ObjectValidator.IsString(target)) {
            if (ElementManager.Exists(target)) {
                return StringUtils.StartsWith(ElementManager.getElement(target).outerHTML, "<input");
            }
            return !this.isSubscribed;
        }
        return false;
    }
    getTouchHandler($handler) {
        return ($eventArgs, $manager, $reflection) => {
            const touches = $eventArgs.NativeEventArgs().touches;
            let index;
            const touchesLength = touches.length;
            for (index = 0; index < touchesLength; index++) {
                const mouseEventArgs = new MouseEventArgs(touches[index]);
                mouseEventArgs.Owner($eventArgs.Owner());
                $handler(mouseEventArgs, $manager, $reflection);
            }
        };
    }
    getTarget($targetId, $force) {
        let target;
        const owner = this.getOwner();
        if (!ObjectValidator.IsEmptyOrNull($targetId)) {
            target = ElementManager.getElement($targetId, $force);
        }
        else if (!ObjectValidator.IsEmptyOrNull(this.subscriber)) {
            target = ElementManager.getElement(this.subscriber, $force);
        }
        else if (!ObjectValidator.IsEmptyOrNull(owner)) {
            target = ElementManager.getElement(owner, $force);
        }
        else {
            target = document;
        }
        return target;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Events.ElementEventsManager", ElementEventsManager);
//# sourceMappingURL=ElementEventsManager.js.map