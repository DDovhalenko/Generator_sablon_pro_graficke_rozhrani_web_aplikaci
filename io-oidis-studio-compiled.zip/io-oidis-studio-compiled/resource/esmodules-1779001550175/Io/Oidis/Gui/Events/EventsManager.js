/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BrowserType } from "./../../../../Io/Oidis/Commons/Enums/BrowserType.js";
import { EventArgs } from "./../../../../Io/Oidis/Commons/Events/Args/EventArgs.js";
import { EventsManager as Parent } from "./../../../../Io/Oidis/Commons/Events/EventsManager.js";
import { ExceptionsManager } from "./../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { DirectionType } from "../Enums/DirectionType.js";
import { EventType } from "../Enums/Events/EventType.js";
import { GeneralEventOwner } from "../Enums/Events/GeneralEventOwner.js";
import { OrientationType } from "../Enums/OrientationType.js";
import { GuiObjectManager } from "../GuiObjectManager.js";
import { Loader } from "../Loader.js";
import { StaticPageContentManager } from "../Utils/StaticPageContentManager.js";
import { TextSelectionManager } from "../Utils/TextSelectionManager.js";
import { KeyEventArgs } from "./Args/KeyEventArgs.js";
import { MouseEventArgs } from "./Args/MouseEventArgs.js";
import { MoveEventArgs } from "./Args/MoveEventArgs.js";
import { ScrollEventArgs } from "./Args/ScrollEventArgs.js";
/**
 * EventsManager class provides handling of native events subscribed to HTML elements.
 */
export class EventsManager extends Parent {
    /**
     * @returns {IEventsManager} Returns the singleton instance of the events manager from the HTTP resolver.
     */
    static getInstanceSingleton() {
        return Loader.getInstance().getHttpResolver().getEvents();
    }
    static bodyFocusEventHandler() {
        try {
            const eventArgs = new EventArgs();
            Loader.getInstance().getHttpResolver().getEvents().FireEvent(GeneralEventOwner.BODY, EventType.ON_FOCUS, eventArgs);
            Loader.getInstance().getHttpResolver().getEvents().FireEvent(GeneralEventOwner.WINDOW, EventType.ON_FOCUS, eventArgs);
        }
        catch (ex) {
            ExceptionsManager.HandleException(ex);
        }
    }
    static bodyBlurEventHandler() {
        try {
            const eventArgs = new EventArgs();
            Loader.getInstance().getHttpResolver().getEvents().FireEvent(GeneralEventOwner.BODY, EventType.ON_BLUR, eventArgs);
            Loader.getInstance().getHttpResolver().getEvents().FireEvent(GeneralEventOwner.WINDOW, EventType.ON_BLUR, eventArgs);
        }
        catch (ex) {
            ExceptionsManager.HandleException(ex);
        }
    }
    /**
     * @param {string|IGuiCommons} $owner Event args owner name.
     * @param {string} $type Event args type of.
     * @param {IEventArgs} $args Set current event args.
     * @returns {void}
     */
    setEventArgs($owner, $type, $args) {
        let eventOwner;
        if (ObjectValidator.IsSet($owner.Id)) {
            eventOwner = $owner.Id();
        }
        else {
            eventOwner = $owner;
        }
        if (ObjectValidator.IsEmptyOrNull($args.Owner())) {
            $args.Owner($owner);
        }
        super.setEventArgs(eventOwner, $type, $args);
    }
    /**
     * @param {string|IGuiCommons} $owner Subscribed event to this owner value.
     * @param {string} $type Subscribe handler to this type of event.
     * @param {IEventsHandler} [$handler] Function suitable for handling of the event.
     * @param {IEventArgs} [$args] Set initial event args.
     * @returns {void}
     */
    setEvent($owner, $type, $handler, $args) {
        let eventOwner;
        if (ObjectValidator.IsSet($owner.Id)) {
            eventOwner = $owner.Id();
        }
        else {
            eventOwner = $owner;
        }
        super.setEvent(eventOwner, $type, $handler, $args);
        if (!ObjectValidator.IsSet($args) && ObjectValidator.IsSet($owner.Id)) {
            this.getArgsList().getItem(eventOwner).getItem($type).Owner($owner);
        }
    }
    /**
     * @param {string|IGuiCommons} $owner Specify fired event owner.
     * @param {string} $type Specify fired type of event.
     * @param {any} [$args] Specify event args for current event process.
     * @param {boolean} [$async] Specify, if event handlers can be execute asynchronously.
     * @returns {void}
     */
    FireEvent($owner, $type, $args, $async) {
        let eventOwner;
        if (ObjectValidator.IsSet($owner.Id)) {
            eventOwner = $owner.Id();
        }
        else {
            eventOwner = $owner;
        }
        if (this.Exists(eventOwner, $type)) {
            const reflection = Reflection.getInstance();
            if (!ObjectValidator.IsSet($args) ||
                (ObjectValidator.IsBoolean($args) && !ObjectValidator.IsBoolean($async))) {
                if (ObjectValidator.IsBoolean($args) && !ObjectValidator.IsBoolean($async)) {
                    $async = $args;
                }
                if (this.getArgsList().KeyExists(eventOwner)) {
                    const args = this.getArgsList().getItem(eventOwner).getItem($type);
                    if (!ObjectValidator.IsEmptyOrNull(args)) {
                        $args = args;
                    }
                }
            }
            else if (reflection.IsMemberOf($args, EventArgs)) {
                this.setEventArgs($owner, $type, $args);
            }
            if (!ObjectValidator.IsBoolean($async)) {
                $async = true;
            }
            const handlers = this.getAll().getItem(eventOwner).getItem($type);
            try {
                const manager = GuiObjectManager.getInstanceSingleton();
                handlers.foreach(($handler) => {
                    if ($async) {
                        setTimeout(() => {
                            try {
                                $handler($args, manager, reflection);
                            }
                            catch (ex) {
                                ExceptionsManager.HandleException(ex);
                            }
                        });
                    }
                    else {
                        $handler($args, manager, reflection);
                    }
                });
            }
            catch (ex) {
                ExceptionsManager.HandleException(ex);
            }
        }
    }
    /**
     * @param {string|IGuiCommons} $owner Event owner name of subscribed handler.
     * @param {string} $type Event type of subscribed handler.
     * @param {IEventsHandler} $handler Handler, which should be removed.
     * @returns {void}
     */
    RemoveHandler($owner, $type, $handler) {
        let eventOwner;
        if (ObjectValidator.IsSet($owner.Id)) {
            eventOwner = $owner.Id();
        }
        else {
            eventOwner = $owner;
        }
        super.RemoveHandler(eventOwner, $type, $handler);
    }
    /**
     * @param {string|IGuiCommons} $owner Validate events subscribed to this owner value.
     * @param {string} $type Validate this type of subevents.
     * @returns {boolean} Returns true, if $owner and $type has been registered, otherwise false.
     */
    Exists($owner, $type) {
        let eventOwner;
        if (ObjectValidator.IsSet($owner.Id)) {
            eventOwner = $owner.Id();
        }
        else {
            eventOwner = $owner;
        }
        return super.Exists(eventOwner, $type);
    }
    /**
     * Subscribes native browser event handlers (keyboard, mouse, touch, scroll, drag) to the document and window elements.
     * @returns {void}
     */
    Subscribe() {
        super.Subscribe();
        if (StaticPageContentManager.BodyEventsEnabled()) {
            let onBeforeUnloadFired = false;
            this.setEvent(GeneralEventOwner.WINDOW, EventType.BEFORE_REFRESH, () => {
                if (!onBeforeUnloadFired) {
                    onBeforeUnloadFired = true;
                    Loader.getInstance().getHttpManager().ReloadTo("/PersistenceManager", null, true);
                }
            });
            this.setEvent(GeneralEventOwner.WINDOW, EventType.ON_HTTP_REQUEST, () => {
                Loader.getInstance().getHttpManager().ReloadTo("/PersistenceManager", null, true);
            });
        }
        const getEventArgs = ($value) => {
            if (!ObjectValidator.IsSet($value)) {
                // eslint-disable-next-line @typescript-eslint/no-deprecated -- polyfill fallback for browsers not passing event args
                return event;
            }
            else {
                return $value;
            }
        };
        window.onresize = ($eventArgs) => {
            try {
                const eventArgs = new EventArgs();
                $eventArgs = getEventArgs($eventArgs);
                eventArgs.NativeEventArgs($eventArgs);
                this.FireEvent(GeneralEventOwner.BODY, EventType.ON_RESIZE, eventArgs, false);
                this.FireEvent(GeneralEventOwner.WINDOW, EventType.ON_RESIZE, eventArgs, false);
            }
            catch (ex) {
                ExceptionsManager.HandleException(ex);
            }
        };
        const isOnLoadKey = this.isOnLoadKey;
        window.document.onkeydown = ($eventArgs) => {
            try {
                $eventArgs = getEventArgs($eventArgs);
                this.FireEvent(GeneralEventOwner.BODY, EventType.ON_KEY_DOWN, new KeyEventArgs($eventArgs), false);
                if (isOnLoadKey($eventArgs)) {
                    this.FireEvent(GeneralEventOwner.BODY, EventType.BEFORE_REFRESH);
                }
            }
            catch (ex) {
                ExceptionsManager.HandleException(ex);
            }
        };
        window.document.onkeyup = ($eventArgs) => {
            try {
                $eventArgs = getEventArgs($eventArgs);
                this.FireEvent(GeneralEventOwner.BODY, EventType.ON_KEY_UP, new KeyEventArgs($eventArgs), false);
            }
            catch (ex) {
                ExceptionsManager.HandleException(ex);
            }
        };
        // eslint-disable-next-line @typescript-eslint/no-deprecated -- keypress event support is maintained for backward compatibility
        window.document.onkeypress = ($eventArgs) => {
            try {
                $eventArgs = getEventArgs($eventArgs);
                this.FireEvent(GeneralEventOwner.BODY, EventType.ON_KEY_PRESS, new KeyEventArgs($eventArgs), false);
            }
            catch (ex) {
                ExceptionsManager.HandleException(ex);
            }
        };
        window.document.onclick = ($eventArgs) => {
            try {
                $eventArgs = getEventArgs($eventArgs);
                this.FireEvent(GeneralEventOwner.BODY, EventType.ON_CLICK, new MouseEventArgs($eventArgs));
                this.FireEvent(GeneralEventOwner.WINDOW, EventType.ON_CLICK, new MouseEventArgs($eventArgs));
            }
            catch (ex) {
                ExceptionsManager.HandleException(ex);
            }
        };
        window.document.ondblclick = ($eventArgs) => {
            try {
                $eventArgs = getEventArgs($eventArgs);
                this.FireEvent(GeneralEventOwner.BODY, EventType.ON_DOUBLE_CLICK, new MouseEventArgs($eventArgs));
                this.FireEvent(GeneralEventOwner.WINDOW, EventType.ON_DOUBLE_CLICK, new MouseEventArgs($eventArgs));
            }
            catch (ex) {
                ExceptionsManager.HandleException(ex);
            }
        };
        window.document.oncontextmenu = ($eventArgs) => {
            try {
                $eventArgs = getEventArgs($eventArgs);
                this.FireEvent(GeneralEventOwner.BODY, EventType.ON_RIGHT_CLICK, new MouseEventArgs($eventArgs), false);
                this.FireEvent(GeneralEventOwner.WINDOW, EventType.ON_RIGHT_CLICK, new MouseEventArgs($eventArgs), false);
            }
            catch (ex) {
                ExceptionsManager.HandleException(ex);
            }
        };
        let moveArgs;
        let isMoveManagerActive = false;
        const onMouseDownHandler = ($eventArgs) => {
            try {
                $eventArgs = getEventArgs($eventArgs);
                this.FireEvent(GeneralEventOwner.BODY, EventType.ON_MOUSE_DOWN, new MouseEventArgs($eventArgs));
                moveArgs = new MoveEventArgs($eventArgs);
                isMoveManagerActive = true;
                this.FireEvent(GeneralEventOwner.MOUSE_MOVE, EventType.ON_START, moveArgs);
            }
            catch (ex) {
                ExceptionsManager.HandleException(ex);
            }
        };
        let lastDeltaX = 0;
        let lastDeltaY = 0;
        window.document.onmousedown = onMouseDownHandler;
        window.document.ontouchstart = ($eventArgs) => {
            const touches = $eventArgs.changedTouches;
            let index;
            const touchesLength = touches.length;
            if (touchesLength === 1) {
                lastDeltaX = 0;
                lastDeltaY = 0;
                onMouseDownHandler(touches[0]);
            }
            else {
                for (index = 0; index < touchesLength; index++) {
                    onMouseDownHandler(touches[index]);
                }
            }
        };
        const simulateScroll = ($eventArgs, $delta, $orientation) => {
            const eventArgs = new ScrollEventArgs();
            eventArgs.NativeEventArgs($eventArgs);
            eventArgs.OrientationType($orientation);
            $delta = Math.abs(Math.ceil($delta));
            let position = 0;
            if ($orientation === OrientationType.HORIZONTAL) {
                position = lastDeltaX - $delta;
                lastDeltaX = $delta;
            }
            else {
                position = lastDeltaY - $delta;
                lastDeltaY = $delta;
            }
            eventArgs.DirectionType(position < 0 ? DirectionType.DOWN : DirectionType.UP);
            position = Math.abs(Math.ceil(position));
            if (position > 0) {
                if (position > 100) {
                    position = 100;
                }
                eventArgs.Position(position);
                this.FireEvent(GeneralEventOwner.BODY, EventType.ON_SCROLL, eventArgs, false);
            }
        };
        const onMouseMoveHandler = ($eventArgs, $singleEvent) => {
            try {
                $eventArgs = getEventArgs($eventArgs);
                if (!ObjectValidator.IsSet(moveArgs)) {
                    moveArgs = new MoveEventArgs($eventArgs);
                }
                moveArgs.NativeEventArgs($eventArgs);
                this.FireEvent(GeneralEventOwner.MOUSE_MOVE, EventType.ON_CHANGE, moveArgs);
                if (isMoveManagerActive) {
                    if (!this.isElementMoveAllowed()) {
                        moveArgs.PreventDefault();
                        TextSelectionManager.Clear();
                    }
                    else if ($singleEvent) {
                        if (moveArgs.getDistanceY() !== 0) {
                            simulateScroll($eventArgs, moveArgs.getDistanceY(), OrientationType.VERTICAL);
                        }
                        if (moveArgs.getDistanceX() !== 0) {
                            simulateScroll($eventArgs, moveArgs.getDistanceX(), OrientationType.HORIZONTAL);
                        }
                    }
                }
            }
            catch (ex) {
                ExceptionsManager.HandleException(ex);
            }
        };
        window.document.onmousemove = ($eventArgs) => {
            onMouseMoveHandler($eventArgs, false);
        };
        window.document.ontouchmove = ($eventArgs) => {
            const touches = $eventArgs.changedTouches;
            let index;
            const touchesLength = touches.length;
            if (touchesLength === 1) {
                onMouseMoveHandler(touches[0], true);
            }
            else {
                for (index = 0; index < touchesLength; index++) {
                    onMouseMoveHandler(touches[index], false);
                }
            }
        };
        const onMouseUpHandler = ($eventArgs) => {
            try {
                $eventArgs = getEventArgs($eventArgs);
                this.FireEvent(GeneralEventOwner.BODY, EventType.ON_MOUSE_UP, new MouseEventArgs($eventArgs));
                moveArgs.NativeEventArgs($eventArgs);
                document.body.style.cursor = "default";
                isMoveManagerActive = false;
                this.FireEvent(GeneralEventOwner.MOUSE_MOVE, EventType.ON_COMPLETE, moveArgs);
            }
            catch (ex) {
                ExceptionsManager.HandleException(ex);
            }
        };
        window.document.onmouseup = onMouseUpHandler;
        window.document.ontouchend = ($eventArgs) => {
            const touches = $eventArgs.changedTouches;
            let index;
            const touchesLength = touches.length;
            for (index = 0; index < touchesLength; index++) {
                onMouseUpHandler(touches[index]);
            }
        };
        let wheelEventTypeFired = false;
        let supportsPassive = false;
        const scrollEventHandler = ($eventArgs) => {
            try {
                $eventArgs = getEventArgs($eventArgs);
                if (supportsPassive) {
                    $eventArgs.preventDefault = () => {
                        // prevent default should not be invoked on passive listeners
                    };
                }
                if ($eventArgs.type && $eventArgs.type === "wheel") {
                    wheelEventTypeFired = true;
                }
                if (!$eventArgs.ctrlKey &&
                    ((wheelEventTypeFired && $eventArgs.type === "wheel") || !wheelEventTypeFired)) {
                    let scrollDelta = 0;
                    let orientation = OrientationType.VERTICAL;
                    let direction = DirectionType.DOWN;
                    if (ObjectValidator.IsSet($eventArgs.deltaY) ||
                        ObjectValidator.IsSet($eventArgs.deltaX)) {
                        if ($eventArgs.deltaX !== 0) {
                            orientation = OrientationType.HORIZONTAL;
                            scrollDelta = $eventArgs.deltaX;
                        }
                        else {
                            scrollDelta = $eventArgs.deltaY;
                        }
                        if (Loader.getInstance().getHttpManager().getRequest().getBrowserType() === BrowserType.FIREFOX ||
                            Loader.getInstance().getHttpManager().getRequest().getBrowserType() === BrowserType.SAFARI) {
                            scrollDelta = scrollDelta * 100;
                        }
                        scrollDelta = (-1) * scrollDelta / 120;
                    }
                    else if (ObjectValidator.IsSet($eventArgs.wheelDeltaY) ||
                        ObjectValidator.IsSet($eventArgs.wheelDeltaX)) {
                        if ($eventArgs.wheelDeltaX !== 0) {
                            orientation = OrientationType.HORIZONTAL;
                            scrollDelta = $eventArgs.wheelDeltaX;
                        }
                        else {
                            scrollDelta = $eventArgs.wheelDeltaY;
                        }
                        scrollDelta = scrollDelta / 120;
                    }
                    else if (ObjectValidator.IsSet($eventArgs.detail)) {
                        scrollDelta = (-1) * $eventArgs.detail / 3;
                    }
                    else {
                        scrollDelta = $eventArgs.wheelDelta / 120;
                    }
                    if ((orientation === OrientationType.VERTICAL && scrollDelta > 0) ||
                        (orientation === OrientationType.HORIZONTAL && scrollDelta > 0)) {
                        direction = DirectionType.UP;
                    }
                    scrollDelta = Math.abs(Math.ceil(scrollDelta));
                    if (scrollDelta < 1) {
                        scrollDelta = 1;
                    }
                    if (scrollDelta > 100) {
                        scrollDelta = 100;
                    }
                    const eventArgs = new ScrollEventArgs();
                    eventArgs.NativeEventArgs($eventArgs);
                    eventArgs.Position(scrollDelta);
                    eventArgs.OrientationType(orientation);
                    eventArgs.DirectionType(direction);
                    this.FireEvent(GeneralEventOwner.BODY, EventType.ON_SCROLL, eventArgs, false);
                }
            }
            catch (ex) {
                ExceptionsManager.HandleException(ex);
            }
        };
        if (ObjectValidator.IsSet(window.document.addEventListener)) {
            // eslint-disable-next-line no-restricted-syntax -- wheel/DOMMouseScroll events have no on* property equivalent
            window.document.addEventListener("wheel", scrollEventHandler, false);
            // eslint-disable-next-line no-restricted-syntax -- wheel/DOMMouseScroll events have no on* property equivalent
            window.document.addEventListener("DOMMouseScroll", scrollEventHandler, false);
            try {
                const opts = Object.defineProperty({}, "passive", {
                    get: () => {
                        supportsPassive = true;
                    }
                });
                const eventName = this.getClassName() + "_testPassive";
                // eslint-disable-next-line no-restricted-syntax -- passive listener detection requires addEventListener
                window.addEventListener(eventName, null, opts);
                window.removeEventListener(eventName, null, opts);
            }
            catch (ex) {
                // ignore detector errors
            }
        }
        if (ObjectValidator.IsSet(window.document.onmousewheel)) {
            window.document.onmousewheel = scrollEventHandler;
        }
        [
            EventType.ON_DRAG_OVER, "ondragstart", "ondragenter", "ondragleave", "ondragend", EventType.ON_DROP
        ].forEach(($type) => {
            window.document[$type] = ($eventArgs) => {
                try {
                    $eventArgs = getEventArgs($eventArgs);
                    this.FireEvent(GeneralEventOwner.BODY, $type, new MouseEventArgs($eventArgs), false);
                }
                catch (ex) {
                    ExceptionsManager.HandleException(ex);
                }
            };
        });
    }
    isOnLoadKey($eventArgs) {
        return (!$eventArgs.ctrlKey && $eventArgs.key === "F5") ||
            ($eventArgs.altKey && $eventArgs.key === "F4") ||
            ($eventArgs.key === "Backspace");
    }
    isElementMoveAllowed() {
        return true;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Events.EventsManager", EventsManager);
//# sourceMappingURL=EventsManager.js.map