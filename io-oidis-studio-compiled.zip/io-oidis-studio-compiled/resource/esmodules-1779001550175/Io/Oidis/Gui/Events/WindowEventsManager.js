import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { EventType } from "../Enums/Events/EventType.js";
import { GeneralEventOwner } from "../Enums/Events/GeneralEventOwner.js";
import { EventsManager } from "./EventsManager.js";
/**
 * WindowEventsManager class provides handling of native events subscribed to window or body elements.
 */
export class WindowEventsManager extends BaseObject {
    events;
    constructor() {
        super();
        this.events = EventsManager.getInstanceSingleton();
    }
    /**
     * @param {string} $type Validate this type of event.
     * @returns {boolean} Returns true, if event type has been registered, otherwise false.
     */
    Exists($type) {
        return this.events.Exists(this.getOwner($type), $type);
    }
    /**
     * @returns {ArrayList<ArrayList<IEventsHandler>>} Returns list of all registered events.
     */
    getAll() {
        return this.events.getAll().getItem(GeneralEventOwner.BODY);
    }
    /**
     * @param {string} $type Subscribe handler to this type of event.
     * @param {IEventsHandler} $handler Function suitable for handling of the event.
     * @returns {void}
     */
    setEvent($type, $handler) {
        this.events.setEvent(this.getOwner($type), $type, $handler);
    }
    /**
     * @param {Function} $handler Function suitable for handling of the event.
     * @param {boolean} [$clearBefore=true] Clean up currently running thread with same handler.
     * @param {number} [$waitForMilliseconds] Specify wait time before execution of the handler in milliseconds.
     * @returns {number} Returns thread number allocated for asynchronous execution.
     */
    FireAsynchronousMethod($handler, $clearBefore, $waitForMilliseconds) {
        return this.events.FireAsynchronousMethod($handler, $clearBefore, $waitForMilliseconds);
    }
    /**
     * @param {string} $type Event type of subscribed handler.
     * @param {IEventsHandler} $handler Handler, which should be removed.
     * @returns {void}
     */
    RemoveHandler($type, $handler) {
        this.events.RemoveHandler(this.getOwner($type), $type, $handler);
    }
    /**
     * Clear all events, if event type has not been specified.
     * Clear subset of events subscribed to event type, if type has been specified.
     * @param {string} [$type] Specify desired type of event.
     * @returns {void}
     */
    Clear($type) {
        this.events.Clear(this.getOwner($type), $type);
    }
    ToString($prefix = "", $htmlTag = true) {
        let output = "Registered events list:";
        if ($htmlTag) {
            output = "<b>" + output + "</b>";
        }
        output = $prefix + output + StringUtils.NewLine($htmlTag);
        this.getAll().foreach(($value, $type) => {
            output += $prefix + StringUtils.Tab(1, $htmlTag) + "[\"" + $type + "\"]" +
                " hooked handlers count: " + $value.Length() + StringUtils.NewLine($htmlTag);
        });
        return output;
    }
    toString() {
        return this.ToString();
    }
    /**
     * @param {IErrorEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnError($handler) {
        this.setEvent(EventType.ON_ERROR, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setBeforeRefresh($handler) {
        this.setEvent(EventType.BEFORE_REFRESH, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnLoad($handler) {
        this.setEvent(EventType.ON_LOAD, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnBlur($handler) {
        this.setEvent(EventType.ON_BLUR, $handler);
    }
    /**
     * @param {IEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnFocus($handler) {
        this.setEvent(EventType.ON_FOCUS, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnClick($handler) {
        this.setEvent(EventType.ON_CLICK, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnRightClick($handler) {
        this.setEvent(EventType.ON_RIGHT_CLICK, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnDoubleClick($handler) {
        this.setEvent(EventType.ON_DOUBLE_CLICK, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnMouseOver($handler) {
        this.setEvent(EventType.ON_MOUSE_OVER, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnMouseOut($handler) {
        this.setEvent(EventType.ON_MOUSE_OUT, $handler);
    }
    /**
     * @param {IMoveEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnMove($handler) {
        this.events.setEvent(GeneralEventOwner.MOUSE_MOVE, EventType.ON_CHANGE, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnMouseDown($handler) {
        this.setEvent(EventType.ON_MOUSE_DOWN, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnMouseUp($handler) {
        this.setEvent(EventType.ON_MOUSE_UP, $handler);
    }
    /**
     * @param {IKeyEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnKeyDown($handler) {
        this.setEvent(EventType.ON_KEY_DOWN, $handler);
    }
    /**
     * @param {IKeyEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnKeyUp($handler) {
        this.setEvent(EventType.ON_KEY_UP, $handler);
    }
    /**
     * @param {IKeyEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnKeyPress($handler) {
        this.setEvent(EventType.ON_KEY_PRESS, $handler);
    }
    /**
     * @param {IResizeEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnResize($handler) {
        this.setEvent(EventType.ON_RESIZE, $handler);
    }
    /**
     * @param {IScrollEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnScroll($handler) {
        this.setEvent(EventType.ON_SCROLL, $handler);
    }
    /**
     * @param {IHttpRequestEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnRequest($handler) {
        this.setEvent(EventType.ON_HTTP_REQUEST, $handler);
    }
    /**
     * @param {IAsyncRequestEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnAsyncRequest($handler) {
        this.setEvent(EventType.ON_ASYNC_REQUEST, $handler);
    }
    /**
     * @param {IMessageEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnMessage($handler) {
        this.setEvent(EventType.ON_MESSAGE, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnDragOver($handler) {
        this.setEvent(EventType.ON_DRAG_OVER, $handler);
    }
    /**
     * @param {IMouseEventsHandler} $handler Specify event callback for current event type.
     * @returns {void}
     */
    setOnDrop($handler) {
        this.setEvent(EventType.ON_DROP, $handler);
    }
    getOwner($type) {
        switch ($type) {
            case EventType.ON_MOUSE_MOVE:
                return GeneralEventOwner.MOUSE_MOVE;
            case EventType.ON_HTTP_REQUEST:
            case EventType.ON_ASYNC_REQUEST:
                return GeneralEventOwner.WINDOW;
            default:
                return GeneralEventOwner.BODY;
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Events.WindowEventsManager", WindowEventsManager);
//# sourceMappingURL=WindowEventsManager.js.map