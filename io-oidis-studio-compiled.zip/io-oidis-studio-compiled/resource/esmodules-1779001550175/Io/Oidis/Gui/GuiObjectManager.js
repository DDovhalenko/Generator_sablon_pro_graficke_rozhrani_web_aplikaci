import { BaseObject } from "./../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { ObjectValidator } from "./../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Loader } from "./Loader.js";
import { GuiObjectsMap } from "./Structures/GuiObjectsMap.js";
/**
 * GuiObjectManager class provides register, filtering and handling of all GUI objects.
 */
export class GuiObjectManager extends BaseObject {
    map;
    hoveredElement;
    activeObjectsMap;
    /**
     * @returns {GuiObjectManager} Returns singleton instance of GuiObjectManager class,
     * which should be used as global GUI objects register.
     */
    static getInstanceSingleton() {
        return Loader.getInstance().getHttpResolver().getGuiRegister();
    }
    constructor() {
        super();
        this.map = new GuiObjectsMap();
        this.hoveredElement = null;
        this.activeObjectsMap = new GuiObjectsMap();
    }
    /**
     * @param {IGuiCommons|IClassName} $value Element object or class name, which should be validated.
     * @returns {boolean} Returns true, if element object or group of elements with desired class name has been registered,
     * otherwise false.
     */
    Exists($value) {
        if (ObjectValidator.IsEmptyOrNull($value)) {
            return false;
        }
        if (ObjectValidator.IsSet($value.ClassName)) {
            return !ObjectValidator.IsEmptyOrNull(this.map.getType($value));
        }
        return this.map.Exists($value);
    }
    /**
     * Add element to the GUI objects register, if element is not already in register.
     * @param {IGuiCommons} [$objectOrMap] Element, which should be registered.
     * @returns {void}
     */
    Add($objectOrMap) {
        this.map.Add($objectOrMap);
    }
    /**
     * @param {IGuiCommons} $element Element, which should be handled.
     * @param {boolean} $status Specify element's focus or activity status.
     * @returns {void}
     */
    setActive($element, $status) {
        if (!ObjectValidator.IsEmptyOrNull($element)) {
            if ($status) {
                this.activeObjectsMap.Add($element);
            }
            else {
                this.activeObjectsMap.Clear($element);
            }
        }
    }
    /**
     * @param {IGuiCommons} $element Element, which should be handled.
     * @param {boolean} $status Specify element's on mouse over status.
     * @returns {void}
     */
    setHovered($element, $status) {
        if ($status) {
            if (!ObjectValidator.IsEmptyOrNull($element) && this.Exists($element)) {
                this.hoveredElement = $element;
            }
        }
        else if (ObjectValidator.IsEmptyOrNull(this.hoveredElement) || this.hoveredElement === $element) {
            this.hoveredElement = null;
        }
    }
    /**
     * @param {IGuiCommons|IClassName} $className Element class name, which should be searched.
     * @returns {ArrayList<IGuiCommons>} Returns array list of elements with desired element type.
     */
    getType($className) {
        return this.map.getType($className);
    }
    /**
     * @param {IGuiCommons|IClassName} [$type] Element type, which should be searched.
     * @returns {ArrayList<IGuiCommons>} Returns array list of all active elements with desired element type,
     * if type has been specified, otherwise returns array list of all active elements.
     */
    getActive($type) {
        if (!ObjectValidator.IsSet($type)) {
            return this.activeObjectsMap.getAll();
        }
        return this.activeObjectsMap.getType($type);
    }
    /**
     * @returns {IGuiCommons} Returns element instance, if some of element has been hovered by the mouse, otherwise null.
     */
    getHovered() {
        return this.hoveredElement;
    }
    /**
     * @param {IGuiCommons|IClassName} $elementOrType Element or class name, which should be validated.
     * @returns {boolean} Returns true, if desired element or group of elements with desired class
     * is hovered, otherwise false.
     */
    IsHovered($elementOrType) {
        if (ObjectValidator.IsSet($elementOrType)) {
            if (ObjectValidator.IsEmptyOrNull(this.getHovered()) || ObjectValidator.IsEmptyOrNull($elementOrType)) {
                return false;
            }
            if (ObjectValidator.IsSet($elementOrType.ClassName)) {
                return this.getHovered().IsMemberOf($elementOrType);
            }
            return this.getHovered() === $elementOrType;
        }
        return false;
    }
    /**
     * @returns {ArrayList<IGuiCommons>} Returns array list of all registered GUI objects.
     */
    getAll() {
        return this.map.getAll();
    }
    /**
     * @param {IGuiCommons|IClassName} $elementOrType Element or class name, which should be validated.
     * @returns {boolean} Returns true, if desired element or group of elements with desired class
     * is focused or in active state, otherwise false.
     */
    IsActive($elementOrType) {
        if (ObjectValidator.IsEmptyOrNull($elementOrType)) {
            return false;
        }
        if (ObjectValidator.IsSet($elementOrType.ClassName)) {
            return !ObjectValidator.IsEmptyOrNull(this.activeObjectsMap.getType($elementOrType));
        }
        return this.activeObjectsMap.Exists($elementOrType);
    }
    /**
     * Clean up all registered elements, if $element has not been specified.
     * Clean up element from the registered GUI objects, if $element has been specified and is registered.
     * @param {IGuiCommons} [$element] Element, which should be removed.
     * @returns {void}
     */
    Clear($element) {
        if (ObjectValidator.IsSet($element)) {
            if (this.Exists($element)) {
                this.setHovered($element, false);
                this.activeObjectsMap.Clear($element);
                if (this.Exists($element.Parent())) {
                    const parent = $element.Parent();
                    parent.getChildElements().RemoveAt(parent.getChildElements().IndexOf($element));
                }
                this.map.Clear($element);
            }
        }
        else {
            this.hoveredElement = null;
            this.activeObjectsMap.Clear();
            this.map.Clear();
        }
    }
    /**
     * @param {string} [$prefix=""] Specify prefix, which should be used for each line of output.
     * @param {boolean} [$htmlTag=true] Specify, if output should contain HTML tags.
     * @returns {string} Returns string representation of all registered and active GUI objects.
     */
    ToString($prefix = "", $htmlTag = true) {
        let output = "All elements:";
        if ($htmlTag) {
            output = "<b>" + output + "</b>";
        }
        output = $prefix + output + StringUtils.NewLine($htmlTag);
        if (this.map.IsEmpty()) {
            output += $prefix + "none of GUI element has been registered yet" + StringUtils.NewLine($htmlTag);
        }
        else {
            output += this.map.ToString($prefix, $htmlTag);
        }
        let active = "Active elements:";
        if ($htmlTag) {
            active = "<b>" + active + "</b>";
        }
        output += $prefix + active + StringUtils.NewLine($htmlTag);
        if (this.activeObjectsMap.IsEmpty()) {
            output += $prefix + "no active elements has been found" + StringUtils.NewLine($htmlTag);
        }
        else {
            output += this.activeObjectsMap.ToString($prefix, $htmlTag);
        }
        return output;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.GuiObjectManager", GuiObjectManager);
//# sourceMappingURL=GuiObjectManager.js.map