/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpResolver as Parent } from "./../../../../Io/Oidis/Commons/HttpProcessor/HttpResolver.js";
import { EventsManager } from "../Events/EventsManager.js";
import { GuiObjectManager } from "../GuiObjectManager.js";
import { HttpManager } from "./HttpManager.js";
export class HttpResolver extends Parent {
    guiRegister;
    constructor($baseUrl) {
        super($baseUrl);
        const guiObjectManager = this.getGuiObjectManagerClass();
        this.guiRegister = new guiObjectManager();
    }
    /**
     * @returns {HttpManager} Returns HTTP manager instance used for handling of current request.
     */
    getManager() {
        return super.getManager();
    }
    /**
     * @returns {EventsManager} Returns events manager instance used for handling of GUI events.
     */
    getEvents() {
        return super.getEvents();
    }
    /**
     * @returns {GuiObjectManager} Returns GuiObjectManager instance used for management of GUI used in resolved requests.
     */
    getGuiRegister() {
        return this.guiRegister;
    }
    getHttpManagerClass() {
        return HttpManager;
    }
    getEventsManagerClass() {
        return EventsManager;
    }
    getGuiObjectManagerClass() {
        return GuiObjectManager;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.HttpProcessor.HttpResolver", HttpResolver);
//# sourceMappingURL=HttpResolver.js.map