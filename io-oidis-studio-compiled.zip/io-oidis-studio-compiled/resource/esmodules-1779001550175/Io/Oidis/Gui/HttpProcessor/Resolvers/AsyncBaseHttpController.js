/*! ******************************************************************************************************** *
 *
 * Copyright 2022-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "./../../../../../Io/Oidis/Commons/Enums/Events/EventType.js";
import { LanguageType } from "./../../../../../Io/Oidis/Commons/Enums/LanguageType.js";
import { BaseHttpResolver } from "./../../../../../Io/Oidis/Commons/HttpProcessor/Resolvers/BaseHttpResolver.js";
import { isBrowser } from "./../../../../../Io/Oidis/Commons/Utils/EnvironmentHelper.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
import { Reflection } from "./../../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { BasePanel } from "../../Bootstrap/Primitives/BasePanel.js";
import { BasePanelController } from "../../Bootstrap/Primitives/BasePanelController.js";
import { BaseViewer } from "../../Bootstrap/Primitives/BaseViewer.js";
import { GuiCommons } from "../../Bootstrap/Primitives/GuiCommons.js";
import { GeneralEventOwner } from "../../Enums/Events/GeneralEventOwner.js";
import { Loader } from "../../Loader.js";
import { ElementManager } from "../../Utils/ElementManager.js";
import { StaticPageContentManager } from "../../Utils/StaticPageContentManager.js";
export class AsyncBaseHttpController extends BaseHttpResolver {
    static rendered;
    pageInstance;
    pageTitle;
    pageCache;
    faviconSource;
    language;
    processing;
    parallelProcessing;
    loaderProcess;
    resolved;
    /**
     * @returns {TController} Returns singleton instance of the controller class.
     */
    static getInstance() {
        const singleton = "__Singleton." + this.ClassName();
        if (this.hasOwnProperty(singleton)) {
            return this[singleton];
        }
        return this[singleton] = (new this());
    }
    constructor() {
        super();
        this.pageInstance = null;
        this.pageTitle = this.getEnvironmentArgs().getProjectName() + " v" + this.getEnvironmentArgs().getProjectVersion();
        this.faviconSource = "resource/graphics/icon.ico";
        this.language = LanguageType.EN;
        this.processing = false;
        this.parallelProcessing = false;
        this.loaderProcess = null;
        this.resolved = false;
    }
    /**
     * @returns {BasePanel} Returns page instance owner associated with the controller.
     */
    InstanceOwner() {
        return this.pageInstance;
    }
    /**
     * Prepare page content including title, language and favicon.
     * @returns {void}
     */
    PreparePageContent() {
        try {
            this.setPageTitle(StringUtils.Format(this.pageTitle, this.getEnvironmentArgs().getProjectVersion()));
        }
        catch (ex) {
            LogIt.Error(ex);
        }
        this.setLanguage(this.language);
        this.setPageIconSource(this.faviconSource);
    }
    /**
     * @param {boolean} [$value] Set parallel processing status.
     * @returns {boolean} Returns true, if controller allows parallel processing, otherwise false.
     */
    ParallelProcessing($value) {
        return this.parallelProcessing = Property.Boolean(this.parallelProcessing, $value);
    }
    /**
     * @param {HttpRequestEventArgs} [$value] Set request event args, which should be propagated to child controllers.
     * @returns {HttpRequestEventArgs} Returns current request event args.
     */
    RequestArgs($value) {
        const value = super.RequestArgs($value);
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            const reflection = Reflection.getInstance();
            const properties = this.getProperties();
            for (const name of properties) {
                if (this.hasOwnProperty(name) && reflection.IsMemberOf(this[name], BasePanelController)) {
                    this[name].RequestArgs(value);
                }
            }
        }
        return value;
    }
    /**
     * Execute resolver implementation for asynchronous controller processing.
     * @returns {void}
     */
    Process() {
        if (!isBrowser) {
            throw new Error("Unsupported backend call of frontend controller: " + this.getClassName() +
                " from " + this.getRequest().getUri());
        }
        if ((!this.processing && !this.parallelProcessing) || this.parallelProcessing) {
            if (this.parallelProcessing && this.processing) {
                LogIt.Warning("Executed parallel processing of {0}", this.getClassName());
            }
            try {
                const renderTarget = GuiCommons.getRenderTarget();
                if (!this.browserValidator()) {
                    LogIt.Error("Unsupported browser. User Agent: " + this.getRequest().getUserAgent());
                    this.getHttpManager().ReloadTo("/ServerError/Browser", null, true);
                    this.stop();
                }
                else if (this.isRendered(renderTarget)) {
                    if (!ObjectValidator.IsEmptyOrNull(renderTarget) && renderTarget.isViewerRunner) {
                        delete renderTarget.isViewerRunner;
                        if (!ObjectValidator.IsEmptyOrNull(BaseViewer.getTestRenderTarget())) {
                            const content = ElementManager.getElement("Content", true);
                            content.appendChild(renderTarget);
                            content.removeChild(content.firstElementChild);
                            BaseViewer.getTestRenderTarget = () => {
                                return null;
                            };
                        }
                    }
                    AsyncBaseHttpController.rendered = this;
                    (new Promise(($resolve, $reject) => {
                        try {
                            let resolverStatus = false;
                            this.canResolve(($status) => {
                                resolverStatus = $status;
                            }).then(() => {
                                $resolve(resolverStatus);
                            }).catch(($ex) => {
                                $reject($ex);
                            });
                        }
                        catch (ex) {
                            $reject(ex);
                        }
                    })).then(($status) => {
                        if ($status) {
                            this.resolver();
                        }
                    }).catch((ex) => {
                        this.onError(ex).catch(($error) => {
                            LogIt.Error($error);
                        });
                    });
                }
                else if (this.resolved) {
                    this.PreparePageContent();
                    // eslint-disable-next-line prefer-spread
                    this.onSuccess.apply(this, this.getProcessArgs()).catch(async ($error) => {
                        await this.onError($error);
                    });
                }
            }
            catch (ex) {
                this.onError(ex).catch(($error) => {
                    LogIt.Error($error);
                });
            }
        }
        else {
            LogIt.Warning("Skipped parallel processing of {0}", this.getClassName());
        }
    }
    setInstanceOwner($value) {
        if (!ObjectValidator.IsEmptyOrNull($value) && $value.IsMemberOf(BasePanel)) {
            this.pageInstance = $value;
        }
    }
    setPageTitle($value) {
        this.pageTitle = Property.String(this.pageTitle, $value);
        StaticPageContentManager.Title(this.pageTitle);
    }
    setPageIconSource($value) {
        this.faviconSource = Property.String(this.faviconSource, $value);
        StaticPageContentManager.FaviconSource(this.faviconSource);
    }
    setLanguage($value) {
        this.language = Property.EnumType(this.language, $value, LanguageType);
        StaticPageContentManager.Language(this.language);
    }
    getLanguage() {
        return this.language;
    }
    loadResources() {
        this.PreparePageContent();
        this.getEventsManager().FireEvent(this.getClassName(), EventType.ON_LOAD);
    }
    isRendered($target) {
        return AsyncBaseHttpController.rendered !== this ||
            ObjectValidator.IsEmptyOrNull($target) ||
            (!ObjectValidator.IsEmptyOrNull($target) && $target.isViewerRunner);
    }
    async canResolve($resolve) {
        $resolve(true);
    }
    getProcessArgs() {
        return [this.InstanceOwner()];
    }
    resolver() {
        this.processing = true;
        this.resolved = true;
        this.getEventsManager().setEvent(this.getClassName(), EventType.ON_LOAD, async () => {
            try {
                const renderUI = ObjectValidator.IsEmptyOrNull(this.pageCache);
                const instance = this.InstanceOwner();
                let holder = GuiCommons.getRenderTarget();
                if (ObjectValidator.IsEmptyOrNull(holder)) {
                    const findHolder = async ($index = 0) => {
                        await new Promise(($resolve) => {
                            setTimeout($resolve, 250);
                        });
                        holder = GuiCommons.getRenderTarget();
                        if (ObjectValidator.IsEmptyOrNull(holder) && $index < 5) {
                            await findHolder($index + 1);
                        }
                    };
                    await findHolder();
                }
                if (!ObjectValidator.IsEmptyOrNull(holder)) {
                    if (renderUI) {
                        StaticPageContentManager.init();
                        ElementManager.setInnerHtml(holder, "");
                        this.loaderProcess = this.getEventsManager().FireAsynchronousMethod(() => {
                            this.showLoader(true);
                        }, 200);
                        await this.beforeLoad.apply(this, this.getProcessArgs()); // eslint-disable-line prefer-spread
                        await instance.Render();
                        if (!ObjectValidator.IsEmptyOrNull(holder.innerHTML)) {
                            StaticPageContentManager.isPrinted = true;
                            this.pageCache = holder.firstElementChild;
                        }
                        await this.afterLoad.apply(this, this.getProcessArgs()); // eslint-disable-line prefer-spread
                        const reflection = Reflection.getInstance();
                        const properties = this.getProperties();
                        for await (const name of properties) {
                            if (this.hasOwnProperty(name) && reflection.IsMemberOf(this[name], BasePanelController)) {
                                this[name].setParent(this);
                                this[name].RequestArgs(this.RequestArgs());
                                await this[name].Process();
                            }
                        }
                        this.getEventsManager().FireEvent(GeneralEventOwner.BODY, EventType.ON_LOAD);
                        this.getEventsManager().FireEvent(this.getClassName(), EventType.ON_SUCCESS);
                        this.getEventsManager().FireEvent(this.getClassName(), EventType.ON_COMPLETE);
                    }
                    else {
                        while (holder.childElementCount > 0) {
                            holder.removeChild(holder.firstElementChild);
                        }
                        holder.appendChild(this.pageCache);
                    }
                    this.PreparePageContent();
                    await this.onSuccess.apply(this, this.getProcessArgs()); // eslint-disable-line prefer-spread
                    if (renderUI) {
                        instance.Register();
                        if (!ObjectValidator.IsEmptyOrNull(this.loaderProcess)) {
                            clearTimeout(this.loaderProcess);
                        }
                        this.showLoader(false);
                    }
                }
                else {
                    window.location.reload();
                }
            }
            catch (ex) {
                this.getEventsManager().FireEvent(this.getClassName(), EventType.ON_ERROR);
                await this.onError(ex);
            }
            this.processing = false;
        });
        this.loadResources();
    }
    async beforeLoad($instance, ...$args) {
        // override this method for ability to prepare instance before it is loaded
    }
    async afterLoad($instance, ...$args) {
        // override this method for ability to setup instance after it is loaded
    }
    async onSuccess($instance, ...$args) {
        // override this method for ability to handle controller state after it has been successfully loaded
    }
    async onError($error) {
        LogIt.Error($error);
    }
    showLoader($value) {
        if (Loader.getInstance().getEnvironmentArgs().HtmlOutputAllowed()) {
            if ($value) {
                ElementManager.Hide(GuiCommons.getRenderTarget());
                ElementManager.Show(this.getLoaderElement());
            }
            else {
                ElementManager.Hide(this.getLoaderElement());
                ElementManager.Show(GuiCommons.getRenderTarget());
            }
        }
    }
    getRefererUrl() {
        let referer = null;
        if (this.RequestArgs().POST().KeyExists("Referer")) {
            const request = this.RequestArgs().POST().getItem("Referer");
            if (this.getHttpManager().getRequest().getUrl() !== request.getUrl()) {
                referer = request.getUrl();
            }
        }
        return referer;
    }
    getLoaderElement() {
        const element = ElementManager.getElement("PageLoader");
        if (!ObjectValidator.IsEmptyOrNull(element)) {
            this.getLoaderElement = () => {
                return element;
            };
        }
        return element;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.HttpProcessor.Resolvers.AsyncBaseHttpController", AsyncBaseHttpController);
//# sourceMappingURL=AsyncBaseHttpController.js.map