var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { AsyncHttpResolver } from "./../../../../../Io/Oidis/Commons/HttpProcessor/Resolvers/AsyncHttpResolver.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { EventType } from "../../Enums/Events/EventType.js";
import { HttpRequestConstants } from "../../Enums/HttpRequestConstants.js";
import { ViewerManager } from "../../ViewerManager.js";
import { Resolver } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
/**
 * AsyncDrawGuiObject class provides handling of requests for rendering of GUI objects.
 */
let AsyncDrawGuiObject = class AsyncDrawGuiObject extends AsyncHttpResolver {
    objectName;
    testModeEnabled;
    includeChildrenEnabled;
    childElement;
    /**
     * Set or get resolver class name or callback.
     * @param {string} [$value] Object class name in string format, which should be used by the resolver.
     * @returns {string} Returns class name of requested object for rendering.
     */
    ObjectClassName($value) {
        if (ObjectValidator.IsEmptyOrNull($value)) {
            if (!ObjectValidator.IsSet(this.objectName)) {
                this.objectName = this.RequestArgs().Url();
                this.objectName = StringUtils.Remove(this.objectName, "/" + HttpRequestConstants.TEST_MODE);
                this.objectName = StringUtils.Remove(this.objectName, "/" + HttpRequestConstants.FORCE_REFRESH);
                this.objectName = StringUtils.Substring(this.objectName, StringUtils.IndexOf(this.objectName, "async/") + 6, StringUtils.Length(this.objectName));
                this.objectName = StringUtils.Replace(this.objectName, "/", ".");
            }
        }
        else {
            this.objectName = Property.String(this.objectName, $value);
        }
        return this.objectName;
    }
    testMode() {
        if (!ObjectValidator.IsSet(this.testModeEnabled)) {
            this.testModeEnabled = StringUtils.Contains(this.getRequest().getScriptPath(), HttpRequestConstants.TEST_MODE);
        }
        return this.testModeEnabled;
    }
    includeChildren() {
        if (!ObjectValidator.IsSet(this.includeChildrenEnabled)) {
            if (this.RequestArgs().POST().KeyExists(HttpRequestConstants.HIDE_CHILDREN)) {
                this.includeChildrenEnabled = !this.RequestArgs().POST().getItem(HttpRequestConstants.HIDE_CHILDREN);
            }
            else {
                this.includeChildrenEnabled = true;
            }
        }
        return this.includeChildrenEnabled;
    }
    getChildElement() {
        if (!ObjectValidator.IsSet(this.childElement)) {
            if (this.RequestArgs().POST().KeyExists(HttpRequestConstants.ELEMENT_INSTANCE)) {
                this.childElement = this.RequestArgs().POST().getItem(HttpRequestConstants.ELEMENT_INSTANCE);
            }
            else {
                this.childElement = null;
            }
        }
        return this.childElement;
    }
    loadGuiObject() {
        const viewerManager = new ViewerManager(this.ObjectClassName(), this.getChildElement());
        viewerManager.TestModeEnabled(this.testMode());
        viewerManager.IncludeChildren(this.includeChildren());
        viewerManager.IsAsyncCallback(true);
        return viewerManager;
    }
    resolver() {
        this.getEventsManager().setEvent(ViewerManager.ClassName(), EventType.ON_COMPLETE, ($eventArgs) => {
            if ($eventArgs.AsyncCallback()) {
                const view = $eventArgs.Result();
                if (!ObjectValidator.IsEmptyOrNull(view)) {
                    this.RequestArgs().Result(view.Show(this.getEnvelopEOL()));
                    this.RequestArgs().POST().Add($eventArgs.ChildElement(), HttpRequestConstants.ELEMENT_INSTANCE);
                    this.RequestArgs().POST().Add(!$eventArgs.IncludeChildren(), HttpRequestConstants.HIDE_CHILDREN);
                    this.success();
                }
                else {
                    this.RequestArgs().Result("<h1>Viewer \"" + this.ObjectClassName() + "\" instance has not been found!</h1>");
                    this.error();
                }
            }
        });
        this.loadGuiObject().Process();
    }
    getEnvelopEOL() {
        if (this.RequestArgs().POST().KeyExists(HttpRequestConstants.ELEMENT_INSTANCE)) {
            return this.getChildElement().outputEndOfLine;
        }
        return "";
    }
};
AsyncDrawGuiObject = __decorate([
    Resolver("/async/**/*")
], AsyncDrawGuiObject);
export { AsyncDrawGuiObject };
globalThis.RegisterClass("Io.Oidis.Gui.HttpProcessor.Resolvers.AsyncDrawGuiObject", AsyncDrawGuiObject);
//# sourceMappingURL=AsyncDrawGuiObject.js.map