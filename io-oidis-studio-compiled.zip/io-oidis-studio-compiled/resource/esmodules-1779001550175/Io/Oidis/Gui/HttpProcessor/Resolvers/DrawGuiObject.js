var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BuilderConnector } from "./../../../../../Io/Oidis/Commons/Connectors/BuilderConnector.js";
import { ExceptionsManager } from "./../../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { BaseHttpResolver } from "./../../../../../Io/Oidis/Commons/HttpProcessor/Resolvers/BaseHttpResolver.js";
import { Convert } from "./../../../../../Io/Oidis/Commons/Utils/Convert.js";
import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { isBrowser } from "./../../../../../Io/Oidis/Commons/Utils/EnvironmentHelper.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
import { Reflection } from "./../../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { BaseViewer as BootstrapBaseViewer } from "../../Bootstrap/Primitives/BaseViewer.js";
import { GuiCommons } from "../../Bootstrap/Primitives/GuiCommons.js";
import { EventType } from "../../Enums/Events/EventType.js";
import { GeneralEventOwner } from "../../Enums/Events/GeneralEventOwner.js";
import { HttpRequestConstants } from "../../Enums/HttpRequestConstants.js";
import { KeyMap } from "../../Enums/KeyMap.js";
import { ElementEventsManager } from "../../Events/ElementEventsManager.js";
import { GuiObjectManager } from "../../GuiObjectManager.js";
import { BaseViewer } from "../../Primitives/BaseViewer.js";
import { ElementOffset } from "../../Structures/ElementOffset.js";
import { Size } from "../../Structures/Size.js";
import { ElementManager } from "../../Utils/ElementManager.js";
import { PageContentBundles, PageContentBundleType } from "../../Utils/PageContentBundles.js";
import { StaticPageContentManager } from "../../Utils/StaticPageContentManager.js";
import { TextSelectionManager } from "../../Utils/TextSelectionManager.js";
import { WindowManager } from "../../Utils/WindowManager.js";
import { ViewerCacheManager } from "../../ViewerCacheManager.js";
import { ViewerManager } from "../../ViewerManager.js";
import { Resolver, ResolverType } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
/**
 * DrawGuiObject class provides handling of requests for rendering of GUI objects.
 */
let DrawGuiObject = class DrawGuiObject extends BaseHttpResolver {
    forceRefreshLinkEvents;
    viewCodeLinkEvents;
    echoOutputLinkEvents;
    echoClearLinkEvents;
    cacheLinkEvents;
    backToIndexLinkEvents;
    cacheGeneratorEvents;
    objectName;
    guiManager;
    testModeEnabled;
    forceRefresh;
    echoOutputId;
    viewerManager;
    constructor() {
        super();
        this.forceRefreshLinkEvents = new ElementEventsManager("ForceRefreshLink");
        this.viewCodeLinkEvents = new ElementEventsManager("ViewCodeLink");
        this.echoOutputLinkEvents = new ElementEventsManager("EchoOutputLink");
        this.cacheLinkEvents = new ElementEventsManager("CacheLink");
        this.cacheGeneratorEvents = new ElementEventsManager("CacheGeneratorLink");
        this.backToIndexLinkEvents = new ElementEventsManager("BackToIndexLink");
        this.echoOutputId = "DeveloperCorner_EchoOutput";
        this.guiManager = GuiObjectManager.getInstanceSingleton();
    }
    /**
     * @param {string} [$value] Object class name in string format, which should be used by the resolver.
     * @returns {string} Returns class name of requested object for rendering.
     */
    ObjectClassName($value) {
        if (ObjectValidator.IsEmptyOrNull($value)) {
            if (!ObjectValidator.IsSet(this.objectName)) {
                this.objectName = this.getRequest().getScriptPath();
                this.objectName = StringUtils.Remove(this.objectName, "/" + HttpRequestConstants.TEST_MODE);
                this.objectName = StringUtils.Remove(this.objectName, "/" + HttpRequestConstants.FORCE_REFRESH);
                this.objectName = StringUtils.Substring(this.objectName, StringUtils.IndexOf(this.objectName, "web/") + 4, StringUtils.Length(this.objectName));
                this.objectName = StringUtils.Replace(this.objectName, "/", ".");
            }
        }
        else {
            this.objectName = Property.String(this.objectName, $value);
        }
        return this.objectName;
    }
    /**
     * Execute resolver implementation.
     * @returns {void}
     */
    Process() {
        if (!isBrowser) {
            ExceptionsManager.HandleException(new Error("Unsupported backend call of frontend controller: " + this.getClassName() +
                " from " + this.getRequest().getUri()));
        }
        let bootstrapRender = false;
        const reflection = Reflection.getInstance();
        const viewerClass = reflection.getClass(this.ObjectClassName());
        if (!ObjectValidator.IsEmptyOrNull(viewerClass)) {
            const viewer = new viewerClass();
            if (reflection.IsMemberOf(viewer, BootstrapBaseViewer)) {
                bootstrapRender = true;
            }
        }
        if (!bootstrapRender) {
            Echo.ClearAll();
            this.resolver();
        }
        else {
            this.bootstrapResolver();
        }
    }
    bootstrapResolver() {
        try {
            const contentTargetId = "PageContentHolder";
            const testTargetId = "TestContentSideBar";
            if (!ElementManager.Exists(GuiCommons.getRenderTarget()) ||
                (this.testMode() && !ElementManager.Exists(BootstrapBaseViewer.getTestRenderTarget())) ||
                (!this.testMode() && ElementManager.Exists(BootstrapBaseViewer.getTestRenderTarget()))) {
                StaticPageContentManager.Clear();
                PageContentBundles.getInstance().Apply(PageContentBundleType.FONTAWESOME);
                if (!this.testMode()) {
                    StaticPageContentManager.BodyAppend(`<section data-oidis-bind="${contentTargetId}" style="display: none;"></section>`);
                }
                else {
                    StaticPageContentManager.BodyAppend(`
                        <div class="row g-0" style="height: 100%;">
                            <div class="col">
                                <button class="btn btn-primary float-start" type="button" data-bs-target="#${testTargetId}" data-bs-toggle="offcanvas" style="width: 40px;height: 100%;padding: 0;border-radius: 0;background: rgb(165,171,177);border-width: 0;">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" class="bi bi-collection-play" style="font-size: 30px; pointer-events: none;">
                                        <path fill-rule="evenodd" d="M14.5 13.5h-13A.5.5 0 0 1 1 13V6a.5.5 0 0 1 .5-.5h13a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5zm-13 1A1.5 1.5 0 0 1 0 13V6a1.5 1.5 0 0 1 1.5-1.5h13A1.5 1.5 0 0 1 16 6v7a1.5 1.5 0 0 1-1.5 1.5h-13zM2 3a.5.5 0 0 0 .5.5h11a.5.5 0 0 0 0-1h-11A.5.5 0 0 0 2 3zm2-2a.5.5 0 0 0 .5.5h7a.5.5 0 0 0 0-1h-7A.5.5 0 0 0 4 1z"></path>
                                        <path fill-rule="evenodd" d="M6.258 6.563a.5.5 0 0 1 .507.013l4 2.5a.5.5 0 0 1 0 .848l-4 2.5A.5.5 0 0 1 6 12V7a.5.5 0 0 1 .258-.437z"></path>
                                    </svg>
                                </button>
                                <div style="height: 100%;"><section data-oidis-bind="${contentTargetId}" style="display: none;"></section></div>
                                <div tabindex="-1" class="offcanvas offcanvas-start" id="${testTargetId}" style="width: 50%;">
                                    <div class="offcanvas-header">
                                        <h5 class="offcanvas-title">Test results</h5>
                                        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                                    </div>
                                    <div class="offcanvas-body" data-oidis-bind="TestContentHolder"></div>
                                </div>
                            </div>
                        </div>`);
                }
                if (ObjectValidator.IsEmptyOrNull(globalThis.bootstrap)) {
                    PageContentBundles.getInstance().Apply(PageContentBundleType.BOOTSTRAP);
                }
                StaticPageContentManager.Draw();
                const target = ElementManager.getElement(contentTargetId, true);
                GuiCommons.getRenderTarget = () => {
                    return target;
                };
                const testTarget = this.testMode() ? ElementManager.getElement(testTargetId, true) : null;
                BootstrapBaseViewer.getTestRenderTarget = () => {
                    return testTarget;
                };
            }
            ElementManager.setInnerHtml(GuiCommons.getRenderTarget(), "");
            GuiCommons.getRenderTarget().isViewerRunner = true;
            const viewerClass = Reflection.getInstance().getClass(this.ObjectClassName());
            const viewer = new viewerClass();
            let args;
            if (ObjectValidator.IsEmptyOrNull(viewerClass.getTestViewerArgs)) {
                args = viewerClass.getTestViewerArgs();
            }
            viewer.TestModeEnabled(this.testMode());
            viewer.ViewerArgs(args);
            viewer.PrepareImplementation();
            viewer.getInstance().Render();
            ElementManager.Hide(ElementManager.getElement("PageLoader"));
            ElementManager.Show(GuiCommons.getRenderTarget());
            if (!this.testModeEnabled) {
                StaticPageContentManager.BodyAppend(viewer.Show());
            }
            else {
                ElementManager.setInnerHtml("TestContentHolder", viewer.Show());
            }
        }
        catch (ex) {
            LogIt.Error(ex.message);
            StaticPageContentManager.BodyAppend("<h1>Viewer \"" + this.ObjectClassName() + "\" source file has not been found " +
                "or it does not implement correct interface!</h1>");
        }
    }
    testMode() {
        if (!ObjectValidator.IsSet(this.testModeEnabled)) {
            this.testModeEnabled = StringUtils.Contains(this.getRequest().getScriptPath(), HttpRequestConstants.TEST_MODE);
        }
        return this.testModeEnabled;
    }
    refresh() {
        if (!ObjectValidator.IsSet(this.forceRefresh)) {
            this.forceRefresh = StringUtils.Contains(this.getRequest().getScriptPath(), HttpRequestConstants.FORCE_REFRESH);
        }
        return this.forceRefresh;
    }
    includeChildren() {
        return true;
    }
    navigator() {
        let url;
        let output = "               ";
        const separator = StringUtils.NewLine(false) + "               " + " | ";
        if (!this.testMode()) {
            output +=
                "<a href=\"#" + this.createLink("") + "/" + HttpRequestConstants.TEST_MODE + "\">Test mode</a>";
        }
        else {
            url = this.createLink("");
            url = StringUtils.Remove(url, "/" + HttpRequestConstants.TEST_MODE);
            output += "<a href=\"#" + url + "\">Normal mode</a>";
        }
        output +=
            separator +
                "<a id=\"" + this.viewCodeLinkEvents.getOwner() + "\" " +
                "href=\"#" + this.createLink("") + "\">View HTML Code</a>" +
                separator +
                "<a id=\"" + this.echoOutputLinkEvents.getOwner() + "\" " +
                "href=\"#" + this.createLink("") + "\">Echo output</a>" +
                separator +
                "<a id=\"" + this.cacheLinkEvents.getOwner() + "\" " +
                "href=\"#" + this.createLink("") + "\">Cache</a>" +
                separator +
                "<a id=\"" + this.forceRefreshLinkEvents.getOwner() + "\" " +
                "href=\"#" + this.createLink("") + "\">Force refresh</a>" +
                separator +
                "<a id=\"" + this.backToIndexLinkEvents.getOwner() + "\" " +
                "href=\"#" + this.createLink("") + "\">Back to index</a>";
        return output;
    }
    developerCorner() {
        const id = "DeveloperCorner";
        const distanceId = "DeveloperCorner_Distance";
        const contentId = "DeveloperCorner_Content";
        const bodyId = "DeveloperCorner_Body";
        const viewCodeId = "DeveloperCorner_ViewCode";
        const bodyEvents = new ElementEventsManager(id);
        const contentEvents = new ElementEventsManager(contentId);
        const navigator = this.navigator();
        const EOL = StringUtils.NewLine(false);
        if (!ObjectValidator.IsEmptyOrNull(navigator)) {
            bodyEvents.setOnMouseOver(() => {
                ElementManager.Show(distanceId);
                ElementManager.Show(contentId);
            });
            contentEvents.setOnDoubleClick(() => {
                TextSelectionManager.Clear();
                ElementManager.setInnerHtml(viewCodeId, "");
                ElementManager.Hide(bodyId);
                ElementManager.Hide(distanceId);
                ElementManager.Hide(contentId);
            });
            this.forceRefreshLinkEvents.setOnClick(($args) => {
                $args.PreventDefault();
                this.loadGuiObject().ClearCache();
                this.getHttpManager().Refresh();
            });
            this.viewCodeLinkEvents.setOnClick(($args, $manager) => {
                $args.PreventDefault();
                const hovered = $manager.getHovered();
                if (!ObjectValidator.IsEmptyOrNull(hovered)) {
                    $manager.setHovered($manager.getHovered(), false);
                }
                ElementManager.Show(distanceId);
                ElementManager.Show(contentId);
                ElementManager.setInnerHtml(viewCodeId, "");
                ElementManager.Hide(this.echoOutputId + "_Envelop");
                ElementManager.Show(viewCodeId);
                ElementManager.setInnerHtml(viewCodeId, WindowManager.ViewHTMLCode());
                ElementManager.Show(bodyId);
                if (ElementManager.Exists(viewCodeId)) {
                    const codes = document.getElementById(viewCodeId).getElementsByTagName("pre");
                    if (codes.length !== 0) {
                        const htmlCode = codes[0];
                        if (document.getElementById(contentId).offsetWidth > htmlCode.offsetWidth) {
                            ElementManager.setWidth(htmlCode, htmlCode.parentElement.offsetWidth);
                        }
                        const contentHeight = htmlCode.parentElement.offsetHeight;
                        const contentOffset = ElementManager.getAbsoluteOffset(htmlCode.parentElement).Top() + 50;
                        const windowHeight = WindowManager.getSize().Height();
                        if (contentHeight + contentOffset > windowHeight) {
                            ElementManager.setHeight(htmlCode, windowHeight - contentOffset);
                        }
                    }
                }
            });
            this.echoOutputLinkEvents.setOnClick(($args, $manager) => {
                $args.PreventDefault();
                const hovered = $manager.getHovered();
                if (!ObjectValidator.IsEmptyOrNull(hovered)) {
                    $manager.setHovered($manager.getHovered(), false);
                }
                ElementManager.Show(distanceId);
                ElementManager.Show(contentId);
                ElementManager.Hide(viewCodeId);
                ElementManager.Show(this.echoOutputId + "_Envelop");
                ElementManager.Show(bodyId);
                const contentHeight = ElementManager.getElement(this.echoOutputId).offsetHeight;
                const contentOffset = ElementManager.getAbsoluteOffset(this.echoOutputId).Top() + 35;
                const windowHeight = WindowManager.getSize().Height();
                if (contentHeight + contentOffset > windowHeight) {
                    ElementManager.setHeight(this.echoOutputId, windowHeight - contentOffset);
                }
            });
            this.echoClearLinkEvents = new ElementEventsManager(this.echoOutputId + "_Clear");
            this.echoClearLinkEvents.setOnClick(($args) => {
                $args.PreventDefault();
                if (!ObjectValidator.IsEmptyOrNull(Echo.getStream())) {
                    ElementManager.setInnerHtml(this.echoOutputId, "");
                    ElementManager.ClearCssProperty(this.echoOutputId, "height");
                    Echo.ClearAll();
                }
            });
            this.backToIndexLinkEvents.setOnClick(($args) => {
                $args.PreventDefault();
                this.getHttpManager().ReloadTo("/web/");
            });
            this.getEventsManager().setEvent(ViewerManager.ClassName(), EventType.BEFORE_LOAD, () => {
                this.forceRefreshLinkEvents.Subscribe();
                this.viewCodeLinkEvents.Subscribe();
                this.echoOutputLinkEvents.Subscribe();
                this.echoClearLinkEvents.Subscribe();
                this.backToIndexLinkEvents.Subscribe();
                bodyEvents.Subscribe();
                contentEvents.Subscribe();
                ElementManager.setHeight(distanceId, ElementManager.getElement(id).offsetHeight);
            });
            const visibility = this.testMode() ? "block" : "none";
            return "<div guiType=\"DeveloperCorner\" class=\"DeveloperCorner\">" + EOL +
                "   <div id=\"" + distanceId + "\" class=\"Distance\" " +
                "style=\"display: " + visibility + "\"></div>" + EOL +
                "   <div id=\"" + id + "\" class=\"Envelop\">" + EOL +
                "       <div id=\"" + contentId + "\" class=\"Content\" style=\"display: " + visibility + "\">" + EOL +
                "           <div class=\"Links\">" + EOL + navigator + EOL +
                "           </div>" + EOL +
                "           <div class=\"Info\">" + EOL +
                "               <div class=\"Viewer\">" + this.ObjectClassName() + "</div>" + EOL +
                StringUtils.Format("               <div class=\"Process\">Page was generated in " +
                    "<span id=\"DeveloperCorner_ProcessTime\">{0}</span> seconds.</div>" + EOL, Convert.TimeToSeconds(this.getHttpManager().getProcessTime())) +
                "           <div style=\"clear: both;\"></div>" + EOL +
                "           </div>" + EOL +
                "           <div id=\"" + bodyId + "\" class=\"Debug\">" + EOL +
                "           <div id=\"" + viewCodeId + "\" class=\"ViewCode\"></div>" + EOL +
                "           <div id=\"" + this.echoOutputId + "_Envelop\">" + EOL +
                "               <div id=\"" + this.echoOutputId + "_Clear\" class=\"Link\">Clear output</div>" + EOL +
                "               <div id=\"" + this.echoOutputId + "\" class=\"Echo\">" +
                "Nothing has been printed by Echo yet.</div>" + EOL +
                "           </div>" + EOL +
                "           </div>" + EOL +
                "       </div>" + EOL +
                "   </div>" + EOL +
                "</div>";
        }
        else {
            return "<div guiType=\"DeveloperCorner\" class=\"DeveloperCorner\">" + EOL +
                "    <div id=\"" + bodyId + "\" class=\"Debug\">" + EOL +
                "       <div id=\"" + this.echoOutputId + "\" class=\"Echo\"></div>" + EOL +
                "    </div>" + EOL +
                "</div>";
        }
    }
    contextMenu() {
        this.getEventsManager().setEvent(ViewerManager.ClassName(), EventType.BEFORE_LOAD, () => {
            this.cacheGeneratorEvents.Subscribe("DeveloperCorner_ContextMenu_GenerateCache");
            this.viewCodeLinkEvents.Subscribe("DeveloperCorner_ContextMenu_ViewCode");
            this.backToIndexLinkEvents.Subscribe("DeveloperCorner_ContextMenu_BackToIndex");
        });
        const EOL = StringUtils.NewLine(false);
        return "<div guiType=\"DeveloperCorner\" class=\"DeveloperCorner\">" + EOL +
            "   <div id=\"DeveloperCorner_ContextMenu\" class=\"ContextMenu\">" + EOL +
            "       <div id=\"DeveloperCorner_ContextMenu_ViewCode\" class=\"Link\">View HTML Code</div>" + EOL +
            "       <div id=\"DeveloperCorner_ContextMenu_GenerateCache\" class=\"Link\">Generate Cache</div>" + EOL +
            "       <div id=\"DeveloperCorner_ContextMenu_BackToIndex\" class=\"Link\">Back to index</div>" + EOL +
            "   </div>" + EOL +
            "</div>";
    }
    builderContent() {
        if (this.getRequest().IsPlugin() && !this.getRequest().getUrlArgs().KeyExists(HttpRequestConstants.DESIGNER)) {
            const backgroundId = "DeveloperCorner_Builder_Background";
            const progressId = "DeveloperCorner_Builder_Progress";
            WindowManager.getEvents().setOnLoad(() => {
                const connector = BuilderConnector.Connect();
                connector.getEvents().OnError(($args) => {
                    document.getElementById(this.echoOutputLinkEvents.getOwner()).click();
                    Echo.Println($args.Message());
                });
                const updateMessagePosition = () => {
                    if (ElementManager.IsVisible(backgroundId)) {
                        const size = WindowManager.getSize();
                        ElementManager.setSize(backgroundId, size.Width(), size.Height());
                        const messageSize = new Size(progressId, true);
                        const position = new ElementOffset((size.Height() - messageSize.Height()) / 2, (size.Width() - messageSize.Width()) / 2);
                        ElementManager.setPosition(progressId, position);
                    }
                };
                WindowManager.getEvents().setOnResize(updateMessagePosition);
                const errorHandler = ($message) => {
                    ElementManager.Hide(backgroundId);
                    ElementManager.Hide(progressId);
                    document.getElementById(this.echoOutputLinkEvents.getOwner()).click();
                    Echo.Println($message);
                };
                connector.getEvents().OnStart(() => {
                    connector.getEvents().OnBuildStart(() => {
                        ElementManager.Show(backgroundId);
                        ElementManager.Show(progressId);
                        ElementManager.setInnerHtml(progressId, "Build in progress, please wait ...");
                        updateMessagePosition();
                    });
                    connector.getEvents().OnFail(errorHandler);
                    connector.getEvents().OnWarning(errorHandler);
                });
            });
            const EOL = StringUtils.NewLine(false);
            return "<div guiType=\"DeveloperCorner\" class=\"DeveloperCorner\">" + EOL +
                "   <div id=\"DeveloperCorner_Builder\" class=\"Builder\">" + EOL +
                "       <div id=\"" + backgroundId + "\" class=\"Background\"></div>" + EOL +
                "       <div id=\"" + progressId + "\" class=\"Progress\"></div>" + EOL +
                "   </div>" + EOL +
                "</div>";
        }
        return "";
    }
    loadGuiObject() {
        if (!ObjectValidator.IsSet(this.viewerManager)) {
            this.viewerManager = new ViewerManager(this.ObjectClassName());
            this.viewerManager.ReloadCacheEnabled(this.refresh());
            this.viewerManager.TestModeEnabled(this.testMode());
            this.viewerManager.IncludeChildren(this.includeChildren());
        }
        return this.viewerManager;
    }
    resolver() {
        WindowManager.getEvents().setOnRightClick(($eventArgs) => {
            $eventArgs.PreventDefault();
            let top = WindowManager.getMouseY($eventArgs.NativeEventArgs(), true) + 15;
            let left = WindowManager.getMouseX($eventArgs.NativeEventArgs(), true) + 15;
            this.getEventsManager().FireAsynchronousMethod(() => {
                ElementManager.Show("DeveloperCorner_ContextMenu");
                const menuSize = new Size("DeveloperCorner_ContextMenu");
                const windowSize = WindowManager.getSize();
                if (top + menuSize.Height() > windowSize.Height()) {
                    top = windowSize.Height() - menuSize.Height() - 20;
                }
                if (left + menuSize.Width() > windowSize.Width()) {
                    left = windowSize.Width() - menuSize.Width() - 20;
                }
                ElementManager.setCssProperty("DeveloperCorner_ContextMenu", "top", top);
                ElementManager.setCssProperty("DeveloperCorner_ContextMenu", "left", left);
            }, 100);
        });
        WindowManager.getEvents().setOnClick(() => {
            if (ElementManager.IsVisible("DeveloperCorner_ContextMenu")) {
                ElementManager.Hide("DeveloperCorner_ContextMenu");
            }
        });
        WindowManager.getEvents().setOnRequest(() => {
            this.getHttpManager().Refresh();
        });
        if (ObjectValidator.IsSet(window.onhashchange)) {
            window.onhashchange = () => {
                this.getHttpManager().Refresh();
            };
        }
        WindowManager.getEvents().setOnKeyDown(($eventArgs, $manager) => {
            if ($eventArgs.getKeyCode() === KeyMap.BACKSPACE && $manager.getActive().IsEmpty()) {
                $eventArgs.PreventDefault();
                this.getHttpManager().ReloadTo("/web/");
            }
        });
        let progressIndex = 0;
        const loadingProgressHandler = () => {
            if (progressIndex < 100) {
                progressIndex++;
                ElementManager.setInnerHtml("DrawGuiContentLoader_Progress", "Progress: " + progressIndex + "%");
            }
        };
        this.getEventsManager().setEvent(ViewerManager.ClassName(), EventType.ON_CHANGE, loadingProgressHandler);
        this.getEventsManager().setEvent(BaseViewer.ClassName(), EventType.ON_CHANGE, loadingProgressHandler);
        StaticPageContentManager.Clear();
        StaticPageContentManager.Title("Oidis - Developer Corner");
        StaticPageContentManager.BodyAppend(this.developerCorner() + StringUtils.NewLine(false));
        StaticPageContentManager.BodyAppend(this.builderContent() + StringUtils.NewLine(false));
        StaticPageContentManager.BodyAppend(this.contextMenu() + StringUtils.NewLine(false) + StringUtils.NewLine(false));
        StaticPageContentManager.BodyAppend("<div id=\"DrawGuiContentLoader\" " +
            "style=\"display: block; position: relative; top: 100px; left: 100px; float: left;\">" + StringUtils.NewLine(false) +
            "   <h1>Loading, please wait ...</h1>" + StringUtils.NewLine(false) +
            "   <div id=\"DrawGuiContentLoader_Progress\"></div>" + StringUtils.NewLine(false) +
            "</div>");
        StaticPageContentManager.Draw();
        ElementManager.setClassName(ElementManager.getElement("Content", true), "Content DrawGuiObject");
        this.getEventsManager().FireEvent(ViewerManager.ClassName(), EventType.BEFORE_LOAD, false);
        const pageSize = WindowManager.getSize();
        const loaderSize = new Size("DrawGuiContentLoader", true);
        ElementManager.setCssProperty("DrawGuiContentLoader", "top", (pageSize.Height() - loaderSize.Height()) / 2);
        ElementManager.setCssProperty("DrawGuiContentLoader", "left", (pageSize.Width() - loaderSize.Width()) / 2);
        this.cacheGeneratorEvents.setOnClick(($args) => {
            $args.PreventDefault();
            document.getElementById(this.echoOutputLinkEvents.getOwner()).click();
            document.getElementById(this.echoClearLinkEvents.getOwner()).click();
            Echo.Println("Generating cache, please wait...");
            const startTime = new Date().getTime();
            this.getEventsManager().setEvent(ViewerCacheManager.ClassName(), EventType.ON_CHANGE, () => {
                if ((new Date().getTime() - startTime) % 100 === 0) {
                    Echo.Print(".");
                }
            });
            this.loadGuiObject().getCache(() => {
                const cacheReport = "Process time: " + Convert.TimeToSeconds(new Date().getTime() - startTime) + " seconds" +
                    StringUtils.NewLine() +
                    this.loadGuiObject().ToString();
                this.loadGuiObject().getCacheRawData();
                Echo.Println("Cache has been created. " +
                    "<span class=\"Link\" style=\"float: none; clear: none;\" onclick=\"" +
                    "document.getElementById('GeneratedCacheDetails').style.display==='block'?" +
                    "document.getElementById('GeneratedCacheDetails').style.display='none':" +
                    "document.getElementById('GeneratedCacheDetails').style.display='block';\">" +
                    "Show/Hide details</span>" +
                    "<div id=\"GeneratedCacheDetails\" style=\"display: none;\">" + cacheReport + "</div>");
            });
        });
        const cleanupPageContent = () => {
            if (!ObjectValidator.IsEmptyOrNull(this.echoOutputId) && ElementManager.Exists(this.echoOutputId)) {
                const stream = document.createElement("span");
                stream.innerHTML = Echo.getStream();
                const nodes = document.body.getElementsByTagName("span");
                let child;
                let attributeValue;
                const attributeKey = "guitype";
                let index;
                for (index = 0; index < nodes.length; index++) {
                    child = nodes[index];
                    if (child.nodeType === 1 && ObjectValidator.IsSet(child.attributes[attributeKey])) {
                        attributeValue = ObjectValidator.IsSet(child.attributes[attributeKey].value) ?
                            child.attributes[attributeKey].value : child.attributes[attributeKey].nodeValue;
                        if (attributeValue === "HtmlAppender" &&
                            StringUtils.Contains(stream.innerHTML, child.innerHTML) &&
                            child.parentElement.id !== this.echoOutputId) {
                            child.parentElement.removeChild(child);
                        }
                    }
                }
            }
        };
        this.getEventsManager().setEvent(ViewerManager.ClassName(), EventType.ON_COMPLETE, ($eventArgs) => {
            if (!$eventArgs.AsyncCallback()) {
                ElementManager.Hide("DrawGuiContentLoader");
                if (!ObjectValidator.IsEmptyOrNull($eventArgs.Result())) {
                    if ($eventArgs.Result().IsTypeOf(ViewerCacheManager)) {
                        StaticPageContentManager.BodyAppend($eventArgs.Result().Show() + StringUtils.NewLine(false));
                    }
                    else {
                        const view = $eventArgs.Result();
                        if (view.IsCached()) {
                            ElementManager.setClassName("DeveloperCorner", "Envelop Cached");
                        }
                        else {
                            if (!ObjectValidator.IsEmptyOrNull(view.getInstance())) {
                                view.getInstance().getEvents().setOnComplete(cleanupPageContent);
                            }
                            StaticPageContentManager.BodyAppend(view.Show() + StringUtils.NewLine(false));
                        }
                        this.cacheLinkEvents.setOnClick(($args) => {
                            $args.PreventDefault();
                            document.getElementById(this.echoOutputLinkEvents.getOwner()).click();
                            document.getElementById(this.echoClearLinkEvents.getOwner()).click();
                            const cacheInfoEvents = new ElementEventsManager("CacheInfoLink");
                            Echo.Println("<a id=\"" + cacheInfoEvents.getOwner() + "\" " +
                                "href=\"#" + this.createLink("") + "\">Show cache info</a>");
                            Echo.Println("<a id=\"" + this.cacheGeneratorEvents.getOwner() + "\" " +
                                "href=\"#" + this.createLink("") + "\">Generate cache</a>");
                            cacheInfoEvents.setOnClick(($args) => {
                                $args.PreventDefault();
                                document.getElementById(this.echoClearLinkEvents.getOwner()).click();
                                Echo.Printf(this.loadGuiObject());
                            });
                            cacheInfoEvents.Subscribe();
                            this.cacheGeneratorEvents.Subscribe();
                        });
                        this.cacheLinkEvents.Subscribe();
                    }
                }
                else {
                    StaticPageContentManager.BodyAppend("<h1>Viewer \"" + this.ObjectClassName() + "\" source file has not been found " +
                        "or it does not implement IBaseViewer interface!</h1>");
                }
                if (!ObjectValidator.IsEmptyOrNull(this.echoOutputId) && ElementManager.Exists(this.echoOutputId)) {
                    cleanupPageContent();
                    const stream = Echo.getStream();
                    if (!ObjectValidator.IsEmptyOrNull(stream)) {
                        ElementManager.setInnerHtml(this.echoOutputId, "");
                    }
                    Echo.Init(this.echoOutputId, true);
                    Echo.Print(stream);
                }
                ElementManager.setInnerHtml("DeveloperCorner_ProcessTime", Convert.TimeToSeconds(this.getHttpManager().getProcessTime()).toString());
                this.getEventsManager().FireEvent(GeneralEventOwner.BODY, EventType.ON_LOAD);
            }
        });
        this.loadGuiObject().Process();
    }
};
DrawGuiObject = __decorate([
    Resolver("/web/**/*", { type: ResolverType.FRONTEND_ONLY }),
    __metadata("design:paramtypes", [])
], DrawGuiObject);
export { DrawGuiObject };
globalThis.RegisterClass("Io.Oidis.Gui.HttpProcessor.Resolvers.DrawGuiObject", DrawGuiObject);
//# sourceMappingURL=DrawGuiObject.js.map