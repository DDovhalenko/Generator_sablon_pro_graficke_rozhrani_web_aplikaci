/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { AsyncHttpResolver } from "./../../../../../Io/Oidis/Commons/HttpProcessor/Resolvers/AsyncHttpResolver.js";
import { PersistenceFactory } from "./../../../../../Io/Oidis/Commons/PersistenceApi/PersistenceFactory.js";
import { ArrayList } from "./../../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { PersistenceType } from "../../Enums/PersistenceType.js";
import { FormsObject } from "../../Primitives/FormsObject.js";
/**
 * PersistenceManager class provides automated store of UI state based on user interaction
 */
export class PersistenceManager extends AsyncHttpResolver {
    resolver() {
        const data = FormsObject.CollectValues();
        const addValues = new ArrayList();
        const removeValues = new ArrayList();
        const addErrors = new ArrayList();
        const removeErrors = new ArrayList();
        data.foreach(($formElement) => {
            if (!ObjectValidator.IsEmptyOrNull($formElement.Value())) {
                addValues.Add($formElement.Value(), $formElement.Id());
            }
            else {
                removeValues.Add($formElement.Id());
            }
            if ($formElement.ErrorFlag()) {
                addErrors.Add($formElement.ErrorFlag(), $formElement.Id());
            }
            else {
                removeErrors.Add($formElement.Id());
            }
        });
        PersistenceFactory.getPersistence(PersistenceType.FORM_VALUES).Variable(addValues);
        PersistenceFactory.getPersistence(PersistenceType.FORM_VALUES).Destroy(removeValues);
        PersistenceFactory.getPersistence(PersistenceType.ERROR_FLAGS).Variable(addErrors);
        PersistenceFactory.getPersistence(PersistenceType.ERROR_FLAGS).Destroy(removeErrors);
        this.success();
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.HttpProcessor.Resolvers.PersistenceManager", PersistenceManager);
//# sourceMappingURL=PersistenceManager.js.map