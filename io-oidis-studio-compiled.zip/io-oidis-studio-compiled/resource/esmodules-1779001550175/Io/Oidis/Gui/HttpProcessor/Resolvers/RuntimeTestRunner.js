var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "./../../../../../Io/Oidis/Commons/Enums/Events/EventType.js";
import { GeneralEventOwner } from "./../../../../../Io/Oidis/Commons/Enums/Events/GeneralEventOwner.js";
import { RuntimeTestRunner as Parent } from "./../../../../../Io/Oidis/Commons/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Reflection } from "./../../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { HttpRequestConstants } from "../../Enums/HttpRequestConstants.js";
import { GuiObjectManager } from "../../GuiObjectManager.js";
import { Loader } from "../../Loader.js";
import { BaseViewer } from "../../Primitives/BaseViewer.js";
import { ElementManager } from "../../Utils/ElementManager.js";
import { StaticPageContentManager } from "../../Utils/StaticPageContentManager.js";
import { WindowManager } from "../../Utils/WindowManager.js";
import { Resolver, ResolverScope } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
/**
 * RuntimeTestRunner class provides handling of unit tests at runtime.
 */
let RuntimeTestRunner = class RuntimeTestRunner extends Parent {
    /**
     * @param {IClassName} [$className] Specify class name from, which should be created the runtime unit test link.
     * @returns {string} Returns link in string format, which can be used for resolver registration or as runtime callback.
     */
    static CreateLink($className) {
        if (!ObjectValidator.IsSet($className)) {
            $className = this; // eslint-disable-line @typescript-eslint/no-this-alias
        }
        if (ObjectValidator.IsSet($className.ClassName)) {
            return "#" + Loader.getInstance().getHttpManager().CreateLink("/" + HttpRequestConstants.RUNTIME_TEST + "/" + StringUtils.Replace($className.ClassName(), ".", "/"));
        }
        return Loader.getInstance().getHttpManager().CreateLink("");
    }
    /**
     * @returns {string} Returns link, which can be used for resolver registration or invoke by link element.
     */
    static CallbackLink() {
        return this.CreateLink();
    }
    /**
     * Execute resolver implementation.
     * @returns {void}
     */
    Process() {
        Echo.ClearAll();
        this.resolver();
    }
    resolver() {
        StaticPageContentManager.Clear();
        StaticPageContentManager.Title("Oidis - Unit Test");
        StaticPageContentManager.Draw();
        this.getEvents().setOnSuiteStart(() => {
            ElementManager.setClassName(document.body, "RuntimeTest");
        });
        const autoScrollHandler = () => {
            WindowManager.ScrollToBottom();
        };
        this.getEvents().setOnTestCaseEnd(autoScrollHandler);
        this.getEvents().setOnSuiteEnd(autoScrollHandler);
        let testName = this.getRequest().getScriptPath();
        let executeParent = true;
        if (StringUtils.Contains(testName, HttpRequestConstants.RUNTIME_TEST)) {
            testName = StringUtils.Substring(testName, StringUtils.IndexOf(testName, HttpRequestConstants.RUNTIME_TEST + "/") + 12, StringUtils.Length(testName));
            testName = StringUtils.Replace(testName, "/", ".");
            if (testName !== this.getClassName()) {
                const reflect = Reflection.getInstance();
                const testClass = reflect.getClass(testName);
                if (!ObjectValidator.IsEmptyOrNull(testClass)) {
                    const testObject = new testClass();
                    if (reflect.IsMemberOf(testObject, Parent)) {
                        testObject.Process();
                        const testViewer = new BaseViewer();
                        const events = this.getEventsManager();
                        events.setEvent(GeneralEventOwner.BODY, EventType.ON_LOAD, () => {
                            const elements = GuiObjectManager.getInstanceSingleton().getAll();
                            elements.foreach(($element) => {
                                if (!$element.IsCached() && !$element.IsLoaded() &&
                                    ObjectValidator.IsEmptyOrNull($element.Parent()) &&
                                    ElementManager.Exists($element.Id())) {
                                    if (ObjectValidator.IsEmptyOrNull($element.InstanceOwner())) {
                                        $element.InstanceOwner(testViewer);
                                    }
                                    if ($element.Visible()) {
                                        if ($element.hasAsynchronousDraw()) {
                                            $element.Visible(true);
                                        }
                                        else {
                                            events.FireEvent($element, EventType.ON_START);
                                            if (ElementManager.IsVisible($element.Id())) {
                                                events.FireEvent($element, EventType.BEFORE_LOAD, false);
                                            }
                                        }
                                    }
                                }
                            });
                        });
                        events.FireEvent(GeneralEventOwner.BODY, EventType.ON_LOAD);
                        executeParent = false;
                    }
                }
            }
        }
        if (executeParent) {
            super.resolver();
        }
    }
};
RuntimeTestRunner = __decorate([
    Resolver("/" + HttpRequestConstants.RUNTIME_TEST + "/**/*", { scope: ResolverScope.DEV })
], RuntimeTestRunner);
export { RuntimeTestRunner };
globalThis.RegisterClass("Io.Oidis.Gui.HttpProcessor.Resolvers.RuntimeTestRunner", RuntimeTestRunner);
//# sourceMappingURL=RuntimeTestRunner.js.map