var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { StringUtils } from "./../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { AsyncBaseHttpController } from "./HttpProcessor/Resolvers/AsyncBaseHttpController.js";
import { RuntimeTestRunner } from "./HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { IndexPage } from "./Pages/IndexPage.js";
import { BaseViewer } from "./Primitives/BaseViewer.js";
import { Resolver, ResolverScope } from "./../../../Io/Oidis/Commons/Primitives/Decorators.js";
/* dev:start */
import { HttpRequestParserTest } from "./../../../Io/Oidis/Commons/RuntimeTests/HttpRequestParserTest.js";
import { ErrorPagesTest } from "./RuntimeTests/ErrorPagesTest.js";
import { ElementEventsManagerTest } from "./RuntimeTests/Events/ElementEventsManagerTest.js";
import { EventsManagerTest } from "./RuntimeTests/Events/EventsManagerTest.js";
import { GuiObjectManagerTest } from "./RuntimeTests/GuiObjectManagerTest.js";
import { ImageFiltersTest } from "./RuntimeTests/ImageProcessor/ImageFiltersTest.js";
import { ImageTransformTest } from "./RuntimeTests/ImageProcessor/ImageTransformTest.js";
import { PerformanceTest } from "./RuntimeTests/PerformanceTest.js";
import { AbstractGuiObjectTest } from "./RuntimeTests/Primitives/AbstractGuiObjectTest.js";
import { AsyncBasePanelViewerTest } from "./RuntimeTests/Primitives/AsyncBasePanelViewerTest.js";
import { BaseGuiObjectTest } from "./RuntimeTests/Primitives/BaseGuiObjectTest.js";
import { BasePanelTest } from "./RuntimeTests/Primitives/BasePanelTest.js";
import { BasePanelViewerTest } from "./RuntimeTests/Primitives/BasePanelViewerTest.js";
import { FormsObjectTest } from "./RuntimeTests/Primitives/FormsObjectTest.js";
import { GuiCommonsTest } from "./RuntimeTests/Primitives/GuiCommonsTest.js";
import { GuiElementTest } from "./RuntimeTests/Primitives/GuiElementTest.js";
import { PrimitivesTest } from "./RuntimeTests/Primitives/PrimitivesTest.js";
import { SerializationTest } from "./RuntimeTests/SerializationTest.js";
import { ElementManagerTest } from "./RuntimeTests/Utils/ElementManagerTest.js";
import { ScreenPositionTest } from "./RuntimeTests/Utils/ScreenPositionTest.js";
import { StaticPageContentManagerTest } from "./RuntimeTests/Utils/StaticPageContentManagerTest.js";
import { TextSelectionManagerTest } from "./RuntimeTests/Utils/TextSelectionManagerTest.js";
import { WindowManagerTest } from "./RuntimeTests/Utils/WindowManagerTest.js";
/* dev:end */
/**
 * Index request resolver class provides handling of web index page.
 */
let Index = class Index extends AsyncBaseHttpController {
    constructor() {
        super();
        this.setInstanceOwner(new IndexPage());
    }
    async onSuccess($instance) {
        $instance.headerTitle.Content("Oidis Framework base GUI Library");
        $instance.headerInfo.Content("Common and abstract classes or interfaces connected with creation and handling of GUI.");
        let content = "";
        /* dev:start */
        content += `
            <h3>Runtime tests</h3>
            <div style="position: fixed; top: 10px; right: 10px; z-index: 9999;">
              <a href="#" onclick="document.documentElement.setAttribute('data-bs-theme', 'light'); return false;" 
                 style="margin-right: 10px; padding: 5px 10px; text-decoration: none; border-radius: 3px;">
                ☀️ Light
              </a>
              <a href="#" onclick="document.documentElement.setAttribute('data-bs-theme', 'dark'); return false;" 
                 style="margin-right: 10px; padding: 5px 10px; text-decoration: none; border-radius: 3px;">
                🌙 Dark
              </a>
            </div>

            <H4>Page content</H4>
            <a href="${WindowManagerTest.CreateLink()}">Window Manager</a>
            <a href="${StaticPageContentManagerTest.CreateLink()}">Static Page Content Manager</a>
            <a href="${EventsManagerTest.CreateLink()}">Global Events Factory</a>
            <a href="${ErrorPagesTest.CreateLink()}">Error Pages</a>

            <H4>GUI elements</H4>
            <a href="${GuiObjectManagerTest.CreateLink()}">GUI Object Manager</a>
            <a href="${ElementEventsManagerTest.CreateLink()}">Element Events Manager</a>
            <a href="${ElementManagerTest.CreateLink()}">Element Manager</a>
            <a href="${PrimitivesTest.CreateLink()}">GUI Primitives</a>
            <a href="${SerializationTest.CreateLink()}">GUI Primitives Serialization</a>
            <a href="${ScreenPositionTest.CallbackLink()}">Screen position test</a>
            <a href="${PerformanceTest.CallbackLink()}">Performance test</a>

            <H4>GUI utils</H4>
            <a href="${RuntimeTestRunner.CreateLink(HttpRequestParserTest)}">Http Request Parser Test</a>
            <a href="#${this.createLink("/web/PersistenceManagerTest")}">Persistence Manager Test</a>

            <H4>Draw GUI resolvers</H4>
            <a href="${BasePanelViewerTest.CallbackLink()}">Base Panel Viewer Test</a>
            <a href="#${this.createLink("/web/" + StringUtils.Replace(this.getClassName(), ".", "/"))}">Missing Viewer Test</a>
            <a href="${BaseViewer.CallbackLink()}">Viewer Bad Implementation Test</a>
            <a href="${AsyncBasePanelViewerTest.CallbackLink()}">Asynchronous Loader Test</a>
            <a href="${TextSelectionManagerTest.CallbackLink()}">TextSelectionManager test</a>

            <H4>Io.Oidis.Gui.ImageProcessor</H4>
            <a href="${ImageTransformTest.CallbackLink()}">ImageTransform test</a>
            <a href="${ImageFiltersTest.CallbackLink()}">ImageFilters test</a>

            <H4>Io.Oidis.Gui.Primitives</H4>
            <a href="${BaseGuiObjectTest.CallbackLink()}">BaseGuiObject test</a>
            <a href="${FormsObjectTest.CallbackLink()}">FormsObject test</a>
            <a href="${BasePanelTest.CallbackLink()}">BasePanel test</a>
            <a href="${AbstractGuiObjectTest.CallbackLink()}">AbstractGuiObject test</a>
            <a href="${GuiElementTest.CallbackLink()}">GuiElement test</a>
            <a href="${GuiCommonsTest.CallbackLink()}">GuiCommons test</a>
`;
        /* dev:end */
        $instance.pageIndex.Content(content);
        $instance.footerInfo.Content("" +
            "version: " + this.getEnvironmentArgs().getProjectVersion() +
            ", build: " + this.getEnvironmentArgs().getBuildTime() +
            ", " + this.getEnvironmentArgs().getProjectConfig().target.copyright);
    }
};
Index = __decorate([
    Resolver(["/", "/index", "/web/"], { scope: ResolverScope.DEV }),
    __metadata("design:paramtypes", [])
], Index);
export { Index };
globalThis.RegisterClass("Io.Oidis.Gui.Index", Index);
//# sourceMappingURL=Index.js.map