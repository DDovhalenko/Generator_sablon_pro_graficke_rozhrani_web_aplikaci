import { IGuiCommons } from "../Primitives/IGuiCommons.js";
// generated-code-start
export const IDragBar = globalThis.RegisterInterface(["getEvents"], IGuiCommons);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Components.IDragBar", IDragBar);
//# sourceMappingURL=IDragBar.js.map