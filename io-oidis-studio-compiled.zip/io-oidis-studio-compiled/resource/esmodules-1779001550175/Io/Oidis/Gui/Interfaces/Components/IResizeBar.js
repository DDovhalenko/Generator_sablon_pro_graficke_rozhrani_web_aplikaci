import { IGuiCommons } from "../Primitives/IGuiCommons.js";
// generated-code-start
export const IResizeBar = globalThis.RegisterInterface(["ResizeableType", "getEvents"], IGuiCommons);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Components.IResizeBar", IResizeBar);
//# sourceMappingURL=IResizeBar.js.map