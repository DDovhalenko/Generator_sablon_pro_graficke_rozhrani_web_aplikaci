import { IGuiCommons } from "../Primitives/IGuiCommons.js";
// generated-code-start
export const IScrollBar = globalThis.RegisterInterface(["GuiType", "OrientationType", "Size", "getEvents"], IGuiCommons);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Components.IScrollBar", IScrollBar);
//# sourceMappingURL=IScrollBar.js.map