// generated-code-start
export const IDesignerElementMap = globalThis.RegisterInterface(["id", "name", "type", "map"]);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Designer.IDesignerElementMap", IDesignerElementMap);
//# sourceMappingURL=IDesignerElementMap.js.map