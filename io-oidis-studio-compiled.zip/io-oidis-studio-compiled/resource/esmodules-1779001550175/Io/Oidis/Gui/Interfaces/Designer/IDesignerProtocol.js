import { IDesignerElementMap } from "./IDesignerElementMap.js";
// generated-code-start
/* eslint-disable */
export const IDesignerItemProtocol = globalThis.RegisterInterface(["id", "top", "left", "width", "height", "zoom", "draggable", "resizeable"]);
export const IDesignerItemArgProtocol = globalThis.RegisterInterface(["id", "name", "type", "value"]);
export const IDesignerItemArgsProtocol = globalThis.RegisterInterface(["id", "value"]);
export const IDesignerEventProtocol = globalThis.RegisterInterface(["type", "args"]);
export const IDesignerProjectMapItems = globalThis.RegisterInterface(["names"]);
export const IDesignerProjectMapViewers = globalThis.RegisterInterface(["links"], IDesignerProjectMapItems);
export const IDesignerProjectMapGuiObjects = globalThis.RegisterInterface(["components", "userControls", "panels"]);
export const IDesignerProjectMapProtocol = globalThis.RegisterInterface(["host", "blankViewer", "viewers", "runtimeTests", "guiObjects"]);
export const IDesignerInstanceMapItem = globalThis.RegisterInterface(["top", "left", "width", "height"], IDesignerElementMap);
export const IDesignerProtocol = globalThis.RegisterInterface(["task", "data"]);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Designer.IDesignerItemProtocol", IDesignerItemProtocol);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Designer.IDesignerItemArgProtocol", IDesignerItemArgProtocol);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Designer.IDesignerItemArgsProtocol", IDesignerItemArgsProtocol);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Designer.IDesignerEventProtocol", IDesignerEventProtocol);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Designer.IDesignerProjectMapItems", IDesignerProjectMapItems);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Designer.IDesignerProjectMapViewers", IDesignerProjectMapViewers);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Designer.IDesignerProjectMapGuiObjects", IDesignerProjectMapGuiObjects);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Designer.IDesignerProjectMapProtocol", IDesignerProjectMapProtocol);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Designer.IDesignerInstanceMapItem", IDesignerInstanceMapItem);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Designer.IDesignerProtocol", IDesignerProtocol);
//# sourceMappingURL=IDesignerProtocol.js.map