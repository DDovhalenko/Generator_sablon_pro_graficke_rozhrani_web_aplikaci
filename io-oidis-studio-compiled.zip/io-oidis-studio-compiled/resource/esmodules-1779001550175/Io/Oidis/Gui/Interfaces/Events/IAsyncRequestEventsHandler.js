import { IEventsHandler } from "../IEventsHandler.js";
// generated-code-start
export const IAsyncRequestEventsHandler = globalThis.RegisterInterface([], IEventsHandler);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IAsyncRequestEventsHandler", IAsyncRequestEventsHandler);
//# sourceMappingURL=IAsyncRequestEventsHandler.js.map