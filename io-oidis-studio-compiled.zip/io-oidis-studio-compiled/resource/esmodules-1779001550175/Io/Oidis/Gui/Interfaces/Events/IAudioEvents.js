import { IFormsObjectEvents } from "./IFormsObjectEvents.js";
// generated-code-start
/* eslint-disable */
export const IAudioEvents = globalThis.RegisterInterface(["setOnPlay", "setOnStop", "setOnPause", "setOnMute", "setOnUnmute", "setOnOpen"], IFormsObjectEvents);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IAudioEvents", IAudioEvents);
//# sourceMappingURL=IAudioEvents.js.map