import { IBasePanelEvents } from "./IBasePanelEvents.js";
// generated-code-start
/* eslint-disable */
export const IBasePanelHolderEvents = globalThis.RegisterInterface(["setOnOpen", "setOnClose", "setBeforeOpen", "setBeforeClose"], IBasePanelEvents);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IBasePanelHolderEvents", IBasePanelHolderEvents);
//# sourceMappingURL=IBasePanelHolderEvents.js.map