import { IFormsObjectEvents } from "./IFormsObjectEvents.js";
// generated-code-start
export const IButtonEvents = globalThis.RegisterInterface(["setOnResize"], IFormsObjectEvents);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IButtonEvents", IButtonEvents);
//# sourceMappingURL=IButtonEvents.js.map