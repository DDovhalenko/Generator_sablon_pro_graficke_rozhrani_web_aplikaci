import { IGuiCommonsEvents } from "./IGuiCommonsEvents.js";
// generated-code-start
/* eslint-disable */
export const ICropBoxEvents = globalThis.RegisterInterface(["setOnResize", "setOnResizeStart", "setOnResizeChange", "setOnResizeComplete"], IGuiCommonsEvents);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.ICropBoxEvents", ICropBoxEvents);
//# sourceMappingURL=ICropBoxEvents.js.map