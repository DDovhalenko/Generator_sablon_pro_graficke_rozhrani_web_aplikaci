import { IFormsObjectEvents } from "./IFormsObjectEvents.js";
// generated-code-start
/* eslint-disable */
export const IDialogEvents = globalThis.RegisterInterface(["setOnOpen", "setOnClose", "setOnDrag", "setBeforeResize", "setOnResize"], IFormsObjectEvents);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IDialogEvents", IDialogEvents);
//# sourceMappingURL=IDialogEvents.js.map