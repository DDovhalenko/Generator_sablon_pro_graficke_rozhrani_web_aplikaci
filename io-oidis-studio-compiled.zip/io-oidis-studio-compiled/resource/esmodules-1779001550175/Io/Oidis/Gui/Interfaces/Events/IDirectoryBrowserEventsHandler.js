import { IEventsHandler } from "../IEventsHandler.js";
// generated-code-start
export const IDirectoryBrowserEventsHandler = globalThis.RegisterInterface([], IEventsHandler);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IDirectoryBrowserEventsHandler", IDirectoryBrowserEventsHandler);
//# sourceMappingURL=IDirectoryBrowserEventsHandler.js.map