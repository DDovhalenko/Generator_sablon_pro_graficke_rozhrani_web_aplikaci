import { IGuiCommonsEvents } from "./IGuiCommonsEvents.js";
// generated-code-start
/* eslint-disable */
export const IDragBarEvents = globalThis.RegisterInterface(["setOnDragStart", "setOnDragChange", "setOnDragComplete"], IGuiCommonsEvents);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IDragBarEvents", IDragBarEvents);
//# sourceMappingURL=IDragBarEvents.js.map