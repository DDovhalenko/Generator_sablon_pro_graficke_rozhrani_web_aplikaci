import { IEventsHandler } from "../IEventsHandler.js";
// generated-code-start
export const IDragBarEventsHandler = globalThis.RegisterInterface([], IEventsHandler);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IDragBarEventsHandler", IDragBarEventsHandler);
//# sourceMappingURL=IDragBarEventsHandler.js.map