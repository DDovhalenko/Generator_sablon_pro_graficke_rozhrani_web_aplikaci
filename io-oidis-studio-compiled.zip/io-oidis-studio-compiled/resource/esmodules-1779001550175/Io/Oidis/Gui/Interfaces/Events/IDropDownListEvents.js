import { IFormsObjectEvents } from "./IFormsObjectEvents.js";
// generated-code-start
export const IDropDownListEvents = globalThis.RegisterInterface(["setOnResize", "setOnScroll", "setOnSelect"], IFormsObjectEvents);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IDropDownListEvents", IDropDownListEvents);
//# sourceMappingURL=IDropDownListEvents.js.map