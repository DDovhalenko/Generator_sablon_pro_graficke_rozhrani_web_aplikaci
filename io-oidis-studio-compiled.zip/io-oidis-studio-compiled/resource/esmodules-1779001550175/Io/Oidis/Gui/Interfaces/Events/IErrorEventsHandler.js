import { IEventsHandler } from "../IEventsHandler.js";
// generated-code-start
export const IErrorEventsHandler = globalThis.RegisterInterface([], IEventsHandler);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IErrorEventsHandler", IErrorEventsHandler);
//# sourceMappingURL=IErrorEventsHandler.js.map