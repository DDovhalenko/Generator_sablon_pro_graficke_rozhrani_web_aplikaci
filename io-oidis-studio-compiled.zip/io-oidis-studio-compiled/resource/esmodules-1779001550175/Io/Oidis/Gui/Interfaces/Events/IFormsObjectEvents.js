import { IGuiCommonsEvents } from "./IGuiCommonsEvents.js";
// generated-code-start
export const IFormsObjectEvents = globalThis.RegisterInterface(["setOnFocus", "setOnBlur", "setOnChange"], IGuiCommonsEvents);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IFormsObjectEvents", IFormsObjectEvents);
//# sourceMappingURL=IFormsObjectEvents.js.map