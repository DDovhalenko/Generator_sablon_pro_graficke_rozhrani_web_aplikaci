import { IBaseObject } from "./../../../../../Io/Oidis/Commons/Interfaces/IBaseObject.js";
// generated-code-start
/* eslint-disable */
export const IGuiCommonsEvents = globalThis.RegisterInterface(["getOwner", "Subscriber", "Exists", "getAll", "setEvent", "FireAsynchronousMethod", "RemoveHandler", "Clear", "Subscribe", "setOnStart", "setBeforeLoad", "setOnLoad", "setOnComplete", "setOnShow", "setOnHide", "setOnMouseOver", "setOnMouseOut", "setOnMouseMove", "setOnMouseDown", "setOnMouseUp", "setOnClick", "setOnDoubleClick"], IBaseObject);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IGuiCommonsEvents", IGuiCommonsEvents);
//# sourceMappingURL=IGuiCommonsEvents.js.map