import { IEventsHandler } from "../IEventsHandler.js";
// generated-code-start
export const IHttpRequestEventsHandler = globalThis.RegisterInterface([], IEventsHandler);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IHttpRequestEventsHandler", IHttpRequestEventsHandler);
//# sourceMappingURL=IHttpRequestEventsHandler.js.map