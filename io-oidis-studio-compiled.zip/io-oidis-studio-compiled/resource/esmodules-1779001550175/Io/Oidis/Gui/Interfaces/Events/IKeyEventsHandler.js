import { IEventsHandler } from "../IEventsHandler.js";
// generated-code-start
export const IKeyEventsHandler = globalThis.RegisterInterface([], IEventsHandler);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IKeyEventsHandler", IKeyEventsHandler);
//# sourceMappingURL=IKeyEventsHandler.js.map