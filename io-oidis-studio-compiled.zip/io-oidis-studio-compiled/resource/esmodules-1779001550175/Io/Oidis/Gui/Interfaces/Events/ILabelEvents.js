import { IGuiCommonsEvents } from "./IGuiCommonsEvents.js";
// generated-code-start
export const ILabelEvents = globalThis.RegisterInterface(["setOnChange"], IGuiCommonsEvents);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.ILabelEvents", ILabelEvents);
//# sourceMappingURL=ILabelEvents.js.map