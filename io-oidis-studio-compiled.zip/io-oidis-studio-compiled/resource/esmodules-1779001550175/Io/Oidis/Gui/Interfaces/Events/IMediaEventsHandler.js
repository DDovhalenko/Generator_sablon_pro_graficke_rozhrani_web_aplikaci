import { IEventsHandler } from "../IEventsHandler.js";
// generated-code-start
export const IMediaEventsHandler = globalThis.RegisterInterface([], IEventsHandler);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IMediaEventsHandler", IMediaEventsHandler);
//# sourceMappingURL=IMediaEventsHandler.js.map