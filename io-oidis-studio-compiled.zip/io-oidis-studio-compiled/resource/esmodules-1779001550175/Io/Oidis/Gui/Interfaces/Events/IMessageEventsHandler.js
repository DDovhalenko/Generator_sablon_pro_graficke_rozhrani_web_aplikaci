import { IEventsHandler } from "../IEventsHandler.js";
// generated-code-start
export const IMessageEventsHandler = globalThis.RegisterInterface([], IEventsHandler);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IMessageEventsHandler", IMessageEventsHandler);
//# sourceMappingURL=IMessageEventsHandler.js.map