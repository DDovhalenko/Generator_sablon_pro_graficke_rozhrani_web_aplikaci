import { IEventsHandler } from "../IEventsHandler.js";
// generated-code-start
export const IMouseEventsHandler = globalThis.RegisterInterface([], IEventsHandler);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IMouseEventsHandler", IMouseEventsHandler);
//# sourceMappingURL=IMouseEventsHandler.js.map