import { IEventsHandler } from "../IEventsHandler.js";
// generated-code-start
export const IMoveEventsHandler = globalThis.RegisterInterface([], IEventsHandler);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IMoveEventsHandler", IMoveEventsHandler);
//# sourceMappingURL=IMoveEventsHandler.js.map