import { IGuiCommonsEvents } from "./IGuiCommonsEvents.js";
// generated-code-start
export const IProgressBarEvents = globalThis.RegisterInterface(["setOnChange"], IGuiCommonsEvents);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IProgressBarEvents", IProgressBarEvents);
//# sourceMappingURL=IProgressBarEvents.js.map