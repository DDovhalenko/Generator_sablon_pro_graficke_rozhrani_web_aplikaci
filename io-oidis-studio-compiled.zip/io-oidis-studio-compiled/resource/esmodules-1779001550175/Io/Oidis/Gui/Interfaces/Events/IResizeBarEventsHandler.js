import { IEventsHandler } from "../IEventsHandler.js";
// generated-code-start
export const IResizeBarEventsHandler = globalThis.RegisterInterface([], IEventsHandler);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IResizeBarEventsHandler", IResizeBarEventsHandler);
//# sourceMappingURL=IResizeBarEventsHandler.js.map