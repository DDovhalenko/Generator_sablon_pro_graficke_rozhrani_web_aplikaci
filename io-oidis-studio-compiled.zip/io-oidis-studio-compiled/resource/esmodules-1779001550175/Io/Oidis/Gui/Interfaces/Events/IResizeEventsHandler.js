import { IEventsHandler } from "../IEventsHandler.js";
// generated-code-start
export const IResizeEventsHandler = globalThis.RegisterInterface([], IEventsHandler);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IResizeEventsHandler", IResizeEventsHandler);
//# sourceMappingURL=IResizeEventsHandler.js.map