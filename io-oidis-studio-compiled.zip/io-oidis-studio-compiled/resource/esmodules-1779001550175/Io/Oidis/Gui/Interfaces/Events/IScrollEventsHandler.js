import { IEventsHandler } from "../IEventsHandler.js";
// generated-code-start
export const IScrollEventsHandler = globalThis.RegisterInterface([], IEventsHandler);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.IScrollEventsHandler", IScrollEventsHandler);
//# sourceMappingURL=IScrollEventsHandler.js.map