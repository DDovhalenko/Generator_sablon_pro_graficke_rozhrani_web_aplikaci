import { IGuiCommonsEvents } from "./IGuiCommonsEvents.js";
// generated-code-start
/* eslint-disable */
export const ISelectBoxEvents = globalThis.RegisterInterface(["setOnResize", "setOnScroll", "setOnChange", "setOnSelect"], IGuiCommonsEvents);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.ISelectBoxEvents", ISelectBoxEvents);
//# sourceMappingURL=ISelectBoxEvents.js.map