import { IEventsHandler } from "../IEventsHandler.js";
// generated-code-start
export const ITouchEventsHandler = globalThis.RegisterInterface([], IEventsHandler);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Events.ITouchEventsHandler", ITouchEventsHandler);
//# sourceMappingURL=ITouchEventsHandler.js.map