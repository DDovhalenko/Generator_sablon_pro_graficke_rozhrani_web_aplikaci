import { IEventsHandler as Parent } from "./../../../../Io/Oidis/Commons/Interfaces/IEventsHandler.js";
// generated-code-start
export const IEventsHandler = globalThis.RegisterInterface([], Parent);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.IEventsHandler", IEventsHandler);
//# sourceMappingURL=IEventsHandler.js.map