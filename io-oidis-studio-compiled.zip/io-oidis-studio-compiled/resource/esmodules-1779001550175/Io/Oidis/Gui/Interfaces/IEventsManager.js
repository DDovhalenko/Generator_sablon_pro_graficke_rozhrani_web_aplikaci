import { IEventsManager as Parent } from "./../../../../Io/Oidis/Commons/Interfaces/IEventsManager.js";
// generated-code-start
/* eslint-disable */
export const IEventsManager = globalThis.RegisterInterface(["getAll", "setEventArgs", "setEvent", "FireEvent", "RemoveHandler", "Exists"], Parent);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.IEventsManager", IEventsManager);
//# sourceMappingURL=IEventsManager.js.map