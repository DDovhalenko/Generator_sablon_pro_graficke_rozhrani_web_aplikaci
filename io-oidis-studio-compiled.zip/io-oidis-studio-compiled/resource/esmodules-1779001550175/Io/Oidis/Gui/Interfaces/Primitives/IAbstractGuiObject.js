import { IBaseGuiObject } from "./IBaseGuiObject.js";
// generated-code-start
/* eslint-disable */
export const IAbstractGuiObject = globalThis.RegisterInterface(["Notification", "setSize", "StyleAttributes", "AppendStyleAttributes"], IBaseGuiObject);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Primitives.IAbstractGuiObject", IAbstractGuiObject);
//# sourceMappingURL=IAbstractGuiObject.js.map