import { IGuiCommons } from "./IGuiCommons.js";
// generated-code-start
export const IBaseGuiObject = globalThis.RegisterInterface(["Title", "Changed", "Value"], IGuiCommons);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Primitives.IBaseGuiObject", IBaseGuiObject);
//# sourceMappingURL=IBaseGuiObject.js.map