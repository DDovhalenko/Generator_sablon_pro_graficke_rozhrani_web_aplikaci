import { IFormsObject } from "./IFormsObject.js";
export class IContainerSizeInfo {
    elementsWithoutWidth;
    elementsWithoutHeight;
    remainingWidth;
    remainingHeight;
}
export class IContainerVisibilityInfo {
    commonsNum;
    visibleCommons;
}
// generated-code-start
/* eslint-disable */
export const IBasePanel = globalThis.RegisterInterface(["loaderIcon", "loaderText", "AddChild", "getChildPanelList", "setChildPanelArgs", "ContentType", "Scrollable", "Width", "Height", "getScrollTop", "getScrollLeft", "getEvents", "Value"], IFormsObject);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Primitives.IBasePanel", IBasePanel);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Primitives.IContainerSizeInfo", IContainerSizeInfo);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Primitives.IContainerVisibilityInfo", IContainerVisibilityInfo);
//# sourceMappingURL=IBasePanel.js.map