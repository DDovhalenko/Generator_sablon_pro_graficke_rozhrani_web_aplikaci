import { IBaseViewer } from "./IBaseViewer.js";
// generated-code-start
export const IBasePanelViewer = globalThis.RegisterInterface(["ViewerArgs"], IBaseViewer);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Primitives.IBasePanelViewer", IBasePanelViewer);
//# sourceMappingURL=IBasePanelViewer.js.map