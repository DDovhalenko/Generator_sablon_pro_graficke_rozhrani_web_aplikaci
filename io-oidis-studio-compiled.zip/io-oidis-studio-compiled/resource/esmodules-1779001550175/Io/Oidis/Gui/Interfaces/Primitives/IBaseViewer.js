/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IBaseObject } from "./../../../../../Io/Oidis/Commons/Interfaces/IBaseObject.js";
// generated-code-start
/* eslint-disable */
export const IBaseViewer = globalThis.RegisterInterface(["InstanceOwner", "IsCached", "IsPrinted", "TestModeEnabled", "ViewerArgs", "getInstance", "setLayer", "getLayersType", "PrepareImplementation", "Show"], IBaseObject);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Primitives.IBaseViewer", IBaseViewer);
//# sourceMappingURL=IBaseViewer.js.map