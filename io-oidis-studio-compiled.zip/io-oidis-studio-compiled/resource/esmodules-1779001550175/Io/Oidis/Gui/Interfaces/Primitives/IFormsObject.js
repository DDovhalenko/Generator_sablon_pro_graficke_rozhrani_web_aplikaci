import { IBaseGuiObject } from "./IBaseGuiObject.js";
// generated-code-start
/* eslint-disable */
export const IFormsObject = globalThis.RegisterInterface(["Notification", "Error", "TabIndex", "getSelectorEvents", "getEvents", "IsPersistent"], IBaseGuiObject);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Primitives.IFormsObject", IFormsObject);
//# sourceMappingURL=IFormsObject.js.map