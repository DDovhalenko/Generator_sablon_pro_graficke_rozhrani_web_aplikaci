import { IBaseObject } from "./../../../../../Io/Oidis/Commons/Interfaces/IBaseObject.js";
// generated-code-start
/* eslint-disable */
export const IGuiCommons = globalThis.RegisterInterface(["getGuiOptions", "getEvents", "getGuiElementClass", "Visible", "Enabled", "StyleClassName", "Id", "Parent", "InstanceOwner", "InstancePath", "getChildElements", "getScreenPosition", "setPosition", "getSize", "Width", "Height", "FitToParent", "getFitToParent", "IsCached", "IsPrepared", "IsLoaded", "IsCompleted", "DisableAsynchronousDraw", "Draw", "getArgs", "setArg", "getInnerHtmlMap", "getWrappingElement", "setWrappingElement", "getWrappingContainer", "setWrappingContainer", "IsPreventingScroll"], IBaseObject);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Primitives.IGuiCommons", IGuiCommons);
//# sourceMappingURL=IGuiCommons.js.map