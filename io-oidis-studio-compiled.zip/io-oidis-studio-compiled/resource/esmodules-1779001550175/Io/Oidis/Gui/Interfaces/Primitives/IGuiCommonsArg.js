// generated-code-start
export const IGuiCommonsArg = globalThis.RegisterInterface(["type", "name", "value"]);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Primitives.IGuiCommonsArg", IGuiCommonsArg);
//# sourceMappingURL=IGuiCommonsArg.js.map