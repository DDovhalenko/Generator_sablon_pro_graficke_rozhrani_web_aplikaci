import { IBaseObject } from "./../../../../../Io/Oidis/Commons/Interfaces/IBaseObject.js";
// generated-code-start
/* eslint-disable */
export const IGuiElement = globalThis.RegisterInterface(["Id", "getId", "GuiTypeTag", "StyleClassName", "Visible", "getVisible", "Width", "getWidth", "Height", "getHeight", "setAttribute", "Add", "addChildElement", "getChildElements", "getChildElement", "getGuiChildElements", "getGuiTypeTag", "getAttributes", "Draw", "ToDOMElement", "getWrappingElement", "setWrappingElement"], IBaseObject);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Primitives.IGuiElement", IGuiElement);
//# sourceMappingURL=IGuiElement.js.map