import { IGuiElement } from "./IGuiElement.js";
// generated-code-start
/* eslint-disable */
export const IResponsiveElement = globalThis.RegisterInterface(["StyleClassName", "WidthOfColumn", "HeightOfRow", "getWidthOfColumn", "getHeightOfRow", "Alignment", "getAlignment", "FitToParent", "getFitToParent", "VisibilityStrategy", "getVisibilityStrategy", "Add"], IGuiElement);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.Primitives.IResponsiveElement", IResponsiveElement);
//# sourceMappingURL=IResponsiveElement.js.map