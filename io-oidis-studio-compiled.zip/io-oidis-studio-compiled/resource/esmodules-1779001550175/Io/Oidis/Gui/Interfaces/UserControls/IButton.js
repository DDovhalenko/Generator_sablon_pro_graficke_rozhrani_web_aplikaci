import { IImageButton } from "./IImageButton.js";
// generated-code-start
export const IButton = globalThis.RegisterInterface(["GuiType", "Text", "Width", "getEvents"], IImageButton);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.UserControls.IButton", IButton);
//# sourceMappingURL=IButton.js.map