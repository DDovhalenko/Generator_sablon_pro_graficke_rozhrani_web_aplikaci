import { IFormsObject } from "../Primitives/IFormsObject.js";
// generated-code-start
/* eslint-disable */
export const IDirectoryBrowser = globalThis.RegisterInterface(["Path", "Filter", "setStructure", "Clear", "getEvents", "Value"], IFormsObject);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.UserControls.IDirectoryBrowser", IDirectoryBrowser);
//# sourceMappingURL=IDirectoryBrowser.js.map