import { IBaseGuiObject } from "../Primitives/IBaseGuiObject.js";
// generated-code-start
export const ILabel = globalThis.RegisterInterface(["Text", "getEvents"], IBaseGuiObject);
globalThis.RegisterClass("Io.Oidis.Gui.Interfaces.UserControls.ILabel", ILabel);
//# sourceMappingURL=ILabel.js.map