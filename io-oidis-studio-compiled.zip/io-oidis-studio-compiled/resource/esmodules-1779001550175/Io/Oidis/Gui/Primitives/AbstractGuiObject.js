/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { BaseGuiObject } from "./BaseGuiObject.js";
/**
 * AbstractGuiObject class provides GUI object, which can be used as temporary element needed
 * for development purposes.
 */
export class AbstractGuiObject extends BaseGuiObject {
    notification;
    width;
    height;
    attributes;
    /**
     * @param {string} [$id] Force to set element's id, instead of generated one.
     */
    constructor($id) {
        super($id);
    }
    /**
     * @returns {INotification} Returns notification component associated with current GUI element.
     */
    Notification() {
        if (ObjectValidator.IsEmptyOrNull(this.notification)) {
            const notificationClass = this.getNotificationClass();
            if (!ObjectValidator.IsEmptyOrNull(notificationClass)) {
                this.notification = new notificationClass(null, null, this.Id() + "_Notification");
            }
        }
        return this.notification;
    }
    /**
     * @param {number} $width Set element's width.
     * @param {number} $height Set element's height.
     * @returns {void}
     */
    setSize($width, $height) {
        this.width = Property.PositiveInteger(this.width, $width);
        this.height = Property.PositiveInteger(this.height, $height);
    }
    /**
     * @param {string} [$value] Specify css style attributes in string format.
     * @returns {string} Returns css style attributes subscribed to the element.
     */
    StyleAttributes($value) {
        return this.attributes = Property.String(this.attributes, $value);
    }
    /**
     * @param {string} $value Specify css style attributes in string format, which should be appended to current ones.
     * @returns {void}
     */
    AppendStyleAttributes($value) {
        let newAttribute = "";
        newAttribute = Property.String(newAttribute, $value);
        if (!StringUtils.Contains(newAttribute, ";")) {
            newAttribute += ";";
        }
        if (!ObjectValidator.IsSet(this.attributes)) {
            this.attributes = "";
        }
        if (!ObjectValidator.IsEmptyOrNull(this.attributes)) {
            this.attributes += " ";
        }
        this.attributes += newAttribute;
    }
    /**
     * @returns {INotification} This method should return class with
     * interface Io.Oidis.Gui.Interfaces.Components.INotification
     */
    getNotificationClass() {
        return null;
    }
    innerHtml() {
        return this.addElement()
            .Width(this.getWidth())
            .Height(this.getHeight())
            .setAttribute("border", "1px solid red")
            .setAttribute("color", "red")
            .setAttribute("overflow-x", "hidden")
            .setAttribute("overflow-y", "hidden")
            .setAttribute("", this.attributes)
            .Add(this.Id());
    }
    excludeSerializationData() {
        const exclude = super.excludeSerializationData();
        exclude.push("width", "height", "attributes");
        return exclude;
    }
    excludeCacheData() {
        const exclude = super.excludeCacheData();
        exclude.push("notification");
        if (this.width === 100) {
            exclude.push("width");
        }
        if (this.height === 20) {
            exclude.push("height");
        }
        if (ObjectValidator.IsEmptyOrNull(this.attributes)) {
            exclude.push("attributes");
        }
        return exclude;
    }
    getWidth() {
        if (!ObjectValidator.IsSet(this.width)) {
            this.width = 100;
        }
        return this.width;
    }
    getHeight() {
        if (!ObjectValidator.IsSet(this.height)) {
            this.height = 20;
        }
        return this.height;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Primitives.AbstractGuiObject", AbstractGuiObject);
//# sourceMappingURL=AbstractGuiObject.js.map