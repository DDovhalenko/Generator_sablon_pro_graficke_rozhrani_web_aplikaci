import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { GuiCommonsArgType } from "../Enums/GuiCommonsArgType.js";
import { GuiOptionType } from "../Enums/GuiOptionType.js";
import { GuiCommons } from "./GuiCommons.js";
/**
 * BaseGuiObject should be used as abstract class for extending to the GUI objects
 * and it is providing base GUI object methods.
 */
export class BaseGuiObject extends GuiCommons {
    title;
    changed;
    static onHoverEventHandler($eventArgs, $manager, $reflection) {
        if (!ObjectValidator.IsEmptyOrNull($eventArgs.Owner().Parent())) {
            $manager.setHovered($eventArgs.Owner().Parent(), true);
        }
        else {
            $manager.setHovered($eventArgs.Owner(), true);
        }
    }
    static onUnhoverEventHandler($eventArgs, $manager, $reflection) {
        $manager.setHovered($eventArgs.Owner(), false);
        if (!ObjectValidator.IsEmptyOrNull($eventArgs.Owner().Parent())) {
            $manager.setHovered($eventArgs.Owner().Parent(), true);
        }
    }
    /**
     * @returns {IToolTip} Returns tooltip component associated with current GUI element.
     */
    Title() {
        if (ObjectValidator.IsEmptyOrNull(this.title)) {
            const toolTipClass = this.getTitleClass();
            if (!ObjectValidator.IsEmptyOrNull(toolTipClass)) {
                this.title = new toolTipClass(null, null, this.Id() + "_ToolTip");
                this.title.Parent(this);
                this.getGuiOptions().Add(GuiOptionType.TOOL_TIP);
            }
        }
        return this.title;
    }
    /**
     * @returns {boolean} Returns true, if user has been interacting with the element, otherwise false.
     */
    Changed() {
        if (!ObjectValidator.IsSet(this.changed)) {
            this.changed = false;
        }
        return this.changed;
    }
    /**
     * @param {any} [$value] Set element's value, which can be used by controllers.
     * @returns {any} Returns value connected with the element, if element is type of input or value has been set,
     * otherwise null.
     */
    Value($value) {
        return null;
    }
    /**
     * @returns {IGuiCommonsArg[]} Returns array of element's attributes.
     */
    getArgs() {
        const args = super.getArgs();
        args.push({
            name: "Title",
            type: GuiCommonsArgType.TEXT,
            value: this.Title().Text()
        });
        args.push({
            name: "Value",
            type: GuiCommonsArgType.TEXT,
            value: this.Value()
        });
        return args;
    }
    /**
     * @param {IGuiCommonsArg} $value Specify argument value, which should be passed to element.
     * @param {boolean} [$force=false] Specify, if value should be set without fire of events connected with argument change.
     * @returns {void}
     */
    setArg($value, $force = false) {
        switch ($value.name) {
            case "Title":
                this.Title().Text($value.value);
                break;
            case "Value":
                this.Value($value.value);
                break;
            default:
                super.setArg($value, $force);
                break;
        }
    }
    availableGuiOptions() {
        const options = super.availableGuiOptions();
        options.Add(GuiOptionType.TOOL_TIP);
        return options;
    }
    /**
     * @returns {IToolTip} This method should return class with
     * interface Io.Oidis.Gui.Interfaces.Components.IToolTip
     */
    getTitleClass() {
        return null;
    }
    setChanged() {
        this.changed = true;
    }
    innerCode() {
        let titleContent = "";
        if (ObjectValidator.IsSet(this.title) || this.getGuiOptions().Contains(GuiOptionType.TOOL_TIP)) {
            titleContent = this.Title();
            this.getEvents().setOnMouseOver(($args) => {
                const element = $args.Owner();
                element.getTitleClass().Show(element.Title(), $args);
            });
            this.getEvents().setOnMouseOut(($args) => {
                const element = $args.Owner();
                element.getTitleClass().Hide(element.Title());
            });
            this.getEvents().setOnMouseMove(($args) => {
                const element = $args.Owner();
                element.getTitleClass().Move(element.Title(), $args);
            });
        }
        this.getEvents().setOnClick(($args, $manager, $reflection) => {
            $reflection.getClass($args.Owner().getClassName()).onHoverEventHandler($args, $manager, $reflection);
        });
        this.getEvents().setOnMouseOut(($args, $manager, $reflection) => {
            $reflection.getClass($args.Owner().getClassName()).onUnhoverEventHandler($args, $manager, $reflection);
        });
        return super.innerCode().Add(titleContent);
    }
    excludeSerializationData() {
        const exclude = super.excludeSerializationData();
        exclude.push("changed");
        return exclude;
    }
    excludeCacheData() {
        const exclude = super.excludeCacheData();
        exclude.push("title", "changed");
        return exclude;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Primitives.BaseGuiObject", BaseGuiObject);
//# sourceMappingURL=BaseGuiObject.js.map