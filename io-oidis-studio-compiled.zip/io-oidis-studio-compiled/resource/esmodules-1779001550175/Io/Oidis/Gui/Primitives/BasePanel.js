/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { GeneralEventOwner } from "./../../../../Io/Oidis/Commons/Enums/Events/GeneralEventOwner.js";
import { TimeoutManager } from "./../../../../Io/Oidis/Commons/Events/TimeoutManager.js";
import { ExceptionsManager } from "./../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { IllegalArgumentException } from "./../../../../Io/Oidis/Commons/Exceptions/Type/IllegalArgumentException.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Alignment } from "../Enums/Alignment.js";
import { DirectionType } from "../Enums/DirectionType.js";
import { EventType } from "../Enums/Events/EventType.js";
import { FitToParent } from "../Enums/FitToParent.js";
import { GeneralCssNames } from "../Enums/GeneralCssNames.js";
import { GuiCommonsArgType } from "../Enums/GuiCommonsArgType.js";
import { GuiOptionType } from "../Enums/GuiOptionType.js";
import { HttpRequestConstants } from "../Enums/HttpRequestConstants.js";
import { KeyMap } from "../Enums/KeyMap.js";
import { OrientationType } from "../Enums/OrientationType.js";
import { PanelContentType } from "../Enums/PanelContentType.js";
import { UnitType } from "../Enums/UnitType.js";
import { VisibilityStrategy } from "../Enums/VisibilityStrategy.js";
import { PanelResizeEventArgs } from "../Events/Args/PanelResizeEventArgs.js";
import { ScrollEventArgs } from "../Events/Args/ScrollEventArgs.js";
import { EventsManager } from "../Events/EventsManager.js";
import { GuiObjectManager } from "../GuiObjectManager.js";
import { IBasePanel } from "../Interfaces/Primitives/IBasePanel.js";
import { IGuiCommons } from "../Interfaces/Primitives/IGuiCommons.js";
import { IGuiElement } from "../Interfaces/Primitives/IGuiElement.js";
import { IResponsiveElement } from "../Interfaces/Primitives/IResponsiveElement.js";
import { PropagableNumber } from "../Structures/PropagableNumber.js";
import { Size } from "../Structures/Size.js";
import { ElementManager } from "../Utils/ElementManager.js";
import { WindowManager } from "../Utils/WindowManager.js";
import { BasePanelViewer } from "./BasePanelViewer.js";
import { FormsObject } from "./FormsObject.js";
import { GuiElement } from "./GuiElement.js";
/**
 * BasePanel should be used as abstract class for extending to the GUI panels and
 * it is providing base methods connected with panel implementation and behaviour.
 * This class also provides static component methods determined to handle panel GUI objects.
 */
export class BasePanel extends FormsObject {
    loaderIcon;
    loaderText;
    verticalScrollBar;
    horizontalScrollBar;
    childPanelList;
    asyncChildLoaders;
    contentType;
    scrollable;
    width;
    height;
    asyncInnerCode;
    asyncChildrenLoader;
    fitToWindow;
    /**
     * @param {BasePanel} $element Specify element, which should be handled.
     * @returns {void}
     */
    static TurnOn($element) {
        // override this method for ability to handle element's ON state
    }
    /**
     * @param {BasePanel} $element Specify element, which should be handled.
     * @returns {void}
     */
    static TurnOff($element) {
        // override this method for ability to handle element's OFF state
    }
    /**
     * @param {BasePanel} $element Specify element, which should be handled.
     * @returns {void}
     */
    static TurnActive($element) {
        // override this method for ability to handle element's ACTIVE state
    }
    /**
     * @param {BasePanel} $element Specify element, which should be handled.
     * @returns {void}
     */
    static Show($element) {
        const id = $element.Id();
        if (ElementManager.Exists(id)) {
            const reflection = Reflection.getInstance();
            if (reflection.IsMemberOf($element, BasePanel) && $element.Visible()) {
                const elementClass = reflection.getClass($element.getClassName());
                ElementManager.Show(id + "_PanelEnvelop");
                ElementManager.Show(id);
                ElementManager.Show(id + "_PanelContentEnvelop");
                if (!$element.IsLoaded()) {
                    ElementManager.ClearCssProperty(id + "_PanelEnvelop", "float");
                }
                if ($element.Width() === -1 || $element.Height() === -1) {
                    if ($element.FitToWindow()) {
                        $element.fitToWindowHandler($element.getWindowSize());
                    }
                    else {
                        if ($element.Width() === -1) {
                            $element.Width(ElementManager.getOffsetWidth(id, true, true));
                        }
                        if ($element.Height() === -1) {
                            $element.Height(ElementManager.getOffsetHeight(id, true, true));
                            if ($element.Height() === 0) {
                                Echo.Println("Panel " + $element.Id() + " is missing height attribute. " +
                                    "Did you forget to specify Height() or css height value?");
                                $element.Height(100);
                            }
                        }
                    }
                }
                if ($element.ContentType() === PanelContentType.ASYNC_LOADER && ElementManager.IsVisible(id + "_AsyncProgress")) {
                    const loaderSize = new Size(id + "_AsyncProgress");
                    let loaderWidth = 0;
                    if (ObjectValidator.IsSet($element.loaderIcon)) {
                        loaderWidth += ElementManager.getElement($element.loaderIcon.Id()).offsetWidth;
                    }
                    if (ObjectValidator.IsSet($element.loaderText)) {
                        loaderWidth += ElementManager.getElement($element.loaderText.Id()).offsetWidth;
                    }
                    loaderSize.Width(loaderWidth);
                    if (loaderSize.Height() === 0) {
                        let loaderHeight = 0;
                        if (ObjectValidator.IsSet($element.loaderIcon) && $element.loaderIcon.Visible()) {
                            loaderHeight = ElementManager.getElement($element.loaderIcon.Id()).offsetHeight;
                        }
                        if (ObjectValidator.IsSet($element.loaderText) && $element.loaderText.Visible()) {
                            const loaderTextHeight = ElementManager.getElement($element.loaderText.Id()).offsetHeight;
                            if (loaderHeight < loaderTextHeight) {
                                loaderHeight = loaderTextHeight;
                            }
                        }
                        loaderSize.Height(loaderHeight);
                    }
                    ElementManager.setSize(id, $element.Width() - ElementManager.getWidthOffset($element.Id()), $element.Height() - ElementManager.getWidthOffset($element.Id()));
                    ElementManager.setCssProperty(id + "_PanelEnvelop", "float", "left");
                    // todo : change to absolute positioned automatically centered
                    ElementManager.setCssProperty(id + "_AsyncProgress", "top", Math.ceil($element.Height() / 2 - loaderSize.Height() / 2));
                    ElementManager.setCssProperty(id + "_AsyncProgress", "left", Math.ceil($element.Width() / 2 - loaderSize.Width() / 2));
                    const events = EventsManager.getInstanceSingleton();
                    if (!$element.IsLoaded()) {
                        if (!$element.IsPrepared()) {
                            $element.asyncInnerCode = $element.innerCode();
                            if ($element.IsCached()) {
                                $element.InstanceOwner().PrepareImplementation();
                            }
                        }
                        const loaderItems = new ArrayList();
                        if (!ObjectValidator.IsEmptyOrNull($element.Parent())) {
                            $element.getEvents().setOnLoad(($eventArgs, $manager, $reflection) => {
                                const element = $eventArgs.Owner();
                                if ($reflection.IsMemberOf(element, BasePanel)) {
                                    loaderItems.Add(() => {
                                        if (element.Visible() && element.ContentType() === PanelContentType.ASYNC_LOADER) {
                                            events.FireEvent(element, EventType.ON_ASYNC_REQUEST);
                                        }
                                    });
                                }
                                else if (ObjectValidator.IsFunction(element.PanelViewer) &&
                                    !ObjectValidator.IsEmptyOrNull(element.PanelViewer()) &&
                                    !ObjectValidator.IsEmptyOrNull(element.PanelViewer().getInstance())) {
                                    loaderItems.Add(() => {
                                        if (element.Visible() &&
                                            element.PanelViewer().getInstance().ContentType() === PanelContentType.ASYNC_LOADER) {
                                            events.FireEvent(element.PanelViewer().getInstance(), EventType.ON_ASYNC_REQUEST, false);
                                        }
                                    });
                                }
                                elementClass.asyncLoadChildren(loaderItems);
                            });
                        }
                        else {
                            loaderItems.Add(() => {
                                if ($element.Visible() && $element.ContentType() === PanelContentType.ASYNC_LOADER) {
                                    events.FireEvent($element, EventType.ON_ASYNC_REQUEST, false);
                                }
                            });
                        }
                        elementClass.asyncLoadChildren(loaderItems);
                    }
                    else if (!$element.IsCompleted()) {
                        events.FireEvent($element, EventType.ON_LOAD);
                    }
                }
                else {
                    if (!$element.IsCached()) {
                        ElementManager.ClearCssProperty(id, "overflow");
                        ElementManager.ClearCssProperty(id, "overflowX");
                        ElementManager.ClearCssProperty(id, "overflowY");
                        ElementManager.ClearCssProperty(id + "_PanelContentEnvelop", "float");
                        ElementManager.ClearCssProperty(id + "_PanelContentEnvelop", "overflow");
                        ElementManager.ClearCssProperty(id + "_PanelContentEnvelop", "overflowX");
                        ElementManager.ClearCssProperty(id + "_PanelContentEnvelop", "overflowY");
                        ElementManager.ClearCssProperty(id + "_PanelContentEnvelop", "width");
                        ElementManager.ClearCssProperty(id + "_PanelContentEnvelop", "height");
                        ElementManager.ClearCssProperty(id + "_PanelContent", "width");
                        ElementManager.ClearCssProperty(id + "_PanelContent", "height");
                        ElementManager.setSize(id, $element.Width() - ElementManager.getWidthOffset($element.Id()), $element.Height() - ElementManager.getHeightOffset($element.Id()));
                        ElementManager.setCssProperty(id, "overflow-x", "hidden");
                        ElementManager.setCssProperty(id, "overflow-y", "hidden");
                        ElementManager.setCssProperty(id + "_PanelEnvelop", "float", "left");
                        ElementManager.setCssProperty(id + "_PanelContentEnvelop", "float", "left");
                        ElementManager.setCssProperty(id + "_PanelContentEnvelop", "overflow-x", "hidden");
                        ElementManager.setCssProperty(id + "_PanelContentEnvelop", "overflow-y", "hidden");
                        elementClass.resize($element);
                    }
                    if ($element.IsCompleted()) {
                        EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_SHOW);
                    }
                }
            }
        }
    }
    /**
     * Provide panel's scroll bars update as reaction on panel content focus.
     * @param {EventArgs} $eventArgs Event args, which should be processed.
     * @param {GuiObjectManager} [$manager] Provide gui object manager instance.
     * @param {Reflection} [$reflection] Provide reflection instance.
     * @returns {void}
     */
    static ContentFocusHandler($eventArgs, $manager, $reflection) {
        let element = $eventArgs.Owner();
        if (!ObjectValidator.IsEmptyOrNull(element.Parent())) {
            element = element.Parent();
            if ($reflection.IsMemberOf(element, BasePanel)) {
                EventsManager.getInstanceSingleton().FireAsynchronousMethod(() => {
                    const elementClass = $reflection.getClass(element.getClassName());
                    elementClass.resize(element);
                }, 100);
            }
        }
    }
    static onHoverEventHandler($eventArgs, $manager, $reflection) {
        $manager.setHovered($eventArgs.Owner(), true);
    }
    static getFirstScrollable($element, $manager, $reflection = Reflection.getInstance(), $orientationType) {
        if (!ObjectValidator.IsEmptyOrNull($element) && !$element.IsPreventingScroll()) {
            if ($reflection.IsMemberOf($element, BasePanel) && $element.Scrollable() && (((ObjectValidator.IsEmptyOrNull($orientationType) || $orientationType === OrientationType.VERTICAL) &&
                ObjectValidator.IsSet($element.verticalScrollBar) && $element.verticalScrollBar.Visible() &&
                ElementManager.IsVisible($element.verticalScrollBar.Id())) ||
                ((ObjectValidator.IsEmptyOrNull($orientationType) || $orientationType === OrientationType.HORIZONTAL) &&
                    (ObjectValidator.IsSet($element.horizontalScrollBar) && $element.horizontalScrollBar.Visible() &&
                        ElementManager.IsVisible($element.horizontalScrollBar.Id()))))) {
                return $element;
            }
            else {
                const instance = $reflection.getClass($element.getClassName());
                if (!ObjectValidator.IsEmptyOrNull(instance) &&
                    ObjectValidator.IsSet(instance.getFirstScrollable)) {
                    return instance.getFirstScrollable($element.Parent(), $manager, $reflection, $orientationType);
                }
                return null;
            }
        }
        else {
            return null;
        }
    }
    static onKeyEventHandler($eventArgs, $manager, $reflection) {
        const hovered = $manager.getHovered();
        if ($reflection.IsMemberOf(hovered, BasePanel) && hovered.Scrollable()) {
            const element = $reflection.getClass(hovered.getClassName())
                .getFirstScrollable(hovered, $manager, $reflection);
            if ($reflection.IsMemberOf(element, BasePanel) && element.Scrollable()) {
                const elementClass = $reflection.getClass(element.getClassName());
                const keyCode = $eventArgs.getKeyCode();
                if (keyCode === KeyMap.UP_ARROW ||
                    keyCode === KeyMap.DOWN_ARROW ||
                    keyCode === KeyMap.LEFT_ARROW ||
                    keyCode === KeyMap.RIGHT_ARROW ||
                    keyCode === KeyMap.SPACE ||
                    keyCode === KeyMap.END ||
                    keyCode === KeyMap.HOME) {
                    $eventArgs.PreventDefault();
                    $manager.setActive(element, true);
                    let position = -1;
                    const eventArgs = new ScrollEventArgs();
                    eventArgs.Owner(element);
                    if (keyCode === KeyMap.UP_ARROW ||
                        keyCode === KeyMap.DOWN_ARROW ||
                        keyCode === KeyMap.SPACE ||
                        keyCode === KeyMap.END ||
                        keyCode === KeyMap.HOME) {
                        if (element.verticalScrollBar.Visible()) {
                            position = elementClass.scrollTop(element);
                            if (position >= 0) {
                                if (keyCode === KeyMap.DOWN_ARROW) {
                                    position += 10;
                                }
                                else if (keyCode === KeyMap.UP_ARROW) {
                                    position -= 15;
                                }
                                else if (keyCode === KeyMap.HOME) {
                                    position = 0;
                                }
                                else if (keyCode === KeyMap.END) {
                                    position = 100;
                                }
                                else {
                                    const content = ElementManager.getElement(element.Id() + "_PanelContentEnvelop");
                                    if (ElementManager.Exists(content)) {
                                        position += Math.ceil(100 / content.clientHeight * content.scrollHeight);
                                    }
                                    else {
                                        position += 50;
                                    }
                                }
                                if (position < 0) {
                                    position = 0;
                                }
                                if (position > 100) {
                                    position = 100;
                                }
                                eventArgs.OrientationType(OrientationType.VERTICAL);
                                position = elementClass.scrollTop(element, position);
                                eventArgs.Position(position);
                                EventsManager.getInstanceSingleton().FireEvent(element, EventType.ON_SCROLL, eventArgs);
                                EventsManager.getInstanceSingleton().FireEvent(BasePanel.ClassName(), EventType.ON_SCROLL, eventArgs);
                                EventsManager.getInstanceSingleton().FireEvent(element, EventType.ON_VERTICAL_SCROLL, eventArgs);
                                EventsManager.getInstanceSingleton()
                                    .FireEvent(BasePanel.ClassName(), EventType.ON_VERTICAL_SCROLL, eventArgs);
                            }
                        }
                    }
                    else {
                        if (element.horizontalScrollBar.Visible()) {
                            position = elementClass.scrollLeft(element);
                            if (position >= 0) {
                                if (keyCode === KeyMap.RIGHT_ARROW) {
                                    position += 10;
                                }
                                else {
                                    position -= 15;
                                }
                                if (position < 0) {
                                    position = 0;
                                }
                                if (position > 100) {
                                    position = 100;
                                }
                                eventArgs.OrientationType(OrientationType.HORIZONTAL);
                                position = elementClass.scrollLeft(element, position);
                                eventArgs.Position(position);
                                EventsManager.getInstanceSingleton()
                                    .FireEvent(element, EventType.ON_SCROLL, eventArgs);
                                EventsManager.getInstanceSingleton()
                                    .FireEvent(BasePanel.ClassName(), EventType.ON_SCROLL, eventArgs);
                                EventsManager.getInstanceSingleton()
                                    .FireEvent(element, EventType.ON_HORIZONTAL_SCROLL, eventArgs);
                                EventsManager.getInstanceSingleton()
                                    .FireEvent(BasePanel.ClassName(), EventType.ON_HORIZONTAL_SCROLL, eventArgs);
                            }
                        }
                    }
                }
            }
        }
    }
    static resize($element) {
        const reflection = Reflection.getInstance();
        if (reflection.IsMemberOf($element, BasePanel)) {
            const scrollBarSizes = BasePanel.getScrollBarSizes($element);
            const elementClass = reflection.getClass($element.getClassName());
            const args = new PanelResizeEventArgs();
            args.Owner($element);
            args.Width($element.Width());
            args.Height($element.Height());
            args.Scrollable($element.Scrollable());
            const envelopWidth = $element.Width() - ElementManager.getWidthOffset($element.Id());
            const envelopHeight = $element.Height() - ElementManager.getHeightOffset($element.Id());
            args.AvailableWidth(envelopWidth - scrollBarSizes.contentOffsetWidth);
            args.AvailableHeight(envelopHeight - scrollBarSizes.contentOffsetHeight);
            args.ScrollBarWidth(envelopWidth - scrollBarSizes.width);
            args.ScrollBarHeight(envelopHeight - scrollBarSizes.height);
            EventsManager.getInstanceSingleton().FireEvent(BasePanel.ClassName(), EventType.BEFORE_RESIZE, args, false);
            EventsManager.getInstanceSingleton().FireEvent($element, EventType.BEFORE_RESIZE, args, false);
            ElementManager.setSize($element.Id(), envelopWidth, envelopHeight);
            ElementManager.setSize($element.Id() + "_PanelContentEnvelop", args.AvailableWidth(), args.AvailableHeight());
            elementClass.contentResizeHandler($element, args.AvailableWidth(), args.AvailableHeight());
            EventsManager.getInstanceSingleton().FireEvent(BasePanel.ClassName(), EventType.ON_RESIZE, args, false);
            EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_RESIZE, args, false);
            EventsManager.getInstanceSingleton().FireEvent(BasePanel.ClassName(), EventType.ON_RESIZE_COMPLETE, args);
            EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_RESIZE_COMPLETE, args);
            $element.getEvents().FireAsynchronousMethod(() => {
                elementClass.scrollBarVisibilityHandler($element);
            }, true, 100);
        }
    }
    static scrollToCurrentPosition($element) {
        const elementClass = Reflection.getInstance().getClass($element.getClassName());
        let position = elementClass.scrollTop($element);
        const eventArgs = new ScrollEventArgs();
        if (position >= 0) {
            eventArgs.Owner($element);
            eventArgs.OrientationType(OrientationType.VERTICAL);
            eventArgs.Position(position);
            EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_SCROLL, eventArgs, false);
            EventsManager.getInstanceSingleton().FireEvent(BasePanel.ClassName(), EventType.ON_SCROLL, eventArgs, false);
            EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_VERTICAL_SCROLL, eventArgs, false);
            EventsManager.getInstanceSingleton().FireEvent(BasePanel.ClassName(), EventType.ON_VERTICAL_SCROLL, eventArgs, false);
        }
        position = elementClass.scrollLeft($element);
        if (position >= 0) {
            eventArgs.Owner($element);
            eventArgs.OrientationType(OrientationType.HORIZONTAL);
            eventArgs.Position(position);
            EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_SCROLL, eventArgs, false);
            EventsManager.getInstanceSingleton().FireEvent(BasePanel.ClassName(), EventType.ON_SCROLL, eventArgs, false);
            EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_HORIZONTAL_SCROLL, eventArgs, false);
            EventsManager.getInstanceSingleton().FireEvent(BasePanel.ClassName(), EventType.ON_HORIZONTAL_SCROLL, eventArgs, false);
        }
    }
    static scrollTop($element, $value) {
        let value = -1;
        const content = ElementManager.getElement($element.Id() + "_PanelContentEnvelop");
        if (ElementManager.Exists(content)) {
            if (ObjectValidator.IsSet($value)) {
                value = Property.PositiveInteger(value, $value);
                content.scrollTop = Math.ceil((content.scrollHeight - content.clientHeight) / 100 * value);
            }
            else {
                value = Math.ceil(100 / (content.scrollHeight - content.clientHeight) * content.scrollTop);
                if (value > 100) {
                    value = 100;
                }
                else if (value < 0 || !ObjectValidator.IsDigit(value)) {
                    value = 0;
                }
            }
        }
        return value;
    }
    static scrollLeft($element, $value) {
        let value = -1;
        const content = ElementManager.getElement($element.Id() + "_PanelContentEnvelop");
        if (ElementManager.Exists(content)) {
            if (ObjectValidator.IsSet($value)) {
                value = Property.PositiveInteger(value, $value);
                content.scrollLeft = Math.ceil((content.scrollWidth - content.clientWidth) / 100 * value);
            }
            else {
                value = Math.ceil(100 / (content.scrollWidth - content.clientWidth) * content.scrollLeft);
                if (value > 100) {
                    value = 100;
                }
                else if (value < 0 || !ObjectValidator.IsDigit(value)) {
                    value = 0;
                }
            }
        }
        return value;
    }
    static contentResizeHandler($element, $contentWidth, $contentHeight) {
        const innerElement = $element.getInnerHtmlMap();
        const envelopSize = new Size();
        envelopSize.Width($contentWidth);
        envelopSize.Height($contentHeight);
        if (innerElement.getGuiTypeTag() === GeneralCssNames.COLUMN ||
            innerElement.getGuiTypeTag() === GeneralCssNames.ROW) {
            const baseObject = innerElement;
            const responsiveElement = baseObject;
            const pseudoWrapper = innerElement.getGuiTypeTag() === GeneralCssNames.ROW ?
                $element.addColumn().Add(responsiveElement) : $element.addRow().Add(responsiveElement);
            innerElement.setWrappingElement(null);
            BasePanel.handleContainerVisibility(innerElement, responsiveElement.getVisibilityStrategy());
            BasePanel.recomputeNestedGuiElementSizes(pseudoWrapper, envelopSize);
            BasePanel.alignNestedChildElements(innerElement, responsiveElement.getAlignment());
            BasePanel.fitToParentNestedChildElements(innerElement, responsiveElement.getFitToParent());
        }
    }
    static onBodyScrollEventHandler($eventArgs, $manager, $reflection) {
        const hovered = $manager.getHovered();
        if ($reflection.IsMemberOf(hovered, BasePanel)) {
            const element = $reflection.getClass(hovered.getClassName())
                .getFirstScrollable(hovered, $manager, $reflection, $eventArgs.OrientationType());
            if ($reflection.IsMemberOf(element, BasePanel) && element.Scrollable()) {
                const elementClass = $reflection.getClass(element.getClassName());
                if (($eventArgs.OrientationType() === OrientationType.VERTICAL &&
                    ObjectValidator.IsSet(element.verticalScrollBar) &&
                    element.verticalScrollBar.Visible() && ElementManager.IsVisible(element.verticalScrollBar.Id())) ||
                    ($eventArgs.OrientationType() === OrientationType.HORIZONTAL &&
                        ObjectValidator.IsSet(element.horizontalScrollBar) &&
                        element.horizontalScrollBar.Visible() && ElementManager.IsVisible(element.horizontalScrollBar.Id()))) {
                    $eventArgs.PreventDefault();
                    let position = -1;
                    if ($eventArgs.OrientationType() === OrientationType.VERTICAL) {
                        position = elementClass.scrollTop(element);
                    }
                    else if ($eventArgs.OrientationType() === OrientationType.HORIZONTAL) {
                        position = elementClass.scrollLeft(element);
                    }
                    if (position >= 0) {
                        if ($eventArgs.DirectionType() === DirectionType.DOWN) {
                            position += element.getScrollIncrement($eventArgs.DirectionType(), $eventArgs.Position());
                        }
                        else {
                            position -= element.getScrollIncrement($eventArgs.DirectionType(), $eventArgs.Position());
                        }
                        if (position < 0) {
                            position = 0;
                        }
                        if (position > 100) {
                            position = 100;
                        }
                        let eventType;
                        const eventArgs = new ScrollEventArgs();
                        eventArgs.Owner(element);
                        eventArgs.OrientationType($eventArgs.OrientationType());
                        if ($eventArgs.OrientationType() === OrientationType.VERTICAL) {
                            element.getEvents().FireAsynchronousMethod(() => {
                                position = elementClass.scrollTop(element, position);
                            }, false);
                            eventType = EventType.ON_VERTICAL_SCROLL;
                        }
                        else if ($eventArgs.OrientationType() === OrientationType.HORIZONTAL) {
                            element.getEvents().FireAsynchronousMethod(() => {
                                position = elementClass.scrollLeft(element, position);
                            }, false);
                            eventType = EventType.ON_HORIZONTAL_SCROLL;
                        }
                        eventArgs.Position(position);
                        EventsManager.getInstanceSingleton().FireEvent(element, EventType.ON_SCROLL, eventArgs);
                        EventsManager.getInstanceSingleton().FireEvent(BasePanel.ClassName(), EventType.ON_SCROLL, eventArgs);
                        EventsManager.getInstanceSingleton().FireEvent(element, eventType, eventArgs);
                        EventsManager.getInstanceSingleton().FireEvent(BasePanel.ClassName(), eventType, eventArgs);
                    }
                }
            }
        }
    }
    static scrollBarVisibilityHandler($element) {
        const args = new PanelResizeEventArgs();
        args.Owner($element);
        args.Width($element.Width());
        args.Height($element.Height());
        args.Scrollable($element.Scrollable());
        args.AvailableWidth($element.Width() - ElementManager.getWidthOffset($element.Id()));
        args.AvailableHeight($element.Height() - ElementManager.getHeightOffset($element.Id()));
        ElementManager.setSize($element.Id() + "_PanelContentEnvelop", args.AvailableWidth(), args.AvailableHeight());
        let scrollBarChange = {
            horizontal: false,
            vertical: false
        };
        if ($element.Scrollable()) {
            let contentSize;
            if ($element.getInnerHtmlMap().getGuiTypeTag() === GeneralCssNames.ROW ||
                $element.getInnerHtmlMap().getGuiTypeTag() === GeneralCssNames.COLUMN) {
                contentSize = new Size($element.getInnerHtmlMap().getId(), true);
            }
            else {
                contentSize = new Size($element.Id() + "_PanelContent", true);
            }
            if (contentSize.Width() > args.AvailableWidth() || contentSize.Height() > args.AvailableHeight()) {
                if (contentSize.Height() > args.AvailableHeight()) {
                    scrollBarChange.vertical = BasePanel.showScrollBar($element, true, OrientationType.VERTICAL).vertical;
                }
                else {
                    scrollBarChange.vertical = BasePanel.showScrollBar($element, false, OrientationType.VERTICAL).vertical;
                }
                if (contentSize.Width() > args.AvailableWidth()) {
                    scrollBarChange.horizontal = BasePanel.showScrollBar($element, true, OrientationType.HORIZONTAL).horizontal;
                }
                else {
                    scrollBarChange.horizontal = BasePanel.showScrollBar($element, false, OrientationType.HORIZONTAL).horizontal;
                }
            }
            else {
                scrollBarChange = BasePanel.showScrollBar($element, false);
            }
        }
        else {
            scrollBarChange = BasePanel.showScrollBar($element, false);
        }
        const scrollBarSizes = BasePanel.getScrollBarSizes($element);
        args.ScrollBarWidth(args.AvailableWidth() - scrollBarSizes.width);
        args.ScrollBarHeight(args.AvailableHeight() - scrollBarSizes.height);
        args.AvailableWidth(args.AvailableWidth() - scrollBarSizes.contentOffsetWidth);
        args.AvailableHeight(args.AvailableHeight() - scrollBarSizes.contentOffsetHeight);
        ElementManager.setSize($element.Id() + "_PanelContentEnvelop", args.AvailableWidth(), args.AvailableHeight());
        if (scrollBarChange.horizontal || scrollBarChange.vertical) {
            const elementClass = Reflection.getInstance().getClass($element.getClassName());
            elementClass.contentResizeHandler($element, args.AvailableWidth(), args.AvailableHeight());
            EventsManager.getInstanceSingleton().FireEvent(BasePanel.ClassName(), EventType.ON_RESIZE, args, false);
            EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_RESIZE, args, false);
            EventsManager.getInstanceSingleton().FireEvent(BasePanel.ClassName(), EventType.ON_RESIZE_COMPLETE, args);
            EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_RESIZE_COMPLETE, args);
            $element.getEvents().FireAsynchronousMethod(() => {
                Reflection.getInstance().getClass($element.getClassName()).scrollToCurrentPosition($element);
            });
        }
    }
    static showScrollBar($element, $value, $type) {
        let vertical = false;
        let horizontal = false;
        const show = ($element) => {
            $element.getEvents().FireAsynchronousMethod(() => {
                ElementManager.ChangeOpacity($element, DirectionType.UP, 10);
            });
        };
        if (ObjectValidator.IsSet($element.verticalScrollBar)) {
            const verticalScrollBarId = $element.verticalScrollBar.Id();
            const isVerticalVisible = ElementManager.IsVisible(verticalScrollBarId);
            if ((!ObjectValidator.IsSet($type) || $type === OrientationType.VERTICAL) &&
                ((isVerticalVisible && !$value) || (!isVerticalVisible && $value))) {
                $element.verticalScrollBar.Visible($value);
                vertical = true;
                if ($value) {
                    ElementManager.setOpacity(verticalScrollBarId, 0);
                    if ($element.verticalScrollBar.IsLoaded()) {
                        show($element.verticalScrollBar);
                    }
                    else {
                        $element.verticalScrollBar.getEvents().setOnLoad(() => {
                            show($element.verticalScrollBar);
                        });
                    }
                }
            }
        }
        if (ObjectValidator.IsSet($element.horizontalScrollBar)) {
            const horizontalScrollBarId = $element.horizontalScrollBar.Id();
            const isHorizontalVisible = ElementManager.IsVisible(horizontalScrollBarId);
            if ((!ObjectValidator.IsSet($type) || $type === OrientationType.HORIZONTAL) &&
                ((isHorizontalVisible && !$value) || (!isHorizontalVisible && $value))) {
                $element.horizontalScrollBar.Visible($value);
                horizontal = true;
                if ($value) {
                    ElementManager.setOpacity(horizontalScrollBarId, 0);
                    if ($element.horizontalScrollBar.IsLoaded()) {
                        show($element.horizontalScrollBar);
                    }
                    else {
                        $element.horizontalScrollBar.getEvents().setOnLoad(() => {
                            show($element.horizontalScrollBar);
                        });
                    }
                }
            }
        }
        return { horizontal, vertical };
    }
    static getScrollBarSizes($panel) {
        let width = 0;
        let height = 0;
        let contentOffsetHeight = 0;
        let contentOffsetWidth = 0;
        if (ObjectValidator.IsSet($panel.verticalScrollBar) && ElementManager.IsVisible($panel.verticalScrollBar)) {
            width = ElementManager.getOffsetWidth($panel.verticalScrollBar.Id());
            contentOffsetWidth = ElementManager.getOffsetWidth($panel.verticalScrollBar.Id() + "_ContentOffset");
        }
        if (ObjectValidator.IsSet($panel.horizontalScrollBar) && ElementManager.IsVisible($panel.horizontalScrollBar)) {
            height = ElementManager.getOffsetHeight($panel.horizontalScrollBar.Id());
            contentOffsetHeight = ElementManager.getOffsetHeight($panel.horizontalScrollBar.Id() + "_ContentOffset");
        }
        return { contentOffsetHeight, contentOffsetWidth, height, width };
    }
    static onCommonsShow($eventArgs, $manager, $reflection) {
        const commons = $eventArgs.Owner();
        const basePanel = commons.Parent();
        if (!ObjectValidator.IsEmptyOrNull(basePanel) && basePanel.IsLoaded() && $reflection.Implements(basePanel, IBasePanel)) {
            const childElement = basePanel.getInnerHtmlMap();
            if (childElement.Implements(IGuiElement) && childElement.Implements(IResponsiveElement)) {
                if (BasePanel.isVisibilityToggleHandled(commons)) {
                    Reflection.getInstance().getClass(basePanel.getClassName()).resize(basePanel);
                }
            }
        }
    }
    static onCommonsHide($eventArgs, $manager, $reflection) {
        const commons = $eventArgs.Owner();
        const basePanel = commons.Parent();
        if (!ObjectValidator.IsEmptyOrNull(basePanel) && basePanel.IsLoaded() && $reflection.Implements(basePanel, IBasePanel)) {
            const childElement = basePanel.getInnerHtmlMap();
            if (childElement.Implements(IGuiElement) && childElement.Implements(IResponsiveElement)) {
                if (BasePanel.isVisibilityToggleHandled(commons)) {
                    Reflection.getInstance().getClass(basePanel.getClassName()).resize(basePanel);
                }
            }
        }
    }
    static isVisibilityToggleHandled($target) {
        let wrapper = $target.getWrappingContainer();
        while (!ObjectValidator.IsEmptyOrNull(wrapper)) {
            if (wrapper.Implements(IGuiElement) && wrapper.Implements(IResponsiveElement)) {
                if (!ObjectValidator.IsEmptyOrNull(wrapper.getVisibilityStrategy())) {
                    return wrapper.getVisibilityStrategy() !== VisibilityStrategy.NONE;
                }
            }
            else {
                return false;
            }
            wrapper = wrapper.getWrappingElement();
        }
        return false;
    }
    static handleContainerVisibility($element, $baseVisibilityStrategy) {
        const visibility = { commonsNum: 0, visibleCommons: 0 };
        let index = 0;
        const childElements = $element.getGuiChildElements();
        const size = childElements.Length();
        if (size > 0) {
            for (index; index < size; index++) {
                const childElement = childElements.getItem(index);
                if (childElement.Implements(IGuiElement) && childElement.Implements(IResponsiveElement)) {
                    const guiElement = childElement;
                    if (guiElement.getGuiTypeTag() === GeneralCssNames.COLUMN ||
                        guiElement.getGuiTypeTag() === GeneralCssNames.ROW) {
                        const baseStrategy = VisibilityStrategy
                            .PriorityValue($baseVisibilityStrategy, childElement.getVisibilityStrategy());
                        const childVisibility = BasePanel.handleContainerVisibility(guiElement, baseStrategy);
                        visibility.commonsNum += childVisibility.commonsNum;
                        visibility.visibleCommons += childVisibility.visibleCommons;
                    }
                }
                else if (childElement.Implements(IGuiCommons)) {
                    const baseStrategy = VisibilityStrategy.PriorityValue($baseVisibilityStrategy);
                    const strategy = VisibilityStrategy.Normalize(baseStrategy);
                    const guiCommons = childElement;
                    const columnId = guiCommons.Id() + "_" + GeneralCssNames.COLUMN;
                    visibility.commonsNum += 1;
                    if (guiCommons.Visible()) {
                        visibility.visibleCommons += 1;
                        ElementManager.setCssProperty(columnId, "display", "");
                    }
                    else {
                        if (strategy === VisibilityStrategy.COLLAPSE_EMPTY) {
                            ElementManager.setCssProperty(columnId, "display", "none");
                        }
                        else {
                            ElementManager.setCssProperty(columnId, "display", "");
                        }
                    }
                }
            }
        }
        const strategy = VisibilityStrategy.Normalize($baseVisibilityStrategy);
        const isContainerVisible = $element.getVisible() !== false &&
            (visibility.commonsNum === 0 || visibility.visibleCommons !== 0);
        if (strategy === VisibilityStrategy.COLLAPSE_EMPTY && !isContainerVisible) {
            ElementManager.setCssProperty($element.getId(), "display", "none");
        }
        else {
            ElementManager.setCssProperty($element.getId(), "display", "");
        }
        return visibility;
    }
    static recomputeNestedGuiElementSizes($element, $containerSize, $widthOfColumn, $heightOfRow) {
        const childElements = $element.getGuiChildElements();
        const size = childElements.Length();
        const sizeInfo = BasePanel.getContainerSizeInfo($element, $containerSize, $widthOfColumn, $heightOfRow);
        if ($element.getGuiTypeTag() === GeneralCssNames.COLUMN) {
            ElementManager.setCssProperty($element.getId(), "width", $containerSize.Width() + "px");
        }
        else if ($element.getGuiTypeTag() === GeneralCssNames.ROW) {
            ElementManager.setCssProperty($element.getId(), "height", $containerSize.Height() + "px");
        }
        BasePanel.handleInnerPaddings($element, sizeInfo, $containerSize);
        let index = 0;
        for (index; index < size; index++) {
            const childElement = childElements.getItem(index);
            if (childElement.Implements(IGuiElement) && childElement.Implements(IResponsiveElement)) {
                const element = childElement;
                if (ElementManager.getCssValue(element.getId(), "display") !== "none") {
                    const priorityWidth = PropagableNumber.PriorityValue($widthOfColumn, childElement.getWidthOfColumn());
                    const priorityHeight = PropagableNumber.PriorityValue($heightOfRow, childElement.getHeightOfRow());
                    const isWidthSet = !ObjectValidator.IsEmptyOrNull(priorityWidth) &&
                        priorityWidth.Normalize($containerSize.Width(), UnitType.PX) > 0;
                    const isHeightSet = !ObjectValidator.IsEmptyOrNull(priorityHeight) &&
                        priorityHeight.Normalize($containerSize.Height(), UnitType.PX) > 0;
                    const containerSize = new Size();
                    if (element.getGuiTypeTag() === GeneralCssNames.COLUMN) {
                        containerSize.Height($containerSize.Height());
                        if (isWidthSet) {
                            containerSize.Width(priorityWidth.Normalize($containerSize.Width(), UnitType.PX));
                        }
                        else if (!sizeInfo.elementsWithoutWidth.IsEmpty()) {
                            containerSize.Width(sizeInfo.remainingWidth > 0 ?
                                Math.round(sizeInfo.remainingWidth / sizeInfo.elementsWithoutWidth.Length()) : 0);
                        }
                        BasePanel.recomputeNestedGuiElementSizes(element, containerSize, priorityWidth, priorityHeight);
                    }
                    else if (element.getGuiTypeTag() === GeneralCssNames.ROW) {
                        containerSize.Width($containerSize.Width());
                        if (isHeightSet) {
                            containerSize.Height(priorityHeight.Normalize($containerSize.Height(), UnitType.PX));
                        }
                        else if (!sizeInfo.elementsWithoutHeight.IsEmpty()) {
                            containerSize.Height(sizeInfo.remainingHeight > 0 ?
                                Math.round(sizeInfo.remainingHeight / sizeInfo.elementsWithoutHeight.Length()) : 0);
                        }
                        BasePanel.recomputeNestedGuiElementSizes(element, containerSize, priorityWidth, priorityHeight);
                    }
                }
            }
            else if (childElement.Implements(IGuiCommons)) {
                const commons = childElement;
                const elementId = commons.Id() + "_" + GeneralCssNames.COLUMN;
                if (ElementManager.getCssValue(elementId, "display") !== "none") {
                    let width = null;
                    if (commons.getWrappingContainer().getGuiTypeTag() !== GeneralCssNames.COLUMN &&
                        !ObjectValidator.IsEmptyOrNull($widthOfColumn) &&
                        $widthOfColumn.Normalize($containerSize.Width(), UnitType.PX) > 0) {
                        width = $widthOfColumn.Normalize($containerSize.Width(), UnitType.PX);
                    }
                    else {
                        if (sizeInfo.elementsWithoutWidth.IsEmpty()) {
                            width = sizeInfo.remainingWidth;
                        }
                        else {
                            width = Math.round(sizeInfo.remainingWidth / sizeInfo.elementsWithoutWidth.Length());
                        }
                    }
                    ElementManager.setCssProperty(elementId, "height", $containerSize.Height() + "px");
                    if (width !== null) {
                        ElementManager.setCssProperty(elementId, "width", width + "px");
                    }
                }
            }
        }
    }
    static getContainerSizeInfo($element, $containerSize, $widthOfColumn, $heightOfRow) {
        let index = 0;
        const childElements = $element.getGuiChildElements();
        const size = childElements.Length();
        let remainingWidth = $containerSize.Width();
        let remainingHeight = $containerSize.Height();
        const elementsWithoutWidth = new ArrayList();
        const elementsWithoutHeight = new ArrayList();
        for (index; index < size; index++) {
            const childElement = childElements.getItem(index);
            let priorityWidth;
            let priorityHeight;
            let isVisible = false;
            if (childElement.Implements(IGuiElement) && childElement.Implements(IResponsiveElement)) {
                const wrapper = childElement;
                if (wrapper.getGuiTypeTag() === GeneralCssNames.COLUMN) {
                    if (ElementManager.getCssValue(wrapper.getId(), "display") !== "none") {
                        priorityWidth = PropagableNumber.PriorityValue($widthOfColumn, wrapper.getWidthOfColumn());
                        isVisible = true;
                    }
                }
                else if (wrapper.getGuiTypeTag() === GeneralCssNames.ROW) {
                    if (ElementManager.getCssValue(wrapper.getId(), "display") !== "none") {
                        priorityHeight = PropagableNumber.PriorityValue($heightOfRow, wrapper.getHeightOfRow());
                        isVisible = true;
                    }
                }
            }
            else if (childElement.Implements(IGuiCommons)) {
                const commons = childElement;
                if (ElementManager.getCssValue(commons.Id() + "_" + GeneralCssNames.COLUMN, "display") !== "none") {
                    if (commons.getWrappingContainer().getGuiTypeTag() !== GeneralCssNames.COLUMN) {
                        priorityWidth = $widthOfColumn;
                    }
                    isVisible = true;
                }
            }
            if (isVisible) {
                if (!ObjectValidator.IsEmptyOrNull(priorityWidth) &&
                    priorityWidth.Normalize($containerSize.Width(), UnitType.PX) > 0) {
                    remainingWidth = remainingWidth - priorityWidth.Normalize($containerSize.Width(), UnitType.PX);
                }
                else {
                    elementsWithoutWidth.Add(childElement);
                }
                if (!ObjectValidator.IsEmptyOrNull(priorityHeight) &&
                    priorityHeight.Normalize($containerSize.Height(), UnitType.PX) > 0) {
                    remainingHeight = remainingHeight - priorityHeight.Normalize($containerSize.Height(), UnitType.PX);
                }
                else {
                    elementsWithoutHeight.Add(childElement);
                }
            }
        }
        return { elementsWithoutHeight, elementsWithoutWidth, remainingHeight, remainingWidth };
    }
    static alignNestedChildElements($element, $baseAlignment) {
        let index = 0;
        const childElements = $element.getGuiChildElements();
        const size = childElements.Length();
        BasePanel.recomputeInnerPaddings($element, Alignment.Normalize($baseAlignment));
        for (index; index < size; index++) {
            const childElement = childElements.getItem(index);
            if (childElement.Implements(IGuiElement) && childElement.Implements(IResponsiveElement)) {
                const element = childElement;
                const responsiveElement = childElement;
                if (element.getGuiTypeTag() === "GuiWrapper") {
                    if (ObjectValidator.IsSet($baseAlignment)) {
                        ElementManager.setClassName($element.getId(), Alignment.StyleClassName($baseAlignment, ElementManager.getClassName($element.getId())));
                    }
                }
                else if (element.getGuiTypeTag() === GeneralCssNames.COLUMN ||
                    element.getGuiTypeTag() === GeneralCssNames.ROW) {
                    BasePanel.alignNestedChildElements(element, Alignment.PriorityValue($baseAlignment, responsiveElement.getAlignment()));
                }
            }
            else if (childElement.Implements(IGuiCommons)) {
                const element = childElement;
                let alignment = element.getWrappingContainer().getAlignment();
                if (ObjectValidator.IsEmptyOrNull(alignment)) {
                    alignment = $baseAlignment;
                }
                if (ObjectValidator.IsSet(alignment)) {
                    const wrapperId = element.Id() + "_" + GeneralCssNames.COLUMN;
                    ElementManager.setClassName(wrapperId, Alignment.StyleClassName(alignment, ElementManager.getClassName(wrapperId)));
                }
            }
        }
    }
    static fitToParentNestedChildElements($element, $baseFitToParent) {
        if (!ObjectValidator.IsEmptyOrNull($element.getId())) {
            let index = 0;
            const childElements = $element.getGuiChildElements();
            const size = childElements.Length();
            for (index; index < size; index++) {
                const childElement = childElements.getItem(index);
                let fitToParent;
                if (((childElement.Implements(IGuiElement) && childElement.Implements(IResponsiveElement)) ||
                    childElement.Implements(IGuiCommons)) &&
                    ObjectValidator.IsSet(childElement.getFitToParent())) {
                    fitToParent = childElement.getFitToParent();
                }
                else {
                    fitToParent = $baseFitToParent;
                }
                if (childElement.Implements(IGuiElement) && childElement.Implements(IResponsiveElement)) {
                    const element = childElement;
                    if (element.getGuiTypeTag() === GeneralCssNames.COLUMN ||
                        element.getGuiTypeTag() === GeneralCssNames.ROW) {
                        BasePanel.fitToParentNestedChildElements(element, fitToParent);
                    }
                }
                else if (childElement.Implements(IGuiCommons)) {
                    const element = childElement;
                    if (element.Visible()) {
                        const columnId = element.Id() + "_" + GeneralCssNames.COLUMN;
                        if (ElementManager.Exists(columnId)) {
                            if (ObjectValidator.IsSet(fitToParent) && fitToParent !== FitToParent.NONE) {
                                const width = ElementManager.getCssIntegerValue(columnId, "width");
                                const height = ElementManager.getCssIntegerValue(columnId, "height");
                                const isWidthSet = ObjectValidator.IsSet(width) && width > 0;
                                const isHeightSet = ObjectValidator.IsSet(height) && height > 0;
                                const wrapperId = element.Id() + "_GuiWrapper";
                                ElementManager.setClassName(wrapperId, FitToParent.StyleClassName(fitToParent, ElementManager.getClassName(wrapperId)));
                                switch (fitToParent) {
                                    case FitToParent.FULL:
                                        if (isHeightSet && element.Height() !== height) {
                                            element.Height(height);
                                        }
                                        if (isWidthSet && element.Width() !== width) {
                                            element.Width(width);
                                        }
                                        break;
                                    case FitToParent.HORIZONTAL:
                                        if (isWidthSet && element.Width() !== width) {
                                            element.Width(width);
                                        }
                                        break;
                                    case FitToParent.VERTICAL:
                                        if (isHeightSet && element.Height() !== height) {
                                            element.Height(height);
                                        }
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    static handleInnerPaddings($element, $sizeInfo, $containerSize) {
        const isRow = $element.getGuiTypeTag() === GeneralCssNames.ROW;
        const isColumn = $element.getGuiTypeTag() === GeneralCssNames.COLUMN;
        const isCreate = (isColumn && $sizeInfo.elementsWithoutHeight.IsEmpty() && $sizeInfo.remainingHeight !== $containerSize.Height()) ||
            (isRow && $sizeInfo.elementsWithoutWidth.IsEmpty() && $sizeInfo.remainingWidth !== $containerSize.Width());
        let divBefore;
        let divAfter;
        if (ElementManager.Exists($element.getId() + "_" + GeneralCssNames.PADDING_BEFORE) &&
            ElementManager.Exists($element.getId() + "_" + GeneralCssNames.PADDING_AFTER)) {
            divBefore = ElementManager.getElement($element.getId() + "_" + GeneralCssNames.PADDING_BEFORE);
            divAfter = ElementManager.getElement($element.getId() + "_" + GeneralCssNames.PADDING_AFTER);
        }
        else if (isCreate) {
            const element = ElementManager.getElement($element.getId());
            if (!ObjectValidator.IsEmptyOrNull(element)) {
                divBefore = document.createElement("div");
                divAfter = document.createElement("div");
                divBefore.id = $element.getId() + "_" + GeneralCssNames.PADDING_BEFORE;
                divAfter.id = $element.getId() + "_" + GeneralCssNames.PADDING_AFTER;
                let innerGuiType;
                if (isRow) {
                    innerGuiType = GeneralCssNames.COLUMN;
                }
                else {
                    innerGuiType = GeneralCssNames.ROW;
                }
                divBefore.setAttribute("guiType", innerGuiType);
                divAfter.setAttribute("guiType", innerGuiType);
                const parentHtmlElement = ElementManager.getElement($element.getId());
                parentHtmlElement.insertBefore(divBefore, parentHtmlElement.firstChild);
                parentHtmlElement.appendChild(divAfter);
            }
        }
        if (!ObjectValidator.IsEmptyOrNull(divBefore)) {
            if (isColumn) {
                divBefore.style.height = "0";
                divAfter.style.height = Math.max(0, isCreate ? $sizeInfo.remainingHeight : 0) + "px";
            }
            else if (isRow) {
                divBefore.style.width = "0";
                divAfter.style.width = Math.max(0, isCreate ? $sizeInfo.remainingWidth : 0) + "px";
            }
        }
    }
    static recomputeInnerPaddings($element, $alignment) {
        if (ObjectValidator.IsSet($element.getId()) &&
            ElementManager.Exists($element.getId() + "_" + GeneralCssNames.PADDING_BEFORE) &&
            ElementManager.Exists($element.getId() + "_" + GeneralCssNames.PADDING_AFTER)) {
            const beforeElement = ElementManager.getElement($element.getId() + "_" + GeneralCssNames.PADDING_BEFORE);
            const afterElement = ElementManager.getElement($element.getId() + "_" + GeneralCssNames.PADDING_AFTER);
            if ($element.getGuiTypeTag() === GeneralCssNames.COLUMN && ObjectValidator.IsSet(afterElement.style.height)) {
                switch ($alignment) {
                    case Alignment.TOP:
                    case Alignment.TOP_LEFT:
                    case Alignment.TOP_RIGHT:
                        beforeElement.style.height = "0";
                        afterElement.style.height = "0";
                        break;
                    case Alignment.LEFT:
                    case Alignment.CENTER:
                    case Alignment.RIGHT:
                        const height = parseFloat(afterElement.style.height); // eslint-disable-line no-case-declarations
                        const beforeHeight = Math.round(height / 2); // eslint-disable-line no-case-declarations
                        const afterHeight = height - beforeHeight; // eslint-disable-line no-case-declarations
                        beforeElement.style.height = beforeHeight + "px";
                        afterElement.style.height = afterHeight + "px";
                        break;
                    case Alignment.BOTTOM_LEFT:
                    case Alignment.BOTTOM:
                    case Alignment.BOTTOM_RIGHT:
                        beforeElement.style.height = afterElement.style.height;
                        afterElement.style.height = "0";
                        break;
                }
            }
            else if ($element.getGuiTypeTag() === GeneralCssNames.ROW && ObjectValidator.IsSet(afterElement.style.width)) {
                switch ($alignment) {
                    case Alignment.TOP:
                    case Alignment.CENTER:
                    case Alignment.BOTTOM:
                        const width = parseFloat(afterElement.style.width); // eslint-disable-line no-case-declarations
                        const beforeWidth = Math.round(width / 2); // eslint-disable-line no-case-declarations
                        const afterWidth = width - beforeWidth; // eslint-disable-line no-case-declarations
                        beforeElement.style.width = beforeWidth + "px";
                        afterElement.style.width = afterWidth + "px";
                        break;
                    case Alignment.TOP_RIGHT:
                    case Alignment.RIGHT:
                    case Alignment.BOTTOM_RIGHT:
                        beforeElement.style.width = afterElement.style.width;
                        afterElement.style.width = "0";
                        break;
                }
            }
        }
    }
    static onWindowResizeEventHandler() {
        const manager = GuiObjectManager.getInstanceSingleton();
        const elements = manager.getType(BasePanel);
        if (!elements.IsEmpty()) {
            elements.foreach(($panel) => {
                if ($panel.FitToWindow()) {
                    $panel.fitToWindowHandler($panel.getWindowSize());
                }
            });
        }
    }
    constructor($id) {
        super($id);
        const loaderIconClass = this.getLoaderIconClass();
        if (!ObjectValidator.IsEmptyOrNull(loaderIconClass)) {
            this.loaderIcon = new loaderIconClass(null);
        }
        const loaderTextClass = this.getLoaderTextClass();
        if (!ObjectValidator.IsEmptyOrNull(loaderTextClass)) {
            this.loaderText = new loaderTextClass("Loading, please wait ...");
        }
        const scrollBarClass = this.getScrollBarClass();
        if (!ObjectValidator.IsEmptyOrNull(scrollBarClass)) {
            this.verticalScrollBar = new scrollBarClass(OrientationType.VERTICAL, this.Id() + "_Vertical_ScrollBar");
            this.verticalScrollBar.StyleClassName("PanelScrollBar");
            this.verticalScrollBar.Visible(false);
            this.verticalScrollBar.Size(50);
            this.horizontalScrollBar = new scrollBarClass(OrientationType.HORIZONTAL, this.Id() + "_Horizontal_ScrollBar");
            this.horizontalScrollBar.StyleClassName("PanelScrollBar");
            this.horizontalScrollBar.Visible(false);
            this.horizontalScrollBar.Size(50);
        }
        this.childPanelList = new ArrayList();
        this.asyncChildLoaders = new ArrayList();
        this.asyncInnerCode = this.addElement();
        this.width = -1;
        this.height = -1;
    }
    /**
     * @returns {IBasePanelEvents} Returns events connected with the element.
     */
    getEvents() {
        return super.getEvents();
    }
    /**
     * @param {PanelContentType} [$type] Set type of output content, which should be rendered.
     * @returns {PanelContentType} Returns type of output content, which will be rendered.
     */
    ContentType($type) {
        if (ObjectValidator.IsSet($type)) {
            this.contentType = $type;
        }
        else if (!ObjectValidator.IsSet(this.contentType)) {
            this.contentType = PanelContentType.WITH_ELEMENT_WRAPPER;
        }
        return this.contentType;
    }
    /**
     * @param {IGuiCommons} $element Specify GUI element, which should be added to the panel's content.
     * @param {string} [$variableName] Specify variable name, which should be used as parent's public field.
     * @returns {void}
     */
    AddChild($element, $variableName) {
        if (!ObjectValidator.IsEmptyOrNull($element)) {
            const loader = ($element) => {
                $element.Parent(this);
                $element.InstanceOwner(this.InstanceOwner());
                if (!ObjectValidator.IsEmptyOrNull($variableName)) {
                    this[$variableName] = $element;
                    $element.InstancePath(this.InstancePath() + "." + $variableName);
                }
                this.getChildElements().Add($element, $element.Id());
                if (this.IsCompleted()) {
                    const visible = $element.Visible();
                    if (visible) {
                        $element.Visible(false);
                    }
                    ElementManager.getElement(this.Id() + "_PanelContent")
                        .appendChild(new GuiElement().Add($element).ToDOMElement(this.outputEndOfLine));
                    if (visible) {
                        $element.Visible(true);
                    }
                }
                else {
                    $element.Visible(true);
                }
            };
            if (this.IsCompleted()) {
                loader($element);
            }
            else {
                this.getInnerHtmlMap().Add($element);
                if (ObjectValidator.IsEmptyOrNull(this.asyncChildrenLoader)) {
                    this.asyncChildrenLoader = new TimeoutManager();
                    this.getEvents().setOnComplete(() => {
                        this.asyncChildrenLoader.Execute();
                    });
                }
                this.asyncChildrenLoader.Add(() => {
                    loader($element);
                });
            }
        }
    }
    /**
     * @returns {ArrayList<IBasePanelViewer>} Returns list of child panels, which has been subscribed to this panel.
     */
    getChildPanelList() {
        return this.childPanelList;
    }
    /**
     * @param {string|BasePanel} $instanceOrId Child panel instance or id.
     * @param {BasePanelViewerArgs} $args Arguments object, which should be set to the desired child panel.
     * @returns {void}
     */
    setChildPanelArgs($instanceOrId, $args) {
        if (!ObjectValidator.IsString($instanceOrId) && ObjectValidator.IsSet($instanceOrId.Id)) {
            $instanceOrId = $instanceOrId.Id();
        }
        if (!ObjectValidator.IsEmptyOrNull($args) && this.childPanelList.KeyExists($instanceOrId)) {
            this.childPanelList.getItem($instanceOrId).ViewerArgs($args);
        }
    }
    /**
     * @param {string|BasePanelViewerArgs} [$value] Panel value or arguments object, which should be set to the panel.
     * @returns {string|BasePanelViewerArgs} Returns panel's value or arguments object, if value has been specified, otherwise null.
     */
    Value($value) {
        if (!ObjectValidator.IsEmptyOrNull(this.Parent()) && this.Parent().IsMemberOf(BasePanel)) {
            if (ObjectValidator.IsSet($value)) {
                this.Parent().setChildPanelArgs(this.Id(), $value);
            }
            if (this.childPanelList.KeyExists(this.Id())) {
                return this.childPanelList.getItem(this.Id()).ViewerArgs();
            }
        }
        return super.Value($value);
    }
    /**
     * @param {boolean} [$value] Specify panel's scrolling ability.
     * @returns {boolean} Returns true, if panel can be scrolled.
     */
    Scrollable($value) {
        if (!ObjectValidator.IsSet(this.scrollable)) {
            this.scrollable = false;
        }
        this.scrollable = Property.Boolean(this.scrollable, $value);
        if (this.scrollable) {
            this.getGuiOptions().Add(GuiOptionType.SCROLLABLE);
        }
        return this.scrollable;
    }
    /**
     * @param {number} [$value] Specify panel's width.
     * @returns {number} Returns panel's width.
     */
    Width($value) {
        this.width = Property.PositiveInteger(this.width, $value);
        if (!ObjectValidator.IsEmptyOrNull($value) && this.IsLoaded() && this.Visible()) {
            Reflection.getInstance().getClass(this.getClassName()).resize(this);
        }
        return this.width;
    }
    /**
     * @param {number} [$value] Specify panel's height.
     * @returns {number} Returns panel's height.
     */
    Height($value) {
        this.height = Property.PositiveInteger(this.height, $value);
        if (!ObjectValidator.IsEmptyOrNull($value) && this.IsLoaded() && this.Visible()) {
            Reflection.getInstance().getClass(this.getClassName()).resize(this);
        }
        return this.height;
    }
    /**
     * @param {boolean} [$value] Specify whether or not panel fits the window.
     * @returns {boolean} Returns whether or not panel fits the window.
     */
    FitToWindow($value) {
        if ($value) {
            BasePanel.onWindowResizeEventHandler();
        }
        return this.fitToWindow = Property.Boolean(this.fitToWindow, $value);
    }
    /**
     * @returns {number} Returns current scroll top value in percentage.
     */
    getScrollTop() {
        const thisClass = Reflection.getInstance().getClass(this.getClassName());
        return thisClass.scrollTop(this);
    }
    /**
     * @returns {number} Returns current scroll left value in percentage.
     */
    getScrollLeft() {
        const thisClass = Reflection.getInstance().getClass(this.getClassName());
        return thisClass.scrollLeft(this);
    }
    /**
     * @param {string} [$EOL] Specify end of line which should be used for rendering
     * @returns {string} Returns panel's content suitable for renderings at the screen.
     */
    Draw($EOL) {
        if (ObjectValidator.IsEmptyOrNull($EOL)) {
            $EOL = StringUtils.NewLine(false);
        }
        if (this.ContentType() === PanelContentType.WITHOUT_ELEMENT_WRAPPER) {
            return this.guiContent().Draw($EOL + "            ") + $EOL + "        ";
        }
        return this.addElement(this.Id() + "_PanelEnvelop")
            .StyleClassName("Panel")
            .Visible(this.Visible())
            .Add(super.Draw($EOL + "    "))
            .Draw($EOL);
    }
    /**
     * @returns {IGuiCommonsArg[]} Returns array of element's attributes.
     */
    getArgs() {
        const args = super.getArgs();
        args.push({
            name: "Scrollable",
            type: GuiCommonsArgType.BOOLEAN,
            value: this.Scrollable()
        });
        return args;
    }
    /**
     * @param {IGuiCommonsArg} $value Specify argument value, which should be passed to element.
     * @param {boolean} [$force=false] Specify, if value should be set without fire of events connected with argument change.
     * @returns {void}
     */
    setArg($value, $force = false) {
        switch ($value.name) {
            case "Width":
                this.Width($value.value);
                break;
            case "Height":
                this.Height($value.value);
                break;
            case "Scrollable":
                this.Scrollable($value.value);
                break;
            default:
                super.setArg($value, $force);
                break;
        }
    }
    fitToWindowHandler($size) {
        this.Width($size.Width());
        this.Height($size.Height());
    }
    getWindowSize() {
        const size = WindowManager.getSize();
        size.Height(size.Height() - ElementManager.getOffsetHeight("DeveloperCorner_Distance"));
        return size;
    }
    asyncChildListLoad($handler, $asyncLoader) {
        if (!this.asyncChildLoaders.IsEmpty()) {
            const reflection = Reflection.getInstance();
            this.asyncChildLoaders.foreach(($child, $key) => {
                $asyncLoader.Add(() => {
                    EventsManager.getInstanceSingleton().FireEvent("Io.Oidis.Gui.Primitives.BaseViewer", EventType.ON_CHANGE, false);
                    const viewer = new $child.viewer($child.args);
                    if (reflection.IsMemberOf(viewer, BasePanelViewer)) {
                        const instance = viewer.getInstance();
                        if (!ObjectValidator.IsEmptyOrNull(instance)) {
                            instance.Parent(this);
                            this.childPanelList.Add(viewer, instance.Id());
                            instance.asyncChildListLoad(() => {
                                $child.postprocessor(this, instance, $key);
                                this.asyncChildLoaders.RemoveAt(this.asyncChildLoaders.getKeys().indexOf($key));
                                if (this.asyncChildLoaders.IsEmpty()) {
                                    $handler(this.InstanceOwner());
                                }
                            }, $asyncLoader);
                        }
                        else {
                            ExceptionsManager.Throw(this.getClassName(), new IllegalArgumentException("Instance of '" + viewer.getClassName() + "' can not be set as source " +
                                "for child panel, because declared viewer class is missing instance of panel object. " +
                                "Please, validate, if setInstance method has been used correctly."));
                        }
                    }
                    else {
                        ExceptionsManager.Throw(this.getClassName(), new IllegalArgumentException("Instance of '" + viewer.getClassName() + "' can not be set as source " +
                            "for child panel, because it is not member of '" +
                            BasePanelViewer.ClassName() + "' class."));
                    }
                });
            });
        }
        else {
            $handler(this.InstanceOwner());
        }
    }
    addChildPanel($panelViewerClass, $panelViewerArgs, $postprocessor) {
        const reflection = Reflection.getInstance();
        if (ObjectValidator.IsString($panelViewerClass)) {
            $panelViewerClass = reflection.getClass($panelViewerClass);
        }
        if (ObjectValidator.IsFunction($postprocessor)) {
            this.asyncChildLoaders.Add({
                args: $panelViewerArgs,
                postprocessor: $postprocessor,
                viewer: $panelViewerClass
            });
        }
        else {
            const viewer = new $panelViewerClass($panelViewerArgs);
            if (reflection.IsMemberOf(viewer, BasePanelViewer)) {
                const instance = viewer.getInstance();
                instance.Parent(this);
                this.childPanelList.Add(viewer, instance.Id());
                return instance;
            }
            else {
                ExceptionsManager.Throw(this.getClassName(), new IllegalArgumentException("Instance of '" + viewer.getClassName() + "' can not be set as source for child panel, " +
                    "because it is not member of '" + BasePanelViewer.ClassName() + "' class."));
            }
        }
        return null;
    }
    availableGuiOptions() {
        const options = super.availableGuiOptions();
        options.Add(GuiOptionType.SCROLLABLE);
        return options;
    }
    /**
     * @returns {IIcon} This method should return class with
     * interface Io.Oidis.Gui.Interfaces.UserControls.IIcon
     */
    getLoaderIconClass() {
        return null;
    }
    /**
     * @returns {ILabel} This method should return class with
     * interface Io.Oidis.Gui.Interfaces.UserControls.ILabel
     */
    getLoaderTextClass() {
        return null;
    }
    /**
     * @returns {IScrollBar} This method should return class with
     * interface Io.Oidis.Gui.Interfaces.Components.IScrollBar
     */
    getScrollBarClass() {
        return null;
    }
    innerCode() {
        const events = EventsManager.getInstanceSingleton();
        const thisClass = Reflection.getInstance().getClass(this.getClassName());
        if (ObjectValidator.IsSet(this.verticalScrollBar)) {
            this.verticalScrollBar.getEvents().setOnStart(($args) => {
                const element = $args.Owner();
                const parent = element.Parent();
                element.Size(parent.Height());
            });
            this.verticalScrollBar.getEvents().setOnComplete(($args) => {
                thisClass.resize($args.Owner().Parent());
            });
        }
        if (ObjectValidator.IsSet(this.horizontalScrollBar)) {
            this.horizontalScrollBar.getEvents().setOnStart(($args) => {
                const element = $args.Owner();
                const parent = element.Parent();
                element.Size(parent.Width());
            });
            this.horizontalScrollBar.getEvents().setOnComplete(($args) => {
                thisClass.resize($args.Owner().Parent());
            });
        }
        WindowManager.getEvents().setOnScroll(BasePanel.onBodyScrollEventHandler);
        WindowManager.getEvents().setOnKeyDown(thisClass.onKeyEventHandler);
        WindowManager.getEvents().setOnResize(thisClass.onWindowResizeEventHandler);
        EventsManager.getInstanceSingleton().setEvent("Io.Oidis.Gui.Primitives.GuiCommons", EventType.ON_SHOW, thisClass.onCommonsShow);
        EventsManager.getInstanceSingleton().setEvent("Io.Oidis.Gui.Primitives.GuiCommons", EventType.ON_HIDE, thisClass.onCommonsHide);
        this.getEvents().setOnMouseOver(($args, $manager, $reflection) => {
            $args.StopAllPropagation();
            $reflection.getClass($args.Owner().getClassName()).onHoverEventHandler($args, $manager, $reflection);
        });
        this.getEvents().setOnClick(($args, $manager, $reflection) => {
            $reflection.getClass($args.Owner().getClassName()).onHoverEventHandler($args, $manager, $reflection);
        });
        this.getEvents().setOnStart(($eventArgs) => {
            const element = $eventArgs.Owner();
            if (ObjectValidator.IsSet(element.verticalScrollBar)) {
                element.verticalScrollBar.Visible(false);
            }
            if (ObjectValidator.IsSet(element.horizontalScrollBar)) {
                element.horizontalScrollBar.Visible(false);
            }
        });
        this.getEvents().setOnComplete(($eventArgs, $manager) => {
            const element = $eventArgs.Owner();
            thisClass.resize(element);
            if (ObjectValidator.IsEmptyOrNull(element.Parent())) {
                $manager.setHovered(element, true);
            }
        });
        const owner = this.InstanceOwner();
        if (!ObjectValidator.IsEmptyOrNull(owner) &&
            !ObjectValidator.IsEmptyOrNull(owner.ViewerArgs()) && owner.ViewerArgs().AsyncEnabled()) {
            events.setEvent(GeneralEventOwner.ASYNC_REQUEST, EventType.ON_COMPLETE, ($eventArgs, $manager, $reflection) => {
                if ($eventArgs.POST().KeyExists(HttpRequestConstants.ELEMENT_INSTANCE)) {
                    const element = $eventArgs.POST().getItem(HttpRequestConstants.ELEMENT_INSTANCE);
                    if (element.IsMemberOf(BasePanel) && element.Visible()) {
                        ElementManager.setInnerHtml(element.Id(), $eventArgs.Result());
                        events.FireEvent(element, EventType.ON_START, false);
                        const thisClass = $reflection.getClass(element.getClassName());
                        thisClass.Show(element);
                        events.FireEvent(element, EventType.BEFORE_LOAD);
                    }
                }
            });
        }
        return super.innerCode();
    }
    guiContent() {
        if (this.ContentType() === PanelContentType.HIDDEN) {
            const hidden = this.addElement().StyleClassName("Hidden").Add(this.Id());
            if (!ObjectValidator.IsEmptyOrNull(this.InstanceOwner())) {
                const link = document.createElement("a");
                const manager = this.getHttpManager();
                link.href = manager.CreateLink("/web/" + StringUtils.Replace(this.InstanceOwner().getClassName(), ".", "/"));
                if (StringUtils.Contains(manager.CreateLink(""), "/" + HttpRequestConstants.TEST_MODE)) {
                    link.href = manager.CreateLink(link.href + "/" + HttpRequestConstants.TEST_MODE);
                }
                if (StringUtils.Contains(manager.CreateLink(""), "/" + HttpRequestConstants.HIDE_CHILDREN)) {
                    link.href = manager.CreateLink(link.href + "/" + HttpRequestConstants.HIDE_CHILDREN);
                }
                link.innerHTML = hidden.Draw(StringUtils.NewLine(false));
                return this.addElement().Add(link);
            }
            else {
                return hidden;
            }
        }
        if (this.ContentType() === PanelContentType.ASYNC_LOADER) {
            const loader = this.addElement(this.Id() + "_AsyncProgress").StyleClassName("Async");
            if (ObjectValidator.IsSet(this.loaderIcon) || ObjectValidator.IsSet(this.loaderText)) {
                if (ObjectValidator.IsSet(this.loaderIcon)) {
                    this.loaderIcon.DisableAsynchronousDraw();
                    loader.Add(this.loaderIcon);
                }
                if (ObjectValidator.IsSet(this.loaderText)) {
                    this.loaderText.DisableAsynchronousDraw();
                    loader.Add(this.loaderText);
                }
            }
            else {
                loader.Add(this.addElement().StyleClassName("Label").Add("Loading ..."));
            }
            if (this.width !== -1 || this.height !== -1) {
                if (this.height !== -1) {
                    loader.setAttribute("top", Math.ceil(this.height / 2) + "px;");
                }
                if (this.width !== -1) {
                    loader.setAttribute("left", Math.ceil(this.width / 2) + "px;");
                }
            }
            return loader;
        }
        else {
            if (ObjectValidator.IsSet(this.loaderIcon)) {
                this.loaderIcon.Visible(false);
            }
            if (ObjectValidator.IsSet(this.loaderText)) {
                this.loaderText.Visible(false);
            }
        }
        if (!ObjectValidator.IsSet(this.asyncInnerCode)) {
            this.asyncInnerCode = this.addElement();
        }
        return this.addElement()
            .GuiTypeTag("Panel")
            .Add(this.addElement(this.Id() + "_PanelContentEnvelop")
            .StyleClassName("Envelop").Visible(false)
            .Add(this.addElement(this.Id() + "_PanelContent").StyleClassName("Content")
            .Add(this.asyncInnerCode)
            .Add(super.guiContent())
            .Add(this.addElement().setAttribute("clear", "both"))))
            .Add(this.getGuiOptions().Contains(GuiOptionType.SCROLLABLE) && ObjectValidator.IsSet(this.verticalScrollBar) ?
            this.verticalScrollBar : "")
            .Add(this.getGuiOptions().Contains(GuiOptionType.SCROLLABLE) && ObjectValidator.IsSet(this.horizontalScrollBar) ?
            this.horizontalScrollBar : "");
    }
    getScrollIncrement($direction, $value) {
        if ($direction === DirectionType.DOWN) {
            return $value;
        }
        else {
            return $value * 3;
        }
    }
    /**
     * Specify attributes of the instance after unserialization.
     */
    setInstanceAttributes() {
        super.setInstanceAttributes();
        if (ObjectValidator.IsEmptyOrNull(this.childPanelList)) {
            this.childPanelList = new ArrayList();
        }
        this.asyncChildLoaders = new ArrayList();
        this.asyncInnerCode = this.addElement();
        this.width = -1;
        this.height = -1;
        if (ObjectValidator.IsSet(this.verticalScrollBar)) {
            this.verticalScrollBar.StyleClassName("PanelScrollBar");
            this.verticalScrollBar.Visible(false);
            this.verticalScrollBar.Size(50);
        }
        if (ObjectValidator.IsSet(this.horizontalScrollBar)) {
            this.horizontalScrollBar.StyleClassName("PanelScrollBar");
            this.horizontalScrollBar.Visible(false);
            this.horizontalScrollBar.Size(50);
        }
    }
    excludeSerializationData() {
        const exclude = super.excludeSerializationData();
        exclude.push("asyncChildLoaders", "asyncChildrenLoader", "contentType", "scrollable", "width", "height");
        return exclude;
    }
    excludeCacheData() {
        const exclude = super.excludeCacheData();
        exclude.push("asyncChildLoaders", "asyncChildrenLoader", "contentType", "asyncInnerCodeOutput");
        if (this.scrollable === false) {
            exclude.push("scrollable");
        }
        if (this.IsCompleted()) {
            if (ObjectValidator.IsSet(this.loaderIcon)) {
                exclude.push("loaderIcon");
            }
            if (ObjectValidator.IsSet(this.loaderText)) {
                exclude.push("loaderText");
            }
            let childPanelsLoaded = true;
            this.childPanelList.foreach(($child) => {
                if (!ObjectValidator.IsEmptyOrNull($child.getInstance()) && !$child.getInstance().IsCompleted()) {
                    childPanelsLoaded = false;
                }
                return childPanelsLoaded;
            });
            if (childPanelsLoaded) {
                exclude.push("outputEndOfLine");
            }
        }
        return exclude;
    }
    beforeCacheCreation($preparationResultHandler) {
        if (this.Scrollable()) {
            if (ObjectValidator.IsSet(this.verticalScrollBar) && this.verticalScrollBar.Visible()) {
                this.verticalScrollBar.Visible(false);
                $preparationResultHandler(this.verticalScrollBar.Id(), true);
            }
            if (ObjectValidator.IsSet(this.horizontalScrollBar) && this.horizontalScrollBar.Visible()) {
                this.horizontalScrollBar.Visible(false);
                $preparationResultHandler(this.horizontalScrollBar.Id(), true);
            }
        }
    }
    afterCacheCreation($id, $value) {
        if (this.Scrollable()) {
            if (ObjectValidator.IsSet(this.verticalScrollBar) && this.verticalScrollBar.Id() === $id) {
                this.verticalScrollBar.Visible($value);
            }
            if (ObjectValidator.IsSet(this.horizontalScrollBar) && this.horizontalScrollBar.Id() === $id) {
                this.horizontalScrollBar.Visible($value);
            }
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Primitives.BasePanel", BasePanel);
//# sourceMappingURL=BasePanel.js.map