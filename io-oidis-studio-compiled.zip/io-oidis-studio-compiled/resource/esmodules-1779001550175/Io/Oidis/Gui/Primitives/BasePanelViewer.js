/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "./../../../../Io/Oidis/Commons/Enums/Events/EventType.js";
import { GeneralEventOwner } from "./../../../../Io/Oidis/Commons/Enums/Events/GeneralEventOwner.js";
import { EventArgs } from "./../../../../Io/Oidis/Commons/Events/Args/EventArgs.js";
import { TimeoutManager } from "./../../../../Io/Oidis/Commons/Events/TimeoutManager.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { HttpRequestConstants } from "../Enums/HttpRequestConstants.js";
import { PanelContentType } from "../Enums/PanelContentType.js";
import { EventsManager } from "../Events/EventsManager.js";
import { IBasePanel } from "../Interfaces/Primitives/IBasePanel.js";
import { BaseViewer } from "./BaseViewer.js";
/**
 * BasePanelViewer should be used as abstract class for extending to the panel viewers and
 * it is providing base methods connected with preparation of panel content.
 */
export class BasePanelViewer extends BaseViewer {
    static asyncRequestsList;
    /**
     * @param {BasePanelViewerArgs} [$args] Set initialization arguments object.
     */
    constructor($args) {
        super($args);
    }
    /**
     * @returns {BasePanel} Returns Panel instance held by this viewer.
     */
    getInstance() {
        return super.getInstance();
    }
    /**
     * @param {BasePanelViewerArgs} [$args] Set panel viewer arguments.
     * @returns {BasePanelViewerArgs} Returns panel viewer arguments.
     */
    ViewerArgs($args) {
        return super.ViewerArgs($args);
    }
    /**
     * Provides preparation of panel's instance, which is held by this viewer.
     * @returns {void}
     */
    PrepareImplementation() {
        super.PrepareImplementation();
        const instance = this.getInstance();
        if (!ObjectValidator.IsEmptyOrNull(instance) &&
            Reflection.getInstance().Implements(instance, IBasePanel)) {
            const events = EventsManager.getInstanceSingleton();
            instance.getChildPanelList().foreach(($childViewer) => {
                if (!ObjectValidator.IsEmptyOrNull($childViewer)) {
                    $childViewer.InstanceOwner(this);
                }
            });
            if (!ObjectValidator.IsEmptyOrNull(this.ViewerArgs()) && this.ViewerArgs().AsyncEnabled()) {
                if (instance.ContentType() === PanelContentType.WITH_ELEMENT_WRAPPER ||
                    (instance.ContentType() === PanelContentType.ASYNC_LOADER && this.IsCached())) {
                    instance.ContentType(PanelContentType.ASYNC_LOADER);
                    let viewerName = this.getClassName();
                    let parentViewer = this.InstanceOwner();
                    while (!ObjectValidator.IsEmptyOrNull(parentViewer)) {
                        viewerName = parentViewer.getClassName();
                        parentViewer = parentViewer.InstanceOwner();
                    }
                    viewerName = StringUtils.Replace(viewerName, ".", "/");
                    if (!ObjectValidator.IsSet(BasePanelViewer.asyncRequestsList)) {
                        BasePanelViewer.asyncRequestsList = new ArrayList();
                    }
                    events.setEvent(GeneralEventOwner.ASYNC_REQUEST, EventType.ON_COMPLETE, ($eventArgs) => {
                        if ($eventArgs.POST().KeyExists(HttpRequestConstants.ELEMENT_INSTANCE)) {
                            BasePanelViewer.asyncRequestsList.RemoveAt(BasePanelViewer.asyncRequestsList.IndexOf($eventArgs.POST().getItem(HttpRequestConstants.ELEMENT_INSTANCE)));
                            if (!BasePanelViewer.asyncRequestsList.IsEmpty()) {
                                const eventArgs = new EventArgs();
                                eventArgs.Owner(BasePanelViewer.asyncRequestsList.getLast());
                                events.FireEvent(BasePanelViewer.ClassName(), EventType.ON_ASYNC_REQUEST, eventArgs);
                            }
                        }
                    });
                    events.setEvent(BasePanelViewer.ClassName(), EventType.ON_ASYNC_REQUEST, ($eventArgs) => {
                        const element = $eventArgs.Owner();
                        const postData = new ArrayList();
                        postData.Add(element, HttpRequestConstants.ELEMENT_INSTANCE);
                        postData.Add(StringUtils.Contains(this.getHttpManager().getRequest().getScriptPath(), HttpRequestConstants.HIDE_CHILDREN), HttpRequestConstants.HIDE_CHILDREN);
                        this.getHttpManager().ReloadTo("/async/" + viewerName, postData, true);
                    });
                    events.setEvent(instance, EventType.ON_ASYNC_REQUEST, ($eventArgs) => {
                        BasePanelViewer.asyncRequestsList.Add($eventArgs.Owner());
                        if (BasePanelViewer.asyncRequestsList.Length() === 1) {
                            events.FireEvent(BasePanelViewer.ClassName(), EventType.ON_ASYNC_REQUEST, $eventArgs);
                        }
                    });
                }
            }
        }
    }
    /**
     * @param {string} [$EOL] Specify end of line which should be used for rendering
     * @returns {string} Returns rendered content
     */
    Show($EOL) {
        if (!ObjectValidator.IsEmptyOrNull(this.getInstance()) &&
            this.getInstance().ContentType() === PanelContentType.WITHOUT_ELEMENT_WRAPPER) {
            return this.getInstance().Draw($EOL);
        }
        return super.Show($EOL);
    }
    asyncLoad($handler) {
        if (!ObjectValidator.IsEmptyOrNull(this.getInstance())) {
            const asyncLoader = new TimeoutManager();
            this.getInstance().asyncChildListLoad($handler, asyncLoader);
            asyncLoader.Execute();
        }
        else {
            $handler(this);
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Primitives.BasePanelViewer", BasePanelViewer);
//# sourceMappingURL=BasePanelViewer.js.map