/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { BaseViewerArgs } from "./BaseViewerArgs.js";
/**
 * BasePanelViewerArgs is abstract structure handling data connected with BaseViewer.
 */
export class BasePanelViewerArgs extends BaseViewerArgs {
    asyncEnabled = false;
    /**
     * @param {boolean} [$value] Specify, if panel content should be loaded asynchronously.
     * @returns {boolean} Returns true, if panel content can be loaded asynchronously, otherwise false.
     */
    AsyncEnabled($value) {
        this.asyncEnabled = Property.Boolean(this.asyncEnabled, $value);
        return this.asyncEnabled;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Primitives.BasePanelViewerArgs", BasePanelViewerArgs);
//# sourceMappingURL=BasePanelViewerArgs.js.map