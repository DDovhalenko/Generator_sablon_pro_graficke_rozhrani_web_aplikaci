/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ExceptionsManager } from "./../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { JsonUtils } from "./../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { BaseViewerLayerType } from "../Enums/BaseViewerLayerType.js";
import { HttpRequestConstants } from "../Enums/HttpRequestConstants.js";
import { GuiObjectManager } from "../GuiObjectManager.js";
import { Loader } from "../Loader.js";
import { AbstractGuiObject } from "./AbstractGuiObject.js";
export class CommonGuiViewer extends BaseObject {
    args;
    instance;
    owner;
    testAppend;
    testModeEnabled;
    testButtons;
    layer;
    testSubscriber;
    /**
     * @param {boolean} [$testMode] Set, if created link should be in test mode.
     * @returns {string} Returns link, which can be used for resolver registration or invoke by link element.
     */
    static CallbackLink($testMode = false) {
        const prefix = Loader.getInstance().getHttpManager()
            .getRequest().getUrlArgs().KeyExists(HttpRequestConstants.DESIGNER) ? "design" : "web";
        let link = Loader.getInstance().getHttpManager()
            .CreateLink("/" + prefix + "/" + StringUtils.Replace(this.ClassName(), ".", "/"));
        link = StringUtils.Replace(link, "/#/", "#/");
        if (!StringUtils.StartsWith(link, "#")) {
            link = "#" + link;
        }
        if ($testMode) {
            link += "/" + HttpRequestConstants.TEST_MODE;
        }
        return link;
    }
    static getTestViewerArgs() {
        return null;
    }
    /**
     * @param {BaseViewerArgs} [$args] Set initialization arguments object.
     */
    constructor($args) {
        super();
        this.instance = null;
        this.testButtons = new ArrayList();
        this.testAppend = "";
        this.owner = null;
        this.ViewerArgs($args);
        this.TestModeEnabled(false);
    }
    /**
     * @param {IBaseViewer} [$value] Set owner of the viewer instance.
     * @returns {IBaseViewer} Returns owner instance of the current instance, if the instance has owner, otherwise null.
     */
    InstanceOwner($value) {
        if (ObjectValidator.IsSet($value)) {
            this.owner = $value;
        }
        return this.owner;
    }
    /**
     * @param {boolean} [$value] Specify, if viewer's object instance should be processed in test mode.
     * @returns {boolean} Returns true, if viewer's object instance will be processed in test mode, otherwise false.
     */
    TestModeEnabled($value) {
        return this.testModeEnabled = Property.Boolean(this.testModeEnabled, $value);
    }
    /**
     * @param {BaseViewerArgs} [$args] Set viewer arguments.
     * @returns {BaseViewerArgs} Returns viewer arguments.
     */
    ViewerArgs($args) {
        if (ObjectValidator.IsSet($args)) {
            this.args = $args;
        }
        return this.args;
    }
    getInstance() {
        return this.instance;
    }
    /**
     * @returns {string} Returns class name with namespace for structure of supported layers.
     */
    getLayersType() {
        return BaseViewerLayerType.ClassName();
    }
    /**
     * @param {BaseViewerLayerType} $type Specify type of layer, which should be aplied on current view.
     * @returns {void}
     */
    setLayer($type) {
        if (!ObjectValidator.IsEmptyOrNull(this.instance) && !ObjectValidator.IsEmptyOrNull($type) && this.layer !== $type) {
            this.layerHandler($type, this.instance);
            this.layer = $type;
        }
    }
    /**
     * Provides preparation of GUI object instance, which is held by this viewer.
     * @returns {void}
     */
    PrepareImplementation() {
        if (!ObjectValidator.IsEmptyOrNull(this.instance)) {
            this.instance.InstanceOwner(this);
            const instanceWithViewer = this.instance;
            if (ObjectValidator.IsFunction(instanceWithViewer.PanelViewer) &&
                !ObjectValidator.IsEmptyOrNull(instanceWithViewer.PanelViewer())) {
                instanceWithViewer.PanelViewer().InstanceOwner(this);
            }
            if (!ObjectValidator.IsEmptyOrNull(this.args)) {
                if (!this.args.Visible()) {
                    this.instance.Visible(false);
                }
                this.argsHandler(this.instance, this.args);
            }
            if (!this.instance.IsCompleted()) {
                this.setLayer(BaseViewerLayerType.DEFAULT);
                this.beforeLoad(this.instance, this.args);
                this.instance.getEvents().setOnComplete(() => {
                    this.afterLoad(this.instance, this.args);
                });
            }
        }
        if (this.testModeEnabled) {
            if (!ObjectValidator.IsEmptyOrNull(this.testSubscriber)) {
                const testProcessor = new this.testSubscriber();
                testProcessor.setOwner(this);
                this.testAppend = testProcessor.Process();
                if (!ObjectValidator.IsSet(this.testAppend)) {
                    this.testAppend = "";
                }
            }
            let testImplementationAppend = this.testImplementation(this.instance, this.args);
            if (!ObjectValidator.IsSet(testImplementationAppend)) {
                testImplementationAppend = "";
            }
            this.testAppend += testImplementationAppend;
            this.testButtons.foreach(($button) => {
                this.testAppend += $button.Draw();
            });
            if (!ObjectValidator.IsEmptyOrNull(this.testAppend)) {
                this.testAppend = "<div style=\"clear: both; height: 50px;\"></div>" + this.testAppend;
            }
            this.testAppend += "<style>body{overflow: auto; margin: inherit;}</style>";
        }
        else {
            this.testAppend = "";
            this.normalImplementation(this.instance, this.args);
        }
        if ((!this.testModeEnabled && ObjectValidator.IsEmptyOrNull(this.instance)) ||
            (this.testModeEnabled &&
                ObjectValidator.IsEmptyOrNull(this.instance) && ObjectValidator.IsEmptyOrNull(this.testAppend))) {
            ExceptionsManager.Throw(this.getClassName(), "Class '" + this.getClassName() + "' does not contains valid implementation for current view mode.");
        }
    }
    /**
     * @param {string} [$EOL] Specify element, which should be handled.
     * @returns {string} Returns content of the viewer in string format, suitable for further rendering to the screen.
     */
    Show($EOL) {
        if (ObjectValidator.IsEmptyOrNull($EOL)) {
            $EOL = StringUtils.NewLine(false);
        }
        let output = "";
        if (!ObjectValidator.IsEmptyOrNull(this.instance)) {
            output += this.instance.Draw($EOL);
        }
        if (!ObjectValidator.IsEmptyOrNull(this.testAppend)) {
            output += this.testAppend;
        }
        return output;
    }
    /**
     * @returns {object} Returns data suitable for object serialization.
     */
    SerializationData() {
        return { instance: this.instance };
    }
    ToString($prefix = "", $htmlTag = true) {
        let id = "instance NOT DEFINED";
        if (!ObjectValidator.IsEmptyOrNull(this.getInstance())) {
            id = this.getInstance().Id();
        }
        return this.getClassName() + " (" + id + ")";
    }
    toString() {
        return this.ToString();
    }
    setInstance($value) {
        this.instance = $value;
        if (!ObjectValidator.IsEmptyOrNull(this.instance)) {
            this.instance.InstanceOwner(this);
        }
    }
    beforeLoad($instance, $args) {
        // override this method for ability to prepare instance before it is loaded
    }
    afterLoad($instance, $args) {
        // override this method for ability to setup instance after it is loaded
    }
    layerHandler($layer, $instance) {
        // override this method for ability to setup instance according to selected layer
    }
    argsHandler($instance, $args) {
        // override this method for ability distribute viewer args into the instance
    }
    normalImplementation($instance, $args) {
        // override this method for ability to setup default instance behaviour
    }
    testImplementation($instance, $args) {
        this.normalImplementation($instance, $args);
        return "";
    }
    setTestSubscriber($className) {
        this.testSubscriber = $className;
        if (ObjectValidator.IsString($className)) {
            this.testSubscriber = Reflection.getInstance().getClass($className);
        }
    }
    getHttpManager() {
        return Loader.getInstance().getHttpResolver().getManager();
    }
    getEventsManager() {
        return Loader.getInstance().getHttpResolver().getEvents();
    }
    getGuiManager() {
        return GuiObjectManager.getInstanceSingleton();
    }
    getTestButtons() {
        return this.testButtons;
    }
    getTestSubscriber() {
        return this.testSubscriber;
    }
    testContent($value) {
        return this.testAppend = Property.String(this.testAppend, $value);
    }
    excludeCacheData() {
        return ["testAppend", "testButtons", "isPrinted", "args", "layer"];
    }
}
/**
 * BaseViewer should be used as abstract class for extending to the GUI viewers and
 * it is providing base methods connected with preparation of GUI object.
 */
export class BaseViewer extends CommonGuiViewer {
    argsHash;
    isPrinted;
    isCached;
    constructor($args) {
        super($args);
        this.argsHash = null;
        this.isPrinted = false;
        this.isCached = false;
    }
    ViewerArgs($args) {
        if (!ObjectValidator.IsEmptyOrNull($args) && !ObjectValidator.IsString($args)) {
            super.ViewerArgs($args);
            const instance = this.getInstance();
            if (!ObjectValidator.IsEmptyOrNull(instance) &&
                (instance.IsLoaded() || this.IsCached() || (!instance.IsLoaded() && !instance.Visible()))) {
                const newHash = $args.getHash();
                if (this.argsHash !== newHash) {
                    this.argsHash = newHash;
                    this.PrepareImplementation();
                }
            }
        }
        return super.ViewerArgs($args);
    }
    /**
     * @returns {IBaseGuiObject} Returns GUI object instance held by this viewer.
     */
    getInstance() {
        return super.getInstance();
    }
    /**
     * @param {boolean} [$value] Set viewer cache status.
     * @returns {boolean} Returns true, if viewer has been loaded from cache, otherwise false.
     */
    IsCached($value) {
        return this.isCached = Property.Boolean(this.isCached, $value);
    }
    /**
     * @returns {boolean} Returns true, if viewer's instance HTML output has been printed, otherwise false.
     */
    IsPrinted() {
        if (!ObjectValidator.IsSet(this.isPrinted)) {
            this.isPrinted = false;
        }
        return this.isPrinted;
    }
    Show($EOL) {
        const output = super.Show($EOL);
        this.isPrinted = true;
        return output;
    }
    SerializationData() {
        return JsonUtils.Extend(super.SerializationData(), { isCached: this.isCached });
    }
    setInstance($value) {
        super.setInstance($value);
    }
    asyncLoad($handler) {
        $handler(this);
    }
    beforeLoad($instance, $args) {
        super.beforeLoad($instance, $args);
    }
    afterLoad($instance, $args) {
        super.afterLoad($instance, $args);
    }
    layerHandler($layer, $instance) {
        super.layerHandler($layer, $instance);
    }
    argsHandler($instance, $args) {
        super.argsHandler($instance, $args);
    }
    normalImplementation($instance, $args) {
        super.normalImplementation($instance, $args);
    }
    testImplementation($instance, $args) {
        return super.testImplementation($instance, $args);
    }
    addTestButton($text, $onClick, $buttonClassName) {
        if (ObjectValidator.IsEmptyOrNull($buttonClassName) || !ObjectValidator.IsSet($buttonClassName.ClassName)) {
            $buttonClassName = AbstractGuiObject;
        }
        let button;
        try {
            button = new $buttonClassName($text);
        }
        catch (ex) {
            button = new AbstractGuiObject($text);
        }
        button.getEvents().setOnClick($onClick);
        this.getTestButtons().Add(button);
    }
    getTestButtons() {
        return super.getTestButtons();
    }
    excludeCacheData() {
        return super.excludeCacheData().concat(["isCached", "isPrinted", "argsHash"]);
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Primitives.CommonGuiViewer", CommonGuiViewer);
globalThis.RegisterClass("Io.Oidis.Gui.Primitives.BaseViewer", BaseViewer);
//# sourceMappingURL=BaseViewer.js.map