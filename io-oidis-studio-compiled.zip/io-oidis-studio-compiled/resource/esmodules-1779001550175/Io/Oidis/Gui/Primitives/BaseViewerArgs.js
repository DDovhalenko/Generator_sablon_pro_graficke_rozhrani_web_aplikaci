/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseArgs } from "./../../../../Io/Oidis/Commons/Primitives/BaseArgs.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
/**
 * BaseViewerArgs is abstract structure handling data connected with BaseViewer.
 */
export class BaseViewerArgs extends BaseArgs {
    visible = true;
    /**
     * @param {boolean} [$value] Specify, if viewer's content should be visible at the screen.
     * @returns {boolean} Returns true, if viewer's content will be visible at the screen, otherwise false.
     */
    Visible($value) {
        this.visible = Property.Boolean(this.visible, $value);
        return this.visible;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Primitives.BaseViewerArgs", BaseViewerArgs);
//# sourceMappingURL=BaseViewerArgs.js.map