/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventArgs } from "./../../../../Io/Oidis/Commons/Events/Args/EventArgs.js";
import { PersistenceFactory } from "./../../../../Io/Oidis/Commons/PersistenceApi/PersistenceFactory.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { EventType } from "../Enums/Events/EventType.js";
import { GeneralCssNames } from "../Enums/GeneralCssNames.js";
import { GuiCommonsArgType } from "../Enums/GuiCommonsArgType.js";
import { GuiOptionType } from "../Enums/GuiOptionType.js";
import { KeyMap } from "../Enums/KeyMap.js";
import { PersistenceType } from "../Enums/PersistenceType.js";
import { ElementEventsManager } from "../Events/ElementEventsManager.js";
import { EventsManager } from "../Events/EventsManager.js";
import { GuiObjectManager } from "../GuiObjectManager.js";
import { IFormsObject } from "../Interfaces/Primitives/IFormsObject.js";
import { Loader } from "../Loader.js";
import { FormValue } from "../Structures/FormValue.js";
import { ElementManager } from "../Utils/ElementManager.js";
import { WindowManager } from "../Utils/WindowManager.js";
import { BaseGuiObject } from "./BaseGuiObject.js";
/**
 * FormsObject should be used as abstract class for extending to the GUI objects type of input
 * and it is providing base methods connected with form elements.
 */
export class FormsObject extends BaseGuiObject {
    valuesPersistence;
    errorFlags;
    notification;
    error;
    tabIndex;
    selectorEvents;
    isPersistent;
    /**
     * @param {FormsObject} $element Specify element, which should be handled.
     * @param {GuiObjectManager} [$manager] Specify instance of GuiObjectManager.
     * @param {Reflection} [$reflection] Specify instance of Reflection.
     * @returns {void}
     */
    static TurnOn($element, $manager, $reflection) {
        if (!$manager.IsActive($element)) {
            ElementManager.TurnOn($element.Id() + "_Enabled");
        }
    }
    /**
     * @param {FormsObject} $element Specify element, which should be handled.
     * @param {GuiObjectManager} [$manager] Specify instance of GuiObjectManager.
     * @param {Reflection} [$reflection] Specify instance of Reflection.
     * @returns {void}
     */
    static TurnOff($element, $manager, $reflection) {
        if (!$manager.IsActive($element)) {
            ElementManager.TurnOff($element.Id() + "_Enabled");
        }
    }
    /**
     * @param {FormsObject} $element Specify element, which should be handled.
     * @param {GuiObjectManager} [$manager] Specify instance of GuiObjectManager.
     * @param {Reflection} [$reflection] Specify instance of Reflection.
     * @returns {void}
     */
    static TurnActive($element, $manager, $reflection) {
        ElementManager.TurnActive($element.Id() + "_Enabled");
    }
    /**
     * @param {FormsObject} $element Specify element, which should be handled.
     * @returns {void}
     */
    static Focus($element) {
        const manager = $element.getGuiManager();
        manager.setActive($element, true);
        const eventArgs = new EventArgs();
        eventArgs.Owner($element);
        EventsManager.getInstanceSingleton().FireEvent($element.getClassName(), EventType.ON_FOCUS, eventArgs);
        EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_FOCUS, eventArgs);
        const thisClass = Reflection.getInstance().getClass($element.getClassName());
        thisClass.TurnActive($element, manager, Reflection.getInstance());
    }
    /**
     * @returns {void}
     */
    static Blur() {
        const manager = GuiObjectManager.getInstanceSingleton();
        const reflection = Reflection.getInstance();
        const elements = manager.getActive();
        elements.foreach(($element) => {
            $element.getGuiManager().setActive($element, false);
            const eventArgs = new EventArgs();
            eventArgs.Owner($element);
            EventsManager.getInstanceSingleton().FireEvent($element.getClassName(), EventType.ON_BLUR, eventArgs);
            EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_BLUR, eventArgs);
            const thisClass = reflection.getClass($element.getClassName());
            thisClass.TurnOff($element, manager, reflection);
        });
    }
    /**
     * @param {FormsObject|string} [$elementOrId] Specify GUI element or DOM element from, which should be collected values.
     * @returns {ArrayList<FormValue>} Returns list of FormValue objects, which are representing all elements
     * interacted by the user. If element id has been specified, list of values is filtered by the id and returned
     * are only values of the element with desired id.
     * If element with desired id is type of panel, returned values will be focused on panel elements and it's
     * subpanels elements.
     */
    static CollectValues($elementOrId) {
        let output = new ArrayList();
        const register = GuiObjectManager.getInstanceSingleton();
        if (ObjectValidator.IsSet($elementOrId)) {
            if (register.Exists($elementOrId)) {
                output = FormsObject.valuesCollector($elementOrId, output);
                $elementOrId.getChildElements().foreach(($child) => {
                    FormsObject.valuesCollector($child, output);
                });
            }
            else if (ObjectValidator.IsSet(document.forms[$elementOrId])) {
                const inputs = document.forms[$elementOrId].getElementsByTagName("input");
                const allObjects = register.getAll();
                let index;
                const inputsLength = inputs.length;
                for (index = 0; index < inputsLength; index++) {
                    let id = inputs[index].getAttribute("id");
                    if (ObjectValidator.IsEmptyOrNull(id)) {
                        id = inputs[index].getAttribute("name");
                    }
                    if (!ObjectValidator.IsEmptyOrNull(id)) {
                        if (allObjects.KeyExists(id)) {
                            output = FormsObject.valuesCollector(allObjects.getItem(id), output);
                        }
                        else {
                            output.Add(new FormValue(id, inputs[index].getAttribute("value")));
                        }
                    }
                }
            }
        }
        else {
            register.getType(FormsObject).foreach(($element) => {
                output = FormsObject.valuesCollector($element, output);
            });
        }
        return output;
    }
    /**
     * @param {string} $id Specify element id, which should be submitted.
     * @param {string} $controllerLink Specify controller link, which is suitable for processing of submitted values.
     * @returns {void}
     */
    static Submit($id, $controllerLink) {
        Loader.getInstance().getHttpManager().ReloadTo($controllerLink, this.CollectValues($id), true);
    }
    static onKeyEventHandler($eventArgs, $manager) {
        if ($eventArgs.getKeyCode() === KeyMap.SPACE || $eventArgs.getKeyCode() === KeyMap.ENTER) {
            EventsManager.getInstanceSingleton().FireAsynchronousMethod(() => {
                const elements = $manager.getActive();
                elements.foreach(($element) => {
                    const element = ElementManager.getElement($element.getEvents().Subscriber());
                    if (!ObjectValidator.IsEmptyOrNull(element)) {
                        element.click();
                    }
                });
            });
        }
    }
    static setErrorStyle($element) {
        if (!ObjectValidator.IsEmptyOrNull($element)) {
            if ($element.Error()) {
                ElementManager.setClassName($element.Id() + "_Status", GeneralCssNames.ERROR);
            }
            else {
                ElementManager.setClassName($element.Id() + "_Status", "");
            }
        }
    }
    static valuesCollector($object, $values) {
        if (Reflection.getInstance().Implements($object, IFormsObject)) {
            const object = $object;
            if (object.Changed()) {
                $values.Add(new FormValue(object.InstancePath(), object.Value(), object.Error()));
            }
        }
        return $values;
    }
    constructor($id) {
        super($id);
        this.valuesPersistence = PersistenceFactory.getPersistence(PersistenceType.FORM_VALUES);
        this.errorFlags = PersistenceFactory.getPersistence(PersistenceType.ERROR_FLAGS);
    }
    /**
     * @returns {IFormsObjectEvents} Returns events connected with the element.
     */
    getEvents() {
        return super.getEvents();
    }
    /**
     * @returns {INotification} Returns notification component associated with current GUI element.
     */
    Notification() {
        if (ObjectValidator.IsEmptyOrNull(this.notification)) {
            const notificationClass = this.getNotificationClass();
            if (!ObjectValidator.IsEmptyOrNull(notificationClass)) {
                this.notification = new notificationClass(null, null, this.Id() + "_Notification");
            }
        }
        return this.notification;
    }
    /**
     * @param {boolean} [$value] Switch type of element mode between enabled and disabled.
     * @returns {boolean} Returns true, if element is in enabled mode, otherwise false.
     */
    Enabled($value) {
        const enabled = super.Enabled($value);
        if (ObjectValidator.IsSet($value) && ElementManager.IsVisible(this.Id())) {
            if (enabled || this.getGuiOptions().Contains(GuiOptionType.DISABLE)) {
                ElementManager.Enabled(this.Id(), enabled);
            }
            if (enabled) {
                this.Error(!ObjectValidator.IsSet(this.error) ? false : this.error);
            }
        }
        return enabled;
    }
    /**
     * @param {boolean} [$value] Specify, if element is in error status or not.
     * @returns {boolean} Returns true, if element is in error state, otherwise false.
     */
    Error($value) {
        if (!ObjectValidator.IsSet(this.error)) {
            this.error = false;
        }
        if (ObjectValidator.IsSet($value) && ElementManager.IsVisible(this.Id())) {
            if (this.error !== $value) {
                this.setChanged();
                const eventArgs = new EventArgs();
                eventArgs.Owner(this);
                EventsManager.getInstanceSingleton().FireEvent(this, EventType.ON_CHANGE, eventArgs);
                EventsManager.getInstanceSingleton().FireEvent(this.getClassName(), EventType.ON_CHANGE, eventArgs);
            }
        }
        if (!this.IsCompleted() && this.errorFlags.Exists(this.InstancePath())) {
            this.error = this.errorFlags.Variable(this.InstancePath());
        }
        else if (ObjectValidator.IsSet($value)) {
            this.error = Property.Boolean(this.error, $value);
        }
        else if (!ObjectValidator.IsSet(this.error)) {
            this.error = false;
        }
        if (ObjectValidator.IsSet($value) && ElementManager.IsVisible(this.Id()) && !this.getGuiManager().IsActive(this)) {
            Reflection.getInstance().getClass(this.getClassName()).setErrorStyle(this);
        }
        return this.error;
    }
    /**
     * @param {number} [$value] Set index for TAB key navigation in the page.
     * @returns {number} Returns index of element in the page based on TAB key elements register.
     */
    TabIndex($value) {
        this.tabIndex = Property.Integer(this.tabIndex, $value);
        return this.tabIndex;
    }
    /**
     * @returns {IGuiCommonsArg[]} Returns array of element's attributes.
     */
    getArgs() {
        const args = super.getArgs();
        args.push({
            name: "Error",
            type: GuiCommonsArgType.BOOLEAN,
            value: this.Error()
        });
        args.push({
            name: "TabIndex",
            type: GuiCommonsArgType.NUMBER,
            value: this.TabIndex()
        });
        return args;
    }
    /**
     * @param {IGuiCommonsArg} $value Specify argument value, which should be passed to element.
     * @param {boolean} [$force=false] Specify, if value should be set without fire of events connected with argument change.
     * @returns {void}
     */
    setArg($value, $force = false) {
        switch ($value.name) {
            case "Error":
                this.Error($value.value);
                break;
            case "TabIndex":
                this.TabIndex($value.value);
                break;
            default:
                super.setArg($value, $force);
                break;
        }
    }
    /**
     * @returns {IFormsObjectEvents} Returns events connected with selection of the element by TAB key.
     */
    getSelectorEvents() {
        if (ObjectValidator.IsEmptyOrNull(this.selectorEvents)) {
            this.selectorEvents = new ElementEventsManager(this, this.Id() + "_Input");
        }
        return this.selectorEvents;
    }
    /**
     * @param $value {boolean} Define if form element value and state should be persistent or not
     * @returns {boolean} Returns true, if element's value should be persistent, otherwise false.
     */
    IsPersistent($value) {
        if (!ObjectValidator.IsSet($value)) {
            const persistenceExists = this.valuesPersistence.Exists(this.InstancePath());
            if (!ObjectValidator.IsSet(this.isPersistent)) {
                this.isPersistent = persistenceExists;
            }
            if (!this.isPersistent && persistenceExists) {
                this.valuesPersistence.Destroy(this.InstancePath());
            }
        }
        return this.isPersistent = Property.Boolean(this.isPersistent, $value);
    }
    statusCss() {
        let envelopType;
        if (this.Enabled()) {
            // eslint-disable-next-line @typescript-eslint/no-unused-expressions
            this.Error() ? envelopType = GeneralCssNames.ERROR : envelopType = "";
        }
        else {
            envelopType = GeneralCssNames.DISABLE;
        }
        return envelopType;
    }
    errorCssName() {
        return this.Error() ? GeneralCssNames.ERROR : "";
    }
    /**
     * @returns {INotification} This method should return class with
     * interface Io.Oidis.Gui.Interfaces.Components.INotification
     */
    getNotificationClass() {
        return null;
    }
    selectorElement() {
        const input = document.createElement("button");
        input.id = this.Id() + "_Input";
        input.name = this.Id();
        input.style.opacity = "0";
        input.className = GeneralCssNames.GUI_SELECTOR;
        if (!ObjectValidator.IsEmptyOrNull(this.TabIndex())) {
            input.tabIndex = this.TabIndex();
        }
        return this.addElement().Add(input);
    }
    innerCode() {
        this.getSelectorEvents().setOnFocus(($eventArgs, $manager, $reflection) => {
            const element = $eventArgs.Owner();
            $reflection.getClass(element.getClassName()).Focus(element);
        });
        this.getSelectorEvents().setOnBlur(($eventArgs, $manager, $reflection) => {
            $reflection.getClass($eventArgs.Owner().getClassName()).Blur();
        });
        const thisClass = Reflection.getInstance().getClass(this.getClassName());
        this.getEvents().setOnBlur(thisClass.onUnhoverEventHandler);
        if (!this.IsMemberOf("Io.Oidis.Gui.Primitives.BasePanel")) {
            this.getEvents().setOnMouseOver(($eventArgs, $manager, $reflection) => {
                thisClass.TurnOn($eventArgs.Owner(), $manager, $reflection);
            });
            this.getEvents().setOnMouseOut(($eventArgs, $manager, $reflection) => {
                thisClass.TurnOff($eventArgs.Owner(), $manager, $reflection);
            });
        }
        this.getEvents().setOnMouseDown(($eventArgs, $manager, $reflection) => {
            thisClass.TurnActive($eventArgs.Owner(), $manager, $reflection);
        });
        this.getEvents().setOnMouseUp(($eventArgs, $manager, $reflection) => {
            thisClass.TurnOn($eventArgs.Owner(), $manager, $reflection);
        });
        WindowManager.getEvents().setOnKeyPress(thisClass.onKeyEventHandler);
        this.getEvents().setOnComplete(($eventArgs) => {
            const element = $eventArgs.Owner();
            element.getSelectorEvents().Subscribe();
            if (element.IsCached()) {
                if (element.errorFlags.Exists(element.InstancePath())) {
                    element.error = element.errorFlags.Variable(element.InstancePath());
                }
                else if (!ObjectValidator.IsSet(element.error)) {
                    element.error = false;
                }
                thisClass.setErrorStyle(element);
            }
        });
        return super.innerCode();
    }
    /**
     * Specify attributes of the instance after unserialization.
     */
    setInstanceAttributes() {
        super.setInstanceAttributes();
        this.valuesPersistence = PersistenceFactory.getPersistence(PersistenceType.FORM_VALUES);
        this.errorFlags = PersistenceFactory.getPersistence(PersistenceType.ERROR_FLAGS);
    }
    excludeSerializationData() {
        const exclude = super.excludeSerializationData();
        exclude.push("error", "tabIndex", "autofillPersistence", "valuesPersistence", "errorFlags", "isPersistent");
        return exclude;
    }
    excludeCacheData() {
        const exclude = super.excludeCacheData();
        exclude.push("notification", "selectorEvents");
        if (this.error === false) {
            exclude.push("error");
        }
        if (ObjectValidator.IsEmptyOrNull(this.TabIndex())) {
            exclude.push("tabIndex");
        }
        if (this.isPersistent === true) {
            exclude.push("isPersistent");
        }
        return exclude;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Primitives.FormsObject", FormsObject);
//# sourceMappingURL=FormsObject.js.map