/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { SyntaxConstants } from "./../../../../Io/Oidis/Commons/Enums/SyntaxConstants.js";
import { EventArgs } from "./../../../../Io/Oidis/Commons/Events/Args/EventArgs.js";
import { TimeoutManager } from "./../../../../Io/Oidis/Commons/Events/TimeoutManager.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { EventType } from "../Enums/Events/EventType.js";
import { GeneralCssNames } from "../Enums/GeneralCssNames.js";
import { GuiCommonsArgType } from "../Enums/GuiCommonsArgType.js";
import { GuiOptionType } from "../Enums/GuiOptionType.js";
import { PositionType } from "../Enums/PositionType.js";
import { ElementEventsManager } from "../Events/ElementEventsManager.js";
import { EventsManager } from "../Events/EventsManager.js";
import { GuiObjectManager } from "../GuiObjectManager.js";
import { GuiOptionsManager } from "../GuiOptionsManager.js";
import { IGuiElement } from "../Interfaces/Primitives/IGuiElement.js";
import { Loader } from "../Loader.js";
import { Size } from "../Structures/Size.js";
import { ElementManager } from "../Utils/ElementManager.js";
import { GuiElement } from "./GuiElement.js";
/**
 * GuiCommons should be used as abstract class for extending to any of GUI object
 * and it is providing base methods connected with GUI elements.
 */
export class GuiCommons extends BaseObject {
    static maxAsyncConcurrentCount = 50;
    static guiElementClass = GuiElement;
    outputEndOfLine;
    options;
    availableOptionsList;
    events;
    guiId;
    guiPath;
    parent;
    owner;
    visible;
    enabled;
    interfaceClassName;
    styleClassName;
    containerClassName;
    loaded;
    asyncDrawEnabled;
    contentLoaded;
    childElements;
    waitFor;
    cached;
    prepared;
    completed;
    innerHtmlMap;
    alignment;
    fitToParent;
    widthOfColumn;
    wrappingElement;
    wrappingContainer;
    /**
     * @param {any} [$dataObject] Data object suitable for data reconstruction.
     * @returns {any} Returns class instance in case of, that data object is suitable for object reconstruction,
     * otherwise null. This method is mainly focused to unserialization purposes, but it can also returns class singleton.
     */
    static getInstance($dataObject) {
        const output = Reflection.getInstanceOf(this.ClassName(), $dataObject);
        if (!ObjectValidator.IsEmptyOrNull(output)) {
            output.setInstanceAttributes();
        }
        return output;
    }
    /**
     * @param {IGuiElement} $value Specify GuiElement class, which should be used for element rendering.
     * @returns {IGuiElement} Returns GuiElement class, which is used for element rendering.
     */
    static GuiElementClass($value) {
        if (ObjectValidator.IsSet($value) && Reflection.getInstance().ClassHasInterface($value, IGuiElement)) {
            GuiCommons.guiElementClass = $value;
        }
        return GuiCommons.guiElementClass;
    }
    /**
     * @param {GuiCommons} $element Specify element, which should be handled.
     * @returns {void}
     */
    static Show($element) {
        ElementManager.Show($element.Id());
        const eventArgs = new EventArgs();
        eventArgs.Owner($element);
        if ($element.IsLoaded()) {
            EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_SHOW, eventArgs, false);
            EventsManager.getInstanceSingleton().FireEvent(GuiCommons.ClassName(), EventType.ON_SHOW, eventArgs, false);
        }
        else {
            const parent = $element.Parent();
            if (!ObjectValidator.IsEmptyOrNull(parent) && parent.IsCompleted()) {
                EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_SHOW, eventArgs, false);
                EventsManager.getInstanceSingleton().FireEvent(GuiCommons.ClassName(), EventType.ON_SHOW, eventArgs, false);
            }
        }
    }
    /**
     * @param {GuiCommons} $element Specify element, which should be handled.
     * @returns {void}
     */
    static Hide($element) {
        ElementManager.Hide($element.Id());
        const eventArgs = new EventArgs();
        eventArgs.Owner($element);
        if ($element.IsLoaded()) {
            EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_HIDE, eventArgs);
            EventsManager.getInstanceSingleton().FireEvent(GuiCommons.ClassName(), EventType.ON_HIDE, eventArgs);
        }
        else {
            const parent = $element.Parent();
            if (!ObjectValidator.IsEmptyOrNull(parent) && parent.IsCompleted()) {
                EventsManager.getInstanceSingleton().FireEvent($element, EventType.ON_HIDE, eventArgs);
                EventsManager.getInstanceSingleton().FireEvent(GuiCommons.ClassName(), EventType.ON_HIDE, eventArgs);
            }
        }
    }
    /**
     * @param {GuiCommons} $element Specify element, which will animate.
     * @returns {void}
     */
    static CreateAnimationContext($element) {
        ElementManager.setCssProperty($element, "transform", "rotate(0deg)");
    }
    static asyncLoadChildren($loaderItems) {
        if (GuiCommons.maxAsyncConcurrentCount > 1) {
            const loaderItemsLength = $loaderItems.Length();
            const loadManager = new TimeoutManager();
            let loaderIndex;
            for (loaderIndex = 0; loaderIndex < Math.ceil(loaderItemsLength / GuiCommons.maxAsyncConcurrentCount); loaderIndex++) {
                loadManager.Add(($loaderIndex) => {
                    let index;
                    for (index = 0; index < GuiCommons.maxAsyncConcurrentCount; index++) {
                        const itemIndex = $loaderIndex * GuiCommons.maxAsyncConcurrentCount + index;
                        if (itemIndex < loaderItemsLength) {
                            $loaderItems.getItem(itemIndex)();
                        }
                        else {
                            break;
                        }
                    }
                });
            }
            loadManager.Execute();
        }
        else {
            EventsManager.getInstanceSingleton().FireAsynchronousMethod(() => {
                $loaderItems.foreach(($item) => {
                    $item();
                });
            });
        }
    }
    /**
     * @param {string} [$id] Force to set element's id, instead of generated one.
     */
    constructor($id) {
        super();
        if (ObjectValidator.IsEmptyOrNull($id)) {
            const manager = this.getGuiManager();
            do {
                this.guiId =
                    this.getClassNameWithoutNamespace() +
                        (new Date().getTime()).toString() +
                        Math.floor(Math.random() * 1000).toString();
            } while (manager.Exists(this));
        }
        else {
            this.guiId = $id;
        }
        this.parent = null;
        this.owner = null;
        this.prepared = false;
        this.completed = false;
        this.loaded = false;
        this.innerHtmlMap = null;
        this.getGuiManager().Add(this);
    }
    /**
     * @returns {IGuiCommonsEvents} Returns events connected with the element.
     */
    getEvents() {
        let initialized = false;
        if (ObjectValidator.IsEmptyOrNull(this.events)) {
            let eventsManagerClass = this.getEventsManagerClass();
            if (ObjectValidator.IsEmptyOrNull(eventsManagerClass)) {
                eventsManagerClass = ElementEventsManager;
            }
            this.events = new eventsManagerClass(this);
            initialized = true;
        }
        else if (ObjectValidator.IsEmptyOrNull(this.events.getOwner())) {
            this.events.owner = this;
            initialized = true;
        }
        if (initialized) {
            this.getEvents = () => {
                return this.events;
            };
        }
        return this.events;
    }
    /**
     * @returns {GuiOptionsManager} Returns manager of element's output and behaviour options.
     */
    getGuiOptions() {
        if (ObjectValidator.IsEmptyOrNull(this.options)) {
            this.options = new GuiOptionsManager(this.availableGuiOptions());
        }
        return this.options;
    }
    /**
     * @returns {IGuiElement} Returns class with IGuiElement interface, which is used for element rendering.
     */
    getGuiElementClass() {
        return GuiCommons.guiElementClass;
    }
    /**
     * @param {boolean} [$value] Set visibility of element content at the screen.
     * @returns {boolean} Returns true, if content will be visible, otherwise false.
     */
    Visible($value) {
        if (ObjectValidator.IsSet($value)) {
            this.visible = Property.Boolean(this.visible, $value);
            if (!ObjectValidator.IsEmptyOrNull(this.InstanceOwner())) {
                if (ElementManager.Exists(this.Id())) {
                    const thisClass = Reflection.getInstance().getClass(this.getClassName());
                    if (this.visible) {
                        const events = EventsManager.getInstanceSingleton();
                        if (!this.isContentLoaded() || !this.IsLoaded()) {
                            events.FireAsynchronousMethod(() => {
                                if (this.visible) {
                                    if (!this.isContentLoaded()) {
                                        if (ObjectValidator.IsEmptyOrNull(this.outputEndOfLine)) {
                                            this.outputEndOfLine = StringUtils.NewLine(false);
                                        }
                                        const EOL = this.outputEndOfLine;
                                        ElementManager.setInnerHtml(this.Id(), this.guiContent().Draw(EOL + "        ") + EOL + "   ");
                                        events.FireEvent(this, EventType.ON_START);
                                    }
                                    thisClass.Show(this);
                                    if (!this.IsLoaded() && ElementManager.IsVisible(this.Id())) {
                                        if (this.IsCached() && !this.IsPrepared()) {
                                            this.innerCode();
                                        }
                                        events.FireEvent(this, EventType.ON_LOAD);
                                    }
                                }
                            }, false);
                        }
                        else {
                            thisClass.Show(this);
                            if (this.IsCached() && (this.IsPrepared() || !ObjectValidator.IsEmptyOrNull(this.Parent()))) {
                                if (!this.IsPrepared()) {
                                    this.innerCode();
                                }
                                if (!this.IsCompleted()) {
                                    let fireCompleted = true;
                                    const validateVisibility = ($parent) => {
                                        if (!ObjectValidator.IsEmptyOrNull($parent)) {
                                            if (!$parent.Visible() || !ElementManager.IsVisible($parent.Id())) {
                                                fireCompleted = false;
                                            }
                                            else {
                                                validateVisibility($parent.Parent());
                                            }
                                        }
                                    };
                                    validateVisibility(this.Parent());
                                    if (fireCompleted) {
                                        this.completed = true;
                                        events.FireEvent(this, EventType.ON_COMPLETE);
                                    }
                                }
                            }
                        }
                    }
                    else {
                        thisClass.Hide(this);
                    }
                }
            }
        }
        if (!ObjectValidator.IsSet(this.visible)) {
            this.visible = true;
        }
        return this.visible;
    }
    /**
     * @param {boolean} [$value] Switch type of element mode between enabled and disabled.
     * @returns {boolean} Returns true, if element is in enabled mode, otherwise false.
     */
    Enabled($value) {
        if (!ObjectValidator.IsSet(this.enabled)) {
            this.enabled = true;
        }
        this.enabled = Property.Boolean(this.enabled, $value);
        if (!this.enabled) {
            if (!this.IsLoaded()) {
                this.getGuiOptions().Add(GuiOptionType.DISABLE);
            }
            else if (!this.getGuiOptions().Contains(GuiOptionType.DISABLE)) {
                Echo.Printf("Disabled HTML mod can be missing at run time for element " + this.Id() + ". " +
                    "Did you add GuiOptionType?");
            }
        }
        if (ObjectValidator.IsSet($value) && ElementManager.IsVisible(this.Id())) {
            if (!this.enabled && this.getGuiOptions().Contains(GuiOptionType.DISABLE)) {
                ElementManager.setClassName(this.Id() + "_Status", GeneralCssNames.DISABLE);
            }
            else {
                ElementManager.setClassName(this.Id() + "_Status", "");
            }
        }
        return this.enabled;
    }
    /**
     * @param {string} [$value] Set type of css class name connected with the object instance.
     * @returns {string} Returns css class name connected with the object instance.
     */
    StyleClassName($value) {
        if (ObjectValidator.IsSet($value)) {
            if (this.styleClassNameSetterValidator($value)) {
                this.styleClassName = StringUtils.Remove($value, ".");
                if (this.IsLoaded()) {
                    ElementManager.setClassName(this.Id() + "_GuiWrapper", this.styleClassName);
                }
            }
        }
        else if (!ObjectValidator.IsSet(this.styleClassName)) {
            this.styleClassName = "";
        }
        return this.styleClassName;
    }
    /**
     * @returns {string} Returns element id suitable to correct element identification in page context.
     */
    Id() {
        return this.guiId;
    }
    /**
     * @param {GuiCommons} [$value] Set instance of the element owner.
     * @returns {GuiCommons} Returns instance of the element owner, if the element has owner, otherwise null.
     */
    Parent($value) {
        if (ObjectValidator.IsSet($value)) {
            this.parent = $value;
            if (!ObjectValidator.IsSet(this.owner)) {
                this.owner = this.parent.InstanceOwner();
            }
        }
        return this.parent;
    }
    /**
     * @param {IBaseViewer} [$value] Set viewer instance of the GUI object instance owner.
     * @returns {IBaseViewer} Returns viewer instance of the GUI object instance owner, if the instance has owner, otherwise null.
     */
    InstanceOwner($value) {
        if (ObjectValidator.IsSet($value)) {
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            this.owner = $value;
        }
        if (ObjectValidator.IsEmptyOrNull(this.owner)) {
            if (!ObjectValidator.IsEmptyOrNull(this.Parent())) {
                this.owner = this.Parent().InstanceOwner();
            }
            else {
                this.owner = null;
            }
        }
        return this.owner;
    }
    /**
     * @param {string} [$value] Set path to instance of the GUI object, which can be used for its usage identification.
     * @returns {string} Returns path to instance of the GUI object in current usage.
     */
    InstancePath($value) {
        if (ObjectValidator.IsEmptyOrNull(this.guiPath)) {
            this.guiPath = this.getClassName();
            if (!ObjectValidator.IsEmptyOrNull(this.InstanceOwner())) {
                let property;
                for (property in this.owner) {
                    if (this.owner[property] === this) {
                        this.guiPath += "." + property;
                        break;
                    }
                }
            }
        }
        return this.guiPath = Property.String(this.guiPath, $value);
    }
    /**
     * @returns {IArrayList<IGuiCommons>} Returns list of child elements belonging to this instance.
     */
    getChildElements() {
        if (!ObjectValidator.IsSet(this.childElements)) {
            this.childElements = new ArrayList();
        }
        return this.childElements;
    }
    /**
     * @returns {ElementOffset} Returns element's position relative to screen top left corner.
     */
    getScreenPosition() {
        return ElementManager.getScreenPosition(this.guiContentId());
    }
    /**
     * Specify rendering position of the element or override position defined by CSS
     * @param {number} $top Specify element's top position
     * @param {number} $left Specify element's left position
     * @param {PositionType} [$type] Specify element's position type
     * @returns {void}
     */
    setPosition($top, $left, $type) {
        const id = this.Id() + "_GuiWrapper";
        const setPosition = () => {
            if (PositionType.Contains($type)) {
                ElementManager.setCssProperty(id, "position", $type.toString());
            }
            else {
                const positionType = ElementManager.getCssValue(id, "position");
                if (ObjectValidator.IsEmptyOrNull(positionType) || positionType === "static") {
                    ElementManager.setCssProperty(id, "position", "relative");
                }
            }
            ElementManager.setCssProperty(id, "top", $top);
            ElementManager.setCssProperty(id, "left", $left);
        };
        if (this.IsLoaded()) {
            setPosition();
        }
        else {
            this.getEvents().setOnComplete(setPosition);
        }
    }
    /**
     * @returns {Size} Returns current element's width and height based on available information.
     */
    getSize() {
        if (this.IsLoaded()) {
            return new Size(this.guiContentId());
        }
        return new Size();
    }
    /**
     * Can be overriden in extending classes for FitToParent capability.
     * @param {number} [$value] Specify element's width value.
     * @returns {number} Returns element's width value if reachable otherwise undefined.
     */
    Width($value) {
        return undefined;
    }
    /**
     * Can be overridden in extending classes for FitToParent capability.
     * @param {number} [$value] Specify element's height value.
     * @returns {number} Returns element's height value if reachable otherwise undefined.
     */
    Height($value) {
        return undefined;
    }
    /**
     * @param {FitToParent} [$value] Specify how should this element be stretched inside its parent.
     * @returns {IGuiCommons} Returns reference to the current GuiCommons instance.
     */
    FitToParent($value) {
        this.fitToParent = $value;
        return this;
    }
    /**
     * @returns {FitToParent} Returns set FitToParent.
     */
    getFitToParent() {
        return this.fitToParent;
    }
    /**
     * @returns {boolean} Returns true, if element has been loaded from cache, otherwise false.
     */
    IsCached() {
        if (!ObjectValidator.IsSet(this.cached)) {
            this.cached = !ObjectValidator.IsEmptyOrNull(this.InstanceOwner()) && this.InstanceOwner().IsCached() && this.IsLoaded();
        }
        return this.cached;
    }
    /**
     * @returns {boolean} Returns true, if element has been prepared by it's owner, otherwise false.
     */
    IsPrepared() {
        if (!ObjectValidator.IsSet(this.prepared)) {
            this.prepared = false;
        }
        return this.prepared;
    }
    /**
     * @returns {boolean} Returns true, if element has been loaded, otherwise false.
     */
    IsLoaded() {
        if (!ObjectValidator.IsSet(this.loaded)) {
            this.loaded = false;
        }
        return this.loaded;
    }
    /**
     * @returns {boolean} Returns true, if element's ON_COMPLETE event has been fired, otherwise false.
     */
    IsCompleted() {
        if (!ObjectValidator.IsSet(this.completed)) {
            this.completed = false;
        }
        return this.completed;
    }
    /**
     * Disable asynchronous rendering of the element to the screen.
     * @returns {void}
     */
    DisableAsynchronousDraw() {
        this.asyncDrawEnabled = false;
    }
    /**
     * @param {string} [$EOL] Specify end of line format for generated html output.
     * @returns {string} Returns element's content suitable for renderings at the screen.
     */
    Draw($EOL) {
        if (ObjectValidator.IsEmptyOrNull($EOL)) {
            $EOL = StringUtils.NewLine(false);
        }
        this.outputEndOfLine = $EOL;
        const id = this.Id();
        let parentId = "not registered";
        if (!ObjectValidator.IsEmptyOrNull(this.Parent())) {
            parentId = this.Parent().Id();
        }
        let content = "";
        if (!this.hasAsynchronousDraw()) {
            content = this.guiContent();
        }
        if (ObjectValidator.IsEmptyOrNull(this.InstanceOwner()) ||
            (!ObjectValidator.IsEmptyOrNull(this.InstanceOwner()) &&
                ObjectValidator.IsSet(this.InstanceOwner().TestModeEnabled) && this.InstanceOwner().TestModeEnabled())) {
            this.getEvents().FireAsynchronousMethod(() => {
                LogIt.Debug("Draw of GUI object placeholder " + id + " with parent " + parentId);
            }, false);
        }
        const mainWrapper = this.addElement().StyleClassName(this.getCssInterfaceName());
        const wrappingElement = this.getWrappingElement();
        if (ObjectValidator.IsSet(wrappingElement)) {
            if (wrappingElement.getGuiTypeTag() === GeneralCssNames.ROW) {
                mainWrapper.Id(this.guiId + "_GuiCol").GuiTypeTag("GuiCol");
            }
            mainWrapper.setWrappingElement(wrappingElement);
            this.setWrappingElement(mainWrapper);
        }
        return mainWrapper
            .Add(this.addElement(this.guiId + "_GuiWrapper")
            .GuiTypeTag("GuiWrapper")
            .StyleClassName(this.StyleClassName())
            .Add(this.addElement(this.guiId)
            .StyleClassName(this.getCssContainerName())
            .Visible(!ObjectValidator.IsEmptyOrNull(content) && this.Visible())
            .Add(content)))
            .Draw($EOL);
    }
    /**
     * @returns {IGuiCommonsArg[]} Returns array of element's attributes.
     */
    getArgs() {
        const size = this.getSize();
        const position = this.getScreenPosition();
        return [
            {
                name: "Id",
                type: GuiCommonsArgType.TEXT,
                value: this.Id()
            },
            {
                name: "StyleClassName",
                type: GuiCommonsArgType.TEXT,
                value: this.StyleClassName()
            },
            {
                name: "Enabled",
                type: GuiCommonsArgType.BOOLEAN,
                value: this.Enabled()
            },
            {
                name: "Visible",
                type: GuiCommonsArgType.BOOLEAN,
                value: this.Visible()
            },
            {
                name: "Width",
                type: GuiCommonsArgType.NUMBER,
                value: size.Width()
            },
            {
                name: "Height",
                type: GuiCommonsArgType.NUMBER,
                value: size.Height()
            },
            {
                name: "Top",
                type: GuiCommonsArgType.NUMBER,
                value: position.Top()
            },
            {
                name: "Left",
                type: GuiCommonsArgType.NUMBER,
                value: position.Left()
            }
        ];
    }
    /**
     * @param {IGuiCommonsArg} $value Specify argument value, which should be passed to element.
     * @param {boolean} [$force=false] Specify, if value should be set without fire of events connected with argument change.
     * @returns {void}
     */
    setArg($value, $force = false) {
        switch ($value.name) {
            case "StyleClassName":
                this.StyleClassName($value.value);
                break;
            case "Visible":
                this.Visible($value.value);
                break;
            case "Enabled":
                this.Enabled($value.value);
                break;
            case "Width":
                ElementManager.setCssProperty(this.guiContentId(), "width", $value.value);
                break;
            case "Height":
                ElementManager.setCssProperty(this.guiContentId(), "height", $value.value);
                break;
            case "Top":
                ElementManager.setCssProperty(this.guiContentId(), "top", $value.value);
                break;
            case "Left":
                ElementManager.setCssProperty(this.guiContentId(), "left", $value.value);
                break;
            default:
                break;
        }
    }
    /**
     * @returns {IGuiElement} Returns reference to element's inner HTML structure object.
     */
    getInnerHtmlMap() {
        if (ObjectValidator.IsEmptyOrNull(this.innerHtmlMap)) {
            this.innerHtmlMap = this.innerHtml();
        }
        return this.innerHtmlMap;
    }
    /**
     * @returns {IGuiElement} Returns reference to element wrapping this instance inside generated HTML.
     */
    getWrappingElement() {
        return this.wrappingElement;
    }
    /**
     * @param {IGuiCommonsArg} $value Specify element wrapping this instance inside generated HTML.
     */
    setWrappingElement($value) {
        this.wrappingElement = $value;
    }
    /**
     * @returns {IGuiElement} Returns reference to element wrapping this instance before conversion to HTML.
     */
    getWrappingContainer() {
        return this.wrappingContainer;
    }
    /**
     * @param {IGuiCommonsArg} $value Specify element wrapping this instance before conversion to HTML.
     */
    setWrappingContainer($value) {
        this.wrappingContainer = $value;
    }
    /**
     * @returns {boolean} Returns true if element should prevent scroll otherwise false.
     */
    IsPreventingScroll() {
        return false;
    }
    ToString($prefix = "", $htmlTag = true) {
        return this.getClassName() + " (" + this.Id() + ")";
    }
    toString() {
        return this.ToString();
    }
    /**
     * @returns {ElementEventsManager} This method should return class with
     * interface Io.Oidis.Gui.Interfaces.Events.IGuiCommonsEvents
     */
    getEventsManagerClass() {
        return ElementEventsManager;
    }
    addElement($id) {
        return new GuiCommons.guiElementClass().Id($id);
    }
    addRow($id) {
        if (ObjectValidator.IsEmptyOrNull($id)) {
            $id = this.getRandomGuiId() + "_" + GeneralCssNames.ROW;
        }
        return new GuiCommons.guiElementClass().Id($id).GuiTypeTag(GeneralCssNames.ROW);
    }
    addColumn($id) {
        if (ObjectValidator.IsEmptyOrNull($id)) {
            $id = this.getRandomGuiId() + "_" + GeneralCssNames.COLUMN;
        }
        return new GuiCommons.guiElementClass().Id($id).GuiTypeTag(GeneralCssNames.COLUMN);
    }
    /**
     * Specify attributes of the instance after unserialization.
     */
    setInstanceAttributes() {
        this.parent = null;
        this.owner = null;
        this.prepared = false;
        this.completed = false;
        this.loaded = false;
        this.innerHtmlMap = null;
        this.getGuiManager().Add(this);
    }
    beforeCacheCreation($preparationResultHandler) {
        // override this method for ability to prepare gui element for cache creation
    }
    afterCacheCreation($id, $value) {
        // override this method for ability to restore gui element after cache creation
    }
    availableGuiOptions() {
        if (!ObjectValidator.IsSet(this.availableOptionsList)) {
            this.availableOptionsList = new ArrayList();
        }
        this.availableOptionsList.Add(GuiOptionType.DISABLE);
        return this.availableOptionsList;
    }
    styleClassNameSetterValidator($value) {
        return true;
    }
    cssInterfaceName() {
        return this.getNamespaceName();
    }
    cssContainerName() {
        return this.getClassNameWithoutNamespace();
    }
    getGuiTypeTag() {
        return this.getCssContainerName();
    }
    /**
     * @returns {IGuiElement} String Used for definition of Code, which should be included as part of GUI object
     */
    innerCode() {
        if (!ObjectValidator.IsSet(this.waitFor)) {
            this.waitFor = new ArrayList();
        }
        const events = EventsManager.getInstanceSingleton();
        if (this.getChildElements().IsEmpty()) {
            let parameter;
            for (parameter in this) {
                if (parameter !== "parent" && parameter !== "owner" &&
                    typeof this[parameter] !== SyntaxConstants.FUNCTION) {
                    const propertyInstance = this[parameter];
                    if (!ObjectValidator.IsEmptyOrNull(propertyInstance) &&
                        ObjectValidator.IsSet(propertyInstance.Parent)) {
                        propertyInstance.Parent(this);
                        propertyInstance.InstancePath(this.InstancePath() + "." + parameter);
                        this.getChildElements().Add(propertyInstance, propertyInstance.Id());
                    }
                }
            }
        }
        if (!this.IsLoaded()) {
            this.cached = false;
            this.getEvents().setOnStart(($eventArgs) => {
                const element = $eventArgs.Owner();
                if (ObjectValidator.IsEmptyOrNull(element.InstanceOwner()) ||
                    (!ObjectValidator.IsEmptyOrNull(element.InstanceOwner()) &&
                        ObjectValidator.IsSet(element.InstanceOwner().TestModeEnabled) && element.InstanceOwner().TestModeEnabled())) {
                    LogIt.Debug("Start " + element.Id());
                }
                element.getChildElements().foreach(($child) => {
                    if (!ObjectValidator.IsEmptyOrNull($child)) {
                        if ($child.Visible() && !$child.IsLoaded() && !element.waitFor.Contains($child)) {
                            element.waitFor.Add($child);
                        }
                        $child.getEvents().setOnComplete(($eventArgs) => {
                            const child = $eventArgs.Owner();
                            const parent = child.Parent();
                            if (!ObjectValidator.IsEmptyOrNull(parent)) {
                                if (!parent.waitFor.IsEmpty()) {
                                    parent.waitFor.RemoveAt(parent.waitFor.IndexOf(child));
                                }
                                if (parent.waitFor.IsEmpty() && !parent.IsCompleted()) {
                                    parent.completed = true;
                                    events.FireEvent(parent, EventType.ON_COMPLETE);
                                }
                            }
                        });
                    }
                });
            });
            this.getEvents().setOnLoad(($eventArgs) => {
                const element = $eventArgs.Owner();
                if (ObjectValidator.IsEmptyOrNull(element.InstanceOwner()) ||
                    (!ObjectValidator.IsEmptyOrNull(element.InstanceOwner()) &&
                        ObjectValidator.IsSet(element.InstanceOwner().TestModeEnabled) && element.InstanceOwner().TestModeEnabled())) {
                    LogIt.Debug("Loaded " + element.Id());
                }
                element.cached = false;
                element.loaded = true;
                if (element.Visible()) {
                    if (ObjectValidator.IsSet(element.waitFor) && !element.waitFor.IsEmpty()) {
                        const loaderItems = new ArrayList();
                        element.waitFor.foreach(($child) => {
                            loaderItems.Add(() => {
                                if (!$child.IsLoaded() && $child.Visible()) {
                                    $child.Visible(true);
                                }
                            });
                        });
                        GuiCommons.asyncLoadChildren(loaderItems);
                    }
                    else if (!element.IsCompleted()) {
                        element.completed = true;
                        events.FireEvent(element, EventType.ON_COMPLETE);
                    }
                }
            });
            this.getEvents().setBeforeLoad(($eventArgs) => {
                const element = $eventArgs.Owner();
                if (ObjectValidator.IsEmptyOrNull(element.InstanceOwner()) ||
                    (!ObjectValidator.IsEmptyOrNull(element.InstanceOwner()) &&
                        ObjectValidator.IsSet(element.InstanceOwner().TestModeEnabled) && element.InstanceOwner().TestModeEnabled())) {
                    LogIt.Debug("Prepare for load " + $eventArgs.Owner().Id());
                }
                events.FireEvent(element, EventType.ON_LOAD);
            });
        }
        else {
            this.cached = true;
        }
        this.getEvents().setOnComplete(($eventArgs) => {
            const element = $eventArgs.Owner();
            if (element.Visible()) {
                if (ObjectValidator.IsEmptyOrNull(element.InstanceOwner()) ||
                    (!ObjectValidator.IsEmptyOrNull(element.InstanceOwner()) &&
                        ObjectValidator.IsSet(element.InstanceOwner().TestModeEnabled) && element.InstanceOwner().TestModeEnabled())) {
                    LogIt.Debug("Completed " + element.Id());
                }
                const parentIsCached = element.IsCached();
                element.getChildElements().foreach(($child) => {
                    if (parentIsCached && $child.IsLoaded()) {
                        $child.cached = true;
                    }
                    if (!$child.IsCompleted()) {
                        let fireCompleted = false;
                        if ($child.Visible() && ElementManager.IsVisible($child.Id())) {
                            fireCompleted = true;
                        }
                        if (fireCompleted) {
                            const validateVisibility = ($parent) => {
                                if (!ObjectValidator.IsEmptyOrNull($parent)) {
                                    if (!$parent.Visible() || !ElementManager.IsVisible($parent.Id())) {
                                        fireCompleted = false;
                                    }
                                    else {
                                        validateVisibility($parent.Parent());
                                    }
                                }
                            };
                            validateVisibility($child.Parent());
                            if (fireCompleted) {
                                if (!$child.IsPrepared()) {
                                    $child.innerCode();
                                }
                                $child.completed = true;
                                events.FireEvent($child, EventType.ON_COMPLETE);
                            }
                        }
                    }
                });
                element.completed = true;
                element.getEvents().Subscribe();
            }
        });
        this.prepared = true;
        return this.addElement();
    }
    /**
     * @returns {IGuiElement} String Used for definition of HTML with final settings
     */
    innerHtml() {
        return this.addElement();
    }
    getHttpManager() {
        return Loader.getInstance().getHttpResolver().getManager();
    }
    getEventsManager() {
        return Loader.getInstance().getHttpResolver().getEvents();
    }
    getGuiManager() {
        return GuiObjectManager.getInstanceSingleton();
    }
    guiContent() {
        this.contentLoaded = true;
        let innerCode = "";
        if (!this.IsPrepared()) {
            innerCode = this.innerCode();
        }
        this.innerHtmlMap = this.innerHtml();
        return this.addElement().Add(innerCode).Add(this.innerHtmlMap);
    }
    guiContentId() {
        return this.Id();
    }
    unhide($process) {
        const clone = ElementManager.getElement(this.Id())
            .parentElement.parentElement.cloneNode(true);
        ElementManager.setOpacity(clone, 0);
        document.body.appendChild(clone);
        const elements = clone.getElementsByTagName("div");
        let index;
        for (index = 0; index < elements.length; index++) {
            if (!$process(elements[index].id, elements[index])) {
                break;
            }
        }
        document.body.removeChild(clone);
    }
    excludeSerializationData() {
        const exclude = super.excludeSerializationData();
        exclude.push("options", "availableOptionsList", "parent", "owner", "guiPath", "visible", "enabled", "prepared", "completed", "interfaceClassName", "styleClassName", "containerClassName", "loaded", "asyncDrawEnabled", "contentLoaded", "waitFor", "outputEndOfLine", "innerHtmlMap");
        if (this.getEvents().getAll().IsEmpty()) {
            exclude.push("events");
        }
        return exclude;
    }
    excludeCacheData() {
        const exclude = [
            "options", "availableOptionsList",
            "events",
            "childElements", "waitFor",
            "cached", "prepared", "completed",
            "parent", "owner", "guiPath",
            "interfaceClassName", "styleClassName", "containerClassName",
            "innerHtmlMap"
        ];
        if (this.visible === true) {
            exclude.push("visible");
        }
        if (this.enabled === true) {
            exclude.push("enabled");
        }
        if (this.asyncDrawEnabled === true) {
            exclude.push("asyncDrawEnabled");
        }
        if (this.contentLoaded === false) {
            exclude.push("contentLoaded");
        }
        else if (this.contentLoaded === true && !this.IsMemberOf("Io.Oidis.Gui.Primitives.BasePanel")) {
            exclude.push("outputEndOfLine");
        }
        if (this.loaded === false) {
            exclude.push("loaded");
        }
        return exclude;
    }
    isContentLoaded() {
        if (!ObjectValidator.IsSet(this.contentLoaded)) {
            this.contentLoaded = false;
        }
        return this.contentLoaded;
    }
    hasAsynchronousDraw() {
        if (!ObjectValidator.IsSet(this.asyncDrawEnabled)) {
            this.asyncDrawEnabled = true;
        }
        return this.asyncDrawEnabled;
    }
    getCssInterfaceName() {
        if (!ObjectValidator.IsSet(this.interfaceClassName)) {
            this.interfaceClassName = StringUtils.Remove(this.cssInterfaceName(), ".");
        }
        return this.interfaceClassName;
    }
    getCssContainerName() {
        if (!ObjectValidator.IsSet(this.containerClassName)) {
            this.containerClassName = StringUtils.Remove(this.cssContainerName(), ".");
        }
        return this.containerClassName;
    }
    getRandomGuiId() {
        return (new Date().getTime()).toString() +
            Math.floor(Math.random() * 100000).toString();
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Primitives.GuiCommons", GuiCommons);
//# sourceMappingURL=GuiCommons.js.map