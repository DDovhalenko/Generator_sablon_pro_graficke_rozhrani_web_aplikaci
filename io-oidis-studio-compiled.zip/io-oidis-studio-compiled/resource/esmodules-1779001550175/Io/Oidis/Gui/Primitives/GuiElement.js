import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { GeneralCssNames } from "../Enums/GeneralCssNames.js";
import { IGuiCommons } from "../Interfaces/Primitives/IGuiCommons.js";
import { IGuiElement } from "../Interfaces/Primitives/IGuiElement.js";
import { IResponsiveElement } from "../Interfaces/Primitives/IResponsiveElement.js";
import { PropagableNumber } from "../Structures/PropagableNumber.js";
/**
 * GuiElement class provides structure for handling of element rendering.
 */
export class GuiElement extends BaseObject {
    id;
    styleClassName;
    visible;
    guiType;
    width;
    height;
    items;
    itemIndex;
    attributes;
    alignment;
    fitToParent;
    visibilityStrategy;
    heightOfRow;
    widthOfColumn;
    wrappingElement;
    constructor() {
        super();
        this.id = null;
        this.styleClassName = null;
        this.visible = null;
        this.guiType = null;
        this.width = null;
        this.height = null;
        this.items = [];
        this.itemIndex = 0;
        this.attributes = null;
    }
    /**
     * @param {string} $value Specify element's id.
     * @returns {IGuiElement} Returns reference to current GuiElement instance.
     */
    Id($value) {
        this.id = Property.String(this.id, $value);
        return this;
    }
    /**
     * @returns {string} Returns current element's id
     */
    getId() {
        return this.id;
    }
    /**
     * @param {string} $value Specify element's guiTag value.
     * @returns {IGuiElement} Returns reference to current GuiElement instance.
     */
    GuiTypeTag($value) {
        this.guiType = Property.String(this.guiType, $value);
        return this;
    }
    /**
     * @param {string|BaseEnum} $value Specify element's CSS className value.
     * @returns {IGuiElement} Returns reference to current GuiElement instance.
     */
    StyleClassName($value) {
        this.styleClassName = Property.String(this.styleClassName, "" + $value);
        return this;
    }
    /**
     * @param {boolean} $value Specify element's visibility.
     * @returns {IGuiElement} Returns reference to current GuiElement instance.
     */
    Visible($value) {
        this.visible = Property.Boolean(this.visible, $value);
        return this;
    }
    /**
     * @returns {boolean} Returns currently set visible status.
     */
    getVisible() {
        return this.visible;
    }
    /**
     * @param {number} $value Specify element's width value in pixel format.
     * @returns {IGuiElement} Returns reference to current GuiElement instance.
     */
    Width($value) {
        this.width = Property.PositiveInteger(this.width, $value);
        return this;
    }
    /**
     * @returns {number} Returns currently set width.
     */
    getWidth() {
        return this.width;
    }
    /**
     * @param {number} $value Specify element's height value in pixel format.
     * @returns {IGuiElement} Returns reference to current IGuiElement instance.
     */
    Height($value) {
        this.height = Property.PositiveInteger(this.height, $value);
        return this;
    }
    /**
     * @returns {number} Returns currently set height.
     */
    getHeight() {
        return this.height;
    }
    /**
     * @param {Alignment | () => Alignment} [$value] Specify how should this element be aligned - can be set to propagate to it's
     * children.
     * @returns {IResponsiveElement} Returns reference to the current IResponsiveElement instance.
     */
    Alignment($value) {
        this.alignment = $value;
        return this;
    }
    /**
     * @returns {Alignment} Returns set Alignment.
     */
    getAlignment() {
        if (ObjectValidator.IsFunction(this.alignment)) {
            return this.alignment();
        }
        return this.alignment;
    }
    /**
     * @param {FitToParent | () => FitToParent} [$value] Specify how should all GuiCommons children be stretched inside their columns
     * @returns {IResponsiveElement} Returns reference to the current IResponsiveElement instance.
     */
    FitToParent($value) {
        this.fitToParent = $value;
        return this;
    }
    /**
     * @returns {FitToParent} Returns set FitToParent.
     */
    getFitToParent() {
        if (ObjectValidator.IsFunction(this.fitToParent)) {
            return this.fitToParent();
        }
        return this.fitToParent;
    }
    /**
     * @param {VisibilityStrategy | () => VisibilityStrategy} [$value] Specify how should visibility of container be handled
     * @returns {IResponsiveElement} Returns reference to the current IResponsiveElement instance.
     */
    VisibilityStrategy($value) {
        this.visibilityStrategy = $value;
        return this;
    }
    /**
     * @returns {VisibilityStrategy} Returns set VisibilityStrategy value.
     */
    getVisibilityStrategy() {
        if (ObjectValidator.IsFunction(this.visibilityStrategy)) {
            return this.visibilityStrategy();
        }
        return this.visibilityStrategy;
    }
    WidthOfColumn($value, par1, par2) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            if (ObjectValidator.IsFunction($value)) {
                this.widthOfColumn = $value;
            }
            else if (ObjectValidator.IsString($value)) {
                this.widthOfColumn = new PropagableNumber($value, Boolean(par1));
            }
            else if (ObjectValidator.IsSet(par1)) {
                this.widthOfColumn = new PropagableNumber({ number: Number($value), unitType: par1 }, Boolean(par2));
            }
        }
        else {
            if (ObjectValidator.IsBoolean(par1)) {
                this.widthOfColumn = new PropagableNumber({ number: -1, unitType: null }, Boolean(par1));
            }
            else if (ObjectValidator.IsSet(par2)) {
                this.widthOfColumn = new PropagableNumber({ number: -1, unitType: null }, Boolean(par2));
            }
            else {
                this.widthOfColumn = new PropagableNumber({ number: -1, unitType: null }, false);
            }
        }
        return this;
    }
    HeightOfRow($value, par1, par2) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            if (ObjectValidator.IsFunction($value)) {
                this.heightOfRow = $value;
            }
            else if (ObjectValidator.IsString($value)) {
                this.heightOfRow = new PropagableNumber($value, Boolean(par1));
            }
            else if (ObjectValidator.IsSet(par1)) {
                this.heightOfRow = new PropagableNumber({ number: Number($value), unitType: par1 }, Boolean(par2));
            }
        }
        else {
            if (ObjectValidator.IsBoolean(par1)) {
                this.heightOfRow = new PropagableNumber({ number: -1, unitType: null }, Boolean(par1));
            }
            else if (ObjectValidator.IsSet(par2)) {
                this.heightOfRow = new PropagableNumber({ number: -1, unitType: null }, Boolean(par2));
            }
            else {
                this.heightOfRow = new PropagableNumber({ number: -1, unitType: null }, false);
            }
        }
        return this;
    }
    /**
     * @returns {PropagableNumber} Returns set width of column
     */
    getWidthOfColumn() {
        if (ObjectValidator.IsFunction(this.widthOfColumn)) {
            return this.widthOfColumn();
        }
        return this.widthOfColumn;
    }
    /**
     * @returns {PropagableNumber} Returns set height of row
     */
    getHeightOfRow() {
        if (ObjectValidator.IsFunction(this.heightOfRow)) {
            return this.heightOfRow();
        }
        return this.heightOfRow;
    }
    /**
     * @param {string} $key Specify element's CSS attribute name.
     * @param {string} $value Specify element's CSS attribute value.
     * @returns {IGuiElement} Returns reference to current GuiElement instance.
     */
    setAttribute($key, $value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            if (this.attributes === null) {
                this.attributes = new ArrayList();
            }
            if (ObjectValidator.IsEmptyOrNull($key)) {
                this.attributes.Add($value);
            }
            else {
                this.attributes.Add($value, $key);
            }
        }
        return this;
    }
    /**
     * @returns {IGuiElement} Returns current element's GuiType
     */
    getGuiTypeTag() {
        return this.guiType;
    }
    /**
     * @param {string|IGuiElement|IResponsiveElement|IGuiCommons|IBaseViewer|HTMLElement} $value Specify element's content.
     * @returns {IGuiElement} Returns reference to current GuiElement instance.
     */
    Add($value) {
        if (ObjectValidator.IsEmptyOrNull($value)) {
            return this;
        }
        const isNative = (ObjectValidator.IsString($value) || $value instanceof HTMLElement);
        let element = $value;
        if (!isNative) {
            const object = $value;
            if (object.Implements(IGuiCommons)) {
                const commons = object;
                if (this.guiType === GeneralCssNames.COLUMN) {
                    const rowElement = new GuiElement().GuiTypeTag(GeneralCssNames.ROW);
                    rowElement.Id(commons.Id() + "_" + GeneralCssNames.ROW);
                    rowElement.Add($value);
                    element = rowElement;
                    commons.setWrappingElement(rowElement);
                    rowElement.setWrappingElement(this);
                }
                else {
                    commons.setWrappingElement(this);
                }
                commons.setWrappingContainer(this);
            }
            else if (object.Implements(IGuiElement) && object.Implements(IResponsiveElement)) {
                const guiElement = object;
                if (this.guiType === GeneralCssNames.COLUMN && guiElement.getGuiTypeTag() === GeneralCssNames.COLUMN) {
                    const rowElement = new GuiElement().GuiTypeTag(GeneralCssNames.ROW);
                    rowElement.Id(this.getUID() + "_" + GeneralCssNames.ROW);
                    rowElement.Add($value);
                    guiElement.setWrappingElement(rowElement);
                    element = rowElement;
                }
                else if (this.guiType === GeneralCssNames.ROW && guiElement.getGuiTypeTag() === GeneralCssNames.ROW) {
                    const columnElement = new GuiElement().GuiTypeTag(GeneralCssNames.COLUMN);
                    columnElement.Id(this.getUID() + "_" + GeneralCssNames.COLUMN);
                    columnElement.Add($value);
                    guiElement.setWrappingElement(columnElement);
                    element = columnElement;
                }
                else {
                    guiElement.setWrappingElement(this);
                }
            }
        }
        else if (this.guiType === GeneralCssNames.COLUMN || this.guiType === GeneralCssNames.ROW) {
            const guiWrapper = new GuiElement().GuiTypeTag("GuiWrapper");
            guiWrapper.addChildElement($value);
            const columnElement = new GuiElement().GuiTypeTag(GeneralCssNames.COLUMN);
            columnElement.Id(this.getUID() + "_" + GeneralCssNames.COLUMN);
            columnElement.addChildElement(guiWrapper);
            if (this.guiType === GeneralCssNames.COLUMN) {
                const rowElement = new GuiElement().GuiTypeTag(GeneralCssNames.ROW);
                rowElement.Id(this.getUID() + "_" + GeneralCssNames.ROW);
                rowElement.addChildElement(columnElement);
                columnElement.setWrappingElement(rowElement);
                element = rowElement;
            }
            else {
                columnElement.setWrappingElement(this);
                element = columnElement;
            }
        }
        this.items[this.itemIndex++] = element;
        return this;
    }
    /**
     * @param {string|IGuiElement|IResponsiveElement|IGuiCommons|IBaseViewer|HTMLElement} $value Specify element to
     * be directly inserted as a child inside this instance.
     */
    addChildElement($value) {
        this.items[this.itemIndex++] = $value;
    }
    /**
     * @returns {IArrayList<IGuiElement | IResponsiveElement | IGuiCommons | IBaseViewer>} Returns reference to IArrayList
     * containing only non-native gui elements.
     */
    getGuiChildElements() {
        const size = this.getChildElements().Length();
        let index = 0;
        const guiChildren = new ArrayList();
        for (index; index < size; index++) {
            const childElement = this.getChildElement(index);
            const isNative = (ObjectValidator.IsString(childElement) || childElement instanceof HTMLElement);
            if (!isNative) {
                const object = childElement;
                if (object.Implements(IGuiElement) || object.Implements(IGuiCommons)) {
                    guiChildren.Add(childElement);
                }
            }
        }
        return guiChildren;
    }
    /**
     * @returns {IArrayList<string | IGuiElement | IGuiCommons | IBaseViewer | HTMLElement>} Returns list of child elements
     * belonging to this instance.
     */
    getChildElements() {
        return ArrayList.ToArrayList(this.items);
    }
    /**
     * @param {number} $index Specify index of desired child. Index starts with 0.
     * @returns {string|IGuiElement|IGuiCommons|IBaseViewer|HTMLElement} Returns element's child, if desired index exists,
     * otherwise null.
     */
    getChildElement($index) {
        if ($index >= 0 && $index < this.itemIndex) {
            return this.items[$index];
        }
        return null;
    }
    /**
     * @returns {ArrayList<string>} Returns element's CSS attributes.
     */
    getAttributes() {
        if (this.attributes === null) {
            this.attributes = new ArrayList();
        }
        return this.attributes;
    }
    /**
     * @param {string} $EOL Specify end of line value, which should be used for rendering.
     * @returns {string} Returns element's content suitable for element rendering or storage.
     */
    Draw($EOL) {
        let id = "";
        if (this.id !== null && this.id !== "") {
            id = " id=\"" + this.id + "\"";
        }
        let guiType = "";
        if (this.guiType !== null && this.guiType !== "") {
            guiType = " guiType=\"" + this.guiType + "\"";
        }
        let styleClass = "";
        if (this.styleClassName !== null && this.styleClassName !== "") {
            styleClass = " class=\"" + this.styleClassName + "\"";
        }
        let style = "";
        if (this.visible !== null) {
            if (this.visible) {
                this.setAttribute("display", "block");
            }
            else {
                this.setAttribute("display", "none");
            }
        }
        if (this.width !== null) {
            this.setAttribute("width", this.width === 0 ? "0" : this.width + "px");
        }
        if (this.height !== null) {
            this.setAttribute("height", this.height === 0 ? "0" : this.height + "px");
        }
        if (!ObjectValidator.IsEmptyOrNull(this.attributes)) {
            this.attributes.SortByKeyUp();
            this.attributes.foreach(($value, $key) => {
                if (style !== "") {
                    style += " ";
                }
                if (!ObjectValidator.IsEmptyOrNull($key) && ObjectValidator.IsString($key)) {
                    style += StringUtils.Remove($key, ":") + ": " + $value + ";";
                }
                else {
                    if (!StringUtils.EndsWith($value, ";")) {
                        $value += ";";
                    }
                    style += $value;
                }
            });
        }
        if (style !== "") {
            style = " style=\"" + StringUtils.Replace(style, ";;", ";") + "\"";
        }
        const attributes = id + guiType + styleClass + style;
        let content = "";
        const contentEOL = attributes !== "" ? $EOL + "   " : $EOL;
        let index;
        for (index = 0; index < this.itemIndex; index++) {
            if (!ObjectValidator.IsEmptyOrNull(this.items[index])) {
                if (ObjectValidator.IsString(this.items[index])) {
                    content += this.itemToString(this.items[index], content !== "" ? $EOL : "", index);
                }
                else if (ObjectValidator.IsSet(this.items[index].outerHTML)) {
                    content += this.itemToString(this.items[index], $EOL, index);
                }
                else if (ObjectValidator.IsSet(this.items[index].Draw) || ObjectValidator.IsSet(this.items[index].Show)) {
                    content += this.itemToString(this.items[index], contentEOL, index);
                }
            }
        }
        if (attributes !== "") {
            if (StringUtils.EndsWith(content, "</div>")) {
                content += $EOL;
            }
            return $EOL + "<div" + attributes + ">" + content + "</div>";
        }
        return content;
    }
    /**
     * @param {string} $EOL Specify end of line value, which should be used for rendering.
     * @returns {HTMLElement} Returns HTMLElement element suitable for manipulation with DOM.
     */
    ToDOMElement($EOL) {
        const element = document.createElement("div");
        element.innerHTML = this.Draw($EOL);
        return element.childNodes[1];
    }
    /**
     * @returns {IGuiElement} Returns reference to element wrapping this instance.
     */
    getWrappingElement() {
        return this.wrappingElement;
    }
    /**
     * @param {IGuiCommonsArg} $value Specify wrapping element.
     */
    setWrappingElement($value) {
        this.wrappingElement = $value;
    }
    toString() {
        return this.Draw(StringUtils.NewLine(false));
    }
    itemToString($item, $EOL, $key) {
        if (!ObjectValidator.IsEmptyOrNull($item)) {
            if (ObjectValidator.IsString($item)) {
                return $EOL + $item;
            }
            else if (ObjectValidator.IsSet($item.outerHTML)) {
                return $EOL + $item.outerHTML;
            }
            else if (ObjectValidator.IsSet($item.Draw)) {
                return $item.Draw($EOL);
            }
            else if (ObjectValidator.IsSet($item.Show)) {
                return $item.Show($EOL);
            }
        }
        return "";
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Primitives.GuiElement", GuiElement);
//# sourceMappingURL=GuiElement.js.map