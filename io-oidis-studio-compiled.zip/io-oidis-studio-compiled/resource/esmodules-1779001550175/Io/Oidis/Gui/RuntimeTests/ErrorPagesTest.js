/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { ExceptionsManager } from "./../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { FatalError } from "./../../../../Io/Oidis/Commons/Exceptions/Type/FatalError.js";
import { RuntimeTestRunner } from "../HttpProcessor/Resolvers/RuntimeTestRunner.js";
export class ErrorPagesTest extends RuntimeTestRunner {
    testExceptionsManager() {
        this.addButton("native exception", () => {
            throw new Error("native error");
        });
        this.addButton("custom exception", () => {
            ExceptionsManager.Throw(ErrorPagesTest.ClassName(), "my error is here");
        });
        this.addButton("fatal error", () => {
            ExceptionsManager.Throw(ErrorPagesTest.ClassName(), new FatalError("my fatal error is here"));
        });
    }
    testHttpManager() {
        this.addButton("http 301", () => {
            this.getHttpManager().Return301Moved("/testFile/location");
        });
        this.addButton("http 403", () => {
            this.getHttpManager().Return403Forbidden();
        });
        this.addButton("http 404", () => {
            this.getHttpManager().Return404NotFound();
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.ErrorPagesTest", ErrorPagesTest);
//# sourceMappingURL=ErrorPagesTest.js.map