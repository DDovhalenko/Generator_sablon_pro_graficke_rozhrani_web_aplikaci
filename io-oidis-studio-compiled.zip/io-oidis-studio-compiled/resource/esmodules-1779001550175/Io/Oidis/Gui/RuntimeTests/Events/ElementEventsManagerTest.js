/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { ExceptionsManager } from "./../../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { EventType } from "../../Enums/Events/EventType.js";
import { ElementEventsManager } from "../../Events/ElementEventsManager.js";
import { RuntimeTestRunner } from "../../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { ElementManager } from "../../Utils/ElementManager.js";
import { WindowManager } from "../../Utils/WindowManager.js";
export class ElementEventsManagerTest extends RuntimeTestRunner {
    testSubscribe() {
        LogIt.Debug(this.getEventsManager().toString());
        Echo.Println("<div id=\"testId0\">test click element</div>");
        Echo.Println("<div id=\"testId1\">test hover element</div>");
        Echo.Println("<div id=\"testId3\">test exception element</div>");
        const manager1 = new ElementEventsManager("testId0");
        manager1.setEvent(EventType.ON_CLICK, () => {
            Echo.Println("Element has been clicked");
        });
        manager1.Subscribe();
        const manager2 = new ElementEventsManager();
        manager2.setEvent(EventType.ON_MOUSE_OVER, () => {
            ElementManager.setCssProperty("testId1", "border", "1px solid red");
        });
        manager2.setEvent(EventType.ON_MOUSE_OUT, () => {
            ElementManager.setCssProperty("testId1", "border", "0px solid red");
        });
        manager2.Subscribe("testId1");
        manager2.Subscribe("testId#");
        const manager3 = new ElementEventsManager("testId3");
        manager3.setEvent(EventType.ON_CLICK, () => {
            ExceptionsManager.Throw(ElementEventsManagerTest.ClassName(), "my error is here");
        });
        manager3.Subscribe();
        const manager4 = new ElementEventsManager();
        manager4.setEvent(EventType.ON_DOUBLE_CLICK, () => {
            Echo.Println("Window has been double clicked");
            Echo.Println(WindowManager.ViewHTMLCode());
        });
        manager4.Subscribe();
        LogIt.Debug(this.getEventsManager().toString());
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.Events.ElementEventsManagerTest", ElementEventsManagerTest);
//# sourceMappingURL=ElementEventsManagerTest.js.map