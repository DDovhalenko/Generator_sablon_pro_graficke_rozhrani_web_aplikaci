import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { EventType } from "../../Enums/Events/EventType.js";
import { GeneralEventOwner } from "../../Enums/Events/GeneralEventOwner.js";
import { RuntimeTestRunner } from "../../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { KeyEventHandler } from "../../Utils/KeyEventHandler.js";
export class EventsManagerTest extends RuntimeTestRunner {
    IntegralTest() {
        this.getEventsManager().setEvent(GeneralEventOwner.WINDOW, EventType.ON_LOAD, () => {
            Echo.Println("Window has been loaded");
        });
        this.getEventsManager().setEvent(GeneralEventOwner.BODY, EventType.ON_LOAD, () => {
            Echo.Println("Body has been loaded");
        });
        let undloadFired = false;
        this.getEventsManager().setEvent(GeneralEventOwner.WINDOW, EventType.BEFORE_REFRESH, ($args) => {
            if (!undloadFired) {
                undloadFired = true;
                $args.PreventDefault();
                Echo.Println("Window is undloading" + StringUtils.NewLine());
            }
        });
        this.getEventsManager().setEvent(GeneralEventOwner.WINDOW, EventType.ON_HTTP_REQUEST, () => {
            Echo.Println("Request has been changed");
        });
        this.getEventsManager().setEvent(GeneralEventOwner.WINDOW, EventType.ON_RESIZE, () => {
            Echo.Println("Window has been resized");
        });
        this.getEventsManager().setEvent(GeneralEventOwner.BODY, EventType.ON_CLICK, () => {
            Echo.Println("Body has been clicked");
        });
        this.getEventsManager().setEvent(GeneralEventOwner.BODY, EventType.ON_KEY_DOWN, ($args) => {
            Echo.Println("Body key down - " + $args.getKeyCode() + " (" + $args.NativeEventArgs().key + ")");
        });
        this.getEventsManager().setEvent(GeneralEventOwner.BODY, EventType.ON_KEY_PRESS, ($args) => {
            Echo.Println("Body key press - " + $args.getKeyCode() + " (" + $args.NativeEventArgs().key + ")");
            Echo.Println("Is navigation key: ");
            Echo.Printf(KeyEventHandler.IsNavigate($args.NativeEventArgs()));
            Echo.Println("Is integer or navigate: ");
            Echo.Printf(KeyEventHandler.IsInteger($args.NativeEventArgs()));
        });
        this.getEventsManager().setEvent(GeneralEventOwner.BODY, EventType.ON_KEY_UP, ($args) => {
            Echo.Println("Body key up - " + $args.getKeyCode() + " (" + $args.NativeEventArgs().key + ")");
        });
        this.getEventsManager().setEvent(GeneralEventOwner.MOUSE_MOVE, EventType.ON_COMPLETE, ($args) => {
            Echo.Println("distance X: " + $args.getDistanceX());
            Echo.Println("distance Y: " + $args.getDistanceY());
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.Events.EventsManagerTest", EventsManagerTest);
//# sourceMappingURL=EventsManagerTest.js.map