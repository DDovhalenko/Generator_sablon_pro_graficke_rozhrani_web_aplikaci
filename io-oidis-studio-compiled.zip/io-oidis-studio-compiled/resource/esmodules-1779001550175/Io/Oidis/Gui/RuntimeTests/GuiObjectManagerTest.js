import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { GuiObjectManager } from "../GuiObjectManager.js";
import { RuntimeTestRunner } from "../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { AbstractGuiObject } from "../Primitives/AbstractGuiObject.js";
import { BaseGuiObject } from "../Primitives/BaseGuiObject.js";
import { FormsObject } from "../Primitives/FormsObject.js";
import { GuiCommons } from "../Primitives/GuiCommons.js";
class TestScrollBar extends GuiCommons {
    static ClassName() {
        return "Io.Oidis.Gui.RuntimeTests.TestScrollBar";
    }
    constructor($orientationType, $id) {
        super();
    }
    GuiType($orientationType) {
        return undefined;
    }
    OrientationType($orientationType) {
        return undefined;
    }
    Size($value) {
        return -1;
    }
    getEvents() {
        return undefined;
    }
}
class MockGuiCommons extends GuiCommons {
}
class MockBaseGuiObject extends BaseGuiObject {
}
class MockFormsObject extends FormsObject {
}
export class GuiObjectManagerTest extends RuntimeTestRunner {
    testAdd() {
        let passed = true;
        try {
            const manager = new GuiObjectManager();
            manager.Add(new MockGuiCommons());
            manager.Add(new MockBaseGuiObject());
            manager.Add(new MockFormsObject());
            manager.Add(new AbstractGuiObject());
        }
        catch (ex) {
            Echo.Println(ex);
            LogIt.Error("runtime test - GuiObjectManager.Add", ex);
            passed = false;
        }
        this.assertEquals(passed, true, "all element types can be added");
    }
    testExists() {
        const manager = new GuiObjectManager();
        const element = new AbstractGuiObject();
        manager.Add(element);
        const unregisterElement = new AbstractGuiObject();
        this.assertEquals(manager.Exists(element), true, "validate that element Id exist");
        this.assertEquals(manager.Exists(unregisterElement), false, "validate that element does not exist");
    }
    testGetType() {
        const manager = new GuiObjectManager();
        const element = new AbstractGuiObject();
        manager.Add(element);
        this.assertEquals(manager.getType(AbstractGuiObject).IsEmpty(), false, "validate that element can be get by type");
        this.assertEquals(manager.getType(TestScrollBar).IsEmpty(), true, "validate that not registered element type can not be get by type");
        manager.Add(element);
        this.assertEquals(manager.getType(AbstractGuiObject).Length(), 1, "validate that element can not be duplicated");
        let undefinedElement;
        this.assertEquals(ObjectValidator.IsEmptyOrNull(manager.getType(undefinedElement)), true, "try to get undefined element");
    }
    testGetAll() {
        const manager = new GuiObjectManager();
        manager.Add(new AbstractGuiObject());
        manager.Add(new MockGuiCommons());
        this.assertEquals(manager.getAll().Length(), 2, "validate that all elements can be get");
    }
    testSetActive() {
        const manager = new GuiObjectManager();
        const element = new AbstractGuiObject();
        const unregisteredElement = new AbstractGuiObject();
        let passed = true;
        try {
            manager.Add(element);
            manager.setActive(element, true);
            manager.setActive(element, false);
            manager.setActive(unregisteredElement, true);
            manager.setActive(unregisteredElement, false);
        }
        catch (ex) {
            Echo.Println(ex);
            LogIt.Error("runtime test - GuiObjectManager.setActive", ex);
            passed = false;
        }
        this.assertEquals(passed, true, "validate element's activation handling");
    }
    testIsActive() {
        const manager = new GuiObjectManager();
        const element = new AbstractGuiObject();
        const unregisteredElement = new AbstractGuiObject();
        let undefinedElement;
        manager.Add(element);
        manager.setActive(element, true);
        this.assertEquals(manager.IsActive(element), true, "validate that element id is active");
        manager.setActive(element, false);
        this.assertEquals(manager.IsActive(element), false, "validate that element id is not active");
        manager.setActive(undefinedElement, true);
        this.assertEquals(manager.IsActive(undefinedElement), false, "validate that undefined element id can not be active");
        manager.setActive(unregisteredElement, true);
        this.assertEquals(manager.IsActive(unregisteredElement), true, "validate that unregistered element can be active");
        manager.setActive(unregisteredElement, false);
        this.assertEquals(manager.IsActive(unregisteredElement), false, "validate that unregistered element id is not active");
        manager.setActive(element, true);
        this.assertEquals(manager.IsActive(AbstractGuiObject), true, "validate that element type is active");
        this.assertEquals(manager.IsActive(FormsObject), false, "validate that element type is not active");
    }
    testGetActive() {
        const manager = new GuiObjectManager();
        const element = new AbstractGuiObject();
        manager.Add(element);
        manager.setActive(element, true);
        this.assertEquals(manager.getActive(AbstractGuiObject).IsEmpty(), false, "validate that element type is active");
        manager.setActive(element, false);
        this.assertEquals(manager.getActive(AbstractGuiObject).IsEmpty(), true, "validate that element type is not active");
        this.assertEquals(manager.getActive(FormsObject).IsEmpty(), true, "validate that not registered element type is not active");
    }
    testClear() {
        const manager = new GuiObjectManager();
        const element = new AbstractGuiObject();
        manager.Add(element);
        manager.setActive(element, true);
        Echo.Println("<i>before clear</i>");
        Echo.Println(manager.ToString());
        this.assertEquals(manager.Exists(element), true, "validate that element exists");
        Echo.Println("<i>after clear</i>");
        manager.Clear();
        Echo.Println(manager.ToString());
        this.assertEquals(manager.Exists(element), false, "validate that element does not exists");
    }
    GlobalManagerTest() {
        const manager = GuiObjectManager.getInstanceSingleton();
        Echo.Println("<i>before registration</i>");
        Echo.Println(manager.ToString());
        const element = new MockFormsObject();
        manager.Add(new MockGuiCommons());
        manager.Add(new MockBaseGuiObject());
        manager.Add(element);
        Echo.Println("<i>after registration</i>");
        Echo.Println(manager.ToString());
        manager.setActive(element, true);
        Echo.Println("<i>after activation</i>");
        Echo.Println(manager.ToString());
        this.assertEquals(manager.Exists(element), true, "validate existence of element");
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.GuiObjectManagerTest", GuiObjectManagerTest);
//# sourceMappingURL=GuiObjectManagerTest.js.map