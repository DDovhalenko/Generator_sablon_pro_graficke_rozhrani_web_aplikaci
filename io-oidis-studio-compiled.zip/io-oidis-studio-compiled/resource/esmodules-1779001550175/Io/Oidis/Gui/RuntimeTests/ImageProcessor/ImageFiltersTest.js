/*! ******************************************************************************************************** *
 *
 * Copyright 2017 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { JsonpFileReader } from "./../../../../../Io/Oidis/Commons/IOApi/Handlers/JsonpFileReader.js";
import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { GrayscaleType } from "../../Enums/GrayscaleType.js";
import { RuntimeTestRunner } from "../../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { ImageFilters } from "../../ImageProcessor/ImageFilters.js";
import { ImageTransform } from "../../ImageProcessor/ImageTransform.js";
import { GuiElement } from "../../Primitives/GuiElement.js";
import { ElementManager } from "../../Utils/ElementManager.js";
export class ImageFiltersTest extends RuntimeTestRunner {
    imageIndex = 0;
    testGrayscale() {
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.Grayscale(pixels);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestGrayscale.jsonp");
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels2 = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels2 = ImageFilters.Grayscale(pixels2, GrayscaleType.AVERAGE);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels2, 0, 0);
            return $input;
        }, "ImageFiltersTestGrayscaleSecond.jsonp");
    }
    testThreshold() {
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.Threshold(pixels, 100);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestThreshold.jsonp");
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.Threshold(pixels, 110);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestThresholdSecond.jsonp");
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.Threshold(pixels, 200);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestThresholdThird.jsonp");
    }
    testInvert() {
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.Invert(pixels);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestInvert.jsonp");
    }
    testBrightness() {
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.Brightness(pixels, -200);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestBrightness.jsonp");
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.Brightness(pixels, 100);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestBrightnessSeconds.jsonp");
    }
    testContrast() {
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.Contrast(pixels, 50);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestContrast.jsonp");
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.Contrast(pixels, -50);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestContrastSecond.jsonp");
    }
    testHorizontalFlip() {
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.HorizontalFlip(pixels);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestHorizontalFlip.jsonp");
    }
    testVerticalFlip() {
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.VerticalFlip(pixels);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestVerticalFlip.jsonp");
    }
    testConvolve() {
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.Convolve(pixels, [200]);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestConvolve.jsonp");
    }
    testGaussianBlur() {
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.GaussianBlur(pixels, 30);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestGaussian.jsonp");
    }
    testLaplace() {
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.Laplace(pixels);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestLaplace.jsonp");
    }
    testSobel() {
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.Sobel(pixels);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestSobel.jsonp");
    }
    testSharp() {
        this.assertImage(($input) => {
            const sourceContext = $input.getContext("2d");
            let pixels = sourceContext.getImageData(0, 0, $input.width, $input.height);
            pixels = ImageFilters.Sharp(pixels);
            sourceContext.clearRect(0, 0, $input.width, $input.height);
            sourceContext.putImageData(pixels, 0, 0);
            return $input;
        }, "ImageFiltersTestSharp.jsonp");
    }
    assertImage($actual, $expected) {
        const input = document.createElement("img");
        const output = document.createElement("canvas");
        const imageId = "testImage_" + this.imageIndex;
        input.onload = () => {
            let data = ImageTransform.ToCanvas(input);
            data = $actual(data);
            output.width = data.width;
            output.height = data.height;
            output.getContext("2d").drawImage(data, 0, 0);
            ElementManager.getElement(imageId).parentNode.appendChild(output);
            JsonpFileReader.Load("test/resource/data/Io/Oidis/Gui/RuntimeTests/ImageProcessor/" + $expected, ($data) => {
                this.assertEquals(ImageTransform.getStream(output, true), $data);
            });
        };
        input.src = "test/resource/graphics/Io/Oidis/Gui/RuntimeTests/ImageProcessor/ChessBoard.png";
        const data = new GuiElement();
        data.Id(imageId);
        data.Add(input);
        Echo.Println(data.Draw(""));
        this.imageIndex++;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.ImageProcessor.ImageFiltersTest", ImageFiltersTest);
//# sourceMappingURL=ImageFiltersTest.js.map