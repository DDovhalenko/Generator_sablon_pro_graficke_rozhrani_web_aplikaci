/*! ******************************************************************************************************** *
 *
 * Copyright 2017 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { JsonpFileReader } from "./../../../../../Io/Oidis/Commons/IOApi/Handlers/JsonpFileReader.js";
import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "../../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { ImageTransform } from "../../ImageProcessor/ImageTransform.js";
import { GuiElement } from "../../Primitives/GuiElement.js";
import { ImageCorners } from "../../Structures/ImageCorners.js";
import { ImageCropDimensions } from "../../Structures/ImageCropDimensions.js";
import { ElementManager } from "../../Utils/ElementManager.js";
export class ImageTransformTest extends RuntimeTestRunner {
    imageIndex = 0;
    testResize() {
        this.assertImage(($input) => {
            return ImageTransform.Resize($input, 300, 300, false);
        }, "ImageTestResize.jsonp");
        this.assertImage(($input) => {
            return ImageTransform.Resize($input, 70, 70, false);
        }, "ImageTestResizeSecond.jsonp");
        this.assertImage(($input) => {
            return ImageTransform.Resize($input, 300, 150);
        }, "ImageTestResizeThird.jsonp");
    }
    testQuality() {
        this.assertImage(($input) => {
            return ImageTransform.Quality($input, 50);
        }, "ImageTestQuality.jsonp");
        this.assertImage(($input) => {
            return ImageTransform.Quality($input, 10);
        }, "ImageTestQualitySecond.jsonp");
    }
    testZoom() {
        this.assertImage(($input) => {
            return ImageTransform.Zoom($input, 10);
        }, "ImageTestZoom.jsonp");
        this.assertImage(($input) => {
            return ImageTransform.Zoom($input, 100);
        }, "ImageTestZoom.jsonp");
        this.assertImage(($input) => {
            return ImageTransform.Zoom($input, 250);
        }, "ImageTestZoomThird.jsonp");
    }
    testRotate() {
        this.assertImage(($input) => {
            return ImageTransform.Rotate($input, 180);
        }, "ImageTestRotate.jsonp");
        this.assertImage(($input) => {
            return ImageTransform.Rotate($input, 90);
        }, "ImageTestRotateSecond.jsonp");
        this.assertImage(($input) => {
            return ImageTransform.Rotate($input, 270);
        }, "ImageTestRotateThird.jsonp");
    }
    testCrop() {
        this.assertImage(($input) => {
            const imagedimension = new ImageCropDimensions(0, 50, 30, 0);
            return ImageTransform.Crop($input, imagedimension);
        }, "ImageTestCrop.jsonp");
        this.assertImage(($input) => {
            const imagedimension2 = new ImageCropDimensions(100, 0, 100, 0);
            return ImageTransform.Crop($input, imagedimension2);
        }, "ImageTestCropSecond.jsonp");
    }
    testModifyCorners() {
        this.assertImage(($input) => {
            const corner = new ImageCorners(20, 20, 20, 20);
            return ImageTransform.ModifyCorners($input, corner, 2);
        }, "ImageTestModifyCorners.jsonp");
        this.assertImage(($input) => {
            const corner2 = new ImageCorners(0, 50, 50, 0);
            return ImageTransform.ModifyCorners($input, corner2, 4);
        }, "ImageTestModifyCornersSecond.jsonp");
        this.assertImage(($input) => {
            const corner2 = new ImageCorners(110, 0, 0, 110);
            return ImageTransform.ModifyCorners($input, corner2, 14);
        }, "ImageTestModifyCornersThird.jsonp");
    }
    testAddWatermark() {
        this.assertImage(($input) => {
            return ImageTransform.AddWatermark($input, $input, true, 90);
        }, "ImageTestWatermark.jsonp");
    }
    assertImage($actual, $expected) {
        const input = document.createElement("img");
        const output = document.createElement("canvas");
        const imageId = "testImage_" + this.imageIndex;
        input.onload = () => {
            let data = ImageTransform.ToCanvas(input);
            data = $actual(data);
            output.width = data.width;
            output.height = data.height;
            output.getContext("2d").drawImage(data, 0, 0);
            ElementManager.getElement(imageId).parentNode.appendChild(output);
            JsonpFileReader.Load("test/resource/data/Io/Oidis/Gui/RuntimeTests/ImageProcessor/" + $expected, ($data) => {
                this.assertEquals(ImageTransform.getStream(output, true), $data);
            });
        };
        input.src = "test/resource/graphics/Io/Oidis/Gui/RuntimeTests/ImageProcessor/ChessBoard.png";
        const data = new GuiElement();
        data.Id(imageId);
        data.Add(input);
        Echo.Println(data.Draw(""));
        this.imageIndex++;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.ImageProcessor.ImageTransformTest", ImageTransformTest);
//# sourceMappingURL=ImageTransformTest.js.map