var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { EventType } from "./../../../../Io/Oidis/Commons/Enums/Events/EventType.js";
import { GeneralEventOwner } from "./../../../../Io/Oidis/Commons/Enums/Events/GeneralEventOwner.js";
import { BaseHttpResolver } from "./../../../../Io/Oidis/Commons/HttpProcessor/Resolvers/BaseHttpResolver.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { FormsObject } from "../Primitives/FormsObject.js";
import { Resolver } from "./../../../../Io/Oidis/Commons/Primitives/Decorators.js";
let PersistenceManagerTest = class PersistenceManagerTest extends BaseHttpResolver {
    resolver() {
        this.getEventsManager().setEvent(GeneralEventOwner.ASYNC_REQUEST, EventType.ON_SUCCESS, () => {
            Echo.Println("<b>Collected data:</b>");
            Echo.Printf(FormsObject.CollectValues());
        });
        this.getHttpManager().ReloadTo("/PersistenceManager", null, true);
    }
};
PersistenceManagerTest = __decorate([
    Resolver("/web/PersistenceManagerTest")
], PersistenceManagerTest);
export { PersistenceManagerTest };
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.PersistenceManagerTest", PersistenceManagerTest);
//# sourceMappingURL=PersistenceManagerTest.js.map