/*! ******************************************************************************************************** *
 *
 * Copyright 2017 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { GuiCommonsArgType } from "../../Enums/GuiCommonsArgType.js";
import { RuntimeTestRunner } from "../../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { BaseGuiObject } from "../../Primitives/BaseGuiObject.js";
import { BasePanel } from "../../Primitives/BasePanel.js";
class MockBaseGuiObject extends BaseGuiObject {
}
export class BaseGuiObjectTest extends RuntimeTestRunner {
    testTitle() {
        const basegui = new MockBaseGuiObject();
        this.assertEquals(basegui.Title(), BaseGuiObject.title);
    }
    testChanged() {
        const basegui = new MockBaseGuiObject();
        this.assertEquals(basegui.Changed(), false);
    }
    testValue() {
        const basegui = new MockBaseGuiObject();
        this.assertEquals(basegui.Value(), null);
    }
    testsetArgs() {
        const basegui = new MockBaseGuiObject();
        basegui.Id();
        basegui.StyleClassName("ToolTip");
        basegui.Enabled(true);
        basegui.Title();
        const args = basegui.getArgs();
        this.assertEquals(ObjectValidator.IsEmptyOrNull(args), false);
        this.assertEquals(args.enabled, true);
        this.assertEquals(args.styleClassName, "ToolTip");
        this.assertEquals(ObjectValidator.IsEmptyOrNull(args.guiId), false);
        this.assertEquals(args.completed, false);
        this.assertEquals(args.loaded, false);
        this.assertEquals(args.prepared, false);
    }
    testsetArgs20() {
        const basegui = new MockBaseGuiObject();
        basegui.Title();
        const basepanel = new BasePanel();
        basegui.Value(basepanel);
        basegui.setArg({
            name: "Title",
            type: GuiCommonsArgType.TEXT,
            value: true
        }, true);
        basegui.setArg({
            name: "Value",
            type: GuiCommonsArgType.TEXT,
            value: false
        }, false);
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.Primitives.BaseGuiObjectTest", BaseGuiObjectTest);
//# sourceMappingURL=BaseGuiObjectTest.js.map