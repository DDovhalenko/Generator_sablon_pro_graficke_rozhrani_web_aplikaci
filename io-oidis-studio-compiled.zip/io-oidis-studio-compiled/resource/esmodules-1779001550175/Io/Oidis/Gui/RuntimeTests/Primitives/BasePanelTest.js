/*! ******************************************************************************************************** *
 *
 * Copyright 2017 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { PanelContentType } from "../../Enums/PanelContentType.js";
import { RuntimeTestRunner } from "../../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { BasePanel } from "../../Primitives/BasePanel.js";
export class BasePanelTest extends RuntimeTestRunner {
    testgetEvents() {
        const basepanel = new BasePanel();
        const handler = () => {
            // test event handler
        };
        basepanel.getEvents().setEvent("test", handler);
        this.assertEquals(basepanel.getEvents().Exists("test"), true);
    }
    testContentType() {
        const basepanel = new BasePanel();
        this.assertEquals(basepanel.ContentType(PanelContentType.WITH_ELEMENT_WRAPPER), PanelContentType.WITH_ELEMENT_WRAPPER);
    }
    testAddChild() {
        const basepanel = new BasePanel();
        const basepanel2 = new BasePanel();
        const basepanel3 = new BasePanel();
        this.assertEquals(basepanel.getChildPanelList().IsEmpty(), true);
        basepanel.AddChild(basepanel2, "test");
        basepanel.AddChild(basepanel3, "test2");
        this.assertEquals(basepanel.getChildPanelList().IsEmpty(), false);
    }
    testValue() {
        const basepanel = new BasePanel();
        this.assertEquals(basepanel.Value("viewerargs"), null);
    }
    testScrollable() {
        const basepanel = new BasePanel();
        this.assertEquals(basepanel.Scrollable(true), true);
    }
    testWidth() {
        const basepanel = new BasePanel();
        this.assertEquals(basepanel.Width(8), 8);
        Echo.PrintCode(JSON.stringify(basepanel.Draw()));
    }
    testHeight() {
        const basepanel = new BasePanel();
        basepanel.Height(16);
        this.assertEquals(basepanel.Height(), 16);
    }
    testGetScrollTop() {
        const basepanel = new BasePanel();
        this.assertEquals(basepanel.getScrollTop(), -1);
    }
    testGetScrollLeft() {
        const basepanel = new BasePanel();
        this.assertEquals(basepanel.getScrollLeft(), -1);
    }
    testDraw() {
        const basepanel = new BasePanel("basePanelId");
        basepanel.DisableAsynchronousDraw();
        Echo.Printf(JSON.stringify(basepanel.Draw()));
        this.assertEquals(basepanel.Draw(), "\r\n<div id=\"basePanelId_PanelEnvelop\" class=\"Panel\" style=\"display: block;\">" +
            "\r\n    <div class=\"IoOidisGuiPrimitives\">" +
            "\r\n       <div id=\"basePanelId_GuiWrapper\" guiType=\"GuiWrapper\">" +
            "\r\n          <div id=\"basePanelId\" class=\"BasePanel\" style=\"display: block;\">" +
            "\r\n             <div guiType=\"Panel\">" +
            "\r\n                <div id=\"basePanelId_PanelContentEnvelop\" class=\"Envelop\" style=\"display: none;\">" +
            "\r\n                   <div id=\"basePanelId_PanelContent\" class=\"Content\">" +
            "\r\n                      <div style=\"clear: both;\"></div>" +
            "\r\n                   </div>" +
            "\r\n                </div>" +
            "\r\n             </div>" +
            "\r\n          </div>" +
            "\r\n       </div>" +
            "\r\n    </div>" +
            "\r\n</div>");
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.Primitives.BasePanelTest", BasePanelTest);
//# sourceMappingURL=BasePanelTest.js.map