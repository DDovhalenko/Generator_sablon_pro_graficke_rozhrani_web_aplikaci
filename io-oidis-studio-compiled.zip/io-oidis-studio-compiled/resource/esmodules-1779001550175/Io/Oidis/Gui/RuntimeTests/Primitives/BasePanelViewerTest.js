/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { BasePanel } from "../../Primitives/BasePanel.js";
import { BasePanelViewer } from "../../Primitives/BasePanelViewer.js";
import { BasePanelViewerArgs } from "../../Primitives/BasePanelViewerArgs.js";
export class BasePanelViewerTest extends BasePanelViewer {
    constructor($args) {
        super($args);
        this.setInstance(new BasePanel());
    }
    getInstance() {
        return super.getInstance();
    }
    normalImplementation() {
        const args = this.ViewerArgs();
        if (!ObjectValidator.IsEmptyOrNull(args) && !ObjectValidator.IsEmptyOrNull(this.getInstance())) {
            // handle viewer args
        }
    }
    testImplementation() {
        const args = new BasePanelViewerArgs();
        args.Visible(true);
        args.AsyncEnabled(false);
        this.ViewerArgs(args);
        this.normalImplementation();
        return "test append";
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.Primitives.BasePanelViewerTest", BasePanelViewerTest);
//# sourceMappingURL=BasePanelViewerTest.js.map