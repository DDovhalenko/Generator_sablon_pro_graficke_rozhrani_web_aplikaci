/*! ******************************************************************************************************** *
 *
 * Copyright 2017 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "../../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { FormsObject } from "../../Primitives/FormsObject.js";
class MockFormsObject extends FormsObject {
}
export class FormsObjectTest extends RuntimeTestRunner {
    testgetEvents() {
        const formsobject = new MockFormsObject();
        const handler = () => {
            // test event handler
        };
        formsobject.getEvents().setEvent("test", handler);
        this.assertEquals(formsobject.getEvents().Exists("test"), true);
    }
    testNotification() {
        const formsobject = new MockFormsObject();
        this.assertEquals(formsobject.Notification(), FormsObject.notification);
    }
    testEnabled() {
        const formsobject = new MockFormsObject();
        this.assertEquals(formsobject.Enabled(), true, "validate enabled");
        const formsobject2 = new MockFormsObject();
        this.assertEquals(formsobject2.Enabled(false), false);
    }
    testError() {
        const formsobject = new MockFormsObject();
        this.assertEquals(formsobject.Error(true), true);
        const formsobject2 = new MockFormsObject();
        this.assertEquals(formsobject2.Error(false), false);
    }
    testTabIndex() {
        const formsobject = new MockFormsObject();
        this.assertEquals(formsobject.TabIndex(5), 5);
    }
    testgetSelectorEvents() {
        const formsobject = new MockFormsObject();
        Echo.PrintCode(JSON.stringify(formsobject));
        const handler = () => {
            // test event handler
        };
        formsobject.getEvents().setEvent("test", handler);
        this.assertEquals(formsobject.getEvents().Exists("test"), true);
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.Primitives.FormsObjectTest", FormsObjectTest);
//# sourceMappingURL=FormsObjectTest.js.map