/*! ******************************************************************************************************** *
 *
 * Copyright 2017 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { ArrayList } from "./../../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { GuiOptionType } from "../../Enums/GuiOptionType.js";
import { RuntimeTestRunner } from "../../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { BaseViewer } from "../../Primitives/BaseViewer.js";
import { BaseViewerArgs } from "../../Primitives/BaseViewerArgs.js";
import { GuiCommons } from "../../Primitives/GuiCommons.js";
import { Size } from "../../Structures/Size.js";
import { ElementManager } from "../../Utils/ElementManager.js";
class MockGuiCommons extends GuiCommons {
}
export class GuiCommonsTest extends RuntimeTestRunner {
    testGuiElementClass() {
        const original = GuiCommons.GuiElementClass();
        GuiCommons.GuiElementClass("testClass");
        this.assertEquals(GuiCommons.GuiElementClass(), "testClass");
        GuiCommons.GuiElementClass(original);
        this.assertEquals(GuiCommons.GuiElementClass(), original);
    }
    testEchoElement() {
        const element = new MockGuiCommons();
        Echo.PrintCode(element.Draw());
    }
    testConstructor() {
        const element = new MockGuiCommons();
        this.assertEquals(element.Enabled(true), true);
    }
    testgetGuiElementClass() {
        const element = new MockGuiCommons();
        this.assertEquals(ElementManager.getClassName(element), null);
    }
    testVisible() {
        const element = new MockGuiCommons("testId1");
        element.Visible(true);
        this.assertEquals(element.Visible(), true);
        const element2 = new MockGuiCommons("testId5");
        element2.Visible(false);
        this.assertEquals(element2.Visible(), false);
    }
    testEnabled() {
        const element = new MockGuiCommons("testEnabledId");
        element.Enabled(true);
        this.assertEquals(element.Enabled(), true);
        element.Enabled(false);
        this.assertEquals(element.Enabled(), false);
    }
    testgetGuiOptions() {
        const element = new MockGuiCommons("testOptionsId");
        element.getGuiOptions().Add(GuiOptionType.ALL);
        this.assertEquals(element.getGuiOptions().Contains(GuiOptionType.ALL), true);
        this.assertEquals(element.getGuiOptions().Contains(GuiOptionType.TOOL_TIP), true);
        const element2 = new MockGuiCommons("testOptionsId2");
        element2.getGuiOptions().Add(GuiOptionType.TOOL_TIP);
        this.assertEquals(element2.getGuiOptions().Contains(GuiOptionType.TOOL_TIP), true);
        this.assertEquals(element2.getGuiOptions().Contains(GuiOptionType.ALL), false);
    }
    testParent() {
        const elementparent = new MockGuiCommons();
        const element = new MockGuiCommons();
        this.assertEquals(element.Parent(elementparent), elementparent);
    }
    testInstanceOwner() {
        const baseviewerargs = new BaseViewerArgs();
        const baseviewer = new BaseViewer(baseviewerargs);
        const element = new MockGuiCommons();
        this.assertEquals(element.InstanceOwner(baseviewer), baseviewer);
    }
    testInstancePath() {
        const element = new MockGuiCommons("testId3");
        this.assertEquals(element.InstancePath("rootElement/ChildElement/SubChildElement/testId3"), "rootElement/ChildElement/SubChildElement/testId3");
    }
    testgetChildElements() {
        const element = new MockGuiCommons("testId9");
        const element2 = new MockGuiCommons("testId10");
        const element3 = new MockGuiCommons("testId11");
        element.getChildElements().Add(element2);
        element.getChildElements().Add(element3);
        const child = new ArrayList();
        child.Add(element2);
        child.Add(element3);
        this.assertEquals(element.getChildElements().Equal(child), true);
    }
    testgetSize() {
        const element = new MockGuiCommons("testId12");
        const origin = element.getSize();
        const golden = new Size();
        this.assertEquals(origin.Width(), golden.Width());
        this.assertEquals(origin.Height(), golden.Height());
    }
    testsetArg() {
        const element = new MockGuiCommons("testId15");
        element.Id();
        element.StyleClassName("ToolTip");
        element.Enabled(true);
        element.Visible(true);
        this.assertEquals(ArrayList.ToArrayList(element.getArgs()).Equal(ArrayList.ToArrayList([
            { name: "Id", type: "Text", value: "testId15" },
            { name: "StyleClassName", type: "Text", value: "ToolTip" },
            { name: "Enabled", type: "Bool", value: true },
            { name: "Visible", type: "Bool", value: true },
            { name: "Width", type: "Number", value: 0 },
            { name: "Height", type: "Number", value: 0 },
            { name: "Top", type: "Number", value: 0 },
            { name: "Left", type: "Number", value: 0 }
        ])), true);
    }
    testDraw() {
        const element = new MockGuiCommons("testDrawId");
        const html = element.Draw();
        this.assertEquals(StringUtils.Contains(html, "testDrawId"), true);
        this.assertEquals(StringUtils.Contains(html, "GuiCommons"), true);
        this.assertEquals(StringUtils.Contains(html, "GuiWrapper"), true);
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.Primitives.GuiCommonsTest", GuiCommonsTest);
//# sourceMappingURL=GuiCommonsTest.js.map