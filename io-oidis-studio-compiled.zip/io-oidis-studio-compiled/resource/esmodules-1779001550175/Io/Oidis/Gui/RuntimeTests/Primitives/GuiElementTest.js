/*! ******************************************************************************************************** *
 *
 * Copyright 2017 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "../../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { BasePanelViewer } from "../../Primitives/BasePanelViewer.js";
import { GuiCommons } from "../../Primitives/GuiCommons.js";
import { GuiElement } from "../../Primitives/GuiElement.js";
import { ElementManager } from "../../Utils/ElementManager.js";
class MockGuiCommons extends GuiCommons {
}
export class GuiElementTest extends RuntimeTestRunner {
    testConstructor() {
        const element = new GuiElement();
    }
    testId() {
        Echo.Println("<div id=\"GuiElement888999\" type=\"text\">Multiple</div>");
        const element = new GuiElement();
        element.Id("GuiElement888999");
        this.assertEquals(ElementManager.Exists("GuiElement888999"), true);
    }
    testGuiTypeTag() {
        Echo.Println("<div id=\"GuiElement888999\" guiType=\"GuiWraper\" >Multiple</div>");
        const element = new GuiElement();
        element.GuiTypeTag("GuiWraper");
    }
    testStyleClassName() {
        Echo.Println("<div id=\"GuiElement888999\" guiType=\"GuiWraper\" class=\"testClassName\"</div>");
        const element = new GuiElement();
        element.StyleClassName("testClassName");
        Echo.Println("<div id=\"GuiElement888999\" guiType=\"GuiWraper\" class=\"testClassName\"</div>");
    }
    testVisible() {
        const element = new GuiElement();
        element.Visible(true);
        Echo.Println("<div id=\"GuiElement888999\" guiType=\"GuiWraper\" class=\"testClassName\"</div>");
        this.assertEquals(ElementManager.IsVisible("GuiElement888999"), true);
    }
    testWidth() {
        const element = new GuiElement();
        element.Width(50);
        Echo.Println("<div id=\"GuiElement888999\" guiType=\"GuiWraper\" class=\"testClassName\" style=\"width: \"50\";\"</div>");
        this.assertEquals(ElementManager.getElement("GuiElement888999").offsetWidth, 1863);
    }
    testHeight() {
        const element = new GuiElement();
        element.Height(100);
        Echo.Println("<div id=\"GuiElement888999\" guiType=\"GuiWraper\" class=\"testClassName\" style=\"width: 50px; height: 100px\"" +
            "</div>");
        this.assertEquals(ElementManager.getElement("GuiElement888999").offsetHeight, 23);
    }
    testsetAttribute() {
        const element = new GuiElement();
        element.setAttribute("display", "none");
        element.setAttribute("color", "blue");
        this.assertEquals(element.getAttributes().getFirst(), "none", "validate that attribute exists on first position");
    }
    testAdd() {
        const element = new GuiElement();
        const elementgui = new MockGuiCommons();
        const elementviewer = new BasePanelViewer();
        element.Add(elementgui);
        element.Add(elementviewer);
        this.assertEquals(element.getChildElement(1), elementviewer, "");
    }
    testgetChildElement() {
        Echo.Println("<div id=\"GuiElement888999\" guiType=\"GuiWraper\" class=\"testClassName\" style=\"width: 50px; height: 100px\"" +
            "</div>");
        const element = new GuiElement();
        const elementChild = new GuiElement();
        const gui = new MockGuiCommons();
        const viewer = new BasePanelViewer();
        element.Add(elementChild);
        element.Add(gui);
        element.Add(viewer);
        element.getChildElement(1);
        this.assertEquals(element.getChildElement(0), elementChild, "validate, that child exists");
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.Primitives.GuiElementTest", GuiElementTest);
//# sourceMappingURL=GuiElementTest.js.map