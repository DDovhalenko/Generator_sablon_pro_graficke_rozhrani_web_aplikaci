import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ObjectDecoder } from "./../../../../Io/Oidis/Commons/Utils/ObjectDecoder.js";
import { ObjectEncoder } from "./../../../../Io/Oidis/Commons/Utils/ObjectEncoder.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { EventType } from "../Enums/Events/EventType.js";
import { RuntimeTestRunner } from "../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { AbstractGuiObject } from "../Primitives/AbstractGuiObject.js";
import { BaseGuiObject } from "../Primitives/BaseGuiObject.js";
import { BasePanel } from "../Primitives/BasePanel.js";
import { FormsObject } from "../Primitives/FormsObject.js";
import { GuiCommons } from "../Primitives/GuiCommons.js";
import { ElementManager } from "../Utils/ElementManager.js";
import { BasePanelViewerTest } from "./Primitives/BasePanelViewerTest.js";
class MockGuiCommons extends GuiCommons {
}
class MockBaseGuiObject extends BaseGuiObject {
}
class MockFormsObject extends FormsObject {
}
export class SerializationTest extends RuntimeTestRunner {
    testGuiCommons() {
        const serialized = ObjectEncoder.Serialize(new MockGuiCommons());
        Echo.Println(StringUtils.HardWrap(serialized, 150));
        Echo.PrintCode(ObjectDecoder.Unserialize(serialized).Draw());
    }
    testBaseGuiObject() {
        const serialized = ObjectEncoder.Serialize(new MockBaseGuiObject());
        Echo.Println(StringUtils.HardWrap(serialized, 150));
        Echo.PrintCode(ObjectDecoder.Unserialize(serialized).Draw());
    }
    testAbstractGuiObject() {
        const object = new AbstractGuiObject();
        object.getEvents().setEvent(EventType.ON_CLICK, () => {
            Echo.Println("deserialized onlick");
        });
        const serialized = ObjectEncoder.Serialize(object);
        Echo.Println(StringUtils.HardWrap(serialized, 150));
        const deserialized = ObjectDecoder.Unserialize(serialized);
        deserialized.getEvents().setEvent(EventType.ON_MOUSE_OVER, ($args) => {
            ElementManager.setCssProperty($args.Owner(), "border", "1px solid green");
        });
        deserialized.getEvents().setEvent(EventType.ON_CLICK, () => {
            Echo.Println("not desirialized onlick");
        });
        deserialized.getEvents().setEvent(EventType.ON_MOUSE_OUT, ($args) => {
            ElementManager.setCssProperty($args.Owner(), "border", "0px solid red");
        });
        Echo.PrintCode(deserialized.Draw());
        Echo.Println(deserialized.Draw());
    }
    testFormsObject() {
        const serialized = ObjectEncoder.Serialize(new MockFormsObject());
        Echo.Println(StringUtils.HardWrap(serialized, 150));
        Echo.PrintCode(ObjectDecoder.Unserialize(serialized).Draw());
    }
    testBasePanel() {
        const serialized = ObjectEncoder.Serialize(new BasePanel());
        Echo.Println(StringUtils.HardWrap(serialized, 150));
        Echo.PrintCode(ObjectDecoder.Unserialize(serialized).Draw());
    }
    testBasePanelViewer() {
        const serialized = ObjectEncoder.Serialize(new BasePanelViewerTest());
        Echo.Println(StringUtils.HardWrap(serialized, 150));
        Echo.PrintCode(ObjectDecoder.Unserialize(serialized).Show());
    }
    testCrcCheck() {
        const testArray = new ArrayList();
        testArray.Add(null, "crc");
        testArray.Add(new ArrayList(), "variables");
        testArray.getItem("variables").Add("string");
        testArray.getItem("variables").Add(true);
        testArray.getItem("variables").Add(123);
        testArray.getItem("variables").Add(new MockBaseGuiObject());
        testArray.getItem("variables").Add(($arg) => {
            return $arg;
        });
        testArray.Add(StringUtils.getCrc(ObjectEncoder.Serialize(testArray.getItem("variables"))), "crc");
        Echo.Println("<i>Serialized object</i>");
        let serialized = ObjectEncoder.Serialize(testArray);
        Echo.Println(StringUtils.HardWrap(serialized, 150) + StringUtils.NewLine());
        Echo.Println("<i>After deserialization</i>");
        const deserialized = ObjectDecoder.Unserialize(serialized);
        Echo.Printf(deserialized);
        serialized = ObjectEncoder.Serialize(deserialized.getItem("variables"));
        Echo.Println("<i>Serialized variables after deserialization</i>");
        Echo.Println(StringUtils.NewLine() + StringUtils.HardWrap(serialized, 150));
        this.assertEquals(deserialized.getItem("crc"), StringUtils.getCrc(serialized));
    }
    testAsyncSerialization() {
        const testArray = new ArrayList();
        testArray.Add(null, "crc");
        testArray.Add(new ArrayList(), "variables");
        testArray.getItem("variables").Add("string");
        testArray.getItem("variables").Add(true);
        testArray.getItem("variables").Add(123);
        testArray.getItem("variables").Add(new MockBaseGuiObject());
        testArray.getItem("variables").Add(($arg) => {
            return $arg;
        });
        testArray.Add(StringUtils.getCrc(ObjectEncoder.Serialize(testArray.getItem("variables"))), "crc");
        let testStart = new Date().getTime();
        ObjectEncoder.Serialize(testArray, ($data) => {
            Echo.Printf(ObjectDecoder.Unserialize($data));
            Echo.Printf("process time: " + (new Date().getTime() - testStart) / 1000);
            testStart = new Date().getTime();
            ObjectDecoder.Unserialize($data, ($output) => {
                Echo.Printf("process time: " + (new Date().getTime() - testStart) / 1000);
                Echo.Printf($output);
            });
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.SerializationTest", SerializationTest);
//# sourceMappingURL=SerializationTest.js.map