/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { BrowserType } from "./../../../../../Io/Oidis/Commons/Enums/BrowserType.js";
import { LanguageType } from "./../../../../../Io/Oidis/Commons/Enums/LanguageType.js";
import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { RuntimeTestRunner } from "../../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { StaticPageContentManager } from "../../Utils/StaticPageContentManager.js";
import { WindowManager } from "../../Utils/WindowManager.js";
export class StaticPageContentManagerTest extends RuntimeTestRunner {
    integralTest() {
        Echo.Println("this text has been printed before tested page manager initialization");
        StaticPageContentManager.Clear();
        StaticPageContentManager.Title("Test title");
        StaticPageContentManager.Charset("UTF-32");
        StaticPageContentManager.Language(LanguageType.CZ);
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = "appended link";
        link.type = "text/css";
        StaticPageContentManager.HeadLinkAppend(link);
        StaticPageContentManager.HeadLinkAppend("test link 2");
        const script = document.createElement("script");
        script.src = "test script";
        script.type = "text/javascript";
        StaticPageContentManager.HeadScriptAppend(script);
        const meta = document.createElement("meta");
        meta.httpEquiv = "Author";
        meta.content = "test meta";
        StaticPageContentManager.HeadMetaDataAppend(meta);
        StaticPageContentManager.BodyAppend("this is new body");
        StaticPageContentManager.Draw();
        Echo.Print(WindowManager.ViewHTMLCode());
    }
    testLanguage() {
        StaticPageContentManager.Language(LanguageType.CZ);
        this.assertEquals(StaticPageContentManager.Language(), LanguageType.CZ, "validate LanguageType");
    }
    testTitle() {
        StaticPageContentManager.Title("Test title");
        this.assertEquals(StaticPageContentManager.Title(), "Test title", "validate title");
    }
    testFaviconSource() {
        StaticPageContentManager.FaviconSource("http://www.oidis.com/favicon.ico");
        this.assertEquals(StaticPageContentManager.FaviconSource(), "http://www.oidis.com/favicon.ico", "validate favicon source");
    }
    testCharset() {
        StaticPageContentManager.Charset("base64");
        this.assertEquals(StaticPageContentManager.Charset(), "base64", "validate content transfer encoding");
    }
    testHeadLinkAppend() {
        Echo.Println("<link rel=\"stylesheet\" type=\"text/css\" href=\"theme.css\">");
        const linkElement = document.createElement("link");
        StaticPageContentManager.HeadLinkAppend(linkElement, "stylesheet", "text/css");
        this.assertEquals(StringUtils.PatternMatched("" +
            "<!DOCTYPE html>\r\n" +
            "\r\n" +
            "<head>\r\n" +
            "<title>Test title</title>\r\n" +
            "\r\n" +
            "<meta content=\"text/html; charset=UTF-8\" http-equiv=\"Content-Type\">\r\n" +
            "<meta http-equiv=\"Author\" content=\"test meta\">\r\n" +
            "\r\n" +
            "<link href=\"http://www.oidis.com/favicon.ico\" rel=\"shortcut icon\" type=\"text/css\">\r\n" +
            "<link href=\"resource/css/io-oidis-gui-*.min.css\" rel=\"stylesheet\" type=\"text/css\">\r\n" +
            "<link rel=\"stylesheet\" href=\"appended link\" type=\"text/css\">\r\n" +
            "<link href=\"test link 2\" rel=\"stylesheet\" type=\"text/css\">\r\n" +
            "<link>\r\n" +
            "\r\n" +
            "<script src=\"test script\" type=\"text/javascript\"></script>\r\n" +
            "</head>\r\n" +
            "\r\n" +
            "<body " +
            "onfocus=\"Io.Oidis.Gui.Events.EventsManager.bodyFocusEventHandler();\" " +
            "onblur=\"Io.Oidis.Gui.Events.EventsManager.bodyBlurEventHandler();\">\r\n" +
            "<div id=\"Browser\" class=\"" + BrowserType[this.getRequest().getBrowserType()] + "\">\r\n" +
            "<div id=\"Language\" class=\"Cz\">\r\n" +
            "<div id=\"Content\" class=\"Content\" guiType=\"PageContent\">\r\n" +
            "this is new body\r\n" +
            "\r\n" +
            "</div>\r\n" +
            "</div>\r\n" +
            "</div>\r\n" +
            "</body>", StaticPageContentManager.ToString()), true);
    }
    testHeadMetaDataAppend() {
        Echo.Println("<meta charset=\"utf-8\">");
        const metaElement = document.createElement("meta");
        StaticPageContentManager.HeadMetaDataAppend(metaElement, "http response header");
        this.assertEquals(StringUtils.PatternMatched("" +
            "<!DOCTYPE html>\r\n" +
            "\r\n" +
            "<head>\r\n" +
            "<title>Test title</title>\r\n" +
            "\r\n" +
            "<meta content=\"text/html; charset=UTF-8\" http-equiv=\"Content-Type\">\r\n" +
            "<meta http-equiv=\"Author\" content=\"test meta\">\r\n" +
            "<meta>\r\n" +
            "\r\n" +
            "<link href=\"http://www.oidis.com/favicon.ico\" rel=\"shortcut icon\" type=\"text/css\">\r\n" +
            "<link href=\"resource/css/io-oidis-gui-*.min.css\" rel=\"stylesheet\" type=\"text/css\">\r\n" +
            "<link rel=\"stylesheet\" href=\"appended link\" type=\"text/css\">\r\n" +
            "<link href=\"test link 2\" rel=\"stylesheet\" type=\"text/css\">\r\n" +
            "<link>\r\n" +
            "\r\n" +
            "<script src=\"test script\" type=\"text/javascript\"></script>\r\n" +
            "</head>\r\n" +
            "\r\n" +
            "<body " +
            "onfocus=\"Io.Oidis.Gui.Events.EventsManager.bodyFocusEventHandler();\" " +
            "onblur=\"Io.Oidis.Gui.Events.EventsManager.bodyBlurEventHandler();\">\r\n" +
            "<div id=\"Browser\" class=\"" + BrowserType[this.getRequest().getBrowserType()] + "\">\r\n" +
            "<div id=\"Language\" class=\"Cz\">\r\n" +
            "<div id=\"Content\" class=\"Content\" guiType=\"PageContent\">\r\n" +
            "this is new body\r\n" +
            "\r\n" +
            "</div>\r\n" +
            "</div>\r\n" +
            "</div>\r\n" +
            "</body>", StaticPageContentManager.ToString()), true);
    }
    testscriptElemet() {
        Echo.Println("<script src=\"test script\" type=\"text/javascript\"></script>");
        const scriptElement = document.createElement("script");
        StaticPageContentManager.HeadScriptAppend(scriptElement, "text/javascript");
        this.assertEquals(StringUtils.PatternMatched("" +
            "<!DOCTYPE html>\r\n" +
            "\r\n" +
            "<head>\r\n" +
            "<title>Test title</title>\r\n" +
            "\r\n" +
            "<meta content=\"text/html; charset=UTF-8\" http-equiv=\"Content-Type\">\r\n" +
            "<meta http-equiv=\"Author\" content=\"test meta\">\r\n" +
            "<meta>\r\n" +
            "\r\n" +
            "<link href=\"http://www.oidis.com/favicon.ico\" rel=\"shortcut icon\" type=\"text/css\">\r\n" +
            "<link href=\"resource/css/io-oidis-gui-*.min.css\" rel=\"stylesheet\" type=\"text/css\">\r\n" +
            "<link rel=\"stylesheet\" href=\"appended link\" type=\"text/css\">\r\n" +
            "<link href=\"test link 2\" rel=\"stylesheet\" type=\"text/css\">\r\n" +
            "<link>\r\n" +
            "\r\n" +
            "<script src=\"test script\" type=\"text/javascript\"></script>\r\n" +
            "<script></script>\r\n" +
            "</head>\r\n" +
            "\r\n" +
            "<body " +
            "onfocus=\"Io.Oidis.Gui.Events.EventsManager.bodyFocusEventHandler();\" " +
            "onblur=\"Io.Oidis.Gui.Events.EventsManager.bodyBlurEventHandler();\">\r\n" +
            "<div id=\"Browser\" class=\"" + BrowserType[this.getRequest().getBrowserType()] + "\">\r\n" +
            "<div id=\"Language\" class=\"Cz\">\r\n" +
            "<div id=\"Content\" class=\"Content\" guiType=\"PageContent\">\r\nt" +
            "his is new body\r\n" +
            "\r\n" +
            "</div>\r\n" +
            "</div>\r\n" +
            "</div>\r\n" +
            "</body>", StaticPageContentManager.ToString()), true);
    }
    testBodyAppend() {
        StaticPageContentManager.BodyAppend("bodyElement");
        this.assertEquals(StaticPageContentManager.getBody(), "this is new body\r\nbodyElement\r\n", "");
    }
    testToString() {
        Echo.PrintCode(StaticPageContentManager.ToString());
    }
    Process() {
        Echo.Println("print before resolver process");
        super.Process();
    }
    resolver() {
        Echo.Println("print before runtime test");
        super.resolver();
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.Utils.StaticPageContentManagerTest", StaticPageContentManagerTest);
//# sourceMappingURL=StaticPageContentManagerTest.js.map