/*! ******************************************************************************************************** *
 *
 * Copyright 2017 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "../../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { ElementManager } from "../../Utils/ElementManager.js";
import { TextSelectionManager } from "../../Utils/TextSelectionManager.js";
export class TextSelectionManagerTest extends RuntimeTestRunner {
    testSelectAll() {
        const element = document.createElement("div");
        const elementinput = document.createElement("input");
        TextSelectionManager.SelectAll(element);
        const inputelement = document.createElement("input");
        TextSelectionManager.SelectAll(inputelement);
        TextSelectionManager.SelectAll("dialog");
        TextSelectionManager.SelectAll(elementinput);
        TextSelectionManager.Clear(elementinput);
        this.assertEquals(TextSelectionManager.Clear(), true);
    }
    testgetSelectedText() {
        Echo.Println("<label><input id=\"testId\" type=\"text\">Multiple</label><br>");
        this.assertEquals(TextSelectionManager.getSelectedText(ElementManager.getElement("testId")), "");
        TextSelectionManager.SelectAll(ElementManager.getElement("testId"));
        this.assertEquals(TextSelectionManager.getSelectedText(ElementManager.getElement("testId")), "Multiple");
        TextSelectionManager.SelectAll(ElementManager.getElement("testId"));
    }
    testsetCurrentPosition() {
        const elementinput = document.createElement("input");
        Echo.Println("<label><input id=\"testId\" type=\"text\">Multiple</label><br>");
        this.assertEquals(TextSelectionManager.setCurrentPosition(ElementManager.getElement("testId", true), 5), "");
        TextSelectionManager.SelectAll(ElementManager.getElement("testId"));
        this.assertEquals(TextSelectionManager.getCurrentPosition(ElementManager.getElement("testId", true)), 5);
    }
    testgetCurrentPosition() {
        const elementinput = document.createElement("input");
        Echo.Println("<label><input id=\"testId\" type=\"text\">Multiple</label><br>");
        TextSelectionManager.setCurrentPosition(ElementManager.getElement("testId"), 4);
        TextSelectionManager.SelectAll(ElementManager.getElement("testId"));
        this.assertEquals(TextSelectionManager.getCurrentPosition(ElementManager.getElement("testId")), 4);
    }
    testPasteTextAtCurrentPosition() {
        const elementinput2 = document.createElement("input");
        Echo.Println("<label><input id=\"testId\" type=\"text\">Multiple</label><br>");
        TextSelectionManager.setCurrentPosition(ElementManager.getElement("testId"), 4);
        TextSelectionManager.PasteTextAtCurrentPosition("new");
        this.assertEquals(TextSelectionManager.getSelectedText(), "Multnewiple");
    }
    testClear() {
        const elementinput = document.createElement("input");
        TextSelectionManager.Clear(elementinput);
        this.assertEquals(TextSelectionManager.Clear(), true, "");
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.Utils.TextSelectionManagerTest", TextSelectionManagerTest);
//# sourceMappingURL=TextSelectionManagerTest.js.map