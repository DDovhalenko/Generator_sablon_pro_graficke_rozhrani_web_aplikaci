/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "../../HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { WindowManager } from "../../Utils/WindowManager.js";
export class WindowManagerTest extends RuntimeTestRunner {
    testGetSize() {
        const size = WindowManager.getSize();
        this.assertEquals(size.Width() > 0, true);
        this.assertEquals(size.Height() > 0, true);
    }
    testViewHTMLCode() {
        this.addButton("View HTML code", () => {
            const code = WindowManager.ViewHTMLCode();
            Echo.Println(code);
        });
    }
    testGetMousePosition() {
        Echo.Println("<div style=\"position: relative; top: 500px; left: 1200px; border: 1px solid red; width: 200px;\" " +
            "id=\"GetPositionButton\">Get mouse position</div>");
        this.getEventsManager().FireAsynchronousMethod(() => {
            const element = document.getElementById("GetPositionButton");
            element.onclick = ($eventArgs) => {
                Echo.Printf(WindowManager.getMouseX($eventArgs));
                Echo.Printf(WindowManager.getMouseY($eventArgs));
            };
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.RuntimeTests.Utils.WindowManagerTest", WindowManagerTest);
//# sourceMappingURL=WindowManagerTest.js.map