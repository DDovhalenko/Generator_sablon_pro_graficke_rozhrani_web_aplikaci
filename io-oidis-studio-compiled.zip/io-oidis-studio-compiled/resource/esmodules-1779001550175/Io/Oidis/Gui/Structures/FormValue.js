/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseArgs } from "./../../../../Io/Oidis/Commons/Primitives/BaseArgs.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
/**
 * FormValue class provides structure for HTML input element.
 */
export class FormValue extends BaseArgs {
    id;
    value;
    errorFlag;
    /**
     * @param {string} $id Set element id value.
     * @param {any} $value Set element value.
     * @param {boolean} [$errorFlag] Specify, if element is in error status or not.
     */
    constructor($id, $value, $errorFlag) {
        super();
        this.id = $id;
        this.value = $value;
        if (ObjectValidator.IsSet($errorFlag)) {
            this.errorFlag = $errorFlag;
        }
        else {
            this.errorFlag = false;
        }
    }
    /**
     * @returns {string} Returns element's id.
     */
    Id() {
        return this.id;
    }
    /**
     * @returns {any} Returns element's value.
     */
    Value() {
        return this.value;
    }
    /**
     * @returns {boolean} Returns true, if element is in error state, otherwise false.
     */
    ErrorFlag() {
        return this.errorFlag;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Structures.FormValue", FormValue);
//# sourceMappingURL=FormValue.js.map