import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { IGuiCommons } from "../Interfaces/Primitives/IGuiCommons.js";
/**
 * GuiObjectsMap is structure, which provides management of GUI objects register.
 */
export class GuiObjectsMap extends BaseObject {
    static guiClasses;
    static membersRegister;
    objects;
    size;
    lastIndex;
    refresh;
    typesMap;
    constructor() {
        super();
        this.objects = [];
        this.size = 0;
        this.refresh = true;
        this.typesMap = new ArrayList();
    }
    /**
     * @returns {number} Returns count of registered GUI objects.
     */
    Length() {
        return this.size;
    }
    /**
     * @returns {boolean} Returns true, if none of GUI object has been registered yet, otherwise false.
     */
    IsEmpty() {
        return this.size === 0;
    }
    /**
     * @param {IGuiCommons} $object Element, which should be validated.
     * @returns {boolean} Returns true, if element has been registered, otherwise false.
     */
    Exists($object) {
        let index;
        for (index = 0; index < this.size; index++) {
            if (this.objects[index].Id() === $object.Id()) {
                return true;
            }
        }
        return false;
    }
    /**
     * Add element to the GUI objects register, if element is not already in register.
     * @param {IGuiCommons} [$object] Element, which should be registered.
     * @returns {void}
     */
    Add($object) {
        if (!this.Exists($object) && ObjectValidator.IsSet($object.Id)) {
            this.objects[this.size] = $object;
            this.size++;
            this.refresh = true;
        }
    }
    /**
     * @param {IGuiCommons|IClassName} $className Element class name, which should be searched.
     * @returns {ArrayList<IGuiCommons>} Returns array list of elements with desired element type.
     */
    getType($className) {
        if (ObjectValidator.IsSet($className) &&
            ObjectValidator.IsSet($className.ClassName) && Reflection.getInstance().Exists($className.ClassName())) {
            if (this.refresh || !this.typesMap.KeyExists($className.ClassName())) {
                this.reindex();
            }
            const items = this.typesMap.getItem($className.ClassName());
            if (items !== null) {
                return items;
            }
        }
        return new ArrayList();
    }
    /**
     * @returns {ArrayList<IGuiCommons>} Returns array list of all registered GUI objects.
     */
    getAll() {
        const objectsMap = [];
        let index;
        for (index = 0; index < this.size; index++) {
            objectsMap[index] = this.objects[index].Id();
        }
        return Reflection.getInstanceOf(ArrayList.ClassName(), {
            data: this.objects,
            getClassName() {
                return ArrayList.ClassName();
            },
            keys: objectsMap,
            size: this.size
        });
    }
    /**
     * Clean up all registered elements, if $object has not been specified.
     * Clean up element from the registered GUI objects, if $object has been specified and is registered.
     * @param {IGuiCommons} [$object] Element, which should be removed.
     * @returns {void}
     */
    Clear($object) {
        if (ObjectValidator.IsSet($object)) {
            const objects = [];
            let size = 0;
            let index;
            for (index = 0; index < this.size; index++) {
                if (this.objects[index] !== $object) {
                    objects[size] = this.objects[index];
                    size++;
                }
            }
            this.objects = objects;
            this.size = size;
            this.lastIndex = size;
            if (ObjectValidator.IsSet(GuiObjectsMap.membersRegister)) {
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                const members = GuiObjectsMap.membersRegister[($object).getClassName()];
                if (!ObjectValidator.IsEmptyOrNull(members)) {
                    let memberIndex;
                    for (memberIndex = 0; memberIndex < members.length; memberIndex++) {
                        const typesMap = this.typesMap.getItem(members[memberIndex]);
                        if (!ObjectValidator.IsEmptyOrNull(typesMap)) {
                            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                            typesMap.RemoveAt(typesMap.IndexOf(($object)));
                            if (typesMap.IsEmpty()) {
                                this.typesMap.RemoveAt(this.typesMap.IndexOf(typesMap));
                            }
                        }
                    }
                }
            }
        }
        else {
            this.objects = [];
            this.size = 0;
            this.lastIndex = 0;
            this.typesMap.Clear();
        }
    }
    ToString($prefix = "", $htmlTag = true) {
        if (this.refresh || !this.typesMap.IsEmpty()) {
            this.reindex();
        }
        let output = "";
        let index;
        for (index = 0; index < this.size; index++) {
            output += $prefix + this.objectInfo(this.objects[index]) + StringUtils.NewLine($htmlTag);
        }
        const objectInfo = this.objectInfo;
        this.typesMap.foreach(($members, $key) => {
            let group = $key;
            if ($htmlTag) {
                group = "<b>" + group + "</b>";
            }
            group = $prefix + group + StringUtils.NewLine($htmlTag);
            $members.foreach(($member) => {
                group += $prefix + StringUtils.Tab(1, $htmlTag) + objectInfo($member) + StringUtils.NewLine($htmlTag);
            });
            output += group;
        });
        return output;
    }
    reindex() {
        const reflection = Reflection.getInstance();
        let classesCount = 0;
        let classIndex;
        if (!ObjectValidator.IsSet(GuiObjectsMap.guiClasses)) {
            const classes = reflection.getAllClasses();
            let guiClassIndex = 0;
            GuiObjectsMap.guiClasses = [];
            classesCount = classes.length;
            for (classIndex = 0; classIndex < classesCount; classIndex++) {
                if (reflection.ClassHasInterface(classes[classIndex], IGuiCommons)) {
                    GuiObjectsMap.guiClasses[guiClassIndex] = reflection.getClass(classes[classIndex]);
                    guiClassIndex++;
                }
            }
        }
        classesCount = GuiObjectsMap.guiClasses.length;
        let index;
        let startIndex = 0;
        if (this.lastIndex > this.size) {
            this.typesMap.Clear();
        }
        else if (this.lastIndex > 0) {
            startIndex = this.lastIndex - 1;
        }
        if (!ObjectValidator.IsSet(GuiObjectsMap.membersRegister)) {
            GuiObjectsMap.membersRegister = {};
        }
        let memberIndex;
        for (index = startIndex; index < this.size; index++) {
            const element = this.objects[index];
            if (element !== null) {
                if (!GuiObjectsMap.membersRegister.hasOwnProperty(element.getClassName())) {
                    GuiObjectsMap.membersRegister[element.getClassName()] = [];
                    for (classIndex = 0; classIndex < classesCount; classIndex++) {
                        if (element instanceof GuiObjectsMap.guiClasses[classIndex]) {
                            GuiObjectsMap.membersRegister[element.getClassName()].push(GuiObjectsMap.guiClasses[classIndex].ClassName());
                        }
                    }
                }
                const members = GuiObjectsMap.membersRegister[element.getClassName()];
                for (memberIndex = 0; memberIndex < members.length; memberIndex++) {
                    if (!this.typesMap.KeyExists(members[memberIndex])) {
                        this.typesMap.Add(new ArrayList(), members[memberIndex]);
                    }
                    this.typesMap.getItem(members[memberIndex]).Add(element, element.Id());
                }
            }
        }
        this.lastIndex = this.size;
        this.refresh = false;
    }
    objectInfo($object) {
        let childOut = "";
        if (!ObjectValidator.IsEmptyOrNull($object.getChildElements())) {
            $object.getChildElements().foreach(($child) => {
                if (!ObjectValidator.IsEmptyOrNull(childOut)) {
                    childOut += ",";
                }
                childOut += $child.Id();
            });
            if (!ObjectValidator.IsEmptyOrNull(childOut)) {
                childOut = "[" + childOut + "]";
            }
        }
        else {
            childOut = "EMPTY";
        }
        return "id: " + $object.Id() +
            ", parentId: " + (ObjectValidator.IsEmptyOrNull($object.Parent()) ? "not registered" : $object.Parent().Id()) +
            ", type: " + $object.getClassName() + ", childrenList: " + childOut;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Structures.GuiObjectsMap", GuiObjectsMap);
//# sourceMappingURL=GuiObjectsMap.js.map