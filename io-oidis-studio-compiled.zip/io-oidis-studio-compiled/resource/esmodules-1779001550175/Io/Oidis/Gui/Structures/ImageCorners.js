/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseArgs } from "./../../../../Io/Oidis/Commons/Primitives/BaseArgs.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
/**
 * ImageCorners class provides structure for handling of image corners radius.
 */
export class ImageCorners extends BaseArgs {
    topLeft;
    topRight;
    bottomLeft;
    bottomRight;
    /**
     * @param {number} [$topLeft] Specify top left radius value in pixels.
     * @param {number} [$topRight] Specify top right radius value in pixels.
     * @param {number} [$bottomLeft] Specify bottom left radius value in pixels.
     * @param {number} [$bottomRight] Specify bottom right radius value in pixels.
     */
    constructor($topLeft, $topRight, $bottomLeft, $bottomRight) {
        super();
        this.topLeft = 0;
        this.topRight = 0;
        this.bottomLeft = 0;
        this.bottomRight = 0;
        this.setCorners($topLeft, $topRight, $bottomLeft, $bottomRight);
    }
    /**
     * @param {number} $topLeft Specify top left radius value in pixels.
     * @param {number} $topRight Specify top right radius value in pixels.
     * @param {number} $bottomLeft Specify bottom left radius value in pixels.
     * @param {number} $bottomRight Specify bottom right radius value in pixels.
     * @returns {void}
     */
    setCorners($topLeft, $topRight, $bottomLeft, $bottomRight) {
        this.TopLeft($topLeft);
        this.TopRight($topRight);
        this.BottomLeft($bottomLeft);
        this.BottomRight($bottomRight);
    }
    /**
     * @param {number} [$value] Set top left radius value in pixels.
     * @returns {number} Returns top left radius value in pixels.
     */
    TopLeft($value) {
        return this.topLeft = Property.PositiveInteger(this.topLeft, $value);
    }
    /**
     * @param {number} [$value] Set top right radius value in pixels.
     * @returns {number} Returns top right radius value in pixels.
     */
    TopRight($value) {
        return this.topRight = Property.PositiveInteger(this.topRight, $value);
    }
    /**
     * @param {number} [$value] Set bottom left radius value in pixels.
     * @returns {number} Returns bottom left radius value in pixels.
     */
    BottomLeft($value) {
        return this.bottomLeft = Property.PositiveInteger(this.bottomLeft, $value);
    }
    /**
     * @param {number} [$value] Set bottom right radius value in pixels.
     * @returns {number} Returns bottom right radius value in pixels.
     */
    BottomRight($value) {
        return this.bottomRight = Property.PositiveInteger(this.bottomRight, $value);
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Structures.ImageCorners", ImageCorners);
//# sourceMappingURL=ImageCorners.js.map