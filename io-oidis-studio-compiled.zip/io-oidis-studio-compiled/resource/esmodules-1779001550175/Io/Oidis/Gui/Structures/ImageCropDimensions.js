/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseArgs } from "./../../../../Io/Oidis/Commons/Primitives/BaseArgs.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
/**
 * ImageCropDimensions class provides structure for handling of image crop dimensions.
 */
export class ImageCropDimensions extends BaseArgs {
    topX;
    topY;
    bottomX;
    bottomY;
    /**
     * @param {number} [$topX] Specify top X position value.
     * @param {number} [$topY] Specify top Y position value.
     * @param {number} [$bottomX] Specify bottom X position value.
     * @param {number} [$bottomY] Specify bottom Y position value.
     */
    constructor($topX, $topY, $bottomX, $bottomY) {
        super();
        this.topX = 0;
        this.topY = 0;
        this.bottomX = 0;
        this.bottomY = 0;
        this.setDimensions($topX, $topY, $bottomX, $bottomY);
    }
    /**
     * @param {number} $topX Specify top X position value.
     * @param {number} $topY Specify top Y position value.
     * @param {number} $bottomX Specify bottom X position value.
     * @param {number} $bottomY Specify bottom Y position value.
     * @returns {void}
     */
    setDimensions($topX, $topY, $bottomX, $bottomY) {
        this.TopX($topX);
        this.TopY($topY);
        this.BottomX($bottomX);
        this.BottomY($bottomY);
    }
    /**
     * @param {number} [$value] Set top X position value.
     * @returns {number} Returns top X position value.
     */
    TopX($value) {
        return this.topX = Property.PositiveInteger(this.topX, $value);
    }
    /**
     * @param {number} [$value] Set top Y position value.
     * @returns {number} Returns top Y position value.
     */
    TopY($value) {
        return this.topY = Property.PositiveInteger(this.topY, $value);
    }
    /**
     * @param {number} [$value] Set bottom X position value.
     * @returns {number} Returns bottom X position value.
     */
    BottomX($value) {
        return this.bottomX = Property.PositiveInteger(this.bottomX, $value);
    }
    /**
     * @param {number} [$value] Set bottom Y position value.
     * @returns {number} Returns bottom Y position value.
     */
    BottomY($value) {
        return this.bottomY = Property.PositiveInteger(this.bottomY, $value);
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Structures.ImageCropDimensions", ImageCropDimensions);
//# sourceMappingURL=ImageCropDimensions.js.map