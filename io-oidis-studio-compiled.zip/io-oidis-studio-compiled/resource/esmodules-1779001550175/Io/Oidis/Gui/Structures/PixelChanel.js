/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { Convert } from "./../../../../Io/Oidis/Commons/Utils/Convert.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
export class PixelChanel extends BaseObject {
    RED;
    GREEN;
    BLUE;
    ALPHA;
    constructor() {
        super();
        this.RED = 0;
        this.GREEN = 0;
        this.BLUE = 0;
        this.ALPHA = 0;
    }
    ToString($prefix = "", $htmlTag = true) {
        let output = "";
        output += $prefix + "[Red] " + Convert.ObjectToString(this.RED) + StringUtils.NewLine($htmlTag);
        output += $prefix + "[Green] " + Convert.ObjectToString(this.GREEN) + StringUtils.NewLine($htmlTag);
        output += $prefix + "[Blue] " + Convert.ObjectToString(this.BLUE) + StringUtils.NewLine($htmlTag);
        output += $prefix + "[Alpha] " + Convert.ObjectToString(this.ALPHA) + StringUtils.NewLine($htmlTag);
        return output;
    }
    toString() {
        return this.ToString();
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Structures.PixelChanel", PixelChanel);
//# sourceMappingURL=PixelChanel.js.map