/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BrowserType } from "./../../../../Io/Oidis/Commons/Enums/BrowserType.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { Convert } from "./../../../../Io/Oidis/Commons/Utils/Convert.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { DirectionType } from "../Enums/DirectionType.js";
import { OpacityEventType } from "../Enums/Events/OpacityEventType.js";
import { GeneralCssNames } from "../Enums/GeneralCssNames.js";
import { ProgressType } from "../Enums/ProgressType.js";
import { EventsManager } from "../Events/EventsManager.js";
import { Loader } from "../Loader.js";
import { ElementOffset } from "../Structures/ElementOffset.js";
import { ValueProgressManager } from "./ValueProgressManager.js";
import { Theme } from "../Enums/Theme.js";
/**
 * ElementManager class provides static methods focused on handling of HTML elements.
 */
export class ElementManager extends BaseObject {
    static domCache;
    static cssRules;
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element object or id, which should be looked up.
     * @param {boolean} [$force=false] Get fresh object instance for DOM.
     * @returns {HTMLElement} Returns instance of DOM element, if element has been found.
     */
    static getElement($id, $force = false) {
        if (ObjectValidator.IsEmptyOrNull($id)) {
            return null;
        }
        if (ObjectValidator.IsString($id)) {
            if ($force === true) {
                this.CleanElementCache($id);
            }
            if (!ObjectValidator.IsSet(this.domCache)) {
                this.domCache = {};
            }
            if (!this.domCache.hasOwnProperty($id)) {
                let element = document.getElementById($id);
                if (!ObjectValidator.IsEmptyOrNull(element)) {
                    this.domCache[$id] = element;
                    return element;
                }
                else {
                    // eslint-disable-next-line no-restricted-syntax -- this IS the framework binding implementation
                    element = document.querySelector("[data-oidis-bind=\"" + $id + "\"]");
                    if (!ObjectValidator.IsEmptyOrNull(element)) {
                        delete element.dataset.oidisBind;
                        return element;
                    }
                }
                return null;
            }
            return this.domCache[$id];
        }
        else if (ObjectValidator.IsFunction($id.Id)) {
            return this.getElement($id.Id());
        }
        return $id;
    }
    /**
     * @param {string} $idOrPattern Element id or pattern for element ids, which should be removed from DOM cache.
     * @returns {void}
     */
    static CleanElementCache($idOrPattern) {
        if (!ObjectValidator.IsEmptyOrNull(this.domCache)) {
            if (StringUtils.Contains($idOrPattern, "*")) {
                for (const id in this.domCache) {
                    if (this.domCache.hasOwnProperty(id) && StringUtils.PatternMatched($idOrPattern, id)) {
                        delete this.domCache[id];
                    }
                }
            }
            else if (this.domCache.hasOwnProperty($idOrPattern)) {
                delete this.domCache[$idOrPattern];
            }
        }
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element object or id, which should be validated.
     * @param {boolean} [$force=false] Get fresh object instance for DOM.
     * @returns {boolean} Returns true, if element has been rendered, otherwise false.
     */
    static Exists($id, $force = false) {
        return !ObjectValidator.IsEmptyOrNull(this.getElement($id, $force));
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be processed.
     * @returns {string} Returns element's class name,
     * if element has been rendered and class name has been registered, otherwise null.
     */
    static getClassName($id) {
        const element = this.getElement($id);
        if (this.Exists(element)) {
            return element.className;
        }
        return null;
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @param {string} $value Class name, which should be set to the element.
     * @returns {void}
     */
    static setClassName($id, $value) {
        const element = this.getElement($id);
        if (this.Exists(element)) {
            element.className = $value;
        }
    }
    /**
     * @param {string|IGuiCommons} $id Element id or object, which should be processed.
     * @param {string} $property Property name, which should be found.
     * @param {boolean} [$force=false] Specify if returned value should be up-to-date (slower - needs layout recalculation).
     * @returns {string} Returns value associated with the property name,
     * if element and property exists, otherwise null.
     */
    static getCssValue($id, $property, $force = false) {
        let css;
        const element = this.getElement($id);
        const propertyName = StringUtils.ToCamelCase($property);
        if (this.Exists(element)) {
            if (ObjectValidator.IsEmptyOrNull(element.cachedStyle)) {
                element.cachedStyle = {};
            }
            css = element.style[propertyName];
            if (!ObjectValidator.IsEmptyOrNull(css)) {
                return css;
            }
            if (!$force) {
                css = element.cachedStyle[propertyName];
                if (!ObjectValidator.IsEmptyOrNull(css)) {
                    return css;
                }
            }
            const cssProperties = this.getRuntimeCss(element);
            if (!ObjectValidator.IsEmptyOrNull(cssProperties)) {
                if (ObjectValidator.IsSet(cssProperties.getPropertyValue)) {
                    css = cssProperties.getPropertyValue($property);
                }
                else {
                    if ($property === "float") {
                        $property = "styleFloat";
                    }
                    css = cssProperties[$property];
                }
            }
            if (!ObjectValidator.IsEmptyOrNull(css)) {
                element.cachedStyle[propertyName] = css;
                return css;
            }
            css = element.style.cssText;
        }
        if (ObjectValidator.IsEmptyOrNull(css) && ObjectValidator.IsString($id)) {
            let className = "";
            if (this.Exists(element)) {
                className = "." + element.className;
                if (className === ".") {
                    className = "#" + $id;
                }
            }
            else {
                className = "." + $id;
            }
            css = this.getCssClassText(className);
            if (ObjectValidator.IsEmptyOrNull(css)) {
                className = "#" + $id;
                css = this.getCssClassText(className);
            }
            if (ObjectValidator.IsEmptyOrNull(css)) {
                css = this.getCssClassText($id);
            }
        }
        if (!ObjectValidator.IsEmptyOrNull(css)) {
            const split1 = StringUtils.Split(css, "; ");
            let index;
            const split1Length = split1.length;
            for (index = 0; index < split1Length; index++) {
                const split2 = StringUtils.Split(split1[index], ": ");
                if (split2.length === 2) {
                    if (StringUtils.ToUpperCase(split2[0]) === StringUtils.ToUpperCase($property)) {
                        css = StringUtils.Remove(split2[1], ";");
                        element.cachedStyle[propertyName] = css;
                        return css;
                    }
                }
            }
        }
        return null;
    }
    /**
     * @param {string|IGuiCommons} $id Element id or class name, which should be processed.
     * @param {string} $property Property name, which should be found.
     * @param {boolean} [$force=false] Specify if returned value should be up-to-date (slower - needs layout recalculation).
     * @returns {number} Returns integer value associated with the property name,
     * if element and property exists, otherwise null.
     */
    static getCssIntegerValue($id, $property, $force = false) {
        const output = Convert.StringToDouble(StringUtils.Remove(this.getCssValue($id, $property, $force), "px"));
        if (ObjectValidator.IsDigit(output)) {
            return Math.round(output);
        }
        return null;
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @param {string} $property Property name, which should be set.
     * @param {string|number} $value Value, which should be associated with the property name.
     * @returns {void}
     */
    static setCssProperty($id, $property, $value) {
        const element = this.getElement($id);
        if (this.Exists(element)) {
            const value = (ObjectValidator.IsString($value) ? $value : $value + "px");
            if (Loader.getInstance().getHttpManager().getRequest().getBrowserType() === BrowserType.INTERNET_EXPLORER) {
                let split1 = [];
                let split2 = [];
                let newCss = "";
                let oldCss = element.style.cssText;
                if (ObjectValidator.IsEmptyOrNull(oldCss)) {
                    let className = "." + element.className;
                    if (className === "." && ObjectValidator.IsString($id)) {
                        className = "#" + $id;
                    }
                    oldCss = this.getCssClassText(className);
                    if (oldCss === null) {
                        oldCss = "";
                    }
                }
                if (!ObjectValidator.IsEmptyOrNull(oldCss)) {
                    let propertyFound = false;
                    split1 = StringUtils.Split(oldCss, "; ");
                    let index;
                    const split1Length = split1.length;
                    for (index = 0; index < split1Length; index++) {
                        split2 = StringUtils.Split(split1[index], ": ");
                        if (split2.length === 2) {
                            if (StringUtils.ToUpperCase(split2[0]) === StringUtils.ToUpperCase($property)) {
                                split2[1] = value;
                                propertyFound = true;
                            }
                            newCss += StringUtils.ToUpperCase(split2[0]) + ": " + split2[1] + "; ";
                        }
                    }
                    if (!propertyFound) {
                        newCss += StringUtils.ToUpperCase($property) + ": " + value + "; ";
                    }
                    element.style.cssText = newCss;
                }
                else {
                    element.style.cssText = StringUtils.ToUpperCase($property) + ": " + value + "; ";
                }
            }
            else {
                element.style.setProperty($property, value, null);
                ElementManager.setCssProperty =
                    ($id, $property, $value) => {
                        const element = ElementManager.getElement($id);
                        if (this.Exists(element)) {
                            const value = (ObjectValidator.IsString($value) ? $value : $value + "px");
                            element.style.setProperty($property, value, null);
                            if (ObjectValidator.IsEmptyOrNull(element.cachedStyle)) {
                                element.cachedStyle = {};
                            }
                            element.cachedStyle[$property] = value;
                        }
                    };
            }
        }
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @param {string} $property Property name, which should be cleaned up.
     * @returns {void}
     */
    static ClearCssProperty($id, $property) {
        const element = this.getElement($id);
        if (this.Exists(element)) {
            const jsProperty = StringUtils.ToCamelCase($property);
            if (!ObjectValidator.IsEmptyOrNull(element.style[jsProperty])) {
                element.style[jsProperty] = "";
            }
            if (!ObjectValidator.IsEmptyOrNull(element.cachedStyle)) {
                element.cachedStyle[jsProperty] = "";
            }
            let split1 = [];
            let split2 = [];
            let newCss = "";
            let oldCss = element.style.cssText;
            if (ObjectValidator.IsEmptyOrNull(oldCss)) {
                let className = "." + element.className;
                if (className === "." && ObjectValidator.IsString($id)) {
                    className = "#" + $id;
                }
                oldCss = this.getCssClassText(className);
                if (oldCss === null) {
                    oldCss = "";
                }
            }
            if (!ObjectValidator.IsEmptyOrNull(oldCss)) {
                split1 = StringUtils.Split(oldCss, "; ");
                let index;
                const split1Length = split1.length;
                for (index = 0; index < split1Length; index++) {
                    split2 = StringUtils.Split(split1[index], ": ");
                    if (split2.length === 2) {
                        if (StringUtils.ToUpperCase(split2[0]) !== StringUtils.ToUpperCase($property)) {
                            newCss += StringUtils.ToUpperCase(split2[0]) + ": " + split2[1] + "; ";
                        }
                    }
                }
                element.style.cssText = newCss;
            }
        }
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be processed.
     * @returns {string} Returns content of the element, if element has been found, otherwise null.
     */
    static getInnerHtml($id) {
        const element = this.getElement($id);
        if (this.Exists(element)) {
            return element.innerHTML;
        }
        return null;
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @param {string} $value Element's content, which should be set.
     * @returns {void}
     */
    static setInnerHtml($id, $value) {
        const element = this.getElement($id);
        if (this.Exists(element)) {
            element.innerHTML = $value;
        }
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @param {string} $value New content, which should be appended to current element's content.
     * @returns {void}
     */
    static AppendHtml($id, $value) {
        const target = this.getElement($id);
        if (this.Exists(target)) {
            const element = document.createElement("span");
            if (StringUtils.StartsWith($value, " ")) {
                $value = StringUtils.Substring($value, 1, StringUtils.Length($value));
                $value = StringUtils.Space(1) + $value;
            }
            element.setAttribute("guiType", "HtmlAppender");
            element.innerHTML = $value;
            target.appendChild(element);
        }
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @param {string} $value New content, which should be prepended to current element's content.
     * @returns {void}
     */
    static PrependHtml($id, $value) {
        const target = this.getElement($id);
        if (this.Exists(target)) {
            const element = document.createElement("span");
            if (StringUtils.StartsWith($value, " ")) {
                $value = StringUtils.Substring($value, 1, StringUtils.Length($value));
                $value = StringUtils.Space(1) + $value;
            }
            element.setAttribute("guiType", "HtmlAppender");
            element.innerHTML = $value;
            if (ObjectValidator.IsSet(target.firstChild)) {
                target.insertBefore(element, target.firstChild);
            }
            else {
                target.appendChild(element);
            }
        }
    }
    /**
     * @param {string|IGuiCommons} $id Element id or object, which should be processed.
     * @returns {boolean} Returns true, if element exist and is visible on the screen.
     */
    static IsVisible($id) {
        if (!this.Exists($id)) {
            return false;
        }
        const value = this.getCssValue($id, "display");
        return ObjectValidator.IsEmptyOrNull(value) || value === "block";
    }
    /**
     * Enable visibility of the element on the screen.
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @returns {void}
     */
    static Show($id) {
        this.setCssProperty($id, "display", "block");
    }
    /**
     * Disable visibility of the element on the screen.
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @returns {void}
     */
    static Hide($id) {
        this.setCssProperty($id, "display", "none");
    }
    /**
     * Enable or disable visibility of the element on the screen based on current element's visibility.
     * @param {string|IGuiCommons} $id Element id or object, which should be handled.
     * @returns {void}
     */
    static ToggleVisibility($id) {
        if (this.IsVisible($id)) {
            this.Hide($id);
        }
        else {
            this.Show($id);
        }
    }
    /**
     * Set general css class name "On" to the handled element.
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @returns {void}
     */
    static TurnOn($id) {
        this.setClassName($id, GeneralCssNames.ON);
    }
    /**
     * Set general css class name "Off" to the handled element.
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @returns {void}
     */
    static TurnOff($id) {
        this.setClassName($id, GeneralCssNames.OFF);
    }
    /**
     * Set general css class name "On" or "Off" based on current element's state.
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @returns {void}
     */
    static ToggleOnOff($id) {
        const element = this.getElement($id);
        if (this.Exists(element)) {
            if (element.className === GeneralCssNames.ON) {
                element.className = GeneralCssNames.OFF;
            }
            else {
                element.className = GeneralCssNames.ON;
            }
        }
    }
    /**
     * Set general css class name "Active" to the handled element.
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @returns {void}
     */
    static TurnActive($id) {
        this.setClassName($id, GeneralCssNames.ACTIVE);
    }
    /**
     * Set z-index value to the handled element, so it will be at topmost position.
     * @param {string|IGuiCommons} $id Element id, which should be handled.
     * @returns {void}
     */
    static TopMost($id) {
        if (ObjectValidator.IsEmptyOrNull(this.getCssValue($id, "position"))) {
            this.setCssProperty($id, "position", "fixed");
        }
        this.setCssProperty($id, "z-index", "99999");
    }
    /**
     * Set z-index value to the handled element, so it will be at front position.
     * @param {string|IGuiCommons} $id Element id, which should be handled.
     * @returns {void}
     */
    static BringToFront($id) {
        if (ObjectValidator.IsEmptyOrNull(this.getCssValue($id, "position"))) {
            this.setCssProperty($id, "position", "relative");
        }
        this.setCssProperty($id, "z-index", "1000");
    }
    /**
     * Set z-index value to the handled element, so it will be at back position.
     * @param {string|IGuiCommons} $id Element id, which should be handled.
     * @returns {void}
     */
    static SendToBack($id) {
        if (ObjectValidator.IsEmptyOrNull(this.getCssValue($id, "position"))) {
            this.setCssProperty($id, "position", "relative");
        }
        this.setCssProperty($id, "z-index", "0");
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @param {number} $value Opacity value, which should be set to the handled element.
     * Value can be set in range <0;100> or <0.00;1.00>, otherwise it will be cut to closest limit.
     * @returns {void}
     */
    static setOpacity($id, $value) {
        if (this.Exists($id)) {
            if ($value > 0 && $value < 1) {
                $value = $value * 100;
            }
            if ($value < 0) {
                $value = 0;
            }
            if ($value > 100) {
                $value = 100;
            }
            const floatValue = ($value / 100).toFixed(2);
            this.setCssProperty($id, "-ms-filter", "progid:DXImageTransform.Microsoft.Alpha(Opacity=" + $value + ")");
            this.setCssProperty($id, "filter", "alpha(opacity=" + $value + ")");
            this.setCssProperty($id, "-moz-opacity", floatValue);
            this.setCssProperty($id, "-khtml-opacity", floatValue);
            this.setCssProperty($id, "opacity", floatValue);
        }
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @param {number} $width Element's width after scale.
     * @param {number} $height Element's height after scale.
     * @returns {void}
     */
    static Scale($id, $width, $height) {
        if (this.Exists($id)) {
            const element = this.getElement($id);
            let elementHeight = element.offsetHeight;
            if (elementHeight < element.scrollHeight) {
                elementHeight = element.scrollHeight;
            }
            let elementWidth = element.offsetWidth;
            if (elementWidth < element.scrollWidth) {
                elementWidth = element.scrollWidth;
            }
            const widthScale = ($containerValue, $elementValue) => {
                const scale = $containerValue / $elementValue;
                if (scale > 1) {
                    return (1 / scale).toFixed(2);
                }
                else {
                    return (scale).toFixed(2);
                }
            };
            const heightScale = ($containerValue, $elementValue) => {
                const scale = $containerValue / $elementValue;
                if (scale > 1) {
                    return (1 - (1 / scale)).toFixed(2);
                }
                else {
                    return (scale).toFixed(2);
                }
            };
            const scaleX = widthScale($width, elementWidth);
            const scaleY = heightScale($height, elementHeight);
            this.setCssProperty(element, "transform-origin", "0% 0%");
            this.setCssProperty(element, "transform", "scale(" + scaleX + ", " + scaleY + ")");
            this.setCssProperty(element, "-ms-transform-origin", "0% 0%");
            this.setCssProperty(element, "-ms-transform", "scale(" + scaleX + ", " + scaleY + ")");
            this.setCssProperty(element, "-moz-transform-origin", "0% 0%");
            this.setCssProperty(element, "-moz-transform", "scale(" + scaleX + ", " + scaleY + ")");
            this.setCssProperty(element, "-webkit-transform-origin", "0% 0%");
            this.setCssProperty(element, "-webkit-transform", "scale(" + scaleX + ", " + scaleY + ")");
            this.setCssProperty(element, "-o-transform-origin", "0% 0%");
            this.setCssProperty(element, "-o-transform", "scale(" + scaleX + ", " + scaleY + ")");
        }
    }
    /**
     * Asynchronously change element opacity with defined change iterations count.
     * @param {IGuiCommons|string} $elementOrId GUI element or id of DOM element, which should be handled.
     * @param {DirectionType} [$directionType] Set direction in, which should be opacity changed.
     * @param {number} [$iterationCount] Set number or iterations, which should be done by value progress manager.
     * @param {number} [$callback] Set callback that should be invoked after opacity change is complete.
     * @returns {void}
     */
    static ChangeOpacity($elementOrId, $directionType, $iterationCount, $callback) {
        let managerId = $elementOrId;
        if (ObjectValidator.IsSet($elementOrId.Id)) {
            managerId = $elementOrId.Id();
        }
        managerId += "_Opacity";
        const manipulatorArgs = ValueProgressManager.get(managerId);
        manipulatorArgs.Owner(managerId);
        manipulatorArgs.DirectionType($directionType);
        if (manipulatorArgs.DirectionType() === DirectionType.UP) {
            manipulatorArgs.ProgressType(ProgressType.FAST_START);
        }
        else {
            manipulatorArgs.ProgressType(ProgressType.FAST_END);
        }
        manipulatorArgs.Step(100 / $iterationCount);
        manipulatorArgs.RangeStart(0);
        manipulatorArgs.RangeEnd(100);
        manipulatorArgs.CurrentValue(Math.ceil(StringUtils.ToDouble(this.getCssValue($elementOrId, "opacity", true)) * 100));
        manipulatorArgs.StartEventType(OpacityEventType.START);
        manipulatorArgs.ChangeEventType(OpacityEventType.CHANGE);
        manipulatorArgs.CompleteEventType(OpacityEventType.COMPLETE);
        EventsManager.getInstanceSingleton().setEvent(managerId, OpacityEventType.CHANGE, (eventArgs) => {
            ElementManager.setOpacity($elementOrId, eventArgs.CurrentValue());
        });
        EventsManager.getInstanceSingleton().setEvent(managerId, OpacityEventType.COMPLETE, () => {
            if (ObjectValidator.IsFunction($callback)) {
                $callback();
            }
        });
        ValueProgressManager.Execute(manipulatorArgs);
    }
    /**
     * Stop asynchronous change of element opacity, if element opacity is currently handled.
     * @param {IGuiCommons|string} $elementOrId GUI element or id of DOM element, which should be handled.
     * @returns {void}
     */
    static StopOpacityChange($elementOrId) {
        let managerId = $elementOrId;
        if (ObjectValidator.IsSet($elementOrId.Id)) {
            managerId = $elementOrId.Id();
        }
        ValueProgressManager.Remove(managerId + "_Opacity");
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @param {boolean} $status Set element's visibility mode.
     * @returns {void}
     */
    static Enabled($id, $status) {
        if (this.Exists($id)) {
            if ($status === true) {
                this.Hide($id + "_Disabled");
                this.Show($id + "_Enabled");
            }
            else {
                this.Hide($id + "_Enabled");
                this.Show($id + "_Disabled");
            }
        }
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be validated.
     * @returns {void}
     */
    static IsEnabled($id) {
        return this.IsVisible($id + "_Enabled");
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @param {number} $value Set element's width value.
     * @returns {void}
     */
    static setWidth($id, $value) {
        this.setCssProperty($id, "width", $value);
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @param {number} $value Set element's height value.
     * @returns {void}
     */
    static setHeight($id, $value) {
        this.setCssProperty($id, "height", $value);
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @param {number} $width Set element's width value.
     * @param {number} $height Set element's height value.
     * @returns {void}
     */
    static setSize($id, $width, $height) {
        this.setCssProperty($id, "width", $width);
        this.setCssProperty($id, "height", $height);
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @param {ElementOffset} $position Specify required position.
     * @returns {void}
     */
    static setPosition($id, $position) {
        this.setCssProperty($id, "top", $position.Top());
        this.setCssProperty($id, "left", $position.Left());
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be processed.
     * @returns {ElementOffset} Returns absolute top and left offset based on current element's position.
     */
    static getAbsoluteOffset($id) {
        const offset = new ElementOffset();
        let offsetLeft = 0;
        let offsetTop = 0;
        let element = this.getElement($id);
        const getOffset = () => {
            offsetLeft = 0;
            offsetTop = 0;
            while (!ObjectValidator.IsEmptyOrNull(element)) {
                if (element.offsetLeft > 0) {
                    offsetLeft += element.offsetLeft;
                }
                if (element.offsetTop > 0) {
                    offsetTop += element.offsetTop;
                }
                element = element.offsetParent;
            }
        };
        getOffset();
        if (Loader.getInstance().getHttpManager().getRequest().getBrowserType() === BrowserType.INTERNET_EXPLORER &&
            Loader.getInstance().getHttpManager().getRequest().getBrowserVersion() <= 7) {
            element = this.getElement($id);
            getOffset();
        }
        offset.Left(offsetLeft);
        offset.Top(offsetTop);
        return offset;
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be processed.
     * @returns {ElementOffset} Returns element's position relative to screen top left corner.
     */
    static getScreenPosition($id) {
        const offset = new ElementOffset();
        let offsetLeft = 0;
        let offsetTop = 0;
        let element = ElementManager.getElement($id);
        let offsetParent = null;
        while (!ObjectValidator.IsEmptyOrNull(element)) {
            if (element === offsetParent || ObjectValidator.IsEmptyOrNull(offsetParent)) {
                offsetLeft += element.offsetLeft;
                offsetTop += element.offsetTop;
                if (!ObjectValidator.IsEmptyOrNull(element.id)) {
                    offsetLeft += ElementManager.getCssIntegerValue(element.id, "border-left-width");
                    offsetTop += ElementManager.getCssIntegerValue(element.id, "border-top-width");
                }
                else {
                    if (!ObjectValidator.IsEmptyOrNull(element.style.borderLeftWidth)) {
                        offsetLeft += StringUtils.ToInteger(StringUtils.Remove(element.style.borderLeftWidth, "px"));
                    }
                    if (!ObjectValidator.IsEmptyOrNull(element.style.borderTopWidth)) {
                        offsetTop += StringUtils.ToInteger(StringUtils.Remove(element.style.borderTopWidth, "px"));
                    }
                }
            }
            offsetLeft -= element.scrollLeft;
            offsetTop -= element.scrollTop;
            offsetParent = element.offsetParent;
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            element = element.parentElement;
        }
        const browser = Loader.getInstance().getHttpManager().getRequest().getBrowserType();
        if (browser === BrowserType.FIREFOX ||
            (browser === BrowserType.INTERNET_EXPLORER && Loader.getInstance().getHttpManager().getRequest().getBrowserVersion() > 7)) {
            offsetLeft -= (document.body.scrollLeft === 0 ? document.documentElement.scrollLeft : document.body.scrollLeft);
            offsetTop -= (document.body.scrollTop === 0 ? document.documentElement.scrollTop : document.body.scrollTop);
        }
        offset.Left(offsetLeft);
        offset.Top(offsetTop);
        return offset;
    }
    /**
     * @param {string|IGuiCommons} $id Element id or object, which should be processed.
     * @param {boolean} [$force=false] Specify if returned value should be up-to-date (slower - needs layout recalculation).
     * @param {boolean} [$ignoreHidden=true] Specify if returned value should be 0 if element is hidden.
     * @returns {number} Returns total element width - eq. offsetWidth + margin-width.
     */
    static getEnvelopWidth($id, $force = false, $ignoreHidden = true) {
        if (!ElementManager.IsVisible($id) && $ignoreHidden) {
            return 0;
        }
        return this.getCssIntegerValue($id, "width", $force) +
            this.getWidthOffset($id, $force);
    }
    /**
     * @param {string|IGuiCommons} $id Element id or object, which should be processed.
     * @param {boolean} [$force=false] Specify if returned value should be up-to-date (slower - needs layout recalculation).
     * @param {boolean} [$ignoreHidden=true] Specify if returned value should be 0 if element is hidden.
     * @returns {number} Returns total element height - eq. offsetHeight + margin-height.
     */
    static getEnvelopHeight($id, $force = false, $ignoreHidden = true) {
        if (!ElementManager.IsVisible($id) && $ignoreHidden) {
            return 0;
        }
        return this.getCssIntegerValue($id, "height", $force) +
            this.getHeightOffset($id, $force);
    }
    /**
     * @param {string|IGuiCommons} $id Element id or object, which should be processed.
     * @param {boolean} [$force=false] Specify if returned value should be up-to-date (slower - needs layout recalculation).
     * @param {boolean} [$ignoreHidden=true] Specify if returned value should be 0 if element is hidden.
     * @returns {number} Returns offsetWidth property.
     */
    static getOffsetWidth($id, $force = false, $ignoreHidden = true) {
        if ($force && $ignoreHidden) {
            const prevElement = this.getElement($id);
            const element = this.getElement($id, true);
            if (ObjectValidator.IsEmptyOrNull(element)) {
                return 0;
            }
            if (!ObjectValidator.IsEmptyOrNull(prevElement)) {
                element.cachedStyle = prevElement.cachedStyle;
            }
            return element.offsetWidth;
        }
        else {
            if (!ElementManager.IsVisible($id) && $ignoreHidden) {
                return 0;
            }
            return this.getCssIntegerValue($id, "width", false) +
                this.getWidthOffset($id, false, false);
        }
    }
    /**
     * @param {string|IGuiCommons} $id Element id or object, which should be processed.
     * @param {boolean} [$force=false] Specify if returned value should be up-to-date (slower - needs layout recalculation).
     * @param {boolean} [$ignoreHidden=true] Specify if returned value should be 0 if element is hidden.
     * @returns {number} Returns offsetHeight property.
     */
    static getOffsetHeight($id, $force = false, $ignoreHidden = true) {
        if ($force && $ignoreHidden) {
            const prevElement = this.getElement($id);
            const element = this.getElement($id, true);
            if (ObjectValidator.IsEmptyOrNull(element)) {
                return 0;
            }
            if (!ObjectValidator.IsEmptyOrNull(prevElement)) {
                element.cachedStyle = prevElement.cachedStyle;
            }
            return element.offsetHeight;
        }
        else {
            if (!ElementManager.IsVisible($id) && $ignoreHidden) {
                return 0;
            }
            return this.getCssIntegerValue($id, "height", false) +
                this.getHeightOffset($id, false, false);
        }
    }
    /**
     * @param {string|IGuiCommons} $id Element id or object, which should be processed.
     * @param {boolean} [$force=false] Specify if returned value should be up-to-date (slower - needs layout recalculation).
     * @param {boolean} [$includeMargin=true] Specify if margin should be included.
     * @param  {boolean} [$includePadding=true] Specify if padding and border should be included.
     * @returns {number} Returns inner width of element's offset - eq. padding-width + border-width.
     */
    static getWidthOffset($id, $force = false, $includeMargin = true, $includePadding = true) {
        return ($includePadding ? this.getCssIntegerValue($id, "padding-left", $force) +
            this.getCssIntegerValue($id, "padding-right", $force) +
            this.getCssIntegerValue($id, "border-left-width", $force) +
            this.getCssIntegerValue($id, "border-right-width", $force) : 0) +
            ($includeMargin ? this.getCssIntegerValue($id, "margin-left", $force) +
                this.getCssIntegerValue($id, "margin-right", $force) : 0);
    }
    /**
     * @param {string|IGuiCommons} $id Element id or object, which should be processed.
     * @param {boolean} [$force=false] Specify if returned value should be up-to-date (slower - needs layout recalculation).
     * @param {boolean} [$includeMargin=true] Specify if margin should be included.
     * @param  {boolean} [$includePadding=true] Specify if padding and border should be included.
     * @returns {number} Returns inner height of element's offset - eq. padding-height + border-height.
     */
    static getHeightOffset($id, $force = false, $includeMargin = true, $includePadding = true) {
        return ($includePadding ? this.getCssIntegerValue($id, "padding-top", $force) +
            this.getCssIntegerValue($id, "padding-bottom", $force) +
            this.getCssIntegerValue($id, "border-top-width", $force) +
            this.getCssIntegerValue($id, "border-bottom-width", $force) : 0) +
            ($includeMargin ? this.getCssIntegerValue($id, "margin-top", $force) +
                this.getCssIntegerValue($id, "margin-bottom", $force) : 0);
    }
    /**
     * @param {string|HTMLElement|IGuiCommons} $id Element id or object, which should be handled.
     * @param {number} $value Specify required zoom.
     * @returns {void}
     */
    static setZoom($id, $value) {
        if ($value > 0 && $value < 1) {
            $value *= 100;
        }
        const percentage = Convert.ToFixed($value / 100, 2);
        ElementManager.setCssProperty($id, "-ms-zoom", percentage);
        ElementManager.setCssProperty($id, "-moz-transform", "scale(" + percentage + ")");
        ElementManager.setCssProperty($id, "-moz-transform-origin", "0 0");
        ElementManager.setCssProperty($id, "-o-transform", "scale(" + percentage + ")");
        ElementManager.setCssProperty($id, "-o-transform-origin", "0 0");
        ElementManager.setCssProperty($id, "-webkit-transform", "scale(" + percentage + ")");
        ElementManager.setCssProperty($id, "-webkit-transform-origin", "0 0");
    }
    static setTheme($theme) {
        if ($theme === Theme.AUTO) {
            $theme = window.matchMedia("(prefers-color-scheme: dark)").matches ? Theme.DARK : Theme.LIGHT;
        }
        document.documentElement.setAttribute("data-bs-theme", $theme.toString());
    }
    static getCssClassText($idOrClassName) {
        const styleSheets = document.styleSheets;
        if (!ObjectValidator.IsSet(styleSheets)) {
            return null;
        }
        if (!ObjectValidator.IsSet(ElementManager.cssRules)) {
            let styleIndex;
            const styleSheetsLength = styleSheets.length;
            for (styleIndex = 0; styleIndex < styleSheetsLength; styleIndex++) {
                if (ObjectValidator.IsSet(styleSheets[styleIndex])) {
                    const styleSheet = styleSheets[styleIndex];
                    try {
                        if (ObjectValidator.IsSet(styleSheet.cssRules)) {
                            ElementManager.cssRules = styleSheet.cssRules;
                        }
                        else {
                            // eslint-disable-next-line @typescript-eslint/no-deprecated -- polyfill fallback for browsers without cssRules
                            ElementManager.cssRules = styleSheet.rules;
                        }
                    }
                    catch (ex) {
                        // unable to read rules
                    }
                }
            }
        }
        if (!ObjectValidator.IsEmptyOrNull(ElementManager.cssRules)) {
            let ruleIndex;
            const cssRulesLength = ElementManager.cssRules.length;
            for (ruleIndex = 0; ruleIndex < cssRulesLength; ruleIndex++) {
                const rule = ElementManager.cssRules[ruleIndex];
                if (rule.selectorText === $idOrClassName) {
                    if (ObjectValidator.IsSet(rule.style) && ObjectValidator.IsSet(rule.style.cssText)) {
                        return rule.style.cssText;
                    }
                    else if (ObjectValidator.IsSet(rule.cssText)) {
                        return rule.cssText;
                    }
                }
            }
        }
        return null;
    }
    static getRuntimeCss($id) {
        let computedStyle = null;
        const element = this.getElement($id);
        if (ObjectValidator.IsSet(window.getComputedStyle)) {
            computedStyle = window.getComputedStyle(element, null);
        }
        else {
            computedStyle = element.currentStyle;
        }
        return computedStyle;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Utils.ElementManager", ElementManager);
//# sourceMappingURL=ElementManager.js.map