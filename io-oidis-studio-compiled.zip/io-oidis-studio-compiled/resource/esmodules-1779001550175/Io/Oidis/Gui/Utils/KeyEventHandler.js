/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { KeyMap } from "../Enums/KeyMap.js";
import { ElementManager } from "./ElementManager.js";
import { TextSelectionManager } from "./TextSelectionManager.js";
/**
 * KeyEventHandler class provides helper methods focused on validation of native keyboard events.
 */
export class KeyEventHandler extends BaseObject {
    /**
     * @param {KeyboardEvent} $event Native keyboard event, which should be validated.
     * @returns {boolean} Returns true, if pressed key is type of navigation key, otherwise false.
     */
    static IsNavigate($event) {
        if (ObjectValidator.IsSet($event.key)) {
            return ($event.key === "F5" ||
                $event.key === "Tab" ||
                $event.key === "Backspace" ||
                $event.key === "ArrowLeft" ||
                $event.key === "ArrowRight" ||
                $event.key === "ArrowDown" ||
                $event.key === "ArrowUp" ||
                ($event.altKey && $event.key === "F4") /* Alt+F4 */);
        }
        /* eslint-disable @typescript-eslint/no-deprecated -- polyfill fallback for browsers without event.key */
        return ($event.keyCode === KeyMap.F5 ||
            $event.keyCode === KeyMap.TAB ||
            $event.keyCode === KeyMap.BACKSPACE ||
            $event.keyCode === KeyMap.LEFT_ARROW ||
            $event.keyCode === KeyMap.RIGHT_ARROW ||
            $event.keyCode === KeyMap.DOWN_ARROW ||
            $event.keyCode === KeyMap.UP_ARROW ||
            ($event.altKey && $event.keyCode === KeyMap.F4) /* Alt+F4 */);
        /* eslint-enable @typescript-eslint/no-deprecated */
    }
    /**
     * @param {KeyboardEvent} $event Native keyboard event, which should be validated.
     * @returns {boolean} Returns true, if pressed key is type of editor key, otherwise false.
     */
    static IsEdit($event) {
        if (ObjectValidator.IsSet($event.key)) {
            return !($event.key === "F5" ||
                $event.key === "ArrowLeft" ||
                $event.key === "ArrowRight" ||
                $event.key === "ArrowDown" ||
                $event.key === "ArrowUp" ||
                ($event.altKey && $event.key === "F4") /* Alt+F4 */) &&
                ($event.key === "Backspace" ||
                    $event.key === "Delete" ||
                    ($event.ctrlKey && $event.key.toLowerCase() === "a") /* Ctrl+A */ ||
                    ($event.ctrlKey && $event.key.toLowerCase() === "c") /* Ctrl+C */ ||
                    ($event.ctrlKey && $event.key.toLowerCase() === "v") /* Ctrl+V */ ||
                    ($event.ctrlKey && $event.key.toLowerCase() === "x") /* Ctrl+X */);
        }
        /* eslint-disable @typescript-eslint/no-deprecated -- polyfill fallback for browsers without event.key */
        return !($event.keyCode === KeyMap.F5 ||
            $event.keyCode === KeyMap.LEFT_ARROW ||
            $event.keyCode === KeyMap.RIGHT_ARROW ||
            $event.keyCode === KeyMap.DOWN_ARROW ||
            $event.keyCode === KeyMap.UP_ARROW ||
            ($event.altKey && $event.keyCode === KeyMap.F4) /* Alt+F4 */) &&
            ($event.keyCode === KeyMap.BACKSPACE ||
                $event.keyCode === KeyMap.DELETE ||
                ($event.ctrlKey && $event.charCode === KeyMap.A) /* Ctrl+A */ ||
                ($event.ctrlKey && $event.charCode === KeyMap.C) /* Ctrl+C */ ||
                ($event.ctrlKey && $event.charCode === KeyMap.V) /* Ctrl+V */ ||
                ($event.ctrlKey && $event.charCode === KeyMap.X) /* Ctrl+X */);
        /* eslint-enable @typescript-eslint/no-deprecated */
    }
    /**
     * @param {KeyboardEvent} $event Native keyboard event, which should be validated.
     * @param {string} [$id] Element id, which should be handled by validation method.
     * @param {number} [$limit] Set max length limit for handled element.
     * @returns {boolean} Returns true, if pressed key is type of integer, otherwise false.
     */
    static IsInteger($event, $id, $limit) {
        if (!this.IsNavigate($event)) {
            if (ObjectValidator.IsSet($event.key)) {
                if ($event.key !== "-" && ($event.key < "0" || $event.key > "9")) {
                    return false;
                }
            }
            else {
                const code = this.getKeyCode($event);
                if (code !== KeyMap.MINUS && (code < KeyMap.ZERO || code > KeyMap.NINE)) {
                    return false;
                }
            }
            if (ObjectValidator.IsSet($id)) {
                const element = ElementManager.getElement($id);
                if (ObjectValidator.IsSet(element)) {
                    const isMinus = ObjectValidator.IsSet($event.key) ?
                        $event.key === "-" : this.getKeyCode($event) === KeyMap.MINUS;
                    if (isMinus && !ObjectValidator.IsEmptyOrNull(element.value) &&
                        TextSelectionManager.getSelectedText(element) !== element.value) {
                        return false;
                    }
                    if (!ObjectValidator.IsSet($limit)) {
                        $limit = 10;
                    }
                    if (StringUtils.Length(StringUtils.Remove(element.value, "-")) < $limit) {
                        return true;
                    }
                    else {
                        return TextSelectionManager.Clear(element);
                    }
                }
            }
        }
        return true;
    }
    /**
     * @param {KeyboardEvent} $event Native keyboard event, which should be validated.
     * @returns {boolean} Returns true, if pressed key is type of double, otherwise false.
     */
    static IsDouble($event) {
        if (ObjectValidator.IsSet($event.key)) {
            if (!this.IsNavigate($event) && $event.key !== "," && $event.key !== ".") {
                return this.IsInteger($event);
            }
        }
        else {
            const code = this.getKeyCode($event);
            if (!this.IsNavigate($event) && code !== KeyMap.COMMA && code !== KeyMap.DOT) {
                return this.IsInteger($event);
            }
        }
        return true;
    }
    /**
     * @param {KeyboardEvent} $event Native keyboard event, which should be validated.
     * @returns {boolean} Returns true, if pressed key is type of positive integer or space, otherwise false.
     */
    static IsPositiveIntegerOrSpace($event) {
        if (ObjectValidator.IsSet($event.key)) {
            if (!this.IsNavigate($event) && $event.key !== "+" && $event.key !== " ") {
                return this.IsInteger($event);
            }
        }
        else {
            const code = this.getKeyCode($event);
            if (!this.IsNavigate($event) && code !== KeyMap.PLUS && code !== KeyMap.SPACE) {
                return this.IsInteger($event);
            }
        }
        return true;
    }
    /* eslint-disable @typescript-eslint/no-deprecated -- polyfill fallback for browsers without event.key */
    static getKeyCode($event) {
        return ObjectValidator.IsSet($event.charCode) ? $event.charCode : $event.keyCode;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Utils.KeyEventHandler", KeyEventHandler);
//# sourceMappingURL=KeyEventHandler.js.map