import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Loader } from "../Loader.js";
import { StaticPageContentManager } from "./StaticPageContentManager.js";
export class PageContentBundles extends BaseObject {
    buildTime;
    packageName;
    /**
     * @returns {PageContentBundles} Returns singleton instance of PageContentBundles class.
     */
    static getInstance() {
        const instance = new this();
        this.getInstance = () => {
            return instance;
        };
        return instance;
    }
    constructor() {
        super();
        const env = Loader.getInstance().getEnvironmentArgs();
        this.buildTime = new Date(env.getBuildTime()).getTime();
        this.packageName = env.getProjectName() + "-" + env.getProjectVersion();
        this.packageName = StringUtils.Replace(this.packageName, ".", "-");
    }
    /**
     * @param {PageContentBundleType} $type Specify content bundle type, which should be applied to the page.
     * @returns {void}
     */
    Apply($type) {
        switch ($type) {
            case PageContentBundleType.OIDIS:
                StaticPageContentManager.HeadScriptAppend("resource/javascript/" + this.packageName + ".min.js?v=" + this.buildTime);
                StaticPageContentManager.HeadScriptAppend("resource/javascript/loader.min.js?v=" + this.buildTime);
                break;
            case PageContentBundleType.BOOTSTRAP:
                StaticPageContentManager.BodyEventsEnabled(false);
                StaticPageContentManager.HeadLinkAppend("resource/libs/Bootstrap/bootstrap.min.css?v=" + this.buildTime);
                const viewPort = document.createElement("meta"); // eslint-disable-line no-case-declarations
                viewPort.name = "viewport";
                viewPort.content = "width=device-width, initial-scale=1.0, shrink-to-fit=no";
                StaticPageContentManager.HeadMetaDataAppend(viewPort);
                StaticPageContentManager
                    .BodyAppend(`<script nonce="${StaticPageContentManager.Nonce()}" src="resource/libs/Bootstrap/bootstrap.min.js?v=${this.buildTime}"></script>`);
                break;
            case PageContentBundleType.REACT:
                StaticPageContentManager.BodyEventsEnabled(false);
                const viewPortR = document.createElement("meta"); // eslint-disable-line no-case-declarations
                viewPortR.name = "viewport";
                viewPortR.content = "width=device-width, initial-scale=1.0, shrink-to-fit=no";
                StaticPageContentManager.HeadMetaDataAppend(viewPortR);
                StaticPageContentManager
                    .HeadScriptAppend("resource/libs/react/react.production.min.js?v=" + this.buildTime);
                StaticPageContentManager
                    .HeadScriptAppend("resource/libs/react/react-dom.production.min.js?v=" + this.buildTime);
                break;
            case PageContentBundleType.FONTAWESOME:
                StaticPageContentManager.HeadLinkAppend("resource/css/fontawesome.css");
                break;
            case PageContentBundleType.SENTRY:
                StaticPageContentManager.BodyAppend(`<script nonce="${StaticPageContentManager.Nonce()}" src="resource/libs/Sentry/sentry.min.js?v=${this.buildTime}" crossorigin="anonymous"></script>`);
                break;
            case PageContentBundleType.QRCODE:
                StaticPageContentManager.HeadScriptAppend("resource/libs/qrcode/qrcode.js?v=" + this.buildTime);
                break;
            case PageContentBundleType.BARCODE:
                StaticPageContentManager.HeadScriptAppend("resource/libs/jsBarcode/JsBarcode.all.min.js?v=" + this.buildTime);
                break;
            case PageContentBundleType.CODE_SCANNER:
                StaticPageContentManager.HeadScriptAppend("resource/libs/html5QRcode/html5-qrcode.min.js?v=" + this.buildTime);
                break;
            default:
                LogIt.Error("Undefined content bundle type: {0}", $type);
                break;
        }
    }
}
export var PageContentBundleType;
(function (PageContentBundleType) {
    PageContentBundleType[PageContentBundleType["OIDIS"] = 0] = "OIDIS";
    PageContentBundleType[PageContentBundleType["BOOTSTRAP"] = 1] = "BOOTSTRAP";
    PageContentBundleType[PageContentBundleType["FONTAWESOME"] = 2] = "FONTAWESOME";
    PageContentBundleType[PageContentBundleType["REACT"] = 3] = "REACT";
    PageContentBundleType[PageContentBundleType["SENTRY"] = 4] = "SENTRY";
    PageContentBundleType[PageContentBundleType["QRCODE"] = 5] = "QRCODE";
    PageContentBundleType[PageContentBundleType["BARCODE"] = 6] = "BARCODE";
    PageContentBundleType[PageContentBundleType["CODE_SCANNER"] = 7] = "CODE_SCANNER";
})(PageContentBundleType || (PageContentBundleType = {}));
globalThis.RegisterClass("Io.Oidis.Gui.Utils.PageContentBundles", PageContentBundles);
//# sourceMappingURL=PageContentBundles.js.map