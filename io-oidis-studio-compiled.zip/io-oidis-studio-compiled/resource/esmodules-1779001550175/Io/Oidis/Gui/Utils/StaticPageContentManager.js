/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BrowserType } from "./../../../../Io/Oidis/Commons/Enums/BrowserType.js";
import { LanguageType } from "./../../../../Io/Oidis/Commons/Enums/LanguageType.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Loader } from "../Loader.js";
import { ElementManager } from "./ElementManager.js";
/**
 * StaticPageContentManager class provides static methods for handling of page content.
 */
export class StaticPageContentManager extends BaseObject {
    static isInitialized = false;
    static isPrinted = false;
    static charset;
    static title;
    static license;
    static faviconSource;
    static links;
    static scripts;
    static metaTags;
    static body;
    static browserType;
    static language;
    static withBodyEvents = false;
    static nonce;
    /**
     * Language type can affect page structure based on conditional css overriding.
     * @param {LanguageType} [$value] Specify language type of the page.
     * @returns {LanguageType} Returns language type of the page.
     */
    static Language($value) {
        this.init();
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.language = $value;
            if (this.isPrinted) {
                ElementManager.setClassName("Language", this.language.toString());
            }
        }
        return this.language;
    }
    /**
     * @param {string} [$value] Specify page title.
     * @returns {string} Returns page title.
     */
    static Title($value) {
        this.init();
        this.title = Property.String(this.title, $value);
        if (!ObjectValidator.IsEmptyOrNull($value) && this.isPrinted) {
            document.title = this.title;
        }
        return this.title;
    }
    /**
     * @param {string} [$value] Specify license text.
     * @returns {string} Returns license text.
     */
    static License($value) {
        this.init();
        return this.license = Property.String(this.license, $value);
    }
    /**
     * @param {string} [$value] Specify source path for favicon.
     * @returns {string} Returns source path for favicon.
     */
    static FaviconSource($value) {
        this.init();
        this.faviconSource = Property.String(this.faviconSource, $value);
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.links.foreach(($link) => {
                if ($link.rel === "icon" || $link.rel === "shortcut icon") {
                    let faviconSource = this.faviconSource;
                    if (!StringUtils.Contains(faviconSource, "?")) {
                        faviconSource += "?v=" + Loader.getInstance().getEnvironmentArgs().getProjectConfig().build.timestamp;
                    }
                    $link.href = faviconSource;
                    return false;
                }
                return true;
            });
        }
        return this.faviconSource;
    }
    /**
     * @param {string} [$value] Specify page encoding.
     * @returns {string} Returns page encoding.
     */
    static Charset($value) {
        this.init();
        this.charset = Property.String(this.charset, $value);
        return this.charset;
    }
    static Nonce($value) {
        return this.nonce = Property.String(this.nonce, $value);
    }
    /**
     * @param {boolean} [$value] Specify is body events should be statically defined or not.
     * @returns {boolean} Returns true if body events are statically included otherwise false.
     */
    static BodyEventsEnabled($value) {
        return this.withBodyEvents = Property.Boolean(this.withBodyEvents, $value);
    }
    /**
     * @param {string|HTMLLinkElement} $value String or link element value,
     * which should be appended to the page head at links position.
     * @param {string} [$rel] Set rel value, if link has been specified as string.
     * @param {string} [$type] Set type value, if link has been specified as string.
     * @returns {HTMLLinkElement} Returns created instance of HTMLLinkElement.
     */
    static HeadLinkAppend($value, $rel, $type) {
        let link;
        if (ObjectValidator.IsObject($value)) {
            link = $value;
        }
        else if (ObjectValidator.IsString($value)) {
            link = document.createElement("link");
            link.href = $value;
            link.rel = "stylesheet";
            link.type = "text/css";
            if (ObjectValidator.IsSet($rel)) {
                link.rel = $rel;
            }
            if (ObjectValidator.IsSet($type)) {
                link.rel = $type;
            }
        }
        if (ObjectValidator.IsSet(link)) {
            link.nonce = "";
            const key = StringUtils.getSha1(link.outerHTML);
            link.nonce = this.nonce;
            if (!this.links.KeyExists(key)) {
                this.links.Add(link, key);
                if (this.isPrinted) {
                    window.document.body.appendChild(link);
                }
            }
        }
        return link;
    }
    /**
     * @returns {ArrayList<HTMLLinkElement>} Returns list of registered link tags.
     */
    static getHeadLinks() {
        return this.links;
    }
    /**
     * @param {string|HTMLMetaElement} $value String or metatag element value,
     * which should be appended to the page head at metatags position.
     * @param {string} [$httpEquiv] Set http-equiv value, if tag has been specified as string.
     * @returns {void}
     */
    static HeadMetaDataAppend($value, $httpEquiv) {
        let meta;
        if (ObjectValidator.IsObject($value)) {
            meta = $value;
        }
        else if (ObjectValidator.IsString($value)) {
            meta = document.createElement("meta");
            meta.content = $value;
            if (ObjectValidator.IsSet($httpEquiv)) {
                meta.httpEquiv = "Content-Type";
            }
        }
        if (ObjectValidator.IsSet(meta)) {
            const key = StringUtils.getSha1(meta.outerHTML);
            if (!this.metaTags.KeyExists(key)) {
                this.metaTags.Add(meta, key);
                if (this.isPrinted) {
                    window.document.body.appendChild(meta);
                }
            }
        }
    }
    /**
     * @returns {ArrayList<HTMLMetaElement>} Returns list of registered meta tags.
     */
    static getHeadMetaData() {
        return this.metaTags;
    }
    /**
     * @param {string|HTMLScriptElement} $value String or script element value,
     * which should be appended to the page head at scripts position.
     * @param {string} [$type] Set type value, if script has been specified as string.
     * @returns {void}
     */
    static HeadScriptAppend($value, $type) {
        let script;
        if (ObjectValidator.IsObject($value)) {
            script = $value;
        }
        else if (ObjectValidator.IsString($value)) {
            script = document.createElement("script");
            script.src = $value;
            if (ObjectValidator.IsSet($type)) {
                script.type = $type;
            }
        }
        if (ObjectValidator.IsSet(script)) {
            script.nonce = "";
            const key = StringUtils.getSha1(script.outerHTML);
            script.nonce = this.nonce;
            if (!this.scripts.KeyExists(key)) {
                this.scripts.Add(script, key);
                if (this.isPrinted) {
                    window.document.body.appendChild(script);
                }
            }
        }
    }
    /**
     * @returns {ArrayList<HTMLScriptElement>} Returns list of registered script tags.
     */
    static getHeadScripts() {
        return this.scripts;
    }
    /**
     * @param {string} $value String value, which should be appended to the page body.
     * @returns {void}
     */
    static BodyAppend($value) {
        this.body = this.htmlAppend(this.body, $value);
        if (this.isPrinted) {
            ElementManager.AppendHtml("Content", $value);
        }
    }
    /**
     * @returns {string} Returns page body content in string format.
     */
    static getBody() {
        this.init();
        return this.body;
    }
    /**
     * Clean up page content
     * @param {boolean} [$force=false] Specify, if all data including header tags should be cleaned up.
     * @returns {void}
     */
    static Clear($force = false) {
        try {
            document.documentElement.innerHTML = "";
        }
        catch (ex) {
            document.body.innerHTML = "";
        }
        this.faviconSource = "";
        this.isInitialized = false;
        this.init($force);
    }
    /**
     * @returns {string} Returns whole page content buffer in string format.
     */
    static ToString() {
        this.init();
        let events = "";
        if (this.withBodyEvents) {
            events = " " +
                "onfocus=\"Io.Oidis.Gui.Events.EventsManager.bodyFocusEventHandler();\" " +
                "onblur=\"Io.Oidis.Gui.Events.EventsManager.bodyBlurEventHandler();\">";
        }
        return "" +
            "<!DOCTYPE html>\n" +
            this.license + "\n" +
            "<html lang=\"" + StringUtils.ToLowerCase(this.language) + "\" data-bs-theme=\"light\">\n" +
            "<head>\n" +
            this.getDocumentHead() +
            "</head>\n" +
            "\n" +
            "<body" + events + ">\n" +
            this.getDocumentBody() +
            "</body>\n" +
            "</html>";
    }
    /**
     * Override current page content by new page content buffer.
     * @returns {void}
     */
    static Draw() {
        if (ObjectValidator.IsSet(window)) {
            this.init();
            try {
                document.documentElement.innerHTML = this.ToString();
            }
            catch (ex) {
                if (ObjectValidator.IsSet(document.head)) {
                    this.removeFromHead(document.head.getElementsByTagName("meta"));
                    this.removeFromHead(document.head.getElementsByTagName("link"));
                    this.removeFromHead(document.head.getElementsByTagName("script"));
                    this.appendToHead(this.metaTags);
                    this.appendToHead(this.links);
                    this.appendToHead(this.scripts);
                }
                else {
                    document.title = this.title;
                }
                document.body.innerHTML = this.getDocumentBody();
            }
            const stream = Echo.getStream();
            Echo.Init("Content", true);
            if (!ObjectValidator.IsEmptyOrNull(stream)) {
                Echo.Print(stream);
            }
            this.isPrinted = true;
        }
    }
    static init($force = false) {
        if (!this.isInitialized) {
            this.charset = "UTF-8";
            this.title = Loader.getInstance().getHttpManager().getRequest().getUrl();
            this.license = "";
            this.browserType = Loader.getInstance().getHttpManager().getRequest().getBrowserType();
            this.language = LanguageType.EN;
            if (ObjectValidator.IsEmptyOrNull(this.faviconSource)) {
                this.faviconSource = "resource/graphics/icon.ico";
            }
            if ($force || ObjectValidator.IsEmptyOrNull(this.links)) {
                let packageName = Loader.getInstance().getEnvironmentArgs().getProjectName() + "-" +
                    Loader.getInstance().getEnvironmentArgs().getProjectVersion();
                packageName = StringUtils.Replace(packageName, ".", "-");
                const buildTime = Loader.getInstance().getEnvironmentArgs().getProjectConfig().build.timestamp;
                this.links = new ArrayList();
                let faviconSource = this.faviconSource;
                if (!StringUtils.Contains(faviconSource, "?")) {
                    faviconSource += "?v=" + buildTime;
                }
                this.HeadLinkAppend(faviconSource, "shortcut icon");
                this.HeadLinkAppend("resource/libs/Bootstrap/bootstrap.min.css?v=" + buildTime);
                this.HeadLinkAppend("resource/css/" + packageName + ".min.css?v=" + buildTime);
                this.scripts = new ArrayList();
                this.metaTags = new ArrayList();
                this.HeadMetaDataAppend("text/html; charset=" + this.charset, "Content-Type");
            }
            this.body = "";
            this.isPrinted = false;
            this.isInitialized = true;
        }
    }
    static htmlAppend($type, $value) {
        this.init();
        if (!ObjectValidator.IsSet($type)) {
            $type = "";
        }
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            $type += $value + "\n";
        }
        return $type;
    }
    static getDocumentHead() {
        let metaTags = "";
        this.metaTags.foreach(($element) => {
            metaTags += $element.outerHTML + "\n";
        });
        if (!ObjectValidator.IsEmptyOrNull(metaTags)) {
            metaTags += "\n";
        }
        let links = "";
        this.links.foreach(($element) => {
            links += $element.outerHTML + "\n";
        });
        if (!ObjectValidator.IsEmptyOrNull(links)) {
            links += "\n";
        }
        let scripts = "";
        this.scripts.foreach(($element) => {
            scripts += $element.outerHTML + "\n";
        });
        return "<title>" + this.title + "</title>\n\n" +
            metaTags +
            links +
            scripts;
    }
    static getDocumentBody() {
        return "" +
            "<div id=\"Browser\" class=\"" + BrowserType[this.browserType] + "\">\n" +
            "<div id=\"Language\" class=\"" + this.language + "\">\n" +
            "<div id=\"Content\" class=\"Content\" guiType=\"PageContent\">\n" +
            this.body + "\n" +
            "</div>\n" +
            "</div>\n" +
            "</div>\n";
    }
    static removeFromHead($elements) {
        let index;
        for (index = $elements.length; index >= 0; index--) {
            if (ObjectValidator.IsSet($elements[index])) {
                $elements[index].parentNode.removeChild($elements[index]);
            }
        }
    }
    static appendToHead($elements) {
        $elements.foreach(($element) => {
            document.head.appendChild($element);
            document.head.appendChild(document.createTextNode("\n"));
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Utils.StaticPageContentManager", StaticPageContentManager);
//# sourceMappingURL=StaticPageContentManager.js.map