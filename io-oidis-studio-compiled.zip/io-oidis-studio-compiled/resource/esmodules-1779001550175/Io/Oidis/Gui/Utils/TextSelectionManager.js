/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ElementManager } from "./ElementManager.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
/**
 * TextSelectionManager class provides static methods focused on handling of selected text.
 */
export class TextSelectionManager extends BaseObject {
    /**
     * Select all text in desired HTML input element.
     * @param {string|HTMLElement|HTMLInputElement} $input HTML element, which should be handled.
     * @returns {void}
     */
    static SelectAll($input) {
        if (ObjectValidator.IsString($input)) {
            $input = ElementManager.getElement($input);
        }
        if (!ObjectValidator.IsEmptyOrNull($input)) {
            if (ObjectValidator.IsSet($input.setSelectionRange)) {
                $input.setSelectionRange(0, StringUtils.Length($input.value));
            }
            else if (ObjectValidator.IsSet(document.selection)) {
                const selectionRange = document.body.createTextRange();
                selectionRange.moveToElementText($input);
                selectionRange.select();
            }
            else if (ObjectValidator.IsSet(window.getSelection)) {
                const windowRange = document.createRange();
                windowRange.selectNodeContents($input);
                window.getSelection().removeAllRanges();
                window.getSelection().addRange(windowRange);
            }
        }
    }
    /**
     * @param {HTMLInputElement} [$input] HTML input element, which should be handled.
     * Element id should be provided, if browser does not supports document.selection.
     * @returns {string} Returns currently selected string.
     */
    static getSelectedText($input) {
        let output = "";
        if (!ObjectValidator.IsEmptyOrNull($input)) {
            if (ObjectValidator.IsSet($input.selectionStart) && $input.selectionStart !== $input.selectionEnd) {
                output = ($input.value + "").substring($input.selectionStart, $input.selectionEnd);
            }
        }
        else if (ObjectValidator.IsSet(window.getSelection)) {
            output = window.getSelection().toString();
        }
        else if (ObjectValidator.IsSet(document.selection) && document.selection.type !== "None") {
            output = document.selection.createRange().text;
        }
        return output;
    }
    /**
     * @param {HTMLInputElement} [$input] HTML input element, which should be handled.
     * Element id should be provided, if browser does not supports document.selection.
     * @returns {number} Returns positive integer of current cursor position, if cursor has been initialized,
     * otherwise -1.
     */
    static getCurrentPosition($input) {
        let position = -1;
        if (ObjectValidator.IsSet(document.selection)) {
            const range = document.selection.createRange();
            const bookmark = range.getBookmark();
            position = StringUtils.getCodeAt(bookmark, 2) - 2;
        }
        else if (ObjectValidator.IsSet($input.setSelectionRange)) {
            position = $input.selectionStart;
        }
        return position;
    }
    /**
     * @param {HTMLInputElement} $input HTML input element, which should be handled.
     * Element id should be provided, if browser does not supports document.selection.
     * @param {number} $position Specify new cursor position.
     * @returns {void}
     */
    static setCurrentPosition($input, $position) {
        if (ObjectValidator.IsSet($input.setSelectionRange)) {
            $input.setSelectionRange($position, $position);
        }
        else if (ObjectValidator.IsSet($input.createTextRange)) {
            const range = $input.createTextRange();
            range.move("character", $position);
            range.select();
        }
        else {
            $input.focus();
        }
    }
    /**
     * @param {string} $value Specify text value, which should be pasted after current position.
     * @returns {void}
     */
    static PasteTextAtCurrentPosition($value) {
        if (ObjectValidator.IsSet(window.getSelection)) {
            const sel = window.getSelection();
            if (sel.getRangeAt && sel.rangeCount) {
                let range = sel.getRangeAt(0);
                range.deleteContents();
                const textNode = document.createTextNode($value);
                range.insertNode(textNode);
                range = range.cloneRange();
                range.setStartAfter(textNode);
                range.collapse(true);
                sel.removeAllRanges();
                sel.addRange(range);
            }
        }
        else if (ObjectValidator.IsSet(document.selection) && document.selection.type !== "Control") {
            document.selection.createRange().text = $value;
        }
    }
    /**
     * @param {HTMLInputElement} [$input] HTML input element, which should be handled.
     * @returns {boolean} Returns true, if selected text has been cleaned up, otherwise false.
     */
    static Clear($input) {
        if (ObjectValidator.IsSet($input)) {
            const selected = this.getSelectedText($input);
            if (!ObjectValidator.IsEmptyOrNull(selected)) {
                const position = this.getCurrentPosition($input);
                $input.value = StringUtils.Remove($input.value, selected);
                if (ObjectValidator.IsSet($input.createTextRange)) {
                    const range = $input.createTextRange();
                    range.move("character", position);
                    range.select();
                }
                else if (ObjectValidator.IsSet($input.selectionStart)) {
                    $input.focus();
                    $input.setSelectionRange(position, position);
                }
                else {
                    $input.focus();
                }
                return true;
            }
        }
        else {
            if (ObjectValidator.IsSet(window.getSelection)) {
                window.getSelection().removeAllRanges();
                return true;
            }
            else if (ObjectValidator.IsSet(document.selection)) {
                document.selection.empty();
                return true;
            }
        }
        return false;
    }
    /**
     * Handle user text selection on whole document or specific element
     * @param {HTMLElement} $value Specify if text selection should be disabled.
     * @param {HTMLElement} [$element] HTML element, which should be handled.
     * @returns {void}
     */
    static Disable($value, $element) {
        if (ObjectValidator.IsEmptyOrNull($element)) {
            $element = document.body;
        }
        [
            "user-select",
            "-o-user-select",
            "-moz-user-select",
            "-khtml-user-select",
            "-webkit-user-select",
            "-ms-user-select"
        ].forEach(($key) => {
            if ($value) {
                ElementManager.setCssProperty($element, $key, "none");
            }
            else {
                ElementManager.ClearCssProperty($element, $key);
            }
        });
        if ($value) {
            $element.setAttribute("unselectable", "on");
        }
        else {
            $element.setAttribute("unselectable", "off");
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Utils.TextSelectionManager", TextSelectionManager);
//# sourceMappingURL=TextSelectionManager.js.map