/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "./../../../../Io/Oidis/Commons/Enums/Events/EventType.js";
import { ThreadPool } from "./../../../../Io/Oidis/Commons/Events/ThreadPool.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { DirectionType } from "../Enums/DirectionType.js";
import { ProgressType } from "../Enums/ProgressType.js";
import { UnitType } from "../Enums/UnitType.js";
import { AnimationThreadPool } from "../Events/AnimationThreadPool.js";
import { ValueProgressEventArgs } from "../Events/Args/ValueProgressEventArgs.js";
import { EventsManager } from "../Events/EventsManager.js";
/**
 * ValueProgressManager class provides asynchronous change of number value with warious progress types.
 */
export class ValueProgressManager extends BaseObject {
    static eventArgsList;
    static timeStep = 10;
    /**
     * @param {ValueProgressEventArgs} $args Set progress event args, which should be processed and
     * provided by ValueProgressManager events.
     * @returns {void}
     */
    static Execute($args) {
        if ($args.RangeStart() !== $args.RangeEnd()) {
            const threadPool = ValueProgressManager.getThreadPool();
            if (!ValueProgressManager.Exists($args.OwnerId())) {
                ValueProgressManager.eventArgsList.Add($args, $args.OwnerId());
            }
            EventsManager.getInstanceSingleton().FireEvent($args.OwnerId(), $args.StartEventType(), $args);
            $args.TimeStamp(ValueProgressManager.getTimeStamp());
            threadPool
                .AddThread($args.OwnerId(), EventType.ON_CHANGE + "_Value", ValueProgressManager.handler, $args);
            threadPool.Execute();
        }
    }
    /**
     * @param {string} $id Set manager id, which should be removed from processing thread.
     * @returns {void}
     */
    static Remove($id) {
        ValueProgressManager.getThreadPool().RemoveThread($id, EventType.ON_CHANGE + "_Value");
    }
    /**
     * @param {string} $id Manager id, which should be validated.
     * @returns {boolean} Returns true, if ValueProgressManager has been registered, otherwise false.
     */
    static Exists($id) {
        if (!ObjectValidator.IsSet(ValueProgressManager.eventArgsList)) {
            ValueProgressManager.eventArgsList = new ArrayList();
        }
        return ValueProgressManager.eventArgsList.KeyExists($id);
    }
    /**
     * @param {string} $id Manager id, which should be get from value progress managers register.
     * @returns {ValueProgressEventArgs} Returns managers args associated with manager id.
     * If managers has not been found, this method will automatically register new manager with desired id.
     */
    static get($id) {
        if (!ValueProgressManager.Exists($id)) {
            ValueProgressManager.eventArgsList.Add(new ValueProgressEventArgs($id), $id);
        }
        return ValueProgressManager.eventArgsList.getItem($id);
    }
    /**
     * @param {number} $pct Specify percentage value, which should be converted to time value.
     * @param {ProgressType} $functionType Specify progress function type, which should be used for conversion.
     * @returns {number} Returns time value calculated from percentage value based on inverse progress function type.
     */
    static getTimeFromPct($pct, $functionType) {
        switch ($functionType) {
            case ProgressType.LINEAR:
                return ValueProgressManager.getPctFromTime($pct, $functionType);
            case ProgressType.FAST_START:
                return ValueProgressManager.getPctFromTime($pct, ProgressType.SLOW_START);
            case ProgressType.SLOW_START:
                return ValueProgressManager.getPctFromTime($pct, ProgressType.FAST_START);
            case ProgressType.FAST_END:
                return ValueProgressManager.getPctFromTime($pct, ProgressType.SLOW_END);
            case ProgressType.SLOW_END:
                return ValueProgressManager.getPctFromTime($pct, ProgressType.FAST_END);
            case ProgressType.FAST_TAILS:
                return ValueProgressManager.getPctFromTime($pct, ProgressType.SLOW_TAILS);
            case ProgressType.SLOW_TAILS:
                return ValueProgressManager.getPctFromTime($pct, ProgressType.FAST_TAILS);
            default:
                return 0;
        }
    }
    /**
     * @param {number} $time Specify time value in range <0;1>, which should be converted to percentage value.
     * @param {ProgressType} $functionType Specify progress function type, which should be used for conversion.
     * @returns {number} Returns percentage value calculated from time value based on progress function type.
     */
    static getPctFromTime($time, $functionType) {
        switch ($functionType) {
            case ProgressType.LINEAR:
                return $time;
            case ProgressType.FAST_START:
                return Math.sqrt($time);
            case ProgressType.SLOW_START:
                return $time * $time;
            case ProgressType.FAST_END:
                return 1 - Math.sqrt(-$time + 1);
            case ProgressType.SLOW_END:
                return $time * (2 - $time);
            case ProgressType.FAST_TAILS:
                return $time < 0.5 ?
                    Math.sqrt($time / 2) :
                    -((-4 + Math.sqrt(-8 * $time + 8)) / 4);
            case ProgressType.SLOW_TAILS:
                return $time < 0.5 ?
                    (2 * $time * $time) :
                    (-1 + (4 - 2 * $time) * $time);
            default:
                return 0;
        }
    }
    static handler($eventArgs) {
        const threadPool = ValueProgressManager.getThreadPool();
        $eventArgs.FloatValue(ValueProgressManager.getValue($eventArgs));
        $eventArgs.TimeStamp(ValueProgressManager.getTimeStamp());
        const isComplete = ($eventArgs.FloatValue() <= Math.min($eventArgs.RangeStart(), $eventArgs.RangeEnd()) &&
            $eventArgs.DirectionType() === DirectionType.DOWN) ||
            ($eventArgs.FloatValue() >= Math.max($eventArgs.RangeStart(), $eventArgs.RangeEnd()) &&
                $eventArgs.DirectionType() === DirectionType.UP);
        if (isComplete) {
            $eventArgs.FloatValue($eventArgs.CurrentValue());
        }
        threadPool.setThreadArgs($eventArgs.OwnerId(), EventType.ON_CHANGE + "_Value", $eventArgs);
        EventsManager.getInstanceSingleton()
            .FireEvent($eventArgs.OwnerId(), $eventArgs.ChangeEventType(), $eventArgs, false);
        if (isComplete) {
            threadPool.RemoveThread($eventArgs.OwnerId(), EventType.ON_CHANGE + "_Value");
            EventsManager.getInstanceSingleton()
                .FireEvent($eventArgs.OwnerId(), $eventArgs.CompleteEventType(), $eventArgs, false);
        }
    }
    static getValue($eventArgs) {
        const minValue = Math.min($eventArgs.RangeStart(), $eventArgs.RangeEnd());
        const maxValue = Math.max($eventArgs.RangeStart(), $eventArgs.RangeEnd());
        const range = maxValue - minValue;
        const targetAnimTime = ($eventArgs.StepUnitType() === UnitType.PCT ?
            100 / $eventArgs.Step() : range / $eventArgs.Step()) * ValueProgressManager.timeStep;
        const timeStamp = ValueProgressManager.getTimeStamp();
        const frameTime = (timeStamp - $eventArgs.TimeStamp()) / targetAnimTime;
        const valuePct = ($eventArgs.FloatValue() - minValue) / range;
        const currentAnimTime = ValueProgressManager.getTimeFromPct($eventArgs.DirectionType() === DirectionType.UP ?
            valuePct : (1 - valuePct), $eventArgs.ProgressType());
        const unitTime = Math.min(1, currentAnimTime + frameTime);
        const animPct = ValueProgressManager.getPctFromTime(unitTime, $eventArgs.ProgressType());
        return minValue + ($eventArgs.DirectionType() === DirectionType.UP ? animPct : 1 - animPct) * range;
    }
    static getTimeStamp() {
        if (ObjectValidator.IsSet(window.performance)) {
            ValueProgressManager.getTimeStamp = () => {
                return window.performance.now();
            };
            return window.performance.now();
        }
        ValueProgressManager.getTimeStamp = () => {
            return new Date().getTime();
        };
        return new Date().getTime();
    }
    static getThreadPool() {
        const threadPool = ObjectValidator.IsSet(window.requestAnimationFrame) ? AnimationThreadPool : ThreadPool;
        ValueProgressManager.getThreadPool = () => {
            return threadPool;
        };
        return threadPool;
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.Utils.ValueProgressManager", ValueProgressManager);
//# sourceMappingURL=ValueProgressManager.js.map