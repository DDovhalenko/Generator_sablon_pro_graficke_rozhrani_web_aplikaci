/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { TimeoutManager } from "./../../../Io/Oidis/Commons/Events/TimeoutManager.js";
import { ExceptionsManager } from "./../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { BasePersistenceHandler } from "./../../../Io/Oidis/Commons/PersistenceApi/Handlers/BasePersistenceHandler.js";
import { PersistenceFactory } from "./../../../Io/Oidis/Commons/PersistenceApi/PersistenceFactory.js";
import { ArrayList } from "./../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { BaseObject } from "./../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { Convert } from "./../../../Io/Oidis/Commons/Utils/Convert.js";
import { LogIt } from "./../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Reflection } from "./../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { EventType } from "./Enums/Events/EventType.js";
import { ElementEventsManager } from "./Events/ElementEventsManager.js";
import { EventsManager } from "./Events/EventsManager.js";
import { GuiObjectManager } from "./GuiObjectManager.js";
import { Loader } from "./Loader.js";
import { BaseViewer } from "./Primitives/BaseViewer.js";
import { GuiCommons } from "./Primitives/GuiCommons.js";
import { Size } from "./Structures/Size.js";
import { ElementManager } from "./Utils/ElementManager.js";
import { WindowManager } from "./Utils/WindowManager.js";
import { ViewerManager } from "./ViewerManager.js";
/**
 * ViewerCacheManager class provides creation and loading of viewer's cache.
 */
export class ViewerCacheManager extends BaseObject {
    storage;
    htmlCache;
    jsCache;
    cacheFilePath;
    viewerInstance;
    isLoaded;
    /**
     * Content should be replaced by cache execution
     * @returns {BaseViewer} Returns instance of BaseViewer which has been resolved from cache
     */
    static getViewerInstance() {
        return null;
    }
    /**
     * Content should be replaced by cache execution
     * @returns {IGuiCommons[]} Returns list of cached elements
     */
    static getCachedElements() {
        return [];
    }
    /**
     * Content should be replaced by cache execution
     * @returns {number} Returns current events count.
     */
    static getProgressEventsCount() {
        return 0;
    }
    /**
     * @param {string} $viewerManagerId Specify viewer's manager id, by which is viewer handled.
     * @param {string} [$cacheFilePath] Specify file path, which should be used for store and load of raw cache data.
     */
    constructor($viewerManagerId, $cacheFilePath) {
        super();
        this.storage = PersistenceFactory.getPersistence($viewerManagerId);
        this.storage.DisableCRC();
        this.cacheFilePath = $cacheFilePath;
        this.htmlCache = "";
        this.jsCache = "";
        this.isLoaded = false;
    }
    /**
     * @param {BaseViewer} $value Specify viewer instance, which should be manged by cache manager.
     * @returns {void}
     */
    setViewerInstance($value) {
        this.viewerInstance = $value;
    }
    /**
     * Load cache data from desired source, but do not provide instantiation of cached viewer.
     * @param {Callback} [$successHandler] Handler, which should be called on successfully loaded cache.
     * @param {Callback} [$errorHandler] Handler, which should be called on cache loading error.
     * @returns {void}
     */
    Load($successHandler, $errorHandler) {
        this.storage.LoadPersistenceAsynchronously(() => {
            this.isLoaded = true;
            if (this.storage.Exists("HTML") && this.storage.Exists("JS")) {
                this.htmlCache = this.storage.Variable("HTML");
                this.jsCache = this.storage.Variable("JS");
                if (ObjectValidator.IsSet($successHandler)) {
                    $successHandler();
                }
            }
            else {
                if (ObjectValidator.IsSet($errorHandler)) {
                    $errorHandler();
                }
            }
        }, this.cacheFilePath);
    }
    /**
     * Create cache from viewer handled by the manager.
     * @param {Callback} [$handler] Handler, which should be called after successfully created cache.
     * @returns {void}
     */
    Create($handler) {
        this.htmlCache = this.getHtmlCode();
        this.getJsCode(($code) => {
            this.jsCache = $code;
            if (ObjectValidator.IsSet($handler)) {
                $handler();
            }
        });
    }
    /**
     * Load cache data and prepare viewer instance.
     * @param {Callback} [$handler] Handler, which should be called after successfully instantiation of cached viewer.
     * @returns {void}
     */
    Process($handler) {
        const events = EventsManager.getInstanceSingleton();
        const loadViewerCache = () => {
            const progressBar = document.createElement("div");
            progressBar.id = "CacheLoadProgress";
            progressBar.className = "CacheLoaderProgressBar";
            document.getElementById("Content").appendChild(progressBar);
            const pageWidth = Loader.getInstance().getHttpManager().getRequest().IsJre(true) ?
                new Size("Browser", true).Width() : WindowManager.getSize().Width();
            let progressScale = 0;
            let progressTick = 0;
            events.setEvent(ViewerCacheManager.ClassName(), EventType.ON_CHANGE, () => {
                const progressBarWidth = Math.round(progressScale * progressTick) -
                    ElementManager.getCssIntegerValue(progressBar.id, "left") * 2;
                progressTick++;
                ElementManager.setWidth(progressBar.id, progressBarWidth);
            });
            const script = document.createElement("script");
            events.setEvent(ViewerCacheManager.ClassName(), EventType.ON_COMPLETE, () => {
                ElementManager.setWidth(progressBar.id, pageWidth - ElementManager.getCssIntegerValue(progressBar.id, "left") * 2);
                this.viewerInstance = ViewerCacheManager.getViewerInstance();
                if (!ObjectValidator.IsEmptyOrNull(script.parentNode)) {
                    script.parentNode.removeChild(script);
                }
                if (ObjectValidator.IsSet($handler)) {
                    $handler(this.viewerInstance, ViewerCacheManager.getCachedElements());
                }
                document.body.style.cursor = "default";
                if (!ObjectValidator.IsEmptyOrNull(progressBar.parentNode)) {
                    progressBar.parentNode.removeChild(progressBar);
                }
            });
            document.body.style.cursor = "wait";
            events.FireAsynchronousMethod(() => {
                script.type = "text/javascript";
                script.text = this.jsCache;
                if (!ObjectValidator.IsEmptyOrNull(globalThis.nonce)) {
                    script.nonce = globalThis.nonce;
                }
                document.body.appendChild(script);
                progressScale = pageWidth / ViewerCacheManager.getProgressEventsCount();
            }, 100);
        };
        if (!this.isLoaded) {
            this.Load(loadViewerCache);
        }
        else {
            loadViewerCache();
        }
    }
    /**
     * Try to save created cache data to the desired cache storage.
     * @param {Callback} [$handler] Handler, which should be called after try to save the cache.
     * @returns {void}
     */
    Store($handler) {
        this.storage.LoadPersistenceAsynchronously(() => {
            try {
                this.storage.Variable("HTML", this.htmlCache);
                this.storage.Variable("JS", this.jsCache);
            }
            catch (ex) {
                LogIt.Error("Viewer cache has not been stored correctly", ex);
            }
            if (ObjectValidator.IsSet($handler)) {
                $handler();
            }
        });
    }
    /**
     * Clean up cache data from cache storage.
     * @returns {void}
     */
    Clear() {
        this.storage.Clear();
    }
    /**
     * @returns {string} Returns HTML output provided by the cache, if the cache has been loaded successfully, otherwise empty string.
     */
    Show() {
        return this.htmlCache;
    }
    /**
     * Provides raw cache data in format specified by the cache storage.
     * It can also provides saving of the cache for ability to read it's raw data.
     * @param {Callback} $handler Handler, which should be called when the cache data are ready.
     * @returns {void}
     */
    getRawData($handler) {
        if (!this.isLoaded) {
            this.Load(() => {
                this.storage.getRawData($handler);
            });
        }
        else {
            this.Store(() => {
                this.storage.getRawData($handler);
            });
        }
    }
    /**
     * @param {string} [$prefix=""] Specify prefix, which should be used for each line of output.
     * @param {boolean} [$htmlTag=true] Specify, if output should contain HTML tags.
     * @returns {string} Returns string representation of cache status including HTML and JavaScript cache sizes.
     */
    ToString($prefix = "", $htmlTag = true) {
        /* dev:start */
        let output = "";
        if (!ObjectValidator.IsEmptyOrNull(this.cacheFilePath)) {
            output += "Cache file path: " + this.cacheFilePath + StringUtils.NewLine($htmlTag);
        }
        let cacheReport = "";
        if (!ObjectValidator.IsEmptyOrNull(this.htmlCache) && !ObjectValidator.IsEmptyOrNull(this.jsCache)) {
            cacheReport +=
                "HTML cache size: " + (StringUtils.Length(this.htmlCache) / 1000) + " KB" + StringUtils.NewLine() +
                    "JavaScript cache size: " + (StringUtils.Length(this.jsCache) / 1000) + " KB";
            if ($htmlTag) {
                let html = StringUtils.Replace(this.htmlCache, "<", "&lt;");
                html = StringUtils.Replace(html, ">", "&gt;");
                let js = StringUtils.Replace(this.jsCache, ";", ";" + StringUtils.NewLine(false));
                js = StringUtils.Replace(js, ",", "," + StringUtils.NewLine(false));
                js = StringUtils.Replace(js, "{", "{" + StringUtils.NewLine(false));
                js = StringUtils.Replace(js, "}", "}" + StringUtils.NewLine(false));
                js = StringUtils.Replace(js, "}" + StringUtils.NewLine(false) + ")", "})");
                js = StringUtils.Replace(js, "}" + StringUtils.NewLine(false) + ";", "};");
                js = StringUtils.Replace(js, "," + StringUtils.NewLine(false) + "\"", ",\"");
                js = StringUtils.Replace(js, "," + StringUtils.NewLine(false) + "false", ",false");
                js = StringUtils.Replace(js, "}" + StringUtils.NewLine(false) + ",\"", "}," + StringUtils.NewLine(false) + "\"");
                js = StringUtils.Replace(js, "\",\"", "\"," + StringUtils.NewLine(false) + "\"");
                js = StringUtils.Replace(js, ",\"progressEventsCount\"", "," + StringUtils.NewLine(false) + "\"progressEventsCount\"");
                js = StringUtils.Replace(js, ",\"Load\"", "," + StringUtils.NewLine(false) + "\"Load\"");
                js = StringUtils.Replace(js, "<", "&lt;");
                js = StringUtils.Replace(js, ">", "&gt;");
                cacheReport +=
                    "<hr>HTML<hr>" +
                        "<pre>" + html + "</pre>" +
                        "<hr>JavaScript<hr>" +
                        "<pre>" + js + "</pre>";
            }
        }
        if (ObjectValidator.IsEmptyOrNull(cacheReport)) {
            output += "Cache status: EMPTY";
        }
        else {
            output += "Cache status: GENERATED" + StringUtils.NewLine($htmlTag) + cacheReport;
        }
        return output;
        /* dev:end */
    }
    getHtmlCode() {
        /* dev:start */
        const manager = GuiObjectManager.getInstanceSingleton();
        const resetItems = new ArrayList();
        const excludeViewers = [];
        ViewerManager.getLoadedViewers().foreach(($viewer) => {
            if ($viewer !== this.viewerInstance) {
                if (!ObjectValidator.IsEmptyOrNull($viewer.getInstance())) {
                    excludeViewers.push($viewer.getInstance().Id());
                }
            }
        });
        manager.getAll().foreach(($element) => {
            $element.beforeCacheCreation(($id, $value) => {
                resetItems.Add({ element: $element, id: $id, value: $value });
            });
        });
        let pageContent = document.createElement("span");
        pageContent.innerHTML = document.body.innerHTML;
        resetItems.foreach(($item) => {
            $item.element.afterCacheCreation($item.id, $item.value);
        });
        let nodes;
        let index;
        let child;
        let attributeValue;
        const attributeKey = "guitype";
        nodes = pageContent.getElementsByTagName("div");
        for (index = 0; index < nodes.length; index++) {
            child = nodes[index];
            if (child.nodeType === 1 && ObjectValidator.IsSet(child.attributes[attributeKey])) {
                attributeValue = ObjectValidator.IsSet(child.attributes[attributeKey].value) ?
                    child.attributes[attributeKey].value : child.attributes[attributeKey].nodeValue;
                if (attributeValue === "DeveloperCorner") {
                    if (!ObjectValidator.IsEmptyOrNull(child.parentNode)) {
                        child.parentNode.removeChild(child);
                    }
                    break;
                }
            }
        }
        for (index = 0; index < nodes.length; index++) {
            child = nodes[index];
            if (child.nodeType === 1 && ObjectValidator.IsSet(child.attributes[attributeKey])) {
                attributeValue = ObjectValidator.IsSet(child.attributes[attributeKey].value) ?
                    child.attributes[attributeKey].value : child.attributes[attributeKey].nodeValue;
                if (attributeValue === "PageContent") {
                    nodes = child.getElementsByTagName("span");
                    break;
                }
            }
        }
        let output = "";
        for (index = 0; index < nodes.length; index++) {
            child = nodes[index];
            if (child.nodeType === 1 && ObjectValidator.IsSet(child.attributes[attributeKey])) {
                attributeValue = ObjectValidator.IsSet(child.attributes[attributeKey].value) ?
                    child.attributes[attributeKey].value : child.attributes[attributeKey].nodeValue;
                if (attributeValue === "HtmlAppender") {
                    let excludeIndex;
                    let exclude = false;
                    for (excludeIndex = 0; excludeIndex < excludeViewers.length; excludeIndex++) {
                        if (StringUtils.Contains(child.innerHTML, excludeViewers[excludeIndex])) {
                            exclude = true;
                            break;
                        }
                    }
                    if (!exclude) {
                        output += child.innerHTML + StringUtils.NewLine(false);
                    }
                }
            }
        }
        output = StringUtils.Remove(output, "<span guitype=\"HtmlAppender\"></span>");
        pageContent = null;
        return output;
        /* dev:end */
    }
    getJsCode($handler) {
        /* dev:start */
        const variableName = "i";
        let asyncManager = new TimeoutManager();
        let classIndex;
        let objectIndex = 0;
        let arrayItemIndex = 0;
        const classMap = [];
        let classMapSize = 0;
        let classes = "";
        let parsedElements = "";
        let parsedObjects = new ArrayList();
        const parsedStrings = new ArrayList();
        let postprocessors = [];
        let postprocessor = "";
        let variablesSubscribe = "";
        const excludeList = [
            "objectClass"
        ];
        let output = "try{" +
            ViewerCacheManager.ClassName() + ".Loader={" +
            "\"" + variableName + "\":null," +
            "\"Load\":function(){" +
            "var a=" + Reflection.ClassName() + "," +
            "b=" + PersistenceFactory.ClassName() + "," +
            "c=" + ElementEventsManager.ClassName() + "," +
            "d=" + GuiObjectManager.ClassName() + ".getInstanceSingleton()," +
            "e=" + EventsManager.ClassName() + ".getInstanceSingleton()," +
            "f=" + EventType.ClassName() + "," +
            "g=\"" + ArrayList.ClassName() + "\"," +
            "h=new " + TimeoutManager.ClassName() + "()," +
            variableName + "=a.getInstanceOf(\"" + this.viewerInstance.getClassName() + "\")," +
            "j=" + StringUtils.ClassName() + "," +
            "eol=j.NewLine(false)," +
            "pc=\"" + ViewerCacheManager.ClassName() + "\"," +
            "ob=[]," +
            "ai=[]," +
            "si=[];";
        output += variableName + ".Show=function(){return \"\";};";
        const events = EventsManager.getInstanceSingleton();
        const cmdLines = new ArrayList();
        const getCode = ($object, $paramName) => {
            asyncManager.Add(($index) => {
                events.FireEvent(ViewerCacheManager.ClassName(), EventType.ON_CHANGE);
                postprocessors[$index] = [];
                objectIndex++;
                cmdLines.Add("ob[" + objectIndex + "]=" + $paramName + ";");
                $paramName = "ob[" + objectIndex + "]";
                parsedObjects.Add($object, $paramName);
                let parameterName;
                let parameterValue;
                let objectExclude = [];
                if (ObjectValidator.IsSet($object.excludeCacheData)) {
                    objectExclude = $object.excludeCacheData();
                }
                for (parameterName in $object) {
                    if ($object.hasOwnProperty(parameterName) &&
                        !excludeList.includes(parameterName) &&
                        !objectExclude.includes(parameterName)) {
                        parameterValue = $object[parameterName];
                        if (!ObjectValidator.IsFunction(parameterValue)) {
                            let cmdLine = "";
                            if (ObjectValidator.IsString(parameterName)) {
                                cmdLine += $paramName + "[\"" + parameterName + "\"]";
                            }
                            else {
                                cmdLine += $paramName + "[\"" + parameterName + "\"]";
                            }
                            if (ObjectValidator.IsClass(parameterValue)) {
                                if (parameterValue.IsMemberOf(BasePersistenceHandler)) {
                                    if (parsedObjects.Contains(parameterValue)) {
                                        cmdLine += "=" + parsedObjects.getKey(parameterValue) + ";";
                                    }
                                    else {
                                        let sessionId = parameterValue.getSessionId();
                                        if (ObjectValidator.IsString(sessionId)) {
                                            sessionId = "\"" + sessionId + "\"";
                                        }
                                        objectIndex++;
                                        parsedObjects.Add(parameterValue, "ob[" + objectIndex + "]");
                                        variablesSubscribe += "ob[" + objectIndex + "]=b.getPersistenceById(" + sessionId + ");";
                                        cmdLine += "=ob[" + objectIndex + "];";
                                    }
                                }
                                else if (parameterValue.IsTypeOf(ElementEventsManager)) {
                                    cmdLine += "=new c(";
                                    const ownerKey = "owner";
                                    const subscriberKey = "subscriber";
                                    if (!ObjectValidator.IsEmptyOrNull(parameterValue[ownerKey])) {
                                        if (parsedObjects.Contains(parameterValue[ownerKey])) {
                                            cmdLine += parsedObjects.getKey(parameterValue[ownerKey]);
                                        }
                                        else {
                                            cmdLine += "\"" + parameterValue[ownerKey] + "\"";
                                        }
                                        if (!ObjectValidator.IsEmptyOrNull(parameterValue[subscriberKey])) {
                                            cmdLine += ",\"" + parameterValue[subscriberKey] + "\"";
                                        }
                                    }
                                    cmdLine += ");";
                                }
                                else {
                                    if (parsedObjects.Contains(parameterValue)) {
                                        cmdLine += "=" + parsedObjects.getKey(parameterValue) + ";";
                                    }
                                    else {
                                        if (parameterValue.IsTypeOf(ArrayList)) {
                                            cmdLine += "=a.getInstanceOf(g);";
                                        }
                                        else {
                                            classIndex = classMap.indexOf(parameterValue.getClassName());
                                            if (classIndex === -1) {
                                                classIndex = classMapSize;
                                                classMap[classMapSize] = parameterValue.getClassName();
                                                classMapSize++;
                                                if (!ObjectValidator.IsEmptyOrNull(classes)) {
                                                    classes += ",";
                                                }
                                                classes += "\"" + classMap[classIndex] + "\"";
                                            }
                                            cmdLine += "=a.getInstanceOf(cm[" + classIndex + "]);";
                                        }
                                        getCode(parameterValue, $paramName + "[\"" + parameterName + "\"]");
                                    }
                                }
                            }
                            else {
                                if (!ObjectValidator.IsSet(parameterValue)) {
                                    cmdLine += ";";
                                }
                                else {
                                    if (ObjectValidator.IsString(parameterValue)) {
                                        classIndex = classMap.indexOf(parameterValue);
                                        if (classIndex > -1) {
                                            cmdLine += "=cm[" + classIndex + "];";
                                        }
                                        else if (ObjectValidator.IsEmptyOrNull(parameterValue)) {
                                            cmdLine += "=\"\";";
                                        }
                                        else if (parameterName === "outputEndOfLine" ||
                                            (StringUtils.StartsWith(parameterValue, StringUtils.NewLine(false)) &&
                                                ObjectValidator.IsEmptyOrNull(StringUtils.Remove(StringUtils.Remove(parameterValue, StringUtils.NewLine(false)), " ")))) {
                                            cmdLine += "=eol+j.Space(" + StringUtils.OccurrenceCount(parameterValue, " ") + ",false);";
                                        }
                                        else {
                                            let stringVariableName;
                                            if (parsedStrings.KeyExists(parameterValue)) {
                                                stringVariableName = parsedStrings.getItem(parameterValue);
                                            }
                                            else {
                                                stringVariableName = "si[" + parsedStrings.Length() + "]";
                                                parsedStrings.Add(stringVariableName, parameterValue);
                                                variablesSubscribe +=
                                                    stringVariableName + "=decodeURI(\"" + encodeURI(parameterValue) + "\");";
                                            }
                                            cmdLine += "=" + stringVariableName + ";";
                                        }
                                    }
                                    else if (ObjectValidator.IsNativeArray(parameterValue)) {
                                        cmdLine += "=[];";
                                        if (!ObjectValidator.IsEmptyOrNull(parameterValue)) {
                                            if (parameterValue.length > 0) {
                                                postprocessor = "";
                                                let index;
                                                for (index = 0; index < parameterValue.length; index++) {
                                                    const item = parameterValue[index];
                                                    let itemToString = "";
                                                    if (ObjectValidator.IsString(item)) {
                                                        itemToString = "\"" + item + "\"";
                                                    }
                                                    else if (ObjectValidator.IsFunction(item)) {
                                                        itemToString = Convert.FunctionToString(item);
                                                    }
                                                    else if (ObjectValidator.IsClass(item)) {
                                                        arrayItemIndex++;
                                                        itemToString = "ai[" + arrayItemIndex + "]";
                                                        classIndex = classMap.indexOf(item.getClassName());
                                                        if (classIndex === -1) {
                                                            classIndex = classMapSize;
                                                            classMap[classMapSize] = item.getClassName();
                                                            classMapSize++;
                                                            if (!ObjectValidator.IsEmptyOrNull(classes)) {
                                                                classes += ",";
                                                            }
                                                            classes += "\"" + classMap[classIndex] + "\"";
                                                        }
                                                        variablesSubscribe +=
                                                            itemToString + "=a.getInstanceOf(cm[" + classIndex + "]);";
                                                        getCode(item, itemToString);
                                                    }
                                                    else if (!ObjectValidator.IsSet(item)) {
                                                        itemToString = "null";
                                                    }
                                                    else {
                                                        itemToString = item;
                                                    }
                                                    postprocessor += $paramName + "[\"" + parameterName + "\"][" + index + "]=" +
                                                        itemToString + ";";
                                                }
                                                postprocessors[$index].push(postprocessor);
                                            }
                                        }
                                    }
                                    else {
                                        cmdLine += "=" + parameterValue + ";";
                                    }
                                }
                            }
                            cmdLines.Add(cmdLine);
                        }
                    }
                }
                if (ObjectValidator.IsClass($object)) {
                    if ($object.IsMemberOf(GuiCommons)) {
                        postprocessor = "d.Add(" + $paramName + ");";
                        postprocessors[$index].push(postprocessor);
                        if (!ObjectValidator.IsEmptyOrNull(parsedElements)) {
                            parsedElements += ",";
                        }
                        parsedElements += $paramName;
                    }
                    else if ($object.IsMemberOf(BaseViewer)) {
                        cmdLines.Add($paramName + ".IsCached(true);");
                    }
                }
            });
        };
        getCode(this.viewerInstance, variableName);
        events.setEvent(asyncManager.getId(), EventType.ON_COMPLETE, () => {
            output += "var cm=[" + classes + "];";
            output += variablesSubscribe;
            let index;
            let cmdLineIndex = 0;
            const cmdLineBlocSize = 500;
            let progressEventsCount = 0;
            const progressBlockSize = 100;
            cmdLines.foreach(($line) => {
                if (cmdLineIndex % cmdLineBlocSize === 0) {
                    if (cmdLineIndex > 0) {
                        output += "});";
                    }
                    output += "h.Add(function(){";
                }
                if (cmdLineIndex % progressBlockSize === 0) {
                    progressEventsCount++;
                    output += "e.FireEvent(pc,\"" + EventType.ON_CHANGE + "\",false);";
                }
                output += $line;
                cmdLineIndex++;
            });
            let processIndex = 0;
            for (index = postprocessors.length - 1; index >= 0; index--) {
                for (processIndex = 0; processIndex < postprocessors[index].length; processIndex++) {
                    if (cmdLineIndex % cmdLineBlocSize === 0) {
                        if (cmdLineIndex > 0) {
                            output += "});";
                        }
                        output += "h.Add(function(){";
                    }
                    if (cmdLineIndex % progressBlockSize === 0) {
                        progressEventsCount++;
                        output += "e.FireEvent(pc,\"" + EventType.ON_CHANGE + "\",false);";
                    }
                    output += postprocessors[index][processIndex];
                    cmdLineIndex++;
                }
            }
            if (!cmdLines.IsEmpty() || postprocessors.length > 0) {
                output += "});";
            }
            classes = "";
            variablesSubscribe = "";
            postprocessors = [];
            cmdLines.Clear();
            cmdLineIndex = 0;
            asyncManager = new TimeoutManager();
            events.setEvent(asyncManager.getId(), EventType.ON_COMPLETE, () => {
                if (!ObjectValidator.IsEmptyOrNull(classes)) {
                    output += "cm.push(" + classes + ");";
                }
                output += variablesSubscribe;
                cmdLines.foreach(($line) => {
                    if (cmdLineIndex % cmdLineBlocSize === 0) {
                        if (cmdLineIndex > 0) {
                            output += "});";
                        }
                        output += "h.Add(function(){";
                    }
                    if (cmdLineIndex % progressBlockSize === 0) {
                        progressEventsCount++;
                        output += "e.FireEvent(pc,\"" + EventType.ON_CHANGE + "\",false);";
                    }
                    output += $line;
                    cmdLineIndex++;
                });
                for (index = postprocessors.length - 1; index >= 0; index--) {
                    for (processIndex = 0; processIndex < postprocessors[index].length; processIndex++) {
                        if (cmdLineIndex % cmdLineBlocSize === 0) {
                            if (cmdLineIndex > 0) {
                                output += "});";
                            }
                            output += "h.Add(function(){";
                        }
                        if (cmdLineIndex % progressBlockSize === 0) {
                            progressEventsCount++;
                            output += "e.FireEvent(pc,\"" + EventType.ON_CHANGE + "\",false);";
                        }
                        output += postprocessors[index][processIndex];
                        cmdLineIndex++;
                    }
                }
                if (!cmdLines.IsEmpty() || postprocessors.length > 0) {
                    output += "});";
                }
                output +=
                    "h.Add(function(){" +
                        ViewerCacheManager.ClassName() + ".Loader." + variableName + "=" + variableName + ";" +
                        ViewerCacheManager.ClassName() + ".Loader.elements=[" + parsedElements + "];" +
                        "ai=null;" +
                        "si=null;" +
                        "ob=null;" +
                        "cm=null;" +
                        "e.FireEvent(pc,\"" + EventType.ON_COMPLETE + "\",false);});" +
                        "h.Execute();" +
                        "}," +
                        "\"elements\":[]," +
                        "\"progressEventsCount\":" + progressEventsCount +
                        "};" +
                        ViewerCacheManager.ClassName() + ".Loader.Load();" +
                        ViewerCacheManager.ClassName() + ".getViewerInstance=" +
                        "function(){return " + ViewerCacheManager.ClassName() + ".Loader." + variableName + ";};" +
                        ViewerCacheManager.ClassName() + ".getCachedElements=" +
                        "function(){return " + ViewerCacheManager.ClassName() + ".Loader.elements;};" +
                        ViewerCacheManager.ClassName() + ".getProgressEventsCount=" +
                        "function(){return " + ViewerCacheManager.ClassName() + ".Loader.progressEventsCount;};" +
                        "}catch(ex){" + ExceptionsManager.ClassName() + ".HandleException(ex);}";
                parsedObjects = null;
                parsedElements = null;
                $handler(output);
            });
            asyncManager.Execute();
        });
        asyncManager.Execute();
        /* dev:end */
    }
}
globalThis.RegisterClass("Io.Oidis.Gui.ViewerCacheManager", ViewerCacheManager);
//# sourceMappingURL=ViewerCacheManager.js.map