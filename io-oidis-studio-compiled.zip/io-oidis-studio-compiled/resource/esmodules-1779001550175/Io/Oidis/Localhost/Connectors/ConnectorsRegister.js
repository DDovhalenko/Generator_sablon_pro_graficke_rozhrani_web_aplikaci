/*! ******************************************************************************************************** *
 *
 * Copyright 2023-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { JsonUtils } from "./../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { IConnectorInfo } from "./../../../../Io/Oidis/Services/Interfaces/IConnectorInfo.js";
export class ConnectorsRegister extends BaseObject {
    static connectorsRegister = [];
    symbolsMap;
    constructor() {
        super();
        this.symbolsMap = {};
    }
    /**
     * @param {string} $filter Optional search filter applied to namespace, requester and owner.
     * @param {IModelListFilter} $options Optional pagination options for offset and limit.
     * @returns {IModelListResult<IConnectorInfo>} Returns the paginated connector info result.
     */
    getList($filter, $options) {
        const output = {
            data: [],
            limit: -1,
            offset: 0,
            size: 0
        };
        JsonUtils.Extend(output, $options);
        ConnectorsRegister.connectorsRegister.filter(($info) => {
            if (ObjectValidator.IsEmptyOrNull($filter)) {
                return true;
            }
            return StringUtils.ContainsIgnoreCase($info.namespace + $info.requester, $filter) || $info.owner === $filter;
        }).forEach(($info, $index) => {
            if ($index >= output.offset && ($index < output.limit || output.limit === -1)) {
                output.data.push({ namespace: $info.namespace, owner: $info.owner, requester: $info.requester, created: $info.created });
            }
        });
        output.size = output.data.length;
        return output;
    }
    /**
     * @param {string} $token Authentication token identifying the connectors to destroy.
     * @returns {Promise<void>} Returns a promise that resolves when all matching connectors are destroyed.
     */
    async Destroy($token) {
        const register = [];
        for await (const info of ConnectorsRegister.connectorsRegister) {
            if (info.token !== $token) {
                register.push(info);
            }
            else {
                await info.connector.Destroy();
            }
        }
        ConnectorsRegister.connectorsRegister = register;
    }
    /**
     * @param {string} $token Authentication token for the connector session.
     * @param {string} $namespace Fully qualified class namespace of the connector.
     * @param {string} $requester Identifier of the requesting client.
     * @returns {BaseConnector} Returns the connector instance or null if not found.
     */
    getConnectorForToken($token, $namespace, $requester) {
        $namespace = this.ResolveSymbol($namespace);
        let instance = null;
        if (!ObjectValidator.IsEmptyOrNull($token)) {
            ConnectorsRegister.connectorsRegister.forEach(($info) => {
                if ($info.token === $token && $info.namespace === $namespace) {
                    instance = $info.connector;
                }
            });
            if (ObjectValidator.IsEmptyOrNull(instance)) {
                LogIt.Debug("Constructing new connector {0} for {1}", $namespace, $token);
                const prototype = Reflection.getInstance().getClass($namespace);
                instance = new prototype();
                ConnectorsRegister.connectorsRegister.push({
                    owner: StringUtils.getSha1($token),
                    created: new Date().getTime(),
                    requester: $requester,
                    token: $token,
                    namespace: $namespace,
                    connector: instance
                });
            }
        }
        else {
            instance = Reflection.getInstance().getClass($namespace).getInstance();
            if (instance.getClassName() !== $namespace) {
                const wantedNamespace = Reflection.NormalizeNamespace($namespace);
                const returnedNamespace = Reflection.NormalizeNamespace(instance.getClassName());
                if (wantedNamespace !== returnedNamespace) {
                    LogIt.Debug("Wants to create class {0} but gets {1}.", wantedNamespace, returnedNamespace);
                    instance = null;
                }
            }
        }
        if (!ObjectValidator.IsEmptyOrNull(instance)) {
            instance.isExternCall = true;
        }
        return instance;
    }
    /**
     * @param {ISymbolDefinition[]} $definitions Symbol definitions to register.
     */
    setSymbolMapping(...$definitions) {
        $definitions.forEach(($definition) => {
            let symbols = [];
            if (ObjectValidator.IsString($definition.symbol)) {
                symbols.push($definition.symbol);
            }
            else {
                symbols = $definition.symbol;
            }
            symbols.forEach(($symbol) => {
                this.symbolsMap[$symbol] = $definition.value;
            });
        });
    }
    /**
     * @param {string} $symbol Symbol or namespace to resolve.
     * @returns {string} Returns the resolved namespace or the original symbol if no mapping exists.
     */
    ResolveSymbol($symbol) {
        let output = $symbol;
        for (const symbol in this.symbolsMap) {
            if (this.symbolsMap.hasOwnProperty(symbol)) {
                if (StringUtils.ContainsIgnoreCase($symbol, symbol) ||
                    StringUtils.PatternMatched(symbol, $symbol)) {
                    output = this.symbolsMap[symbol];
                    // LogIt.Debug("Mapping namespace symbol: {0} to: {1}", $symbol, output);
                }
            }
        }
        return output;
    }
}
// generated-code-start
export const ISymbolDefinition = globalThis.RegisterInterface(["symbol", "value"]);
export const IConnectorMeta = globalThis.RegisterInterface(["token", "connector"], IConnectorInfo);
globalThis.RegisterClass("Io.Oidis.Localhost.Connectors.ConnectorsRegister", ConnectorsRegister);
globalThis.RegisterClass("Io.Oidis.Localhost.Connectors.ISymbolDefinition", ISymbolDefinition);
globalThis.RegisterClass("Io.Oidis.Localhost.Connectors.IConnectorMeta", IConnectorMeta);
//# sourceMappingURL=ConnectorsRegister.js.map