/*! ******************************************************************************************************** *
 *
 * Copyright 2020-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { JsonUtils } from "./../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Resources } from "./../../../../Io/Oidis/Services/DAO/Resources.js";
import { Loader } from "../Loader.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
export class Elastic extends BaseConnector {
    client;
    index;
    constructor() {
        super();
    }
    /**
     * @param {any[]} $data Array of data items to process.
     */
    Process($data) {
        this.process($data)
            .then(() => {
            LogIt.Info("Elastic processed");
        })
            .catch(($error) => {
            LogIt.Error($error.message, $error);
        });
    }
    async init() {
        const { Client } = require("@elastic/elasticsearch");
        const fs = require("fs");
        const config = {
            cert: "",
            index: "data",
            location: "https://elastic.oidis.io",
            mapping: "resource/configs/elastic.mapping.json",
            pass: "",
            user: ""
        };
        Resources.Extend(config, Loader.getInstance().getAppConfiguration().elastic);
        Loader.getInstance().getAppConfiguration().elastic = config;
        let ssl;
        if (ObjectValidator.IsEmptyOrNull(config.cert)) {
            LogIt.Info("CA certificate missing - continuing without unauthorized rejection. To use certificate, set " +
                "elastic.cert property.");
            ssl = {
                rejectUnauthorized: false
            };
        }
        else {
            ssl = {
                ca: fs.readFileSync(config.cert),
                checkServerIdentity() {
                    return undefined;
                },
                rejectUnauthorized: true
            };
        }
        const options = {
            node: config.location,
            ssl
        };
        if (!ObjectValidator.IsEmptyOrNull(config.user)) {
            options.auth = {
                username: config.user
            };
            if (!ObjectValidator.IsEmptyOrNull(config.pass)) {
                options.auth.password = config.pass;
            }
        }
        this.client = new Client(options);
        this.index = config.index;
        if (ObjectValidator.IsEmptyOrNull(this.index) || (this.index.length < 4)) {
            throw new Error("Index property for elastic has to been specified and name length has to be greater than 3.");
        }
    }
    async createMapping() {
        const mappingPath = Loader.getInstance().getAppConfiguration().elastic.mapping;
        const mappingData = Loader.getInstance().getFileSystemHandler().Read(Loader.getInstance().getProgramArgs().AppDataPath() + "/" + mappingPath).toString();
        if (!ObjectValidator.IsEmptyOrNull(mappingData)) {
            let mappings = {};
            // eslint-disable-next-line no-useless-catch
            try {
                mappings = JSON.parse(mappingData);
            }
            catch ($e) {
                throw $e;
            }
            // TODO(mkelnar) mapping generation ?
            if (await this.mappingExists()) {
                LogIt.Warning("Attempting to modify mapping for elastic data. " +
                    "It can damage already existing elastic data or data viewers be aware of what you are doing...");
                const result = await this.client.indices.putMapping({ body: mappings, index: this.index });
                this.elasticErrorHandler(result);
            }
            else {
                LogIt.Info("Creating mapping.");
                const result = await this.client.indices.create({
                    body: {
                        mappings
                    },
                    index: this.index
                });
                this.elasticErrorHandler(result);
            }
        }
        else {
            LogIt.Warning("Mapping file was not found so operation skipped.");
        }
    }
    async deleteMapping() {
        LogIt.Warning("Attempting to delete mapping for elastic data. " +
            "It can damage already existing elastic data or data viewers be aware of what you are doing...");
        try {
            const result = await this.client.indices.delete({ index: this.index });
            this.elasticErrorHandler(result);
        }
        catch ($e) {
            if (!ObjectValidator.IsEmptyOrNull($e.meta) && !ObjectValidator.IsEmptyOrNull($e.meta.body) &&
                $e.meta.body.error.type === "index_not_found_exception") {
                LogIt.Info("Mapping is not exist so delete were not succeed.");
                LogIt.Debug("Mapping delete: " + JSON.stringify($e));
            }
            else {
                throw $e;
            }
        }
    }
    async mappingExists() {
        const result = await this.client.indices.exists({ index: this.index });
        return result.statusCode === 200 && ObjectValidator.IsBoolean(result.body) && result.body === true;
    }
    async process($data) {
        if (ObjectValidator.IsEmptyOrNull(this.client)) {
            await this.init();
        }
        if (Loader.getInstance().getProgramArgs().ElasticMapping() || !await this.mappingExists()) {
            await this.createMapping();
        }
        const promises = [];
        $data.forEach(($item) => {
            promises.push(this.pushData($item));
        });
        return await Promise.all(promises);
    }
    async exists($id) {
        LogIt.Debug("Checking existence of: " + $id);
        const result = await this.client.exists({ index: this.index, id: $id });
        return result.statusCode === 200 && ObjectValidator.IsBoolean(result.body) && result.body === true;
    }
    async pushData($data) {
        if (this.pushCondition($data)) {
            let id = this.getUID();
            if (!ObjectValidator.IsEmptyOrNull($data.id)) {
                id = $data.id;
                if (await this.exists(id)) {
                    LogIt.Debug("Updating item: " + id);
                    await this.client.update({
                        body: await this.preprocessData($data),
                        id,
                        index: this.index
                    });
                    return id;
                }
            }
            LogIt.Debug("Creating new item: " + id);
            await this.client.create({
                body: await this.preprocessData($data),
                id,
                index: this.index
            });
            return id;
        }
        return "";
    }
    async deleteItem($id) {
        try {
            const result = await this.client.delete({ index: this.index, id: $id });
            this.elasticErrorHandler(result);
        }
        catch ($e) {
            if (!ObjectValidator.IsEmptyOrNull($e.meta) && !ObjectValidator.IsEmptyOrNull($e.meta.body) &&
                $e.meta.body.error.type === "index_not_found_exception") {
                LogIt.Info("Item is not exist in elastic so delete were not succeed.");
                LogIt.Debug("Item delete failed: " + JSON.stringify($e));
            }
            else {
                throw $e;
            }
        }
    }
    async deleteByQuery($query) {
        LogIt.Debug("Delete items by query");
        return this.client.deleteByQuery({
            body: $query,
            index: this.index
        });
    }
    async findById($id) {
        const found = await this.find({
            query: {
                ids: {
                    values: [$id]
                }
            }
        });
        if (!ObjectValidator.IsEmptyOrNull(found)) {
            if (found.length > 1 || found.length < 1) {
                throw new Error("Multiple items found by findById function is not expected result.");
            }
            return found[0];
        }
    }
    async find($dsl) {
        const response = await this.client.search({
            body: $dsl,
            index: this.index
        });
        const retVal = [];
        if (!ObjectValidator.IsEmptyOrNull(response.body) && !ObjectValidator.IsEmptyOrNull(response.body.hits) &&
            !ObjectValidator.IsEmptyOrNull(response.body.hits.hits)) {
            response.body.hits.hits.forEach(($item) => {
                retVal.push(this.toObject($item));
            });
        }
        return retVal;
    }
    async preprocessData($data) {
        if (ObjectValidator.IsEmptyOrNull($data.timestamp)) {
            $data.timestamp = await this.acquireRealTimestamp();
        }
        if (!ObjectValidator.IsEmptyOrNull($data.id)) {
            delete $data.id;
        }
        return $data;
    }
    toObject($eData) {
        if (!ObjectValidator.IsEmptyOrNull($eData._source)) {
            return JsonUtils.Clone($eData._source);
        }
        return {};
    }
    pushCondition($data) {
        return !ObjectValidator.IsEmptyOrNull($data);
    }
    async acquireRealTimestamp() {
        const date = new Date();
        return date.toISOString();
    }
    async delay($ms) {
        return await new Promise(($resolve) => {
            setTimeout($resolve, ObjectValidator.IsEmptyOrNull($ms) ? 2000 : $ms);
        });
    }
    elasticErrorHandler($response) {
        if ($response.statusCode !== 200) {
            if (ObjectValidator.IsEmptyOrNull($response.body)) {
                throw new Error(this.getClassNameWithoutNamespace() + ": " + $response.toString());
            }
            else {
                if (ObjectValidator.IsEmptyOrNull($response.body.error)) {
                    throw new Error($response.body.error.root_cause[0].type + ": " + $response.body.error.root_cause[0].reason);
                }
                else {
                    throw new Error(this.getClassNameWithoutNamespace() + ": Unknown error");
                }
            }
        }
    }
}
// generated-code-start
export const IElasticResponse = globalThis.RegisterInterface(["body", "statusCode", "warnings"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Connectors.Elastic", Elastic);
globalThis.RegisterClass("Io.Oidis.Localhost.Connectors.IElasticResponse", IElasticResponse);
//# sourceMappingURL=Elastic.js.map