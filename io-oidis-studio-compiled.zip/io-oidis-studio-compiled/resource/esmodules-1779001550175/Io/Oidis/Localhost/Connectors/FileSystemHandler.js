var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpMethodType } from "./../../../../Io/Oidis/Commons/Enums/HttpMethodType.js";
import { LogLevel } from "./../../../../Io/Oidis/Commons/Enums/LogLevel.js";
import { LogSeverity } from "./../../../../Io/Oidis/Commons/Enums/LogSeverity.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { JsonUtils } from "./../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectDecoder } from "./../../../../Io/Oidis/Commons/Utils/ObjectDecoder.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Resources } from "./../../../../Io/Oidis/Services/DAO/Resources.js";
import { CallbackResponse } from "../HttpProcessor/ResponseApi/Handlers/CallbackResponse.js";
import { ResponseFactory } from "../HttpProcessor/ResponseApi/ResponseFactory.js";
import { Loader } from "../Loader.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
import { IntegrityCheck } from "../Primitives/Decorators.js";
import { EnvironmentHelper } from "../Utils/EnvironmentHelper.js";
export class FileSystemHandler extends BaseConnector {
    downloadedFileCheckCount;
    downloadedFileCheckPeriod;
    responseRegister;
    terminal;
    useOldRm;
    lockCheckCount;
    lockCheckPeriod;
    constructor() {
        super();
        this.responseRegister = {
            abort: [],
            running: {}
        };
        this.downloadedFileCheckCount = 10;
        this.downloadedFileCheckPeriod = 10;
        this.lockCheckCount = 10;
        this.lockCheckPeriod = 10;
        this.terminal = Loader.getInstance().getTerminal();
        this.useOldRm = false;
    }
    static async fileSystemHandler() {
        if (StringUtils.IsEmpty(Loader.getInstance().getFileSystemHandler().getTempPath())) {
            throw new Error("Basic validation of FileSystemHandler failed");
        }
    }
    /**
     * @param {string} $path File system path to check.
     * @returns {boolean} Returns true if the path exists.
     */
    Exists($path) {
        const status = this.exists($path);
        LogIt.Info("> validate path \"" + $path + "\" existence: " + status, LogSeverity.MEDIUM);
        return status;
    }
    /**
     * @param {string} $path File system path to check.
     * @returns {boolean} Returns true if the path is empty or does not exist.
     */
    IsEmpty($path) {
        const fs = require("fs");
        LogIt.Info("> validate if \"" + $path + "\" is empty", LogSeverity.LOW);
        let status = true;
        if (!ObjectValidator.IsEmptyOrNull($path)) {
            try {
                if (fs.existsSync($path)) {
                    if (fs.statSync($path).isDirectory()) {
                        status = this.Expand($path + "/*").length === 0;
                    }
                    else {
                        status = fs.readFileSync($path).length === 0;
                    }
                }
            }
            catch (ex) {
                LogIt.Warning(ex.message);
            }
        }
        return status;
    }
    /**
     * @param {string} $path File system path to check.
     * @returns {boolean} Returns true if the path is a file.
     */
    IsFile($path) {
        return this.exists($path) && require("fs").lstatSync(this.NormalizePath($path)).isFile();
    }
    /**
     * @param {string} $path File system path to check.
     * @returns {boolean} Returns true if the path is a directory.
     */
    IsDirectory($path) {
        return this.exists($path) && require("fs").lstatSync(this.NormalizePath($path)).isDirectory();
    }
    /**
     * @param {string} $path File system path to check.
     * @returns {boolean} Returns true if the path is a symbolic link.
     */
    IsSymbolicLink($path) {
        return this.exists($path) && require("fs").lstatSync(this.NormalizePath($path)).isSymbolicLink();
    }
    /**
     * @param {string} $path File system path to check.
     * @returns {boolean} Returns true if the file is locked.
     */
    IsFileLocked($path) {
        if (this.IsFile($path)) {
            const fs = require("fs");
            try {
                fs.closeSync(fs.openSync(this.NormalizePath($path), "r+"));
            }
            catch (ex) {
                if (ex.code === "EBUSY") {
                    return true;
                }
            }
        }
        return false;
    }
    /**
     * @returns {string} Returns the resolved temporary directory path.
     */
    getTempPath() {
        let value;
        if (this.exists(Loader.getInstance().getAppConfiguration().target.tmpPath)) {
            value = this.NormalizePath(Loader.getInstance().getAppConfiguration().target.tmpPath);
        }
        else {
            if (EnvironmentHelper.IsWindows()) {
                const spawnSync = require("child_process").spawnSync;
                let retVal = spawnSync("reg query \"HKCU\\Environment\" /v \"TEMP\"", {
                    shell: true,
                    windowsHide: true
                });
                if (retVal.status === 0) {
                    let regValue = retVal.stdout.toString();
                    regValue = StringUtils.Substring(regValue, StringUtils.IndexOf(regValue, "REG_EXPAND_SZ") + 13).trim();
                    if (!ObjectValidator.IsEmptyOrNull(regValue)) {
                        retVal = spawnSync("echo " + regValue, {
                            shell: true,
                            windowsHide: true
                        });
                        if (retVal.status === 0) {
                            regValue = retVal.stdout.toString().trim();
                            if (!ObjectValidator.IsEmptyOrNull(regValue)) {
                                if (require("fs").existsSync(regValue)) {
                                    value = this.NormalizePath(regValue);
                                    this.getTempPath = () => {
                                        return value;
                                    };
                                }
                            }
                        }
                    }
                }
                else {
                    LogIt.Warning("> " + retVal.stdout + retVal.stderr);
                }
            }
            if (ObjectValidator.IsEmptyOrNull(value)) {
                const os = require("os");
                value = os.tmpdir();
            }
        }
        return value;
    }
    /**
     * @returns {string} Returns the project base path from program arguments.
     */
    getProjectBasePath() {
        return Loader.getInstance().getProgramArgs().ProjectBase();
    }
    /**
     * @returns {string} Returns the application data path from program arguments.
     */
    getAppDataPath() {
        return Loader.getInstance().getProgramArgs().AppDataPath();
    }
    /**
     * @returns {string} Returns the user-specific local app data path or the temporary path as fallback.
     */
    getLocalAppDataPath() {
        const spawnSync = require("child_process").spawnSync;
        let value = this.getTempPath();
        const retVal = spawnSync(EnvironmentHelper.IsWindows() ? "cmd /c echo %USERPROFILE%" : "echo \"$HOME\"", {
            shell: true,
            windowsHide: true
        });
        if (retVal.status === 0) {
            const rawOutput = StringUtils.Remove(retVal.stdout.toString(), "\r\n", "\n", "\\\"").trim();
            if (!ObjectValidator.IsEmptyOrNull(rawOutput)) {
                const path = this.NormalizePath(rawOutput);
                if (this.exists(path) && require("path").isAbsolute(path)) {
                    value = path;
                    if (EnvironmentHelper.IsWindows()) {
                        value += "/AppData/Local";
                    }
                }
                else {
                    LogIt.Warning("System local app path not exists or is not absolute. => Using temporary path.");
                }
            }
            else {
                LogIt.Warning("System local app path is empty. => Using temporary path.");
            }
        }
        else {
            LogIt.Warning("> " + retVal.stdout + retVal.stderr + " => Using temporary path.");
        }
        return value;
    }
    /**
     * @param {string | string[]} $pattern Glob pattern or array of patterns to expand.
     * @returns {string[]} Returns an array of matching file paths.
     */
    Expand($pattern) {
        LogIt.Info("> search for pattern \"" + $pattern + "\"", LogSeverity.MEDIUM);
        if (ObjectValidator.IsString($pattern)) {
            $pattern = [$pattern];
        }
        const glob = require("glob");
        let output = [];
        const input = [];
        const ignore = [];
        $pattern.forEach(($pattern) => {
            // eslint-disable-next-line @typescript-eslint/no-unused-expressions
            StringUtils.StartsWith($pattern, "!") ? ignore.push(StringUtils.Substring($pattern, 1)) : input.push($pattern);
        });
        let cwd = Loader.getInstance().getProgramArgs().TargetBase();
        if (cwd !== process.cwd()) {
            cwd = this.NormalizePath(process.cwd());
        }
        input.forEach(($pattern) => {
            $pattern = StringUtils.Replace($pattern, "\\", "/");
            try {
                output = output.concat(glob.globSync($pattern, {
                    cwd,
                    dot: true,
                    ignore
                }));
            }
            catch (ex) {
                LogIt.Warning("> " + ex.message);
            }
        });
        return output.map((item) => {
            if (typeof item !== "string") {
                return item;
            }
            return item.replace(/^([a-zA-Z]):/, ($match, $driveLetter) => $driveLetter.toUpperCase() + ":");
        });
    }
    /**
     * @param {string} $path Directory path to create.
     * @returns {boolean} Returns true if the directory was created successfully.
     */
    CreateDirectory($path) {
        LogIt.Info("> create directory at \"" + $path + "\"", LogSeverity.MEDIUM);
        let status = false;
        if (!ObjectValidator.IsEmptyOrNull($path)) {
            try {
                this.pmkdir($path);
                status = true;
            }
            catch (ex) {
                LogIt.Warning(ex.message);
            }
        }
        return status;
    }
    /**
     * @param {string} $oldPath Current file system path.
     * @param {string} $newPath New file system path.
     * @returns {boolean} Returns true if the rename was successful.
     */
    Rename($oldPath, $newPath) {
        const fs = require("fs");
        LogIt.Info("> rename from \"" + $oldPath + "\" to \"" + $newPath + "\"", LogSeverity.MEDIUM);
        let status = false;
        if (!ObjectValidator.IsEmptyOrNull($oldPath) && !ObjectValidator.IsEmptyOrNull($newPath)) {
            try {
                if ($oldPath === $newPath) {
                    status = true;
                }
                else if (this.exists($oldPath)) {
                    fs.renameSync($oldPath, $newPath);
                    status = true;
                }
            }
            catch (ex) {
                LogIt.Warning(ex.message);
            }
        }
        return status;
    }
    /**
     * @param {string} $path File path to read from.
     * @returns {string | Buffer} Returns the file content as a string or Buffer.
     */
    Read($path) {
        const fs = require("fs");
        let data = "";
        if (!ObjectValidator.IsEmptyOrNull($path)) {
            $path = this.NormalizePath($path);
            if (!StringUtils.StartsWith($path, "/snapshot/") && ((EnvironmentHelper.IsWindows() && !StringUtils.Contains($path, ":/")) ||
                (!EnvironmentHelper.IsWindows() && ($path[0] !== "/")))) {
                let cwd = Loader.getInstance().getProgramArgs().TargetBase();
                if (cwd !== process.cwd()) {
                    cwd = this.NormalizePath(process.cwd());
                }
                $path = cwd + "/" + $path;
            }
            $path = this.NormalizePath($path);
            LogIt.Info("> read content from \"" + $path + "\"", LogSeverity.MEDIUM);
            try {
                if (this.IsFile($path)) {
                    data = fs.readFileSync($path);
                }
            }
            catch (ex) {
                LogIt.Warning(ex.message);
            }
        }
        return data;
    }
    /**
     * @param {string} $path File path to write to.
     * @param {any} $data Content to write.
     * @param {boolean} $append When true, appends to the file instead of overwriting.
     * @returns {boolean} Returns true if the write was successful.
     */
    Write($path, $data, $append = false) {
        let status = false;
        if (!ObjectValidator.IsEmptyOrNull($path)) {
            $path = this.NormalizePath($path);
            LogIt.Info("> write content to \"" + $path + "\"", LogSeverity.MEDIUM);
            try {
                this.pmkdir(StringUtils.Substring($path, 0, StringUtils.IndexOf($path, "/", false)));
                if ($append) {
                    require("fs").appendFileSync($path, $data);
                }
                else {
                    require("fs").writeFileSync($path, $data);
                }
                status = true;
            }
            catch (ex) {
                LogIt.Warning(ex.message);
            }
        }
        return status;
    }
    /**
     * @param {string} $sourcePath Source file or directory path.
     * @param {string} $destinationPath Destination file or directory path.
     * @param {(($status : boolean) => void) | IResponse} $callback Completion callback or response object.
     */
    Copy($sourcePath, $destinationPath, $callback) {
        const fs = require("fs");
        const path = require("path");
        const response = ResponseFactory.getResponse($callback);
        const onComplete = ($status) => {
            response.Send($status);
        };
        try {
            if (this.exists($sourcePath) && !ObjectValidator.IsEmptyOrNull($destinationPath)) {
                const fileStats = fs.lstatSync($sourcePath);
                if (fileStats.isFile() || fileStats.isSymbolicLink()) {
                    LogIt.Info("> copy file from \"" + $sourcePath + "\" to \"" + $destinationPath + "\"", LogSeverity.MEDIUM);
                    const permissions = fs.lstatSync($sourcePath).mode & parseInt("777", 8);
                    this.pmkdir(path.dirname($destinationPath));
                    if (this.IsDirectory($destinationPath)) {
                        $destinationPath = $destinationPath + "/" + path.basename($sourcePath);
                    }
                    const write = fs.createWriteStream($destinationPath, { mode: permissions });
                    write.on("close", () => {
                        onComplete(true);
                    });
                    write.on("error", ($error) => {
                        response.OnError($error);
                    });
                    fs.createReadStream($sourcePath).pipe(write);
                }
                else {
                    let cmd;
                    let args;
                    $sourcePath = this.NormalizePath($sourcePath, true);
                    $destinationPath = this.NormalizePath($destinationPath, true);
                    if (EnvironmentHelper.IsWindows()) {
                        cmd = "Robocopy";
                        args = ["\"" + $sourcePath + "\"", "\"" + $destinationPath + "\"", "/E", "/MT", "/NP", "/NFL"];
                    }
                    else {
                        cmd = "cp";
                        args = ["-Rp", "\"" + $sourcePath + "\"/*", "\"" + $destinationPath + "\""];
                        this.pmkdir($destinationPath);
                    }
                    this.terminal.Spawn(cmd, args, "", ($exitCode) => {
                        if (EnvironmentHelper.IsWindows()) {
                            onComplete($exitCode === 1 || $exitCode === 3);
                        }
                        else {
                            onComplete($exitCode === 0);
                        }
                    });
                }
            }
            else {
                LogIt.Info("> copy from \"" + $sourcePath + "\" to \"" + $destinationPath +
                    "\" skipped: source does not exist or destination is empty");
                onComplete(false);
            }
        }
        catch (ex) {
            response.OnError(ex);
        }
    }
    /**
     * @param {string} $sourcePath Source file or directory path.
     * @param {string} $destinationPath Destination file or directory path.
     * @returns {Promise<void>} Returns a promise that resolves when the copy is complete.
     */
    async CopyAsync($sourcePath, $destinationPath) {
        return await new Promise(($resolve, $reject) => {
            this.Copy($sourcePath, $destinationPath, ($status) => {
                if ($status) {
                    $resolve();
                }
                else {
                    $reject(new Error("copy from \"" + $sourcePath + "\" to \"" + $destinationPath + "\" failed."));
                }
            });
        });
    }
    /**
     * @param {string | IFileSystemDownloadOptions} $urlOrOptions URL string or download options object.
     * @param {(($headers : string, $bodyOrPath : string) => void) | IResponse} $callback Completion callback or response object.
     * @param {($httpResponse : any, $callback : IResponse) => boolean} $onHttpError Optional HTTP error handler.
     */
    Download($urlOrOptions, $callback, $onHttpError) {
        const fs = require("fs");
        const options = {
            body: "",
            headers: {},
            maxReconnection: 5,
            method: HttpMethodType.GET,
            streamOutput: false,
            streamReturnsBuffer: false,
            strictSSL: true,
            url: "",
            verbose: true
        };
        if (ObjectValidator.IsString($urlOrOptions)) {
            options.url = $urlOrOptions;
        }
        else if (ObjectValidator.IsObject($urlOrOptions)) {
            let parameter;
            for (parameter in $urlOrOptions) {
                if ($urlOrOptions.hasOwnProperty(parameter)) {
                    options[parameter] = $urlOrOptions[parameter];
                }
            }
        }
        const response = ResponseFactory.getResponse($callback);
        let httpStatusCodeHandler = ($httpResponse, $callback) => {
            $callback.OnError("Bad response status code: " + $httpResponse.statusCode + " (" +
                require("http").STATUS_CODES[$httpResponse.statusCode] + ")");
            return true;
        };
        if (!ObjectValidator.IsEmptyOrNull($onHttpError)) {
            httpStatusCodeHandler = $onHttpError;
        }
        if (ObjectValidator.IsString(options.url)) {
            try {
                options.url = new URL(options.url);
            }
            catch ($ex) {
                if (!ObjectValidator.IsEmptyOrNull($onHttpError)) {
                    $onHttpError($ex, response);
                }
                else {
                    response.OnError("Invalid URL: " + options.url);
                }
                return;
            }
            options.url.method = options.method;
            options.url.headers = options.headers;
        }
        if (!ObjectValidator.IsEmptyOrNull(options.mTLS)) {
            options.url.cert = this.Read(options.mTLS.cert);
            options.url.key = this.Read(options.mTLS.key);
            if (!ObjectValidator.IsEmptyOrNull(options.mTLS.ca)) {
                options.url.ca = this.Read(options.mTLS.ca);
            }
        }
        if (options.method === HttpMethodType.GET) {
            options.body = "";
        }
        if (!ObjectValidator.IsEmptyOrNull(options.proxy) && options.proxy === false) {
            if (ObjectValidator.IsEmptyOrNull(options.proxyConfig)) {
                options.proxyConfig = {};
            }
            options.proxyConfig.noProxy = "*";
        }
        const utils = new DownloadUtils(this, options);
        if (options.verbose) {
            LogIt.Info("> download (" + options.method + ") from: " + (new URL(options.url)).toString());
            const headers = JSON.stringify(options.url.headers);
            if (headers !== "{}") {
                LogIt.Info("> with headers: " + headers);
            }
            if (options.body !== "") {
                LogIt.Info("> with body: " + options.body);
            }
        }
        if (options.url.protocol === "http:" || options.url.protocol === "https:") {
            const makeRequest = ($client, $options) => {
                // TODO(mkelnar): Replace this hack with a proper approach.
                //  The first parameter should ideally be RequestOptions or a URL, and the second should be RequestOptions.
                //  Currently, internal merging is overly strict. Since the URL object lacks certain properties
                //  present in $options.url (due to loose typing), the 'method' property is lost during the merge.
                //  As a workaround, we pass the URL object as the first argument and a copy of it as the second.
                //  This ensures all injected options are preserved, though it's not an elegant solution.
                const httpRequest = $client.request($options.url, $options.url, ($httpResponse) => {
                    if ($httpResponse.statusCode === 200 || $httpResponse.statusCode === 201) {
                        const meta = utils.ParseHeaders($httpResponse.headers);
                        const length = meta.length;
                        const isChunked = meta.isChunked || $options.method === HttpMethodType.HEAD;
                        let currentLength = 0;
                        try {
                            let fileName = "";
                            let streamBuffers = [];
                            let fsStream = null;
                            let completed = false;
                            const onComplete = () => {
                                if (!completed) {
                                    completed = true;
                                    if ($options.streamOutput) {
                                        const data = Buffer.concat(streamBuffers);
                                        response.OnComplete($httpResponse.headers, $options.streamReturnsBuffer ? data : data.toString());
                                        // eslint-disable-next-line @typescript-eslint/no-array-delete
                                        delete this.responseRegister.running[response.getId()];
                                    }
                                    else {
                                        this.downloadFileCheck(fileName, isChunked ? currentLength : length, ($status) => {
                                            if ($status) {
                                                this.filesUnlockCheck([fileName], ($status) => {
                                                    if ($status) {
                                                        response.OnComplete($httpResponse.headers, fileName);
                                                        // eslint-disable-next-line @typescript-eslint/no-array-delete
                                                        delete this.responseRegister.running[response.getId()];
                                                    }
                                                    else {
                                                        response.OnError("Downloaded file lock check failed.");
                                                    }
                                                }, $options.verbose);
                                            }
                                            else {
                                                response.OnError("Downloaded file size check failed.");
                                            }
                                        }, $options.verbose);
                                    }
                                }
                            };
                            if (!$options.streamOutput) {
                                fileName = meta.fileName;
                                fileName = utils.PrepareTmp(fileName);
                                fsStream = fs.createWriteStream(fileName);
                                fsStream.on("end", () => {
                                    onComplete();
                                });
                                $httpResponse.pipe(fsStream);
                            }
                            let counter = 0;
                            $httpResponse.on("data", ($chunk) => {
                                currentLength += $chunk.length;
                                if ($options.streamOutput) {
                                    streamBuffers.push($chunk);
                                }
                                if ($options.verbose) {
                                    if (counter < 100) {
                                        Echo.Print(".");
                                    }
                                    else {
                                        if (!isNaN(length)) {
                                            Echo.Println(" (" + Math.floor(100 / length * currentLength) + "%)");
                                        }
                                        else {
                                            Echo.Println(".");
                                        }
                                        counter = 0;
                                    }
                                    counter++;
                                }
                                response.OnChange({
                                    currentValue: currentLength,
                                    rangeEnd: length,
                                    rangeStart: 0
                                });
                            });
                            let connectionClosed = false;
                            $httpResponse.on("close", () => {
                                if (currentLength !== length && !isChunked) {
                                    connectionClosed = true;
                                    if (!$options.streamOutput) {
                                        this.Delete(fileName);
                                    }
                                    else {
                                        streamBuffers = [];
                                    }
                                    const abortIndex = this.responseRegister.abort.indexOf(response.getId() + "");
                                    if (abortIndex !== -1) {
                                        this.responseRegister.abort.splice(abortIndex, 1);
                                        if ($options.verbose) {
                                            LogIt.Info("Connection has been aborted.");
                                        }
                                    }
                                    else {
                                        if (this.responseRegister.running.hasOwnProperty(response.getId()) &&
                                            !ObjectValidator.IsEmptyOrNull(this.responseRegister.running[response.getId()])) {
                                            if (this.responseRegister.running[response.getId()]
                                                .reconnectCounter < $options.maxReconnection) {
                                                if ($options.verbose) {
                                                    LogIt.Warning("Reconnecting ...");
                                                }
                                                httpRequest.end();
                                                this.Download($urlOrOptions, response, $onHttpError);
                                            }
                                            else {
                                                response.OnError("Connection has been lost.");
                                            }
                                            this.responseRegister.running[response.getId()].reconnectCounter++;
                                        }
                                        else {
                                            response.OnError("Connection has been lost.");
                                        }
                                    }
                                }
                                else {
                                    onComplete();
                                }
                            });
                            $httpResponse.on("end", () => {
                                if (!connectionClosed) {
                                    if ($options.verbose) {
                                        Echo.Println(" (100%)");
                                    }
                                    if (!$options.streamOutput) {
                                        onComplete();
                                    }
                                }
                            });
                        }
                        catch (ex) {
                            response.OnError(ex);
                        }
                    }
                    else if ($httpResponse.statusCode === 301 || $httpResponse.statusCode === 302) {
                        $options.url = $httpResponse.headers.location;
                        this.Download($options, response, $onHttpError);
                    }
                    else if (httpStatusCodeHandler($httpResponse, response)) {
                        delete this.responseRegister.running[response.getId()]; // eslint-disable-line @typescript-eslint/no-array-delete
                    }
                });
                httpRequest.on("error", ($ex) => {
                    if (this.responseRegister.running.hasOwnProperty(response.getId()) &&
                        !ObjectValidator.IsEmptyOrNull(this.responseRegister.running[response.getId()])) {
                        if (this.responseRegister.running[response.getId()].reconnectCounter < $options.maxReconnection) {
                            if ($options.verbose) {
                                Echo.Println($ex.message);
                            }
                            this.Download($urlOrOptions, response, $onHttpError);
                        }
                        else {
                            if ($options.verbose) {
                                Echo.Println("");
                            }
                            response.OnError($ex);
                        }
                        this.responseRegister.running[response.getId()].reconnectCounter++;
                    }
                    else {
                        response.OnError($ex);
                    }
                });
                if ($options.body !== "") {
                    httpRequest.write($options.body);
                }
                httpRequest.end();
                if (!this.responseRegister.running.hasOwnProperty(response.getId())) {
                    response.OnStart();
                    this.responseRegister.running[response.getId()] = {
                        httpRequest,
                        reconnectCounter: 0
                    };
                }
                else {
                    this.responseRegister.running[response.getId()].httpRequest = httpRequest;
                }
            };
            Loader.getInstance().getHttpResolver().FetchHelper(options)
                .then(($environment) => {
                makeRequest($environment.client, $environment.options);
            })
                .catch(($error) => {
                response.OnError($error);
            });
        }
        else if (options.url.protocol === "file:") {
            try {
                let urlTemp = options.url.href;
                if (ObjectValidator.IsString($urlOrOptions)) {
                    urlTemp = $urlOrOptions;
                }
                if (options.streamOutput) {
                    const data = this.Read(utils.FormatUrl(urlTemp));
                    response.OnComplete({}, data);
                }
                else {
                    const tmpPath = utils.PrepareTmp();
                    this.Copy(utils.FormatUrl(urlTemp), tmpPath, () => {
                        response.OnComplete({}, tmpPath);
                    });
                }
            }
            catch (ex) {
                response.OnError(ex);
            }
        }
        else {
            response.OnError("Selected protocol \"" + options.url.protocol + "\" is not supported." +
                " Please use http://, https:// or file:// protocol instead.");
        }
    }
    /**
     * @param {string | IFileSystemDownloadOptions} $urlOrOptions URL string or download options object.
     * @returns {Promise<IDownloadResult>} Returns a promise resolving to the download result with headers and body or path.
     */
    async DownloadAsync($urlOrOptions) {
        return await new Promise(($resolve, $reject) => {
            const callback = new CallbackResponse(($headers, $bodyOrPath) => {
                $resolve({ bodyOrPath: $bodyOrPath, headers: $headers });
            });
            callback.OnError = ($message, ...$args) => {
                if (ObjectValidator.IsString($message)) {
                    $reject(new Error($message));
                }
                else {
                    $reject($message);
                }
            };
            this.Download($urlOrOptions, callback, ($httpResponse) => {
                $reject(new Error($httpResponse.statusMessage + " (" + $httpResponse.statusCode + ")"));
                return true;
            });
        });
    }
    /**
     * @param {number} $id Connection identifier of the download to abort.
     * @returns {boolean} Returns true if the download was successfully aborted.
     */
    AbortDownload($id) {
        const id = $id + "";
        let status = false;
        if (this.responseRegister.running.hasOwnProperty(id)) {
            try {
                this.responseRegister.abort.push(id);
                this.responseRegister.running[id].httpRequest.abort();
                delete this.responseRegister.running[id]; // eslint-disable-line @typescript-eslint/no-array-delete
                status = true;
                LogIt.Info("Download with connection id \"" + $id + "\" has been abort.");
            }
            catch (ex) {
                LogIt.Warning(ex.message);
            }
        }
        return status;
    }
    /**
     * @param {string | IFSDeleteOptions} $pathOrOptions File path or delete options object.
     * @param {(($status : boolean) => void) | IResponse} $callback Completion callback or response object.
     * @returns {boolean} Returns true if the deletion was successful.
     */
    Delete($pathOrOptions, $callback) {
        const options = {
            ignoreLocked: false,
            path: "",
            statusHandler: ($message, $type, $severity) => {
                if ($type === "print") {
                    Echo.Print($message);
                }
                else if ($type === "println") {
                    Echo.Println($message);
                }
                else if ($type === LogLevel.WARNING) {
                    LogIt.Warning($message);
                }
                else if ($type === LogLevel.INFO) {
                    LogIt.Info($message, $severity);
                }
                else if ($type === LogLevel.ERROR) {
                    LogIt.Error($message);
                }
                else {
                    LogIt.Debug($message);
                }
            },
            useRecursive: this.useOldRm
        };
        if (ObjectValidator.IsString($pathOrOptions)) {
            options.path = $pathOrOptions;
        }
        else {
            JsonUtils.Extend(options, $pathOrOptions);
        }
        const fs = require("fs");
        let status = false;
        const response = ResponseFactory.getResponse($callback);
        response.OnStart();
        if (!ObjectValidator.IsEmptyOrNull($pathOrOptions)) {
            try {
                if (options.ignoreLocked) {
                    options.statusHandler("> running insecurely with ignoreLocked option. Some files or dirs may not be deleted.", LogLevel.WARNING);
                }
                let counter = 0;
                const failedDelete = [];
                const deleteRecursive = ($path) => {
                    if (this.exists($path)) {
                        try {
                            if (fs.lstatSync($path).isDirectory()) {
                                fs.readdirSync($path).forEach(($file) => {
                                    deleteRecursive($path + "/" + $file);
                                });
                                fs.rmdirSync($path);
                            }
                            else {
                                fs.unlinkSync($path);
                            }
                        }
                        catch (ex) {
                            try {
                                options.statusHandler("Trying to remove file as directory because of:" + ex.message, LogLevel.WARNING);
                                fs.rmdirSync($path);
                            }
                            catch (ex) {
                                if (options.ignoreLocked) {
                                    options.statusHandler(ex.message, LogLevel.INFO, LogSeverity.MEDIUM);
                                    failedDelete.push($path);
                                }
                                else {
                                    throw ex;
                                }
                            }
                        }
                        response.OnChange({
                            currentValue: counter,
                            rangeEnd: 100,
                            rangeStart: 0
                        });
                        if (counter < 100) {
                            options.statusHandler(".", "print");
                        }
                        else {
                            options.statusHandler(".", "println");
                            counter = 0;
                        }
                        counter++;
                    }
                };
                const oldRm = ($path) => {
                    if (this.exists($path)) {
                        if (fs.lstatSync($path).isDirectory()) {
                            deleteRecursive($path);
                            options.statusHandler("", "println");
                        }
                        else {
                            fs.unlinkSync($path);
                        }
                    }
                };
                options.path = this.NormalizePath(options.path);
                options.statusHandler("> delete path \"" + options.path + "\"", LogLevel.INFO, LogSeverity.MEDIUM);
                if (!options.useRecursive) {
                    // progress like setInterval() in execute can not be there because it will need to be async but delete is used
                    // as sync on some places so no prints here but it is ok for low files count dirs but i.e. nodejs dir in deps
                    // rm takes some tens second
                    try {
                        fs.rmSync(options.path, { force: true, recursive: true, maxRetries: 20, retryDelay: 500 });
                    }
                    catch (ex) {
                        if (options.ignoreLocked) {
                            options.statusHandler("> rmSync failed, falling back to recursive delete", LogLevel.INFO, LogSeverity.LOW);
                            oldRm();
                        }
                        else {
                            throw ex;
                        }
                    }
                }
                else {
                    oldRm();
                }
                status = true;
                if (!ObjectValidator.IsEmptyOrNull(failedDelete)) {
                    options.statusHandler("> not deleted: " + failedDelete.join(","), LogLevel.WARNING);
                }
            }
            catch (ex) {
                options.statusHandler(ex.message, LogLevel.WARNING);
            }
        }
        response.OnComplete(status);
        return status;
    }
    /**
     * @param {string | IFSDeleteOptions} $pathOrOptions File path or delete options object.
     * @returns {Promise<void>} Returns a promise that resolves when the deletion is complete.
     */
    async DeleteAsync($pathOrOptions) {
        const options = {
            ignoreLocked: false,
            path: "",
            statusHandler: ($message, $type, $severity) => {
                if ($type === "print") {
                    Echo.Print($message);
                }
                else if ($type === "println") {
                    Echo.Println($message);
                }
                else if ($type === LogLevel.WARNING) {
                    LogIt.Warning($message);
                }
                else if ($type === LogLevel.INFO) {
                    LogIt.Info($message, $severity);
                }
                else if ($type === LogLevel.ERROR) {
                    LogIt.Error($message);
                }
                else {
                    LogIt.Debug($message);
                }
            }
        };
        if (ObjectValidator.IsString($pathOrOptions)) {
            options.path = $pathOrOptions;
        }
        else {
            JsonUtils.Extend(options, $pathOrOptions);
        }
        const fs = require("fs/promises");
        if (ObjectValidator.IsEmptyOrNull($pathOrOptions)) {
            return;
        }
        try {
            if (options.ignoreLocked) {
                options.statusHandler("> running insecurely with ignoreLocked option. Some files or dirs may not be deleted.", LogLevel.WARNING);
            }
            options.path = this.NormalizePath(options.path);
            options.statusHandler("> delete path \"" + options.path + "\"", LogLevel.INFO, LogSeverity.MEDIUM);
            await fs.rm(options.path, {
                force: true,
                recursive: true,
                maxRetries: options.ignoreLocked ? 1 : 20,
                retryDelay: options.ignoreLocked ? 10 : 500
            });
        }
        catch (ex) {
            throw new Error("File or folder at path \"" + options.path + "\" can not be deleted.");
        }
    }
    /**
     * @param {string | string[]} $path Source path, glob pattern or array of paths to archive.
     * @param {IArchiveOptions} $options Archive options including type, output path and strip settings.
     * @param {(($tmpPath : string) => void) | IResponse} $callback Completion callback or response object.
     */
    Pack($path, $options, $callback) {
        const path = require("path");
        const fs = require("fs");
        const archiver = require("archiver");
        let cwd = "";
        if (ObjectValidator.IsString($path)) {
            if (this.IsFile($path)) {
                $path = path.dirname($path);
            }
            if (!StringUtils.Contains($path, "*")) {
                $path += "/**/*";
            }
            cwd = StringUtils.Substring($path, 0, StringUtils.IndexOf($path, "/*", false));
        }
        const paths = this.Expand($path);
        let notFound = false;
        const response = ResponseFactory.getResponse($callback === undefined ? $options : $callback);
        if (paths.length > 0) {
            paths.forEach(($element, $index) => {
                if (!this.exists($element)) {
                    response.OnError("Unable to locate file \"" + $element + "\" for archive creation.");
                    notFound = true;
                }
                else {
                    paths[$index] = this.NormalizePath($element, true);
                }
            });
        }
        else {
            notFound = true;
            response.OnError("Unable to create archive from empty source \"" + $path + "\"");
        }
        if (!notFound) {
            const options = {
                autoStrip: false,
                cwd,
                output: "",
                override: true,
                type: EnvironmentHelper.IsWindows() ? "zip" : "tar.bz2"
            };
            if (ObjectValidator.IsObject($options)) {
                Resources.Extend(options, $options);
            }
            if (ObjectValidator.IsEmptyOrNull(options.output)) {
                let tmpOutput;
                if (ObjectValidator.IsString($path)) {
                    tmpOutput = path.basename(this.NormalizePath(StringUtils.Remove($path, "*")));
                }
                else {
                    tmpOutput = "archive";
                }
                options.output = this.getTempPath() + "/" + Loader.getInstance().getEnvironmentArgs().getProjectName() + "/" +
                    tmpOutput + "." + options.type;
            }
            else if (StringUtils.Contains(options.output, ".tar")) {
                options.type = StringUtils.Substring(options.output, StringUtils.IndexOf(options.output, ".tar"));
            }
            if (StringUtils.StartsWith(options.type, ".")) {
                options.type = StringUtils.Substring(options.type, 1);
            }
            if (!["zip", "tar", "tar.gz", "tar.bz2"].includes(options.type)) {
                response.OnError("Failed to create archive: required format \"" + options.type + "\" does not match " +
                    "any of supported formats (zip, tar, tar.gz and tar.bz2)");
            }
            else {
                options.output = this.NormalizePath(options.output);
                if (StringUtils.Contains(options.output, ".")) {
                    options.output = StringUtils.Substring(options.output, 0, StringUtils.IndexOf(options.output, "."));
                }
                options.output += "." + options.type;
                options.cwd = this.NormalizePath(options.cwd);
                LogIt.Info("> pack \"" + options.cwd + "\" to \"" + options.output + "\"");
                options.output = StringUtils.Remove(options.output, ".bz2");
                if (StringUtils.OccurrenceCount(options.cwd, "/") > 1) {
                    options.cwd = path.dirname(options.cwd);
                }
                try {
                    if (!options.override && this.Exists(options.output)) {
                        response.OnError("Failed to create archive: destination file already exists");
                    }
                    else {
                        this.Delete(options.output);
                        this.pmkdir(path.dirname(options.output));
                        const output = fs.createWriteStream(options.output);
                        const archive = archiver(StringUtils.Contains(options.type, "tar") ? "tar" : options.type, {
                            gzip: StringUtils.Contains(options.type, ".gz"),
                            zlib: { level: 9 }
                        });
                        output.on("close", () => {
                            if (StringUtils.Contains(options.type, ".bz2")) {
                                LogIt.Info("> compression to bzip2 format");
                                let compressjs = null;
                                try {
                                    compressjs = require("compressjs");
                                }
                                catch (ex) {
                                    // handle optional module
                                }
                                if (!ObjectValidator.IsEmptyOrNull(compressjs)) {
                                    this.Write(options.output + ".bz2", compressjs.Bzip2.compressFile(this.Read(options.output)));
                                    this.Delete(options.output);
                                    response.Send(options.output + ".bz2");
                                }
                                else {
                                    LogIt.Error("Missing optional dependency \"compressjs\" for ability to support .bz2 format. " +
                                        "Please specify required include in project configuration.");
                                    response.OnError("Failed to compress in bz2 format due to missing module.");
                                }
                            }
                            else {
                                response.Send(options.output);
                            }
                        });
                        archive.on("warning", ($error) => {
                            if ($error.code === "ENOENT") {
                                LogIt.Warning($error);
                            }
                            else {
                                response.OnError($error);
                            }
                        });
                        archive.on("error", ($error) => {
                            response.OnError($error);
                        });
                        let rootFolder = "";
                        if (!options.autoStrip) {
                            rootFolder = path.basename(options.output);
                            rootFolder = StringUtils.Substring(rootFolder, 0, StringUtils.IndexOf(rootFolder, "."));
                            rootFolder += "/";
                        }
                        paths.forEach(($file) => {
                            archive.file($file, {
                                name: rootFolder + StringUtils.Remove(this.NormalizePath($file), options.cwd + "/")
                            });
                        });
                        archive.pipe(output);
                        archive.finalize();
                    }
                }
                catch (ex) {
                    response.OnError(ex);
                }
            }
        }
    }
    /**
     * @param {string | string[]} $path Source path, glob pattern or array of paths to archive.
     * @param {IArchiveOptions} $options Archive options including type, output path and strip settings.
     * @returns {Promise<string>} Returns a promise resolving to the output archive path.
     */
    async PackAsync($path, $options) {
        return await new Promise(($resolve, $reject) => {
            this.Pack($path, $options, ($tmpPath) => {
                if (this.exists($tmpPath)) {
                    $resolve($tmpPath);
                }
                else {
                    $reject(new Error("Packaging failed."));
                }
            });
        });
    }
    /**
     * @param {string} $path Path to the archive file.
     * @param {IArchiveOptions} $options Extraction options including output path and strip settings.
     * @param {(($tmpPath : string) => void) | IResponse} $callback Completion callback or response object.
     */
    Unpack($path, $options, $callback) {
        const path = require("path");
        const fs = require("fs");
        const decompress = require("decompress");
        let pathExtension = path.extname($path);
        const pathMatch = $path.match(/\.tar\.[a-zA-Z0-9]+$/g);
        if (!ObjectValidator.IsEmptyOrNull(pathMatch) && !ObjectValidator.IsEmptyOrNull(pathMatch[0])) {
            pathExtension = pathMatch[0];
        }
        const response = ResponseFactory.getResponse(!ObjectValidator.IsSet($callback) ? $options : $callback);
        const options = {
            autoStrip: true,
            output: "",
            override: true
        };
        if (ObjectValidator.IsObject($options)) {
            Resources.Extend(options, $options);
        }
        if (options.output === "") {
            options.output = this.getTempPath() + "/" + Loader.getInstance().getEnvironmentArgs().getProjectName() + "/" +
                path.basename($path).replace(pathExtension, "");
        }
        options.output = this.NormalizePath(options.output);
        $path = this.NormalizePath($path);
        LogIt.Info("> unpack \"" + $path + "\" to \"" + options.output + "\"");
        const files = [];
        const onComplete = () => {
            this.filesUnlockCheck(files, ($status) => {
                if ($status) {
                    response.OnComplete(options.output);
                }
                else {
                    response.OnError("Unable to unlock extracted files.");
                }
            });
        };
        if (!options.override && fs.existsSync(options.output)) {
            onComplete();
        }
        else {
            this.Delete(options.output);
            try {
                decompress($path, options.output, {
                    map: ($file) => {
                        if ($file.type === "symlink") {
                            if (EnvironmentHelper.IsWindows() && !fs.existsSync($file.linkname)) {
                                $file.linkname = this.NormalizePath(options.output + "/" + $file.linkname);
                            }
                        }
                        else if ($file.type === "file") {
                            files.push(options.output + "/" + $file.path);
                        }
                        return $file;
                    },
                    plugins: [
                        require("decompress-unzip")(),
                        require("decompress-tar")(),
                        require("decompress-tarbz2")(),
                        require("decompress-targz")()
                    ],
                    strip: options.autoStrip ? 1 : 0
                }).then(() => {
                    onComplete();
                }).catch(($error) => {
                    if ($error.code === "EPERM" || $error.code === "ENOENT") {
                        LogIt.Warning($error.stack);
                        onComplete();
                    }
                    else {
                        response.OnError($error);
                    }
                });
            }
            catch (ex) {
                response.OnError(ex);
            }
        }
    }
    /**
     * @param {string} $path Path to the archive file.
     * @param {IArchiveOptions} $options Extraction options including output path and strip settings.
     * @returns {Promise<string>} Returns a promise resolving to the extracted output directory path.
     */
    async UnpackAsync($path, $options) {
        return await new Promise(($resolve, $reject) => {
            this.Unpack($path, $options, ($tmpPath) => {
                if (this.exists($tmpPath)) {
                    $resolve($tmpPath);
                }
                else {
                    $reject(new Error("Package extraction failed."));
                }
            });
        });
    }
    /**
     * @param {string} $source File path to normalize.
     * @param {boolean} $osSeparator When true, uses OS-native path separators instead of forward slashes.
     * @returns {string} Returns the normalized path string.
     */
    NormalizePath($source, $osSeparator = false) {
        const path = require("path");
        return path.normalize($source).replace(/[\\/]+/g, $osSeparator ? path.sep : "/");
    }
    downloadFileCheck($path, $demandSize, $callback, $verbose = true) {
        if ($verbose) {
            LogIt.Info("> check downloaded file existence", LogSeverity.LOW);
        }
        const fs = require("fs");
        let iterations = 0;
        const check = () => {
            let success = false;
            let size = 0;
            try {
                const stats = fs.lstatSync($path);
                size = stats.size;
                success = size === $demandSize;
            }
            catch {
                // dummy
                size = -1;
            }
            if ($verbose) {
                LogIt.Debug("[" + (iterations + 1) + "/" + this.downloadedFileCheckCount +
                    "] Checking size of downloaded file {0}: [" + size + "/" + $demandSize + "] = " + success, $path);
            }
            if (success) {
                $callback(true);
            }
            else if (iterations++ < this.downloadedFileCheckCount) {
                setTimeout(check, this.downloadedFileCheckPeriod); // eslint-disable-line @typescript-eslint/no-implied-eval
            }
            else {
                $callback(false);
            }
        };
        check();
    }
    filesUnlockCheck($files, $callback, $verbose = true) {
        if ($verbose) {
            LogIt.Info("> check " + $files.length + " files lock", LogSeverity.LOW);
        }
        let iterations = 0;
        const check = () => {
            let locked = false;
            for (const path of $files) {
                if ($verbose) {
                    LogIt.Debug("[" + (iterations + 1) + "/" + this.lockCheckCount + "] Checking file lock: {0}", path);
                }
                if (this.IsFileLocked(path)) {
                    locked = true;
                    break;
                }
            }
            if (!locked) {
                $callback(true);
            }
            else if (iterations++ < this.lockCheckCount) {
                setTimeout(check, this.lockCheckPeriod); // eslint-disable-line @typescript-eslint/no-implied-eval
            }
            else {
                $callback(false);
            }
        };
        check();
    }
    exists($path) {
        let status = false;
        if (!ObjectValidator.IsEmptyOrNull($path)) {
            $path = this.NormalizePath($path);
            const fs = require("fs");
            const isLink = () => {
                let retVal = false;
                try {
                    retVal = fs.lstatSync($path).isSymbolicLink();
                    LogIt.Info("> is existing symbolic link", LogSeverity.LOW);
                }
                catch (e) {
                    // leave this block empty
                }
                return retVal;
            };
            status = fs.existsSync($path) || isLink();
        }
        return status;
    }
    pmkdir($path) {
        const fs = require("fs");
        if (!fs.existsSync($path)) {
            $path.split("/").reduce(($currentPath, $folder) => {
                $currentPath += $folder + "/";
                if (!fs.existsSync($currentPath)) {
                    LogIt.Info("> create dir: " + $currentPath, LogSeverity.LOW);
                    fs.mkdirSync($currentPath);
                }
                return $currentPath;
            }, "");
        }
    }
}
__decorate([
    IntegrityCheck(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], FileSystemHandler, "fileSystemHandler", null);
export class DownloadUtils extends BaseObject {
    owner;
    path;
    fs;
    options;
    constructor($owner, $options) {
        super();
        this.owner = $owner;
        this.path = require("path");
        this.fs = require("fs");
        this.options = $options;
    }
    /**
     * @param {string} $fileName Optional file name to use in the temporary path.
     * @returns {string} Returns the unique temporary file path.
     */
    PrepareTmp($fileName) {
        let tmpPath = this.owner.getTempPath() + "/" + Loader.getInstance().getEnvironmentArgs().getProjectName() + "/downloads";
        this.owner.pmkdir(tmpPath);
        if (!ObjectValidator.IsEmptyOrNull($fileName)) {
            tmpPath += "/" + $fileName;
        }
        else {
            if (this.options.url.pathname.indexOf("/") !== -1) {
                const name = this.options.url.pathname.substr(this.options.url.pathname.lastIndexOf("/"));
                if (name !== "") {
                    tmpPath += "/" + name;
                }
                else {
                    tmpPath += "/" + new Date().getTime();
                }
            }
            else {
                tmpPath += "/" + new Date().getTime();
            }
        }
        tmpPath = this.owner.NormalizePath(tmpPath);
        if (this.fs.existsSync(tmpPath)) {
            let index = 2;
            let pathExtension = this.path.extname(tmpPath);
            const pathMatch = tmpPath.match(/.tar.[a-zA-Z0-9]+$/g);
            if (pathMatch !== null && pathMatch.length >= 0 && pathMatch[0] !== undefined) {
                pathExtension = pathMatch[0];
            }
            let newPath;
            do {
                if (pathExtension !== "") {
                    newPath = StringUtils.Replace(tmpPath, pathExtension, "_" + index + pathExtension);
                }
                else {
                    newPath = tmpPath + "_" + index;
                }
                index++;
            } while (this.fs.existsSync(newPath));
            tmpPath = newPath;
        }
        return tmpPath;
    }
    /**
     * @param {string} $url File URL to format.
     * @returns {string} Returns the local file path.
     */
    FormatUrl($url) {
        if (EnvironmentHelper.IsWindows()) {
            $url = StringUtils.Remove($url, "file:///");
        }
        return StringUtils.Remove($url, "file://");
    }
    /**
     * @param {any} $headers HTTP response headers object.
     * @returns {any} Returns an object with fileName, isChunked and length properties.
     */
    ParseHeaders($headers) {
        const length = StringUtils.ToInteger($headers["content-length"]);
        const isChunked = !ObjectValidator.IsEmptyOrNull($headers["transfer-encoding"]) &&
            StringUtils.ContainsIgnoreCase($headers["transfer-encoding"], "chunked");
        let fileName = "";
        const disposition = "content-disposition";
        if ($headers.hasOwnProperty(disposition)) {
            const filenameKey = "filename=";
            const dispositionValue = $headers[disposition];
            if (StringUtils.Contains(dispositionValue, "attachment;") &&
                StringUtils.Contains(dispositionValue, filenameKey)) {
                const parts = StringUtils.Split(dispositionValue, ";");
                parts.forEach(($part) => {
                    if (StringUtils.Contains($part, filenameKey) && ObjectValidator.IsEmptyOrNull(fileName)) {
                        $part = $part.trim();
                        $part = StringUtils.Remove($part, filenameKey);
                        $part = StringUtils.Remove($part, "\"");
                        fileName = ObjectDecoder.Url($part.trim());
                    }
                });
            }
        }
        return {
            fileName,
            isChunked,
            length
        };
    }
}
// generated-code-start
export const IResponsesRegister = globalThis.RegisterInterface(["running", "abort"]);
export const IDownloadResult = globalThis.RegisterInterface(["headers", "bodyOrPath"]);
export const IFSDeleteOptions = globalThis.RegisterInterface(["path", "ignoreLocked", "useRecursive", "statusHandler"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Connectors.FileSystemHandler", FileSystemHandler);
globalThis.RegisterClass("Io.Oidis.Localhost.Connectors.DownloadUtils", DownloadUtils);
globalThis.RegisterClass("Io.Oidis.Localhost.Connectors.IResponsesRegister", IResponsesRegister);
globalThis.RegisterClass("Io.Oidis.Localhost.Connectors.IDownloadResult", IDownloadResult);
globalThis.RegisterClass("Io.Oidis.Localhost.Connectors.IFSDeleteOptions", IFSDeleteOptions);
//# sourceMappingURL=FileSystemHandler.js.map