var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2023-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IModelListFilter } from "./../../../../Io/Oidis/Services/Connectors/AuthManagerConnector.js";
import { Loader } from "../Loader.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
import { Extern, Route } from "../Primitives/Decorators.js";
import { Metrics } from "../Utils/Metrics.js";
export class RuntimeHandler extends BaseConnector {
    /**
     * @param {number} $code Process exit code, defaults to 0.
     */
    Exit($code = 0) {
        Loader.getInstance().Exit($code);
    }
    /**
     * @returns {number} Returns the build timestamp as a Unix epoch value.
     */
    getBuildTime() {
        return Loader.getInstance().getAppConfiguration().build.timestamp;
    }
    /**
     * @returns {number} Returns the uptime in milliseconds.
     */
    getUpTime() {
        return Loader.getInstance().getUptime();
    }
    /**
     * @returns {string} Returns the version from the application configuration.
     */
    getVersion() {
        return Loader.getInstance().getAppConfiguration().version;
    }
    /**
     * @param {string} $filter Optional search filter for connector namespace or requester.
     * @param {IModelListFilter} $options Optional pagination options.
     * @returns {Promise<IModelListResult<IConnectorInfo>>} Returns a promise resolving to the paginated connector info.
     */
    async getConnectorsInfo($filter, $options) {
        return Loader.getInstance().getConnectorsRegister().getList($filter, $options);
    }
    /**
     * @param {Date} $date Date for which to retrieve the log.
     * @param {string} $format Log file format extension, defaults to "txt".
     * @returns {string} Returns the log file content as a string.
     */
    getLog($date, $format = "txt") {
        const fromDate = new Date($date);
        const year = fromDate.getUTCFullYear() + "";
        const day = fromDate.getUTCDate() < 10 ? "0" + fromDate.getUTCDate() : fromDate.getUTCDate() + "";
        const monthNumber = fromDate.getUTCMonth() + 1;
        const month = monthNumber < 10 ? "0" + monthNumber : monthNumber + "";
        const path = Loader.getInstance().getCwd() +
            "/log/" + year + "/" + month + "/" + day + "_" + month + "_" + year + "." + $format;
        return Loader.getInstance().getFileSystemHandler().Read(path).toString("utf-8");
    }
    /**
     * @returns {any} Returns the traffic statistics object from the metrics collector.
     */
    getTrafficStats() {
        return Metrics.getInstance().getStats();
    }
}
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", void 0)
], RuntimeHandler.prototype, "Exit", null);
__decorate([
    Extern(),
    Route("GET /application/buildTime"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Number)
], RuntimeHandler.prototype, "getBuildTime", null);
__decorate([
    Extern(),
    Route("GET /application/upTime"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Number)
], RuntimeHandler.prototype, "getUpTime", null);
__decorate([
    Extern(),
    Route("GET /application/version"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", String)
], RuntimeHandler.prototype, "getVersion", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], RuntimeHandler.prototype, "getConnectorsInfo", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Date, String]),
    __metadata("design:returntype", String)
], RuntimeHandler.prototype, "getLog", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Object)
], RuntimeHandler.prototype, "getTrafficStats", null);
globalThis.RegisterClass("Io.Oidis.Localhost.Connectors.RuntimeHandler", RuntimeHandler);
//# sourceMappingURL=RuntimeHandler.js.map