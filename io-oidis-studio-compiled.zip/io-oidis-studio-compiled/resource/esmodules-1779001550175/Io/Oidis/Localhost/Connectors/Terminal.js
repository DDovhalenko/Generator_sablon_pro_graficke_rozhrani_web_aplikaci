var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { StdinType } from "../Enums/StdinType.js";
import { ResponseFactory } from "../HttpProcessor/ResponseApi/ResponseFactory.js";
import { Loader } from "../Loader.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
import { IntegrityCheck } from "../Primitives/Decorators.js";
import { EnvironmentHelper } from "../Utils/EnvironmentHelper.js";
import { FileSystemHandler } from "./FileSystemHandler.js";
export class Terminal extends BaseConnector {
    static async terminalHandler() {
        const result = await Loader.getInstance().getTerminal().ExecuteAsync("echo", [EnvironmentHelper.IsWindows() ? "%OIDIS_INTEGRITY_CHECK_ENV%" : "$OIDIS_INTEGRITY_CHECK_ENV"], {
            env: { OIDIS_INTEGRITY_CHECK_ENV: "oidis-integrity-check-env-value" },
            verbose: false
        });
        if (!StringUtils.Contains(result.std.join(), "oidis-integrity-check-env-value")) {
            throw new Error("Basic validation of TerminalHandler failed");
        }
    }
    /**
     * @param {string} $cmd Command to execute.
     * @param {string[]} $args Command arguments.
     * @param {string | ITerminalOptions} $cwdOrOptions Working directory or options object.
     * @param {(($exitCode : number, $std? : string[]) => void) | IResponse} $callback Completion callback or response object.
     * @returns {number} Returns the process ID.
     */
    Execute($cmd, $args, $cwdOrOptions, $callback) {
        const execProcess = require("child_process").exec;
        const path = require("path");
        const fs = require("fs");
        const response = ResponseFactory.getResponse($callback);
        let cwd = $cwdOrOptions;
        const cmdOptions = {
            advanced: {
                colored: false,
                noExitOnStderr: false,
                noTerminalLog: false
            },
            shell: true,
            verbose: true,
            windowsHide: true
        };
        if (!ObjectValidator.IsSet(cwd) || ObjectValidator.IsEmptyOrNull(cwd)) {
            cwd = process.cwd();
        }
        else if (ObjectValidator.IsObject($cwdOrOptions)) {
            const options = $cwdOrOptions;
            if (ObjectValidator.IsSet(options.cwd)) {
                cwd = options.cwd;
            }
            else {
                cwd = process.cwd();
            }
            if (ObjectValidator.IsSet(options.env)) {
                cmdOptions.env = options.env;
            }
            if (ObjectValidator.IsSet(options.verbose)) {
                cmdOptions.verbose = options.verbose;
            }
            if (ObjectValidator.IsSet(options.detached)) {
                LogIt.Warning("Detached option is not supported by Execute method use Spawn instead.");
            }
            if (ObjectValidator.IsSet(options.shell)) {
                cmdOptions.shell = options.shell;
            }
            if (ObjectValidator.IsSet(options.advanced)) {
                if (ObjectValidator.IsSet(options.advanced.colored)) {
                    cmdOptions.advanced.colored = options.advanced.colored;
                }
                if (ObjectValidator.IsSet(options.advanced.noTerminalLog)) {
                    cmdOptions.advanced.noTerminalLog = options.advanced.noTerminalLog;
                }
                if (ObjectValidator.IsSet(options.advanced.noExitOnStderr)) {
                    cmdOptions.advanced.noExitOnStderr = options.advanced.noExitOnStderr;
                }
            }
        }
        if (cmdOptions.hasOwnProperty("env") && cmdOptions.env.hasOwnProperty("PATH")) {
            cmdOptions.env.PATH = this.NormalizeEnvironmentPath(cmdOptions.env.PATH);
        }
        if (!ObjectValidator.IsSet(cmdOptions.env)) {
            cmdOptions.env = process.env;
        }
        else {
            cmdOptions.env.HTTP_PROXY = process.env.HTTP_PROXY;
            cmdOptions.env.http_proxy = process.env.http_proxy;
            cmdOptions.env.HTTPS_PROXY = process.env.HTTPS_PROXY;
            cmdOptions.env.https_proxy = process.env.https_proxy;
            cmdOptions.env.NO_PROXY = process.env.NO_PROXY;
            cmdOptions.env.no_proxy = process.env.no_proxy;
        }
        if (EnvironmentHelper.IsDetached() || cmdOptions.detached) {
            if (!ObjectValidator.IsSet(cmdOptions.env)) {
                cmdOptions.env = process.env;
            }
            cmdOptions.env.IS_OIDIS_DETACHED_PROCESS = "1";
        }
        if (!ObjectValidator.IsSet($args) || ObjectValidator.IsEmptyOrNull($args)) {
            $args = [];
        }
        if (cmdOptions.verbose) {
            if (!cmdOptions.advanced.noTerminalLog) {
                LogIt.Info(cwd + " > " + $cmd + " " + $args.join(" "));
            }
        }
        else {
            LogIt.Info("Execute process in silent mode at: " + cwd);
        }
        let counter = 0;
        const progress = setInterval(() => {
            if (counter < 100) {
                if (cmdOptions.verbose && !cmdOptions.advanced.noTerminalLog) {
                    Echo.Print(".");
                }
            }
            else {
                if (cmdOptions.verbose && !cmdOptions.advanced.noTerminalLog) {
                    Echo.Println(".");
                }
                counter = 0;
            }
            response.OnChange(".");
            counter++;
        }, 250);
        let exitCode = -1;
        const onExitHandler = ($exitCode, $stdout, $stderr) => {
            clearInterval(progress);
            $stdout = this.normalizeStdout($stdout, cmdOptions.advanced.colored);
            $stderr = this.normalizeStdout($stderr, cmdOptions.advanced.colored);
            if (cmdOptions.verbose) {
                Echo.Println("");
                LogIt.Info($stdout + $stderr);
            }
            if (!cmdOptions.advanced.noTerminalLog) {
                LogIt.Info("exit code: " + $exitCode);
            }
            response.OnComplete($exitCode, [$stdout, $stderr]);
        };
        response.OnStart();
        try {
            cmdOptions.cwd = cwd.replace(/[/\\]/g, path.sep);
            let tmpCmd = path.normalize(StringUtils.Remove($cmd, "\""));
            if (fs.existsSync(tmpCmd)) {
                if (this.checkWuiApp(tmpCmd)) {
                    $args.push("--disable-console");
                }
            }
            else {
                tmpCmd = path.normalize(cmdOptions.cwd + "/" + tmpCmd);
                if (fs.existsSync(tmpCmd)) {
                    if (this.checkWuiApp(tmpCmd)) {
                        $args.push("--disable-console");
                    }
                }
            }
            const child = execProcess($cmd + " " + $args.join(" "), cmdOptions, ($error, $stdout, $stderr) => {
                onExitHandler(exitCode, $stdout, $stderr);
            });
            child.on("exit", ($exitCode) => {
                if (!ObjectValidator.IsEmptyOrNull($exitCode)) {
                    exitCode = $exitCode;
                }
            });
            response.AddAbortHandler(() => {
                const process = cmdOptions.verbose ? ($cmd + " " + $args.join(" ")) : "";
                LogIt.Warning(cmdOptions.cwd + ">" + process + " Process kill requested by abort.");
                child.kill("SIGINT");
            });
            return child.pid;
        }
        catch (ex) {
            onExitHandler(-1, "", ex.message);
            LogIt.Info(ex.stack);
        }
        return -1;
    }
    /**
     * @param {string} $cmd Command to execute.
     * @param {string[]} $args Command arguments.
     * @param {string | ITerminalOptions} $cwdOrOptions Working directory or options object.
     * @returns {Promise<IExecuteResult>} Returns a promise resolving to the exit code and standard output.
     */
    async ExecuteAsync($cmd, $args, $cwdOrOptions) {
        return await new Promise(($resolve) => {
            this.Execute($cmd, $args, $cwdOrOptions, ($exitCode, $std) => {
                $resolve({ exitCode: $exitCode, std: $std });
            });
        });
    }
    /**
     * @param {string} $cmd Command to spawn.
     * @param {string[]} $args Command arguments.
     * @param {string | ITerminalOptions} $cwdOrOptions Working directory or options object.
     * @param {(($exitCode : number, $std? : string[]) => void) | IResponse} $callback Completion callback or response object.
     * @returns {number} Returns the process ID.
     */
    Spawn($cmd, $args, $cwdOrOptions, $callback) {
        const spawn = require("child_process").spawn;
        const pathNormalize = require("path").normalize;
        const fs = require("fs");
        const response = ResponseFactory.getResponse($callback);
        const cmdOptions = {
            advanced: {
                colored: false,
                noExitOnStderr: false,
                noTerminalLog: false,
                useStdIn: false
            },
            detached: false,
            shell: true,
            verbose: true,
            windowsHide: true
        };
        let cwd = $cwdOrOptions;
        const colored = false;
        if (!ObjectValidator.IsSet($cwdOrOptions) || ObjectValidator.IsEmptyOrNull($cwdOrOptions)) {
            cwd = process.cwd();
        }
        else if (ObjectValidator.IsObject($cwdOrOptions)) {
            const options = $cwdOrOptions;
            if (ObjectValidator.IsSet(options.cwd)) {
                cwd = options.cwd;
            }
            else {
                cwd = process.cwd();
            }
            if (ObjectValidator.IsSet(options.env)) {
                cmdOptions.env = options.env;
            }
            if (ObjectValidator.IsSet(options.verbose)) {
                cmdOptions.verbose = options.verbose;
            }
            if (ObjectValidator.IsSet(options.detached)) {
                cmdOptions.detached = options.detached;
            }
            if (ObjectValidator.IsSet(options.shell)) {
                cmdOptions.shell = options.shell;
            }
            if (ObjectValidator.IsSet(options.advanced)) {
                if (ObjectValidator.IsSet(options.advanced.colored)) {
                    cmdOptions.advanced.colored = options.advanced.colored;
                }
                if (ObjectValidator.IsSet(options.advanced.noTerminalLog)) {
                    cmdOptions.advanced.noTerminalLog = options.advanced.noTerminalLog;
                }
                if (ObjectValidator.IsSet(options.advanced.noExitOnStderr)) {
                    cmdOptions.advanced.noExitOnStderr = options.advanced.noExitOnStderr;
                }
                if (ObjectValidator.IsSet(options.advanced.useStdIn)) {
                    cmdOptions.advanced.useStdIn = options.advanced.useStdIn;
                }
            }
        }
        cmdOptions.cwd = cwd;
        if (cmdOptions.hasOwnProperty("env") && cmdOptions.env.hasOwnProperty("PATH")) {
            cmdOptions.env.PATH = this.NormalizeEnvironmentPath(cmdOptions.env.PATH);
        }
        if (!ObjectValidator.IsEmptyOrNull(Loader.getInstance().getAppConfiguration().httpProxy)) {
            if (!ObjectValidator.IsSet(cmdOptions.env)) {
                cmdOptions.env = process.env;
            }
            cmdOptions.env.HTTP_PROXY = process.env.HTTP_PROXY;
            cmdOptions.env.http_proxy = process.env.http_proxy;
            cmdOptions.env.HTTPS_PROXY = process.env.HTTPS_PROXY;
            cmdOptions.env.https_proxy = process.env.https_proxy;
        }
        if (!ObjectValidator.IsSet($args) || ObjectValidator.IsEmptyOrNull($args)) {
            $args = [];
        }
        if (cmdOptions.verbose) {
            if (!cmdOptions.advanced.noTerminalLog) {
                LogIt.Info(cwd + " > " + $cmd + " " + $args.join(" "));
            }
        }
        else {
            LogIt.Info("Spawn process in silent mode at: " + cwd);
        }
        let fired = false;
        let stdout = "";
        let stderr = "";
        const onExitHandler = ($exitCode) => {
            if (!fired) {
                fired = true;
                if (!cmdOptions.advanced.noTerminalLog) {
                    LogIt.Info("exit code: " + $exitCode);
                }
                response.OnComplete($exitCode, [stdout, stderr]);
            }
        };
        const onErrorHandler = ($error) => {
            stderr += $error.message;
            LogIt.Info($error.stack);
            onExitHandler(-1);
        };
        try {
            let tmpCmd = pathNormalize(StringUtils.Remove($cmd, "\""));
            if (fs.existsSync(tmpCmd)) {
                if (this.checkWuiApp(tmpCmd)) {
                    $args.push("--disable-console");
                }
            }
            else {
                tmpCmd = pathNormalize(cmdOptions.cwd + "/" + tmpCmd);
                if (fs.existsSync(tmpCmd)) {
                    if (this.checkWuiApp(tmpCmd)) {
                        $args.push("--disable-console");
                    }
                }
            }
            if (cmdOptions.detached) {
                cmdOptions.stdio = ["pipe", "pipe", "pipe", "ipc"];
            }
            else if (cmdOptions.advanced.useStdIn) {
                cmdOptions.stdio = ["inherit", "pipe", "pipe"];
            }
            if (EnvironmentHelper.IsDetached() || cmdOptions.detached) {
                if (!ObjectValidator.IsSet(cmdOptions.env)) {
                    cmdOptions.env = process.env;
                }
                cmdOptions.env.IS_OIDIS_DETACHED_PROCESS = "1";
            }
            response.OnStart();
            const child = cmdOptions.shell ?
                spawn($cmd + " " + $args.join(" "), [], cmdOptions) :
                spawn($cmd, $args, cmdOptions);
            child.on("exit", onExitHandler);
            child.on("close", onExitHandler);
            child.on("error", onErrorHandler);
            child.stdout.on("data", ($data) => {
                $data = this.normalizeStdout($data, colored);
                if ($data.includes(StdinType.STRING) || $data.includes(StdinType.PASS)) {
                    response.OnChange($data, child.stdin);
                }
                else {
                    stdout += $data;
                    if (cmdOptions.verbose) {
                        Echo.Print($data);
                    }
                    response.OnChange($data);
                }
            });
            child.stderr.on("data", ($data) => {
                $data = this.normalizeStdout($data, colored);
                stderr += $data;
                if (cmdOptions.verbose) {
                    Echo.Print($data);
                }
                response.OnChange($data);
                if (cmdOptions.advanced.noExitOnStderr) {
                    if ($data.toLowerCase().includes("fatal:") ||
                        $data.toLowerCase().includes("error:")) {
                        onExitHandler(-1);
                    }
                }
            });
            if (cmdOptions.detached) {
                child.on("message", ($data) => {
                    $data = this.normalizeStdout($data, colored);
                    stdout += $data;
                    if (cmdOptions.verbose) {
                        Echo.Print($data);
                    }
                    response.OnChange($data);
                });
            }
            response.AddAbortHandler(() => {
                const process = cmdOptions.verbose ? ($cmd + " " + $args.join(" ")) : "";
                LogIt.Warning(cmdOptions.cwd + ">" + process + " Process kill requested by abort.");
                child.kill("SIGINT");
            });
            return child.pid;
        }
        catch (ex) {
            onErrorHandler(ex);
        }
        return -1;
    }
    /**
     * @param {string} $cmd Command to spawn.
     * @param {string[]} $args Command arguments.
     * @param {string | ITerminalOptions} $cwdOrOptions Working directory or options object.
     * @returns {Promise<IExecuteResult>} Returns a promise resolving to the exit code and standard output.
     */
    async SpawnAsync($cmd, $args, $cwdOrOptions) {
        return await new Promise(($resolve) => {
            this.Spawn($cmd, $args, $cwdOrOptions, ($exitCode, $std) => {
                $resolve({ exitCode: $exitCode, std: $std });
            });
        });
    }
    /**
     * @param {string} $path File path or URL to open.
     * @param {(($exitCode : number) => void) | IResponse} $callback Completion callback or response object.
     * @returns {number} Returns the process ID or -1 on failure.
     */
    Open($path, $callback) {
        const exec = require("child_process").exec;
        const onOpenHandler = ($error, $data) => {
            if ($error !== null) {
                LogIt.Info($error);
            }
            LogIt.Info($data.toString());
            ResponseFactory.getResponse($callback).Send($error === null ? 0 : -1);
        };
        LogIt.Info("open > " + $path);
        if (ObjectValidator.IsEmptyOrNull($path)) {
            onOpenHandler(-1, "Undefined or empty path for open.");
        }
        else {
            return exec(FileSystemHandler.getInstance()
                .NormalizePath($path, true), { windowsHide: true }, onOpenHandler).pid;
        }
        return -1;
    }
    /**
     * @param {string} $path File path or URL to open.
     * @returns {Promise<number>} Returns a promise resolving to the exit code.
     */
    async OpenAsync($path) {
        return await new Promise(($resolve) => {
            this.Open($path, ($exitCode) => {
                $resolve($exitCode);
            });
        });
    }
    /**
     * @param {string} $cmd Command to execute with elevated privileges.
     * @param {string[]} $args Command arguments.
     * @param {string} $cwd Working directory for the elevated process.
     * @param {(($exitCode : number, $std? : string[]) => void) | IResponse} $callback Completion callback or response object.
     * @returns {number} Returns the process ID.
     */
    Elevate($cmd, $args, $cwd, $callback) {
        const pathSeparator = require("path").sep;
        let cmd;
        let args;
        if (EnvironmentHelper.IsWindows()) {
            cmd = "powershell.exe";
            args = [
                "-Command \"(Start-Process " +
                    "-WindowStyle hidden '" + $cmd + "' " +
                    (ObjectValidator.IsEmptyOrNull($args) ? "" : "-ArgumentList '" + $args.join(" ") + "' ") +
                    "-Verb RunAs " +
                    "-PassThru).Id\""
            ];
        }
        else {
            cmd = "sudo";
            args = [$cmd];
            if (!ObjectValidator.IsEmptyOrNull($args)) {
                $args.forEach(($arg) => {
                    args.push($arg);
                });
            }
        }
        if (ObjectValidator.IsEmptyOrNull($cwd)) {
            cmd = "cd \"" + $cwd.replace(/\//gi, pathSeparator) + "\" && " + cmd;
        }
        return this.Execute(cmd, args, null, ($exitCode, $std) => {
            ResponseFactory.getResponse($callback).Send($exitCode, $std);
        });
    }
    /**
     * @param {string} $cmd Command to execute with elevated privileges.
     * @param {string[]} $args Command arguments.
     * @param {string} $cwd Working directory for the elevated process.
     * @returns {Promise<IExecuteResult>} Returns a promise resolving to the exit code and standard output.
     */
    async ElevateAsync($cmd, $args, $cwd) {
        return await new Promise(($resolve) => {
            this.Elevate($cmd, $args, $cwd, ($exitCode, $std) => {
                $resolve({ exitCode: $exitCode, std: $std });
            });
        });
    }
    /**
     * @param {string} $input Custom PATH string to normalize and prepend.
     * @returns {string} Returns the merged PATH string with OS-appropriate separators.
     */
    NormalizeEnvironmentPath($input) {
        const envSeparator = EnvironmentHelper.IsWindows() ? ";" : ":";
        if (EnvironmentHelper.IsWindows()) {
            $input = StringUtils.Replace($input, "/", "\\");
        }
        else {
            $input = StringUtils.Replace($input, "\\", "/");
        }
        if (!StringUtils.EndsWith($input, envSeparator)) {
            $input += envSeparator;
        }
        let systemPath = process.env.PATH;
        $input = StringUtils.Replace($input, envSeparator + envSeparator, envSeparator);
        StringUtils.Split($input, envSeparator).forEach(($path) => {
            if ($path !== "") {
                systemPath = StringUtils.Replace(systemPath, $path + envSeparator, "");
            }
        });
        if (!StringUtils.EndsWith($input, envSeparator)) {
            $input += envSeparator;
        }
        return StringUtils.Replace($input + systemPath, envSeparator + envSeparator, envSeparator);
    }
    /**
     * @param {string} $pathOrName Executable path or process name to kill.
     * @param {(($status : boolean) => void) | IResponse} $callback Completion callback or response object.
     */
    Kill($pathOrName, $callback) {
        const path = require("path");
        const response = ResponseFactory.getResponse($callback);
        let binPath = StringUtils.Replace($pathOrName, "\\", "/");
        binPath = StringUtils.Replace(binPath, "/", path.sep);
        const binName = path.basename(binPath);
        const killAll = binPath === binName;
        if (EnvironmentHelper.IsWindows()) {
            this.Execute("wmic", [
                "process", "where name=\"" + binName + "\" get processid, executablepath"
            ], {
                verbose: false
            }, ($exitCode, $std) => {
                if ($exitCode === 0) {
                    const outList = $std[0].trim();
                    if (!ObjectValidator.IsEmptyOrNull(outList)) {
                        const entries = StringUtils.Split(StringUtils.Remove(outList, "\r"), "\n");
                        let status = true;
                        entries.forEach(($item) => {
                            if (!ObjectValidator.IsEmptyOrNull($item)) {
                                const parts = $item.trim().replace(/\s+/g, "*").split("*");
                                if (parts.length >= 2 && StringUtils.ContainsIgnoreCase(parts[0], killAll ? binPath : binName)) {
                                    const pid = StringUtils.ToInteger(parts[1]);
                                    if (pid !== process.pid) {
                                        try {
                                            process.kill(pid);
                                        }
                                        catch (ex) {
                                            status = false;
                                            LogIt.Warning("Failed to kill process with PID " + parts[1] + ": " + ex.message);
                                        }
                                    }
                                }
                            }
                        });
                        response.Send(status);
                    }
                    else {
                        response.Send(true);
                    }
                }
                else {
                    LogIt.Warning($std[0] + $std[1]);
                    response.Send(false);
                }
            });
        }
        else if (EnvironmentHelper.IsMac()) {
            // TODO(mkelnar) add kill implementation for macos (/proc folder not exist on macos)
            LogIt.Warning("Kill is not implemented on MacOS.");
            response.Send(false);
        }
        else {
            let pids = [];
            let status = true;
            const killProcess = ($index) => {
                if ($index < pids.length) {
                    if (!ObjectValidator.IsEmptyOrNull(pids[$index])) {
                        this.Execute("ls", ["-l", "/proc/" + pids[$index] + "/exe"], {
                            verbose: false
                        }, ($exitCode, $std) => {
                            if ($exitCode === 0) {
                                const processInfo = $std[0].trim();
                                if (!ObjectValidator.IsEmptyOrNull(processInfo)) {
                                    const parts = StringUtils.Split(processInfo, " -> ");
                                    if (parts.length >= 2 && StringUtils.ContainsIgnoreCase(parts[1], killAll ? binPath : binName)) {
                                        const pid = StringUtils.ToInteger(pids[$index]);
                                        if (pid !== process.pid) {
                                            try {
                                                process.kill(pid);
                                            }
                                            catch (ex) {
                                                LogIt.Warning("Failed to kill process with PID " + pids[$index] + ": " + ex.message);
                                                status = false;
                                            }
                                        }
                                    }
                                }
                            }
                            else {
                                LogIt.Warning($std[0] + $std[1]);
                                status = false;
                            }
                            killProcess($index + 1);
                        });
                    }
                    else {
                        killProcess($index + 1);
                    }
                }
                else {
                    response.Send(status);
                }
            };
            this.Execute("pgrep", ["\"" + binName + "\""], {
                verbose: false
            }, ($exitCode, $std) => {
                if ($exitCode === 0 || ($exitCode === 1 && ObjectValidator.IsEmptyOrNull($std[0] + $std[1]))) {
                    const outList = $std[0].trim();
                    if (!ObjectValidator.IsEmptyOrNull(outList)) {
                        pids = StringUtils.Split(outList, "\n");
                        killProcess(0);
                    }
                    else {
                        response.Send(true);
                    }
                }
                else {
                    LogIt.Warning($std[0] + $std[1]);
                    response.Send(false);
                }
            });
        }
    }
    /**
     * @param {string} $pathOrName Executable path or process name to kill.
     * @returns {Promise<void>} Returns a promise that resolves when the process is killed.
     */
    async KillAsync($pathOrName) {
        return await new Promise(($resolve, $reject) => {
            this.Kill($pathOrName, ($status) => {
                if ($status) {
                    $resolve();
                }
                else {
                    $reject(new Error("Process kill failed."));
                }
            });
        });
    }
    normalizeStdout($value, $colorized = false) {
        const os = require("os");
        $value = Buffer.from($value + "").toString("utf8")
            .replace(/█/gm, "[__BAR__]")
            .replace(/▇/gm, "[__BAR__]")
            .replace(/✓/gm, "[__OK__]")
            .replace(/×/gm, "[__FAIL__]")
            .replace(/→/gm, "[__ARROW__]")
            .replace(/\r\n/gm, "\n")
            .replace(/\n/gm, "[__EOL__]");
        if (!$colorized) {
            try {
                $value = $value.replace(// eslint-disable-next-line no-control-regex
                /[\u001b\u009b][[()#;?]*(?:[0-9]{1,4}(?:;[0-9]{0,4})*)?[0-9A-ORZcf-nqry=><]/g, "");
            }
            catch ($ex) {
                // let std as is
            }
            $value = $value.replace(/[^ -~]+/g, "");
        }
        $value = $value.replace(/\[__EOL__\]/gm, os.EOL);
        if ($value.match(/(\(.*\d+\/\d+\))?.*\[[#-]+\].*%/gm) !== null) {
            $value = $value.replace(/%/gm, "%" + os.EOL);
        }
        return $value;
    }
    checkWuiApp($path) {
        let status = false;
        if (EnvironmentHelper.IsWindows()) {
            try {
                const filePath = require("path").normalize(StringUtils.Remove($path, "\""));
                if (require("fs").existsSync(filePath)) {
                    const verInfo = require("win-version-info")(filePath);
                    if (!ObjectValidator.IsEmptyOrNull(verInfo) &&
                        verInfo.hasOwnProperty("BaseProjectName") && (StringUtils.StartsWith(verInfo.BaseProjectName, "io-oidis-") ||
                        StringUtils.StartsWith(verInfo.BaseProjectName, "com-wui-framework-"))) {
                        LogIt.Info("Executing command has been found as Oidis Framework application.");
                        status = true;
                    }
                }
            }
            catch (ex) {
                // Can not read version info. Executable will be processed as default.
            }
        }
        else {
            this.checkWuiApp = ($path) => {
                return false;
            };
        }
        return status;
    }
}
__decorate([
    IntegrityCheck(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], Terminal, "terminalHandler", null);
// generated-code-start
export const IExecuteResult = globalThis.RegisterInterface(["exitCode", "std"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Connectors.Terminal", Terminal);
globalThis.RegisterClass("Io.Oidis.Localhost.Connectors.IExecuteResult", IExecuteResult);
//# sourceMappingURL=Terminal.js.map