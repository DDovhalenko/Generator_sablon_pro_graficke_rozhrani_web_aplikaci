/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2026 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "./../../../../Io/Oidis/Commons/Primitives/BaseEnum.js";
import { isBrowser } from "./../../../../Io/Oidis/Commons/Utils/EnvironmentHelper.js";
import { isMainThread } from "../Utils/EnvironmentHelper.js";
export class ColorType extends BaseEnum {
    static YELLOW = "yellow";
    static RED = "red";
    static GREEN = "green";
    /**
     * @param {string} $input String to underline.
     * @returns {string} Returns the underlined string.
     */
    static Underline($input) {
        if (!isBrowser && isMainThread) {
            return require("colors").underline($input);
        }
        return $input;
    }
    /**
     * @param {string} $input String to colorize.
     * @param {ColorType} $type Color type to apply.
     * @returns {string} Returns the colorized string.
     */
    static setColor($input, $type) {
        if (!isBrowser && isMainThread) {
            return require("colors")[$type]($input);
        }
        return $input;
    }
}
if (!isBrowser) {
    Object.defineProperty(String.prototype, "underline", {
        get() {
            return ColorType.Underline(this.toString());
        }
    });
    [
        ColorType.YELLOW,
        ColorType.RED,
        ColorType.GREEN
    ].forEach(($value) => {
        Object.defineProperty(String.prototype, $value, {
            get() {
                return ColorType.setColor(this.toString(), $value);
            }
        });
    });
    String.prototype.setColor = function ($type) {
        return ColorType.setColor(this.toString(), $type);
    };
    String.prototype.Underline = function () {
        return ColorType.Underline(this.toString());
    };
}
globalThis.RegisterClass("Io.Oidis.Localhost.Enums.ColorType", ColorType);
//# sourceMappingURL=ColorType.js.map