/*! ******************************************************************************************************** *
 *
 * Copyright 2021-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { LogAdapterType as Parent } from "./../../../../Io/Oidis/Commons/Enums/LogAdapterType.js";
export class LogAdapterType extends Parent {
    static FILE = "FILE";
    static STD = "STD";
    static JSON = "JSON";
}
globalThis.RegisterClass("Io.Oidis.Localhost.Enums.LogAdapterType", LogAdapterType);
//# sourceMappingURL=LogAdapterType.js.map