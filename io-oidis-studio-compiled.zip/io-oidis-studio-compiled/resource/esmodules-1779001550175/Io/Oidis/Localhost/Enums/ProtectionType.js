/*! ******************************************************************************************************** *
 *
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "./../../../../Io/Oidis/Commons/Primitives/BaseEnum.js";
export class ProtectionType extends BaseEnum {
    static ENCRYPTION = "ENCRYPTION";
    static HASH = "HASH";
    static SIGNATURE = "SIGNATURE";
    static NONE = "NONE";
}
globalThis.RegisterClass("Io.Oidis.Localhost.Enums.ProtectionType", ProtectionType);
//# sourceMappingURL=ProtectionType.js.map