/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "./../../../../Io/Oidis/Commons/Primitives/BaseEnum.js";
export class StdinType extends BaseEnum {
    static STRING = "__[STDIN:STRING]__";
    static PASS = "__[STDIN:PASS]__";
}
globalThis.RegisterClass("Io.Oidis.Localhost.Enums.StdinType", StdinType);
//# sourceMappingURL=StdinType.js.map