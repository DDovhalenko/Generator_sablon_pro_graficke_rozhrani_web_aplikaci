/*! ******************************************************************************************************** *
 *
 * Copyright 2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EnvironmentArgs as Parent } from "./../../../Io/Oidis/Commons/EnvironmentArgs.js";
import { ObjectValidator } from "./../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { ScriptHandler } from "./IOApi/Handlers/ScriptHandler.js";
import { Loader } from "./Loader.js";
import { EnvironmentHelper } from "./Utils/EnvironmentHelper.js";
import { SchemaValidator } from "./Utils/SchemaValidator.js";
export class EnvironmentArgs extends Parent {
    isDebug;
    constructor() {
        super();
        this.isDebug = process.argv.includes("--debug");
    }
    /**
     * @returns {boolean} Returns false for server-side execution.
     */
    HtmlOutputAllowed() {
        return false;
    }
    /**
     * @returns {number} Returns the process PID.
     */
    getProcessID() {
        return process.pid;
    }
    /**
     * @returns {IProject} Returns the project configuration.
     */
    getProjectConfig() {
        return super.getProjectConfig();
    }
    getConfigPaths() {
        let paths = super.getConfigPaths();
        if (!this.HtmlOutputAllowed()) {
            paths = [];
            let cwd = EnvironmentHelper.getNodejsRoot();
            if (StringUtils.Contains(cwd, "/dependencies/nodejs")) {
                cwd = StringUtils.Replace(cwd, "/dependencies/nodejs", "/build/target");
            }
            if (StringUtils.Contains(cwd, "/build/target")) {
                const privateConfPath = StringUtils.Remove(cwd + "/private.conf.json", "/build/target");
                paths.push(privateConfPath + "p");
                paths.push(privateConfPath);
            }
            else {
                const appName = this.getAppName();
                const getAppConfigs = ($cwd) => {
                    paths.push($cwd + "/" + appName + ".conf.json");
                    paths.push($cwd + "/" + appName + ".config.jsonp");
                };
                paths.push(cwd + "/" + appName + ".config.jsonp");
                paths.push(cwd + "/private.conf.json");
                getAppConfigs(cwd + "/..");
                let appDataPath = this.getProjectConfig().target.appDataPath;
                if (!ObjectValidator.IsEmptyOrNull(appDataPath)) {
                    appDataPath = StringUtils.Replace(appDataPath, "\\", "/");
                    this.getProjectConfig().target.appDataPath = appDataPath;
                    getAppConfigs(appDataPath);
                }
            }
        }
        return paths;
    }
    fileLoaderClass() {
        return ScriptHandler;
    }
    validate($config) {
        let passed = false;
        const validator = this.getValidator();
        if (!ObjectValidator.IsEmptyOrNull(validator)) {
            try {
                const errors = validator.Validate($config.data);
                if (!ObjectValidator.IsEmptyOrNull(errors)) {
                    this.printHandler("ERROR: invalid configuration detected at: " + $config.path + "\n" +
                        validator.ErrorsToString(errors), true);
                }
                else {
                    passed = true;
                }
            }
            catch (ex) {
                this.printHandler("> failed validation of " + $config.path + " " + ex.stack);
            }
        }
        else {
            this.printHandler("> validator is empty");
        }
        if (!passed || !super.validate($config)) {
            Loader.getInstance().Exit(-1);
            return false;
        }
        return true;
    }
    printHandler($message, $force = false) {
        if (this.isDebug || $force) {
            console.log($message); // eslint-disable-line no-console
        }
    }
    errorHandler($error, $path) {
        if (StringUtils.ContainsIgnoreCase($error.message, "Unable to find script")) {
            return super.errorHandler($error, $path);
        }
        this.printHandler("ERROR: " + (ObjectValidator.IsSet($error.stack) ? $error.stack : $error.message), true);
        Loader.getInstance().Exit(-1);
    }
    getValidator() {
        let validator = null;
        try {
            validator = new SchemaValidator();
            validator.Schema(__dirname + "/../../resource/configs/package.conf.schema.json");
            validator.ErrorHandler(($error) => {
                this.printHandler($error.message);
            });
        }
        catch (ex) {
            this.printHandler("> failed initialization of config validator\n" + ex.stack);
        }
        this.getValidator = () => {
            return validator;
        };
        return validator;
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.EnvironmentArgs", EnvironmentArgs);
//# sourceMappingURL=EnvironmentArgs.js.map