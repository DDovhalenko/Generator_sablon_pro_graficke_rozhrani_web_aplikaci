var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2022-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpStatusType } from "./../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { BrowserErrorPage as Parent } from "./../../../../Io/Oidis/Gui/ErrorPages/BrowserErrorPage.js";
import { StaticPageContentManager } from "./../../../../Io/Oidis/Gui/Utils/StaticPageContentManager.js";
import { HttpServer } from "../HttpProcessor/HttpServer.js";
import { Resolver } from "./../../../../Io/Oidis/Commons/Primitives/Decorators.js";
let BrowserErrorPage = class BrowserErrorPage extends Parent {
    Process() {
        super.Process();
        HttpServer.SendData(this.getRequest(), this.RequestArgs().POST().getItem("Connector"), HttpStatusType.NOT_ACCEPTABLE, {}, StaticPageContentManager.ToString());
    }
};
BrowserErrorPage = __decorate([
    Resolver("/ServerError/Browser")
], BrowserErrorPage);
export { BrowserErrorPage };
globalThis.RegisterClass("Io.Oidis.Localhost.ErrorPages.BrowserErrorPage", BrowserErrorPage);
//# sourceMappingURL=BrowserErrorPage.js.map