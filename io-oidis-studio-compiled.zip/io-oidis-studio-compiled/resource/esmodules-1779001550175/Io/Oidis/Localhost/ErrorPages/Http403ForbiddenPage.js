var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2022-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpStatusType } from "./../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { Http403ForbiddenPage as Parent } from "./../../../../Io/Oidis/Gui/ErrorPages/Http403ForbiddenPage.js";
import { StaticPageContentManager } from "./../../../../Io/Oidis/Gui/Utils/StaticPageContentManager.js";
import { HttpServer } from "../HttpProcessor/HttpServer.js";
import { Resolver } from "./../../../../Io/Oidis/Commons/Primitives/Decorators.js";
let Http403ForbiddenPage = class Http403ForbiddenPage extends Parent {
    Process() {
        super.Process();
        HttpServer.SendData(this.getRequest(), this.RequestArgs().POST().getItem("Connector"), HttpStatusType.FORBIDDEN, {}, StaticPageContentManager.ToString());
    }
};
Http403ForbiddenPage = __decorate([
    Resolver("/ServerError/Http/Forbidden")
], Http403ForbiddenPage);
export { Http403ForbiddenPage };
globalThis.RegisterClass("Io.Oidis.Localhost.ErrorPages.Http403ForbiddenPage", Http403ForbiddenPage);
//# sourceMappingURL=Http403ForbiddenPage.js.map