var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2010-2013 Jakub Cieslar
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpStatusType } from "./../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { Http404NotFoundPage as Parent } from "./../../../../Io/Oidis/Gui/ErrorPages/Http404NotFoundPage.js";
import { StaticPageContentManager } from "./../../../../Io/Oidis/Gui/Utils/StaticPageContentManager.js";
import { HttpServer } from "../HttpProcessor/HttpServer.js";
import { Resolver } from "./../../../../Io/Oidis/Commons/Primitives/Decorators.js";
let Http404NotFoundPage = class Http404NotFoundPage extends Parent {
    Process() {
        super.Process();
        HttpServer.SendData(this.getRequest(), this.RequestArgs().POST().getItem("Connector"), HttpStatusType.NOT_FOUND, {}, StaticPageContentManager.ToString());
    }
};
Http404NotFoundPage = __decorate([
    Resolver("/ServerError/Http/NotFound")
], Http404NotFoundPage);
export { Http404NotFoundPage };
globalThis.RegisterClass("Io.Oidis.Localhost.ErrorPages.Http404NotFoundPage", Http404NotFoundPage);
//# sourceMappingURL=Http404NotFoundPage.js.map