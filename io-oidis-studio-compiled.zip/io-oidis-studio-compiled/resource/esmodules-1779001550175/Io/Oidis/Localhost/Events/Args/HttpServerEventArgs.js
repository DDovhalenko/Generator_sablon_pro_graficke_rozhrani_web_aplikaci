/*! ******************************************************************************************************** *
 *
 * Copyright 2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventArgs } from "./../../../../../Io/Oidis/Commons/Events/Args/EventArgs.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
export class HttpServerEventArgs extends EventArgs {
    port;
    clientId;
    /**
     * @param {number} $port Server port number.
     * @param {number} $clientId Optional client connection identifier.
     */
    constructor($port, $clientId) {
        super();
        this.port = $port;
        this.clientId = $clientId;
    }
    /**
     * @param {number} $value Optional port value to set.
     * @returns {number} Returns the current port number.
     */
    Port($value) {
        return this.port = Property.Integer(this.port, $value);
    }
    /**
     * @param {number} $value Optional client ID value to set.
     * @returns {number} Returns the current client ID or undefined if not set.
     */
    ClientId($value) {
        return this.clientId = Property.Integer(this.clientId, $value);
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.Events.Args.HttpServerEventArgs", HttpServerEventArgs);
//# sourceMappingURL=HttpServerEventArgs.js.map