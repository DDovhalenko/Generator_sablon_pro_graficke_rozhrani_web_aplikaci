import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { EventType } from "./../../../../Io/Oidis/Gui/Enums/Events/EventType.js";
import { GeneralEventOwner } from "./../../../../Io/Oidis/Gui/Enums/Events/GeneralEventOwner.js";
import { EventsManager as Parent } from "./../../../../Io/Oidis/Gui/Events/EventsManager.js";
import { Loader } from "../Loader.js";
export class EventsManager extends Parent {
    Subscribe() {
        if (!Loader.getInstance().getEnvironmentArgs().HtmlOutputAllowed()) {
            const onResolveRequestHandler = ($eventArgs) => {
                LogIt.Debug("Back-end internal request detected for: {0}", $eventArgs.Url());
                Loader.getInstance().getHttpResolver().ResolveRequest($eventArgs);
            };
            this.setEvent(GeneralEventOwner.WINDOW, EventType.ON_HTTP_REQUEST, onResolveRequestHandler);
            this.setEvent(GeneralEventOwner.WINDOW, EventType.ON_ASYNC_REQUEST, onResolveRequestHandler);
        }
        else {
            super.Subscribe();
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.Events.EventsManager", EventsManager);
//# sourceMappingURL=EventsManager.js.map