/*! ******************************************************************************************************** *
 *
 * Copyright 2022-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
export class ErrorLocalizable extends Error {
    /** Localization map for error message translations. */
    localizations;
    /**
     * @param {string} $message Error message.
     * @param {ILocalization} $localizations Optional localization map.
     */
    constructor($message, $localizations) {
        super($message);
        this.localizations = $localizations;
        if (ObjectValidator.IsEmptyOrNull(this.localizations)) {
            this.localizations = {};
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.Exceptions.Type.ErrorLocalizable", ErrorLocalizable);
//# sourceMappingURL=ErrorLocalizable.js.map