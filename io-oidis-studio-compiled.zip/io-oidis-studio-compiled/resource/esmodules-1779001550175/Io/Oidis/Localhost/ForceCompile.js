/*! ******************************************************************************************************** *
 *
 * Copyright 2022-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
// Main goal of this file is to provide ability to force process of TS compile by list of imports below
// Reason for this is that source code can contain classes used only over LCP or by target project
// If not mentioned here it can be missing at runtime and cause also target project loading issues
import "./Connectors/Elastic.js";
import "./Connectors/RuntimeHandler.js";
import "./WebServiceApi/Clients/WebSocket.js";
import "./ErrorPages/BrowserErrorPage.js";
import "./ErrorPages/ExceptionErrorPage.js";
import "./ErrorPages/Http301MovedPage.js";
import "./ErrorPages/Http403ForbiddenPage.js";
import "./ErrorPages/Http404NotFoundPage.js";
import "./HttpProcessor/Resolvers/AcmeResolver.js";
import "./HttpProcessor/Resolvers/ConnectorResponse.js";
import "./HttpProcessor/Resolvers/CSPReportResolver.js";
import "./HttpProcessor/Resolvers/FileRequestResolver.js";
import "./HttpProcessor/Resolvers/FrontEndLoader.js";
import "./HttpProcessor/Resolvers/LiveContentResolver.js";
import "./HttpProcessor/Resolvers/LoaderResolver.js";
import "./HttpProcessor/Resolvers/MapFilesPatchResolver.js";
import "./HttpProcessor/Resolvers/RESTResolver.js";
import "./HttpProcessor/Resolvers/XOriginInterface.js";
import "./HttpProcessor/Resolvers/XOriginServices.js";
/* dev:start */
import "./RuntimeTests/ExternAndRouteTestHandler.js";
import "./RuntimeTests/MockAuthConnector.js";
import "./RuntimeTests/RestServiceTestHandler.js";
/* dev:end */
// generated-code-start
import "./Utils/Cron.js";
import "./HttpProcessor/Resolvers/SentryTunnelResolver.js";
import "./Gui/Index.js";
import "./Gui/Controllers/Pages/MainPageController.js";
//# sourceMappingURL=ForceCompile.js.map