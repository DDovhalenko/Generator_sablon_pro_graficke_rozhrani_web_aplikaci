/*! ******************************************************************************************************** *
 *
 * Copyright 2022-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { StringUtils } from "./../../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { BasePanel } from "./../../../../../../Io/Oidis/Gui/Bootstrap/Primitives/BasePanel.js";
import { GuiCommons } from "./../../../../../../Io/Oidis/Gui/Bootstrap/Primitives/GuiCommons.js";
export class MainPage extends BasePanel {
    footerInfo;
    constructor() {
        super();
        this.footerInfo = new GuiCommons();
    }
    innerCode() {
        this.footerInfo.Content("" +
            "Localhost version: " + this.getEnvironmentArgs().getProjectVersion() +
            ", build: " + this.getEnvironmentArgs().getBuildTime() +
            ", Copyright " + StringUtils.YearFrom(2019) + " Oidis");
        return super.innerCode();
    }
    innerHtml() {
        return `
<section style="background: var(--bs-dark);">
    <div class="container-fluid">
        <div class="row"></div>
        <div class="row" style="text-align: center;margin: 10%;">
            <div class="col"><img class="img-fluid d-xl-flex" src="resource/graphics/Io/Oidis/Localhost/Gui/Pages/MainPage/Logo.png" style="margin: auto;" /></div>
        </div>
        <div class="row">
            <div class="col">
                <p style="text-align: center;margin-top: 40px;color: var(--bs-light);" data-oidis-bind="${this.footerInfo}">Copyright ${StringUtils.YearFrom(2019)} Oidis</p>
            </div>
        </div>
    </div>
</section>`;
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.Gui.Controllers.Pages.MainPage", MainPage);
//# sourceMappingURL=MainPage.js.map