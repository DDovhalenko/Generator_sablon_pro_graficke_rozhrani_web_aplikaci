var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2018 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { AsyncBasePageController } from "./../../../../../../Io/Oidis/Services/HttpProcessor/Resolvers/AsyncBasePageController.js";
import { MainPage } from "./MainPage.js";
import { Resolver } from "./../../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
let MainPageController = class MainPageController extends AsyncBasePageController {
    constructor() {
        super();
        this.setInstanceOwner(new MainPage());
        this.setPageTitle("Oidis Localhost");
    }
};
MainPageController = __decorate([
    Resolver("/", ["/index", "/index.html", "/web/", "/main"]),
    __metadata("design:paramtypes", [])
], MainPageController);
export { MainPageController };
globalThis.RegisterClass("Io.Oidis.Localhost.Gui.Controllers.Pages.MainPageController", MainPageController);
//# sourceMappingURL=MainPageController.js.map