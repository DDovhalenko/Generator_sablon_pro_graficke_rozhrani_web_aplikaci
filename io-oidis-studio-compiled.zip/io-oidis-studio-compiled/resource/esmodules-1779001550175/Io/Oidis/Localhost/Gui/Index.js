var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IndexPage } from "./../../../../Io/Oidis/Gui/Pages/IndexPage.js";
import { AsyncBasePageController } from "./../../../../Io/Oidis/Services/HttpProcessor/Resolvers/AsyncBasePageController.js";
import { Resolver, ResolverScope } from "./../../../../Io/Oidis/Commons/Primitives/Decorators.js";
/* dev:start */
import { AuthConnectorTest } from "./RuntimeTests/AuthConnectorTest.js";
import { ExternAndRouteTest } from "./RuntimeTests/ExternAndRouteTest.js";
import { RestServiceTest } from "./RuntimeTests/RestServiceTest.js";
/* dev:end */
let Index = class Index extends AsyncBasePageController {
    constructor() {
        super();
        this.setInstanceOwner(new IndexPage());
    }
    async onSuccess($instance) {
        $instance.headerTitle.Content("Oidis Localhost");
        $instance.headerInfo.Content("Oidis Framework code base for Node.js-based localhost services");
        let content = "";
        /* dev:start */
        content += `
            <h3>Runtime tests</h3>
            <a href="${RestServiceTest.CallbackLink()}">Back-end connection test</a>
            <a href="${AuthConnectorTest.CallbackLink()}">Auth connector access test</a>
            <a href="${ExternAndRouteTest.CallbackLink()}">Extern/Route test</a>
            `;
        /* dev:end */
        $instance.pageIndex.Content(content);
        $instance.footerInfo.Content("" +
            "version: " + this.getEnvironmentArgs().getProjectVersion() +
            ", build: " + this.getEnvironmentArgs().getBuildTime() +
            ", " + this.getEnvironmentArgs().getProjectConfig().target.copyright);
    }
};
Index = __decorate([
    Resolver("/", ["/index", "/index.html", "/web/"], { scope: ResolverScope.DEV }),
    __metadata("design:paramtypes", [])
], Index);
export { Index };
globalThis.RegisterClass("Io.Oidis.Localhost.Gui.Index", Index);
//# sourceMappingURL=Index.js.map