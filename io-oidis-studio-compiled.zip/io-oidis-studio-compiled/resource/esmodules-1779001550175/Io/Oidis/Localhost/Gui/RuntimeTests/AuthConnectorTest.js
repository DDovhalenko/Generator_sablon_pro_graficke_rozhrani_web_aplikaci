/*! ******************************************************************************************************** *
 *
 * Copyright 2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "./../../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { WebServiceClientType } from "./../../../../../Io/Oidis/Services/Enums/WebServiceClientType.js";
import { BaseConnector } from "./../../../../../Io/Oidis/Services/Primitives/BaseConnector.js";
export class AuthTestConnector extends BaseConnector {
    /**
     * @returns {ILiveContentErrorPromise} Returns a live content error promise.
     */
    AuthMethodStaticWithCallback() {
        return this.invoke("AuthMethodStaticWithCallback");
    }
    /**
     * @returns {ILiveContentErrorPromise} Returns a live content error promise.
     */
    AuthMethodStaticWithReturn() {
        return this.invoke("AuthMethodStaticWithReturn");
    }
    /**
     * @returns {ILiveContentErrorPromise} Returns a live content error promise.
     */
    AuthMethodWithCallback() {
        return this.invoke("AuthMethodWithCallback");
    }
    /**
     * @returns {ILiveContentErrorPromise} Returns a live content error promise.
     */
    AuthMethodWithReturn() {
        return this.invoke("AuthMethodWithReturn");
    }
    /**
     * @returns {ILiveContentErrorPromise} Returns a live content error promise.
     */
    AuthMethodVoid() {
        return this.invoke("AuthMethodVoid");
    }
    /**
     * @returns {ILiveContentErrorPromise} Returns a live content error promise.
     */
    AuthMethodNull() {
        return this.invoke("AuthMethodNull");
    }
    /**
     * @returns {ILiveContentErrorPromise} Returns a live content error promise.
     */
    AuthMethodEmpty() {
        return this.invoke("AuthMethodEmpty");
    }
    /**
     * @returns {ILiveContentErrorPromise} Returns a live content error promise.
     */
    AuthMethodBuffer() {
        return this.invoke("AuthMethodBuffer");
    }
    getClientType() {
        return WebServiceClientType.WEB_SOCKETS;
    }
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.WEB_SOCKETS] = "Io.Oidis.Localhost.RuntimeTests.MockAuthConnector";
        return namespaces;
    }
}
export class AuthConnectorTest extends RuntimeTestRunner {
    testConnector() {
        const connector = new AuthTestConnector(10, this.getRequest().getHostUrl() + "/connector.config.jsonp");
        this.addButton("AuthMethodStaticWithCallback", () => {
            connector
                .AuthMethodStaticWithCallback()
                .Then(($status) => {
                Echo.Printf("AuthMethodStaticWithCallback status: {0}", $status);
            });
        });
        this.addButton("AuthMethodStaticWithReturn", () => {
            connector
                .AuthMethodStaticWithReturn()
                .Then(($status) => {
                Echo.Printf("AuthMethodStaticWithReturn status: {0}", $status);
            });
        });
        this.addButton("AuthMethodWithCallback", () => {
            connector
                .AuthMethodWithCallback()
                .Then(($status) => {
                Echo.Printf("AuthMethodWithCallback status: {0}", $status);
            });
        });
        this.addButton("AuthMethodWithReturn", () => {
            connector
                .AuthMethodWithReturn()
                .Then(($status) => {
                Echo.Printf("AuthMethodWithReturn status: {0}", $status);
            });
        });
        this.addButton("AuthMethodVoid", () => {
            connector
                .AuthMethodVoid()
                .Then(($retVal) => {
                Echo.Printf("AuthMethodVoid status: {0}", $retVal);
            });
        });
        this.addButton("AuthMethodNull", () => {
            connector
                .AuthMethodNull()
                .Then(($retVal) => {
                Echo.Printf("AuthMethodNull status: {0}", $retVal);
            });
        });
        this.addButton("AuthMethodEmpty", () => {
            connector
                .AuthMethodEmpty()
                .Then(($retVal) => {
                Echo.Printf("AuthMethodEmpty status: {0}", $retVal);
            });
        });
        this.addButton("AuthMethodBuffer", () => {
            connector
                .AuthMethodBuffer()
                .Then(($retVal) => {
                Echo.Printf("AuthMethodBuffer status: {0}", $retVal);
            });
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.Gui.RuntimeTests.AuthTestConnector", AuthTestConnector);
globalThis.RegisterClass("Io.Oidis.Localhost.Gui.RuntimeTests.AuthConnectorTest", AuthConnectorTest);
//# sourceMappingURL=AuthConnectorTest.js.map