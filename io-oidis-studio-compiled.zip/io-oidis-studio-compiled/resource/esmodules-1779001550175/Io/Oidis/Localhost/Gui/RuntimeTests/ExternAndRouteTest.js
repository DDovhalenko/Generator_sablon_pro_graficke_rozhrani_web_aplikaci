/*! ******************************************************************************************************** *
 *
 * Copyright 2023-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { EventType } from "./../../../../../Io/Oidis/Commons/Enums/Events/EventType.js";
import { HttpMethodType } from "./../../../../../Io/Oidis/Commons/Enums/HttpMethodType.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { RuntimeTestRunner } from "./../../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { WebServiceClientType } from "./../../../../../Io/Oidis/Services/Enums/WebServiceClientType.js";
import { BaseConnector } from "./../../../../../Io/Oidis/Services/Primitives/BaseConnector.js";
export class ExternTestConnector extends BaseConnector {
    /**
     * @returns {ILiveContentPromise} Returns a live content promise.
     */
    SyncValueNoArgsIPromise() {
        return this.invoke("SyncValueNoArgs");
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {ILiveContentPromise} Returns a live content promise.
     */
    SyncValueWithArgsIPromise($param) {
        return this.invoke("SyncValueWithArgs", $param);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {ILiveContentPromise} Returns a live content promise.
     */
    SyncValueWithIResponseIPromise($param) {
        return this.invoke("SyncValueWithIResponse", $param);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {ILiveContentPromise} Returns a live content promise.
     */
    SyncValueWithoutIResponseIPromise($param) {
        return this.invoke("SyncValueWithoutIResponse", $param);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {IProgressPromise} Returns a progress promise with start, message, and complete callbacks.
     */
    SyncValueWithFullIResponseIPromiseNoVoid($param) {
        return this.invokeFullIResponseIPromise("SyncValueWithFullIResponseNoVoid", $param);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {IProgressPromise} Returns a progress promise with start, message, and complete callbacks.
     */
    SyncValueWithFullIResponseIPromise($param) {
        return this.invokeFullIResponseIPromise("SyncValueWithFullIResponse", $param);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {ILiveContentPromise} Returns a live content promise.
     */
    SyncValueWithIncorrectIResponseNoVoidIPromise($param) {
        return this.invoke("SyncValueWithIncorrectIResponseNoVoid", $param);
    }
    /**
     * @param {...string} $params The variadic parameters to pass to the server method.
     * @returns {ILiveContentPromise} Returns a live content promise.
     */
    SyncValueWithOpenArgsIPromise(...$params) {
        return this.invoke("SyncValueWithOpenArgs", ...$params);
    }
    /**
     * @param {string} $param The required parameter.
     * @param {string} [$optional] The optional parameter.
     * @returns {ILiveContentPromise} Returns a live content promise.
     */
    SyncValueWithOptionArgsIPromise($param, $optional) {
        return this.invoke("SyncValueWithOptionArgs", $param, $optional);
    }
    /**
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncValueNoArgs() {
        return this.asyncInvoke("SyncValueNoArgs");
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncValueWithArgs($param) {
        return this.asyncInvoke("SyncValueWithArgs", $param);
    }
    /**
     * @param {any} $param The JSON parameter to pass to the server method.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncValueWithJsonArgs($param) {
        return this.asyncInvoke("SyncValueWithJsonArgs", $param);
    }
    /**
     * @param {any} $param The JSON parameter to pass to the server method.
     * @returns {Promise<any>} Returns a promise resolving to the JSON server response.
     */
    SyncJsonWithJsonArgs($param) {
        return this.asyncInvoke("SyncJsonWithJsonArgs", $param);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {Promise<any>} Returns a promise resolving to the buffer response.
     */
    SyncBufferWithArgs($param) {
        return this.asyncInvoke("SyncBufferWithArgs", $param);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncValueWithIResponseNoVoid($param) {
        return this.asyncInvoke("SyncValueWithIResponseNoVoid", $param);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncValueWithIResponse($param) {
        return this.asyncInvoke("SyncValueWithIResponse", $param);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {Promise<string>} Returns a promise resolving to the server response or rejecting on timeout.
     */
    SyncValueWithoutIResponse($param) {
        return Promise.race([
            new Promise(($resolve, $reject) => {
                setTimeout(() => {
                    $reject(new Error("SyncValueWithoutIResponse timeout"));
                }, 500);
            }),
            this.asyncInvoke("SyncValueWithoutIResponse", $param)
        ]);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncValueWithIncorrectIResponseNoVoid($param) {
        return this.asyncInvoke("SyncValueWithIncorrectIResponseNoVoid", $param);
    }
    /**
     * @param {...string} $params The variadic parameters to pass to the server method.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncValueWithOpenArgs(...$params) {
        return this.asyncInvoke("SyncValueWithOpenArgs", ...$params);
    }
    /**
     * @param {string} $param The required parameter.
     * @param {string} [$optional] The optional parameter.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncValueWithOptionArgs($param, $optional) {
        return this.asyncInvoke("SyncValueWithOptionArgs", $param, $optional);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @param {Function} $onChange The callback invoked on each progress update.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncWithProgress($param, $onChange) {
        return this.progressWrapper("SyncWithProgress", [$param], $onChange);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @param {Function} $onChange The callback invoked on each progress update.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncWithIncorrectProgress($param, $onChange) {
        return this.progressWrapper("SyncWithIncorrectProgress", [$param], $onChange);
    }
    /**
     * @param {Function} $onChange The callback invoked on each progress update.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncWithStartAfterChange($onChange) {
        return this.progressWrapper("SyncWithStartAfterChange", [], $onChange);
    }
    /**
     * @param {Function} $onChange The callback invoked on each progress update.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncWithStartAfterComplete($onChange) {
        return this.progressWrapper("SyncWithStartAfterComplete", [], $onChange);
    }
    /**
     * @param {Function} $onChange The callback invoked on each progress update.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncWithChangeAfterComplete($onChange) {
        return this.progressWrapper("SyncWithChangeAfterComplete", [], $onChange);
    }
    /**
     * @param {Function} $onChange The callback invoked on each progress update.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncWithMultipleStarts($onChange) {
        return this.progressWrapper("SyncWithMultipleStarts", [], $onChange);
    }
    /**
     * @param {Function} $onChange The callback invoked on each progress update.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    SyncWithMultipleCompletes($onChange) {
        return this.progressWrapper("SyncWithMultipleCompletes", [], $onChange);
    }
    /**
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    AsyncValueNoArgs() {
        return this.asyncInvoke("AsyncValueNoArgs");
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    AsyncValueWithArgs($param) {
        return this.asyncInvoke("AsyncValueWithArgs", $param);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    AsyncValueWithIResponse($param) {
        return this.asyncInvoke("AsyncValueWithIResponse", $param);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    AsyncValueWithIResponseNoVoid($param) {
        return this.asyncInvoke("AsyncValueWithIResponseNoVoid", $param);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    AsyncValueWithIncorrectIResponse($param) {
        return this.asyncInvoke("AsyncValueWithIncorrectIResponse", $param);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    AsyncValueWithIncorrectIResponseNoVoid($param) {
        return this.asyncInvoke("AsyncValueWithIncorrectIResponseNoVoid", $param);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @returns {Promise<string>} Returns a promise resolving to the server response or rejecting on timeout.
     */
    AsyncValueWithoutIResponse($param) {
        return Promise.race([
            new Promise(($resolve, $reject) => {
                setTimeout(() => {
                    $reject(new Error("AsyncValueWithoutIResponse timeout"));
                }, 500);
            }),
            this.asyncInvoke("AsyncValueWithoutIResponse", $param)
        ]);
    }
    /**
     * @param {...string} $params The variadic parameters to pass to the server method.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    AsyncValueWithOpenArgs(...$params) {
        return this.asyncInvoke("AsyncValueWithOpenArgs", ...$params);
    }
    /**
     * @param {string} $param The required parameter.
     * @param {string} [$optional] The optional parameter.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    AsyncValueWithOptionArgs($param, $optional) {
        return this.asyncInvoke("AsyncValueWithOptionArgs", $param, $optional);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @param {Function} $onChange The callback invoked on each progress update.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    AsyncProgress($param, $onChange) {
        return this.progressWrapper("SyncVoidWithIncorrectIResponse", [$param], $onChange);
    }
    /**
     * @param {string} $param The parameter to pass to the server method.
     * @param {Function} $onChange The callback invoked on each progress update.
     * @returns {Promise<string>} Returns a promise resolving to the server response.
     */
    AsyncValueWithProgress($param, $onChange) {
        return this.progressWrapper("AsyncValueWithProgress", [$param], $onChange);
    }
    /**
     * @returns {Promise<string>} Returns a promise resolving to the version string.
     */
    getVersion() {
        return this.asyncInvoke("getVersion");
    }
    getClientType() {
        return WebServiceClientType.WEB_SOCKETS;
    }
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.WEB_SOCKETS] = "Io.Oidis.Localhost.RuntimeTests.ExternAndRouteTestHandler";
        return namespaces;
    }
    invokeFullIResponseIPromise($method, $param) {
        const callbacks = {
            onComplete($result) {
                // declare default callback
            },
            onMessage($result) {
                // declare default callback
            },
            onStart($result) {
                // declare default callback
            }
        };
        this.invoke($method, $param)
            .Then(($result) => {
            if (ObjectValidator.IsSet($result.type)) {
                if ($result.type === EventType.ON_START) {
                    callbacks.onStart($result.data);
                }
                else if ($result.type === EventType.ON_CHANGE) {
                    callbacks.onMessage($result.data);
                }
                else if ($result.type === EventType.ON_COMPLETE) {
                    callbacks.onComplete($result.data);
                }
            }
        });
        const promise = {
            OnMessage: ($callback) => {
                callbacks.onMessage = $callback;
                return promise;
            },
            OnStart: ($callback) => {
                callbacks.onStart = $callback;
                return promise;
            },
            Then: ($callback) => {
                callbacks.onComplete = $callback;
            }
        };
        return promise;
    }
}
export class ExternAndRouteTest extends RuntimeTestRunner {
    client;
    constructor() {
        super();
        this.client = new ExternTestConnector(true, this.getRequest().getHostUrl() + "/connector.config.jsonp");
        this.setMethodFilter(
        // "testExternLCPversion",
        // "testExternSyncValueIPromise",
        // "testExternSyncValue",
        // "testExternSyncIResponse",
        // "testExternSyncProgress",
        // "testExternAsyncValue",
        // "testExternAsyncIResponse",
        // "testExternAsyncProgress",
        // "testIncorrectResponsesOrder",
        // "testRouteSyncValue",
        // "testRouteASyncValue",
        // "testRouteParamTypes",
        // "testRouteIncorrectInvoke",
        // "testRouteWithCallback"
        );
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when the assertion passes.
     */
    async testExternLCPversion() {
        this.assertEquals(await this.client.getVersion(), "v1.1");
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when all use cases pass.
     */
    async testExternSyncValueIPromise() {
        const useCases = [
            ($done) => {
                this.client.SyncValueNoArgsIPromise().Then(($value) => {
                    this.assertEquals($value, "testSyncValueNoArgs");
                    $done();
                });
            },
            ($done) => {
                this.client.SyncValueWithArgsIPromise("test").Then(($value) => {
                    this.assertEquals($value, "testSyncValue:test");
                    $done();
                });
            },
            ($done) => {
                this.client.SyncValueWithIResponseIPromise("test")
                    .Then(($value) => {
                    this.assertEquals($value, "testSyncIResponse:test");
                    $done();
                });
            },
            ($done) => {
                setTimeout(() => {
                    $done();
                }, 500);
                this.client.SyncValueWithoutIResponseIPromise("test")
                    .Then(($value) => {
                    this.assertOk(false);
                    $done();
                });
            },
            ($done) => {
                this.client.SyncValueWithFullIResponseIPromise("test")
                    .OnStart(($value) => {
                    this.assertEquals($value, "testSyncIResponse:Start");
                })
                    .OnMessage(($value) => {
                    this.assertEquals($value, "testSyncIResponse:Message");
                })
                    .Then(($value) => {
                    this.assertEquals($value, "testSyncIResponse:test");
                    $done();
                });
            },
            ($done) => {
                this.client.SyncValueWithFullIResponseIPromiseNoVoid("test")
                    .OnStart(($value) => {
                    this.assertEquals($value, "testSyncIResponse:Start");
                })
                    .OnMessage(($value) => {
                    this.assertEquals($value, "testSyncIResponse:Message");
                })
                    .Then(($value) => {
                    this.assertEquals($value, "testSyncIResponse:test");
                    $done();
                });
            },
            ($done) => {
                this.client.SyncValueWithIncorrectIResponseNoVoidIPromise("test").Then(($value) => {
                    this.assertEquals($value, "testSyncIResponse:test");
                    $done();
                });
            },
            ($done) => {
                this.client.SyncValueWithOpenArgsIPromise("test1", "test2").Then(($value) => {
                    this.assertEquals($value, "testSyncValues:test1,test2");
                    $done();
                });
            },
            ($done) => {
                this.client.SyncValueWithOptionArgsIPromise("test1").Then(($value) => {
                    this.assertEquals($value, "testSyncValueOptional:test1, optional: undefined");
                    $done();
                });
            },
            ($done) => {
                this.client.SyncValueWithOptionArgsIPromise("test1", "optional").Then(($value) => {
                    this.assertEquals($value, "testSyncValueOptional:test1, optional: optional");
                    $done();
                });
            }
        ];
        return await new Promise(($resolve) => {
            const runUseCase = ($index = 0) => {
                if ($index < useCases.length) {
                    useCases[$index](() => {
                        runUseCase($index + 1);
                    });
                }
                else {
                    $resolve();
                }
            };
            runUseCase();
        });
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when all assertions pass.
     */
    async testExternSyncValue() {
        this.assertEquals(await this.client.SyncValueNoArgs(), "testSyncValueNoArgs");
        this.assertEquals(await this.client.SyncValueWithArgs("test"), "testSyncValue:test");
        this.assertEquals(await this.client.SyncValueWithJsonArgs({ test: true }), "testSyncValue:{\"test\":true}");
        this.assertDeepEqual(await this.client.SyncJsonWithJsonArgs({ test: true }), { test: true });
        this.assertEquals(await this.client.SyncBufferWithArgs("test"), "test");
        this.assertEquals(await this.client.SyncValueWithOpenArgs("test1", "test2"), "testSyncValues:test1,test2");
        this.assertEquals(await this.client.SyncValueWithOptionArgs("test1"), "testSyncValueOptional:test1, optional: undefined");
        this.assertEquals(await this.client.SyncValueWithOptionArgs("test1", "optional"), "testSyncValueOptional:test1, optional: optional");
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when all assertions pass.
     */
    async testExternSyncIResponse() {
        this.assertEquals(await this.client.SyncValueWithIResponse("test"), "testSyncIResponse:test");
        try {
            await this.client.SyncValueWithoutIResponse("test");
        }
        catch (ex) {
            this.assertEquals(ex.message, "SyncValueWithoutIResponse timeout");
        }
        this.assertEquals(await this.client.SyncValueWithIResponseNoVoid("test"), "testSyncIResponse:test");
        this.assertEquals(await this.client.SyncValueWithIncorrectIResponseNoVoid("test"), "testSyncIResponse:test");
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when all assertions pass.
     */
    async testExternSyncProgress() {
        this.assertEquals(await this.client.SyncWithProgress("test", ($data) => {
            this.assertEquals($data, "testSyncIResponse:Message");
        }), "testSyncIResponse:test");
        this.assertEquals(await this.client.SyncWithIncorrectProgress("test", ($data) => {
            this.assertOk($data === "testSyncIResponse:Start" || $data === "testSyncIResponse:Message");
        }), "testSyncIResponse:test");
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when all assertions pass.
     */
    async testIncorrectResponsesOrder() {
        try {
            await this.client.SyncWithStartAfterChange(($data) => {
                this.assertEquals($data, "testSyncIResponse:Message1");
            });
        }
        catch (ex) {
            this.assertEquals(ex.message, "LCP Error: cannot notify onstart after onchange");
        }
        try {
            this.assertDeepEqual(await this.client.SyncWithStartAfterComplete(($data) => {
                this.assertEquals($data, "testSyncIResponse:Message1");
            }), {
                data: "testSyncIResponse:End1",
                type: "oncomplete"
            });
        }
        catch (ex) {
            this.assertEquals(ex.message, "LCP Error: cannot notify onstart after oncomplete");
        }
        this.assertDeepEqual(await this.client.SyncWithChangeAfterComplete(($data) => {
            this.assertOk($data === "testSyncIResponse:Start" ||
                $data === "testSyncIResponse:Message1");
        }), {
            data: "testSyncIResponse:End1",
            type: "oncomplete"
        });
        try {
            await this.client.SyncWithMultipleStarts(($data) => {
                this.assertEquals($data, "testSyncIResponse:Start");
            });
        }
        catch (ex) {
            this.assertEquals(ex.message, "LCP Error: onstart notify can be send only once");
        }
        this.assertDeepEqual(await this.client.SyncWithMultipleCompletes(($data) => {
            this.assertOk($data === "testSyncIResponse:Message1" ||
                $data === "testSyncIResponse:Message2");
        }), {
            data: "testSyncIResponse:End1",
            type: "oncomplete"
        });
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when all assertions pass.
     */
    async testExternAsyncValue() {
        this.assertEquals(await this.client.AsyncValueNoArgs(), "testAsyncValueNoArgs");
        this.assertEquals(await this.client.AsyncValueWithArgs("test"), "testAsyncValue:test");
        this.assertEquals(await this.client.AsyncValueWithOpenArgs("test1", "test2"), "testAsyncValues:test1,test2");
        this.assertEquals(await this.client.AsyncValueWithOptionArgs("test1"), "testAsyncValueOptional:test1, optional: undefined");
        this.assertEquals(await this.client.AsyncValueWithOptionArgs("test1", "optional"), "testAsyncValueOptional:test1, optional: optional");
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when all assertions pass.
     */
    async testExternAsyncIResponse() {
        this.assertEquals(await this.client.AsyncValueWithIResponse("test"), "testAsyncIResponse:test");
        this.assertEquals(await this.client.AsyncValueWithIResponseNoVoid("test"), "testAsyncIResponse:test");
        this.assertEquals(await this.client.AsyncValueWithIncorrectIResponse("test"), "testAsyncAutoResponse:test");
        this.assertEquals(await this.client.AsyncValueWithIncorrectIResponseNoVoid("test"), "testAsyncAutoResponse:test");
        try {
            await this.client.AsyncValueWithoutIResponse("test");
        }
        catch (ex) {
            this.assertEquals(ex.message, "AsyncValueWithoutIResponse timeout");
        }
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when all assertions pass.
     */
    async testExternAsyncProgress() {
        this.assertEquals(await this.client.AsyncProgress("test", ($data) => {
            this.assertOk($data === "testSyncIResponse:Start" || $data === "testSyncIResponse:Message");
        }), "testSyncIResponse:test");
        this.assertEquals(await this.client.AsyncValueWithProgress("test", ($data) => {
            this.assertEquals($data, "testAsyncAutoResponse:Message");
        }), "testAsyncAutoResolve:test");
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when all assertions pass.
     */
    async testRouteSyncValue() {
        this.assertEquals(await this.fetchResponse("/api/test/syncNoArgs"), "testSyncValueNoArgs");
        this.assertEquals(await this.fetchResponse("/api/test/altEndpointForSyncNoArgs"), "testSyncValueNoArgs");
        this.assertEquals(await this.fetchResponse("/api/test/syncValueWithArgs?param=test"), "testSyncValue:test");
        this.assertEquals(await this.fetchResponse("/api/test/syncValueWithOptionArgs?param=test"), "testSyncValueOptional:test, optional: undefined");
        this.assertEquals(await this.fetchResponse("/api/test/syncValueWithOptionArgs?param=test&optional=1"), "testSyncValueOptional:test, optional: 1");
        this.assertEquals(await this.fetchResponse("/api/test/SyncValueWithJsonArgs", {
            body: JSON.stringify({ test: "test" }),
            headers: { "Content-Type": "application/json" },
            method: HttpMethodType.POST
        }), "testSyncValue:{\\\"test\\\":\\\"test\\\"}");
        this.assertEquals(await this.fetchResponse("/api/test/SyncValueWithJsonArgs", {
            body: JSON.stringify({ test: "testPut" }),
            headers: { "Content-Type": "application/json" },
            method: HttpMethodType.PUT
        }), "testSyncValue:{\\\"test\\\":\\\"testPut\\\"}");
        this.assertEquals(await this.fetchResponse("/api/test/syncValueWithArgs?param=test", {
            method: HttpMethodType.DELETE
        }), "testSyncValue:test");
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when all assertions pass.
     */
    async testRouteASyncValue() {
        this.assertEquals(await this.fetchResponse("/api/test/asyncValueWithArgs?param=test"), "testAsyncValue:test");
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when all assertions pass.
     */
    async testRouteParamTypes() {
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithIntParam?param=1"), "testRouteValue:Object type: number. Return value: 1");
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithDefaultIntDefaultParam"), "testRouteValue:Object type: number. Return value: 5");
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithDefaultIntDefaultParam?param=10"), "testRouteValue:Object type: number. Return value: 10");
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithDefaultNumberDefaultParam"), "testRouteValue:Object type: number. Return value: 8");
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithDefaultFloatDefaultParam"), "testRouteValue:Object type: number. Return value: 1.1");
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithDefaultFloatDefaultParam?param=3.005"), "testRouteValue:Object type: number. Return value: 3.005");
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithDefaultDoubleDefaultParam"), "testRouteValue:Object type: number. Return value: 2.2");
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithDefaultDoubleDefaultParam?param=7.005"), "testRouteValue:Object type: number. Return value: 7.005");
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithBoolParam?param=true"), "testRouteValue:Object type: boolean. Return value: true");
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithDefaultBoolDefaultParam"), "testRouteValue:Object type: boolean. Return value: false");
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithDefaultBoolDefaultParam?param=true"), "testRouteValue:Object type: boolean. Return value: true");
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithStringParam"), "testRouteValue:test");
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithIntParam?param=test"), "testRouteValue:Object type: number. Return value: NaN");
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithMultipleArgs?param2=test"), "testRouteValues:false, test");
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when all assertions pass.
     */
    async testRouteIncorrectInvoke() {
        this.assertEquals(await this.fetchResponse("/api/test/routeValueWithKeywordParam"), "testRouteValue:int");
        try {
            await this.fetchResponse("/api/test/syncValueWithOpenArgs?param1=test&param2=test2");
        }
        catch (ex) {
            // open args are not supported for REST
            this.assertEquals(ex.message, "Passed more arguments then declared in route schema: " +
                "GET /test/syncValueWithOpenArgs?param1&param2");
        }
        try {
            await this.fetchResponse("/api/test/notExist");
        }
        catch (ex) {
            this.assertEquals(ex.message, "Unsupported method GET for section /test/notExist");
        }
        try {
            await this.fetchResponse("/api/test/syncNoArgs?missingParam=true");
        }
        catch (ex) {
            this.assertEquals(ex.message, "Passed parameters [missingParam] not declared in route schema: " +
                "GET /test/syncNoArgs");
        }
        try {
            await this.fetchResponse("/api/test/syncValueWithArgs?param=test&unexpectedParam=true");
        }
        catch (ex) {
            this.assertEquals(ex.message, "Passed parameters [unexpectedParam] not declared in route schema: " +
                "GET /test/syncValueWithArgs?param");
        }
        // progress for REST does not make a sense, so just validate that output will be first progress message
        this.assertEquals(await this.fetchResponse("/api/test/asyncValueWithProgress?param=true"), "\"data\":\"testAsyncAutoResponse:Message\",\"type\":\"onchange\"");
        try {
            /// TODO: this is currently not supported mainly because RESTResolver is registered only for
            //        variable section and subsection after /api/.
            //        Also Route decorator is not able to parse variables from url like /{param}.
            //        Anyway this is commonly used in REST and should be also generally supported somehow
            //        otherwise it must be implemented by custom resolver (older way).
            await Promise.race([
                new Promise(($resolve, $reject) => {
                    setTimeout(() => {
                        $reject(new Error("syncValueWithUrlArgs timeout"));
                    }, 500);
                }),
                this.fetchResponse("/api/test/syncValueWithUrlArgs/test")
            ]);
        }
        catch (ex) {
            this.assertEquals(ex.message, "Unsupported method GET for section /test/syncValueWithUrlArgs/test");
        }
        try {
            // HTTP request with #hash is possible only in browser, so it will never respond
            await Promise.race([
                new Promise(($resolve, $reject) => {
                    setTimeout(() => {
                        $reject(new Error("syncValueWithHashArgs timeout"));
                    }, 500);
                }),
                this.fetchResponse("/api/test/syncValueWithHashArgs#test")
            ]);
        }
        catch (ex) {
            this.assertEquals(ex.message, "syncValueWithHashArgs timeout");
        }
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when all assertions pass.
     */
    async testRouteWithCallback() {
        this.assertEquals(await this.fetchResponse("/api/test/asyncValueWithIResponse?param=test"), "testAsyncIResponse:test");
    }
    async fetchResponse($url, $options) {
        const response = await fetch($url, $options);
        const output = await response.text();
        if (response.ok) {
            return output.substring(1, output.length - 1);
        }
        else {
            let error = output;
            try {
                error = JSON.parse(error);
            }
            catch (ex) {
                // just fallback to string output
            }
            if (ObjectValidator.IsString(error)) {
                throw new Error(error);
            }
            else if (!ObjectValidator.IsEmptyOrNull(error) && !ObjectValidator.IsEmptyOrNull(error.message)) {
                throw new Error(error.message);
            }
            else {
                throw new Error(response.statusText);
            }
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.Gui.RuntimeTests.ExternTestConnector", ExternTestConnector);
globalThis.RegisterClass("Io.Oidis.Localhost.Gui.RuntimeTests.ExternAndRouteTest", ExternAndRouteTest);
//# sourceMappingURL=ExternAndRouteTest.js.map