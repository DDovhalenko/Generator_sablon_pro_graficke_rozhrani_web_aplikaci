import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "./../../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { WebServiceClientType } from "./../../../../../Io/Oidis/Services/Enums/WebServiceClientType.js";
import { BaseConnector } from "./../../../../../Io/Oidis/Services/Primitives/BaseConnector.js";
import { LiveContentWrapper } from "./../../../../../Io/Oidis/Services/WebServiceApi/LiveContentWrapper.js";
import { WebServiceClientFactory } from "./../../../../../Io/Oidis/Services/WebServiceApi/WebServiceClientFactory.js";
export class RestServiceTestConnector extends BaseConnector {
    /**
     * @param {string} $message The message to pass to the server method.
     * @returns {ILiveContentErrorPromise} Returns a live content error promise.
     */
    SelfCallMethod($message) {
        return this.invoke("SelfCallMethod", $message);
    }
    /**
     * @param {string} $message The message to pass to the server method.
     * @returns {ILiveContentErrorPromise} Returns a live content error promise.
     */
    ExceptionTest($message) {
        return this.invoke("ExceptionTest", $message);
    }
    /**
     * @param {string} $message The message to pass to the server method.
     * @returns {ILiveContentErrorPromise} Returns a live content error promise.
     */
    ErrorTest($message) {
        return this.invoke("ErrorTest", $message);
    }
    /**
     * @param {string} $path The file path of the archive to unpack.
     * @returns {ILiveContentErrorPromise} Returns a live content error promise.
     */
    Unpack($path) {
        return this.invoke("UnpackTest", $path);
    }
    /**
     * @returns {ILiveContentErrorPromise} Returns a live content error promise.
     */
    Download() {
        return this.invoke("DownloadTest");
    }
    /**
     * @param {string} $data The data string to transfer.
     * @returns {ILiveContentErrorPromise} Returns a live content error promise.
     */
    DataTransfer($data) {
        return this.invoke("DataTransferTest", $data);
    }
    getClientType() {
        return WebServiceClientType.WEB_SOCKETS;
    }
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.WEB_SOCKETS] = "Io.Oidis.Localhost.RuntimeTests.RestServiceTestHandler";
        return namespaces;
    }
}
export class RestServiceTest extends RuntimeTestRunner {
    handlerClassName = "Io.Oidis.Localhost.RuntimeTests.RestServiceTestHandler";
    testWebsocketsConnection() {
        const client = WebServiceClientFactory.getClient(WebServiceClientType.WEB_SOCKETS, this.getRequest().getHostUrl() + "connector.config.jsonp");
        client.getEvents().OnError(($eventArgs) => {
            Echo.Printf("General error handler: {0}", $eventArgs.Exception().ToString());
        });
        const invoke = ($method, $message) => {
            LiveContentWrapper.InvokeMethod(client, this.handlerClassName, $method, $message)
                .Then(() => {
                Echo.Printf("Function successfully invoked.");
            });
        };
        this.addButton("Self-Invoke function", () => {
            invoke("SelfCallMethod", "test message");
        });
        /// TODO: enable test after auth method will be possible
        // this.addButton("Secure Self-Invoke function", () : void => {
        //     invoke("SelfSecureCallMethod", "secure test message");
        // });
    }
    testWebsocketsErrors() {
        const client = WebServiceClientFactory.getClient(WebServiceClientType.WEB_SOCKETS, this.getRequest().getHostUrl() + "connector.config.jsonp");
        client.MaxReconnectsCount(10);
        // (<WebSocketsClient>client).MaxReconnectsCount(0);
        client.getEvents().OnError(($eventArgs) => {
            Echo.Printf("General error handler: {0}", $eventArgs.Exception().ToString());
        });
        this.addButton("Missing API invoke", () => {
            LiveContentWrapper.InvokeMethod(client, this.handlerClassName, "SomethingMissing", "test message")
                .Then(() => {
                Echo.Printf("Function successfully invoked?");
            });
        });
        this.addButton("Exception invoke", () => {
            LiveContentWrapper.InvokeMethod(client, this.handlerClassName, "ExceptionTest", "test message")
                .OnError(($eventArgs) => {
                Echo.Printf("Exception successfully handled: {0}", $eventArgs.Exception().ToString());
            })
                .Then(() => {
                Echo.Printf("Function successfully invoked?");
            });
        });
        this.addButton("Error invoke", () => {
            LiveContentWrapper.InvokeMethod(client, this.handlerClassName, "ErrorTest", "test message")
                .OnError(($eventArgs, $result, $nextMessage) => {
                Echo.Printf("Error successfully handled: {0}", $eventArgs.Exception().ToString());
                Echo.Printf("{0}{1}", $result, $nextMessage);
            })
                .Then(() => {
                Echo.Printf("Function successfully invoked?");
            });
        });
        this.addButton("Global exception invoke", () => {
            LiveContentWrapper.InvokeMethod(client, this.handlerClassName, "ExceptionTest", "test message")
                .Then(() => {
                Echo.Printf("Function successfully invoked?");
            });
        });
        this.addButton("Global error invoke", () => {
            LiveContentWrapper.InvokeMethod(client, this.handlerClassName, "ErrorTest", "test message")
                .Then(() => {
                Echo.Printf("Function successfully invoked?");
            });
        });
    }
    testHttpConnection() {
        const client = WebServiceClientFactory.getClient(WebServiceClientType.REST_CONNECTOR, this.getRequest().getHostUrl() + "connector.config.jsonp");
        client.getEvents().OnError(($eventArgs) => {
            Echo.Printf($eventArgs.Exception().ToString());
        });
        this.addButton("Self-Invoke function", () => {
            LiveContentWrapper.InvokeMethod(client, this.handlerClassName, "SelfCallMethod", "test message")
                .Then(() => {
                Echo.Printf("Function successfully invoked.");
            });
        });
        /// TODO: enable test after auth method will be possible
        // this.addButton("Secure Self-Invoke function", () : void => {
        //    LiveContentWrapper.InvokeMethod(client, this.handlerClassName, "SelfSecureCallMethod", "secure test message")
        //         .Then(() : void => {
        //             Echo.Printf("Function successfully invoked.");
        //         });
        // });
    }
    testConnector() {
        const connector = new RestServiceTestConnector(10, this.getRequest().getHostUrl() + "/connector.config.jsonp");
        this.addButton("Unpack invoke", () => {
            const basePath = this.getAbsoluteRoot() + "/../../test/resource/data/Io/Oidis/Localhost/Connectors";
            connector
                .Unpack(basePath + "/archTest1.zip")
                .Then(($path) => {
                Echo.Printf("Unpacked to: {0}", $path);
                connector
                    .Unpack(basePath + "/archTest1.tar.xz")
                    .Then(($path) => {
                    Echo.Printf("Unpacked to: {0}", $path);
                });
            });
        });
        this.addButton("Download invoke", () => {
            Echo.Printf("<span id=\"status\"></span>");
            connector
                .Download()
                .Then(($data) => {
                if ($data.type === "oncomplete") {
                    Echo.Printf("downloaded");
                }
                else if ($data.type === "onstart") {
                    Echo.Printf("download stared");
                }
                else if ($data.type === "onchange") {
                    document.getElementById("status").innerText = $data.data.currentValue;
                }
            });
        });
        this.addButton("Large data transfer", () => {
            let data = "";
            while (data.length < 70 * 1024) {
                data += "Some test string...Some test string...Some test string...Some test string...";
            }
            Echo.Printf("Send message with length: {0}", data.length);
            connector
                .DataTransfer(data)
                .Then(($length) => {
                Echo.Printf("Received message with length: {0}", $length);
                this.assertEquals(data.length, $length);
            });
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.Gui.RuntimeTests.RestServiceTestConnector", RestServiceTestConnector);
globalThis.RegisterClass("Io.Oidis.Localhost.Gui.RuntimeTests.RestServiceTest", RestServiceTest);
//# sourceMappingURL=RestServiceTest.js.map