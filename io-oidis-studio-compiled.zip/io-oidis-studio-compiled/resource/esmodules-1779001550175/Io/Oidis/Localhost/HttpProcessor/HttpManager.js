/*! ******************************************************************************************************** *
 *
 * Copyright 2010-2026 Jakub Cieslar
 * Copyright 2014-2026 Freescale Semiconductor, Inc.
 * Copyright 2017-2026 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpManager as Parent } from "./../../../../Io/Oidis/Services/HttpProcessor/HttpManager.js";
export class HttpManager extends Parent {
    /**
     * @returns {HttpRequestParser} Returns the HTTP request parser instance.
     */
    getRequest() {
        return super.getRequest();
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.HttpManager", HttpManager);
//# sourceMappingURL=HttpManager.js.map