/*! ******************************************************************************************************** *
 *
 * Copyright 2010-2026 Jakub Cieslar
 * Copyright 2014-2026 Freescale Semiconductor, Inc.
 * Copyright 2017-2026 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpRequestParser as Parent } from "./../../../../Io/Oidis/Commons/HttpProcessor/HttpRequestParser.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Loader } from "../Loader.js";
export class HttpRequestParser extends Parent {
    /**
     * @returns {string} Returns the request URL string.
     */
    getUrl() {
        if (this.isOnBackend()) {
            const url = this.getOwner().url;
            if (ObjectValidator.IsEmptyOrNull(url)) {
                return "/";
            }
            return url;
        }
        return super.getUrl();
    }
    /**
     * @returns {string} Returns the protocol scheme string.
     */
    getScheme() {
        if (this.isOnBackend()) {
            return this.getOwner().protocol;
        }
        return this.parsedInfo.scheme;
    }
    /**
     * @returns {string} Returns the client IP address string.
     */
    getClientIP() {
        if (this.isOnBackend()) {
            const request = this.getOwner();
            try {
                if (!ObjectValidator.IsEmptyOrNull(request) && request !== window) {
                    const ip = request.headers["x-forwarded-for"] ||
                        request.connection.remoteAddress ||
                        request.socket.remoteAddress ||
                        request.connection.socket.remoteAddress;
                    return ip.split(",")[0];
                }
            }
            catch (ex) {
                // unable to read or request properties correctly
            }
        }
        return super.getClientIP();
    }
    /**
     * @returns {string} Returns the server IP address string.
     */
    getServerIP() {
        if (this.isOnBackend()) {
            const interfaces = require("os").networkInterfaces();
            let output = this.parsedInfo.hostIpAddress;
            Object.keys(interfaces).forEach(($name) => {
                interfaces[$name].forEach(($networkInterface) => {
                    if ("IPv4" !== $networkInterface.family || $networkInterface.internal !== false) {
                        return;
                    }
                    output = $networkInterface.address;
                });
            });
            return output;
        }
        return this.parsedInfo.hostIpAddress;
    }
    getServerLocation() {
        if (this.isOnBackend()) {
            if ((this.getOwner() === window) &&
                !ObjectValidator.IsEmptyOrNull(Loader.getInstance().getAppConfiguration()?.domain?.location)) {
                return new URL("http://" + Loader.getInstance().getAppConfiguration().domain.location);
            }
            return new URL(this.getUrl(), "http://localhost");
        }
        return super.getServerLocation();
    }
    getNavigator() {
        if (this.isOnBackend()) {
            const userAgent = this.getRawHeaders().getItem("user-agent");
            return {
                cookieEnabled: false,
                language: "en-US",
                onLine: true,
                platform: "win64",
                userAgent: ObjectValidator.IsEmptyOrNull(userAgent) ? "Node.js Chrome/52.0.2743.116" : userAgent
            };
        }
        return super.getNavigator();
    }
    getRawHeaders() {
        if (this.isOnBackend()) {
            const headers = new ArrayList();
            try {
                if (!ObjectValidator.IsEmptyOrNull(this.getOwner()) && this.getOwner() !== window) {
                    let key;
                    for (key in this.getOwner().headers) {
                        if (this.getOwner().headers.hasOwnProperty(key)) {
                            headers.Add(this.getOwner().headers[key], StringUtils.ToLowerCase(key));
                        }
                    }
                }
            }
            catch (ex) {
                // unable to read or parse headers
            }
            return headers;
        }
        return new ArrayList();
    }
    isOnBackend() {
        const status = !Loader.getInstance().getEnvironmentArgs().HtmlOutputAllowed();
        this.isOnBackend = () => {
            return status;
        };
        return status;
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.HttpRequestParser", HttpRequestParser);
//# sourceMappingURL=HttpRequestParser.js.map