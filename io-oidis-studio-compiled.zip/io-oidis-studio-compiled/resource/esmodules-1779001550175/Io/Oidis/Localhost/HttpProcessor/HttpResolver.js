/*! ******************************************************************************************************** *
 *
 * Copyright 2010-2026 Jakub Cieslar
 * Copyright 2014-2026 Freescale Semiconductor, Inc.
 * Copyright 2017-2026 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpMethodType } from "./../../../../Io/Oidis/Commons/Enums/HttpMethodType.js";
import { LogSeverity } from "./../../../../Io/Oidis/Commons/Enums/LogSeverity.js";
import { isBrowser } from "./../../../../Io/Oidis/Commons/Utils/EnvironmentHelper.js";
import { JsonUtils } from "./../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectEncoder } from "./../../../../Io/Oidis/Commons/Utils/ObjectEncoder.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { HttpResolver as Parent } from "./../../../../Io/Oidis/Services/HttpProcessor/HttpResolver.js";
import { EventsManager } from "../Events/EventsManager.js";
import { Loader } from "../Loader.js";
import { EnvironmentHelper } from "../Utils/EnvironmentHelper.js";
import { HttpManager } from "./HttpManager.js";
import { HttpRequestParser } from "./HttpRequestParser.js";
export class HttpResolver extends Parent {
    /**
     * @param {string} $baseUrl Optional base URL override.
     * @returns {HttpRequestParser} Returns the new request parser.
     */
    CreateRequest($baseUrl) {
        return super.CreateRequest($baseUrl);
    }
    /**
     * @returns {EventsManager} Returns the server events manager.
     */
    getEvents() {
        return super.getEvents();
    }
    /**
     * @param {IFileSystemDownloadOptions} $options Fetch options including URL, method, headers.
     * @returns {Promise<IFetchAttributes>} Returns fetch result attributes.
     */
    async FetchHelper($options) {
        if (isBrowser) {
            /// TODO: FE implementation can be reused from VIT and used for async download with headers etc.
            //        > options will be able to resolve filename by DownloadUtils
            //        > client will be returned based on CORS conditions
            throw new Error("Only back-end calls are supported for FetchHelper");
        }
        const config = this.detectProxy($options.url, $options.proxyConfig);
        if (process.env.hasOwnProperty("DISABLE_STRICT_SSL") || Loader.getInstance().getAppConfiguration().disableStrictSSL ||
            !$options.strictSSL) {
            $options.url.strictSSL = false;
            $options.url.rejectUnauthorized = false;
        }
        if (($options.method === HttpMethodType.DELETE ||
            $options.method === HttpMethodType.CONNECT) && !ObjectValidator.IsEmptyOrNull($options.body)) {
            JsonUtils.Extend($options.headers, {
                "content-length": $options.body.length
            });
        }
        return await new Promise(($resolve, $reject) => {
            const request = this.fetchOptionsResolver($options);
            if (config.noProxy || (config.client === "http" && ObjectValidator.IsEmptyOrNull(config.agent))) {
                $resolve({ client: request.client, options: request.options });
            }
            else {
                require("http")
                    .request(request.proxy)
                    .on("connect", ($httpResponse, $socket) => {
                    if ($httpResponse.statusCode === 200) {
                        request.options.url.agent = new (request.agent)({ socket: $socket });
                        $resolve({ client: request.client, options: $options });
                    }
                })
                    .on("error", ($error) => {
                    $reject($error);
                })
                    .end();
            }
        });
    }
    getRequestParserClass() {
        return HttpRequestParser;
    }
    getHttpManagerClass() {
        return HttpManager;
    }
    getEventsManagerClass() {
        return EventsManager;
    }
    detectProxy($url, $config) {
        if (ObjectValidator.IsEmptyOrNull($config)) {
            $config = EnvironmentHelper.NormalizeProxySetting({});
        }
        // returns true is proxy should not be applied
        const checkUrlPattern = ($hostname, $port, $defaultPort) => {
            if (ObjectValidator.IsEmptyOrNull($config.noProxy)) {
                return true;
            }
            if ($config.noProxy === "*") {
                return true;
            }
            return $config.noProxy.split(",").some(($pattern) => {
                if (StringUtils.StartsWith($pattern, ".")) {
                    $pattern = StringUtils.Substring($pattern, 1);
                }
                if (!StringUtils.StartsWith($pattern, "*")) {
                    $pattern = "*" + $pattern;
                }
                return StringUtils.PatternMatched($pattern, $hostname) || StringUtils.PatternMatched($pattern, $hostname + ":" +
                    (ObjectValidator.IsEmptyOrNull($port) ? $defaultPort : $port));
            });
        };
        const retVal = {
            agent: "", // when agent is specified then proxy is required
            client: "", // client without agent means direct http/https/ws/wss connection
            excluded: false, // just for tests for now
            noProxy: false, // identify if proxy should be used or not
            proxyUrl: "" // return defined proxy url which should be used for next processing
        };
        if (ObjectValidator.IsEmptyOrNull($url)) {
            return retVal;
        }
        const destUrl = ObjectValidator.IsString($url) ? new (require("url").URL)($url) : $url;
        switch (destUrl.protocol) {
            case "ws:":
            case "http:":
                retVal.client = StringUtils.Remove(destUrl.protocol, ":");
                if (!ObjectValidator.IsEmptyOrNull($config.httpProxy)) {
                    if (!ObjectValidator.IsEmptyOrNull($config.noProxy)) {
                        if (checkUrlPattern(destUrl.hostname, destUrl.port, 80)) {
                            // excluded from proxy
                            retVal.excluded = true;
                            retVal.noProxy = true;
                        }
                    }
                    if (!retVal.noProxy) {
                        retVal.proxyUrl = $config.httpProxy;
                        // proxy enabled so update WS
                        if (retVal.client === "ws") {
                            retVal.client = "http"; // forced use of http client as entrypoint because secured proxy is not supported
                            retVal.agent = "ws"; // this also turn on http agent pool type
                        }
                    }
                }
                else {
                    // no proxy defined for dest url continue as normal for non-secure
                    retVal.noProxy = true;
                }
                break;
            case "wss:":
            case "https:":
                retVal.client = StringUtils.Remove(destUrl.protocol, ":");
                if (!ObjectValidator.IsEmptyOrNull($config.httpsProxy)) {
                    if (!ObjectValidator.IsEmptyOrNull($config.noProxy)) {
                        if (checkUrlPattern(destUrl.hostname, destUrl.port, 443)) {
                            // excluded from proxy
                            retVal.excluded = true;
                            retVal.noProxy = true;
                        }
                    }
                    if (!retVal.noProxy) {
                        retVal.proxyUrl = $config.httpsProxy;
                        if (retVal.client === "wss") {
                            retVal.agent = "wss"; // this also turn on https agent pool type
                        }
                        else {
                            retVal.agent = "https";
                        }
                        retVal.client = "http"; // forced use of http client as entrypoint because secured proxy is not supported
                    }
                }
                else {
                    // no proxy defined for dest url
                    retVal.noProxy = true;
                }
                break;
            default:
                throw new Error("Unsupported protocol");
        }
        LogIt.Info("> detected proxy: " + JSON.stringify(retVal), LogSeverity.LOW);
        return retVal;
    }
    fetchOptionsResolver($options) {
        $options = JsonUtils.Extend({
            body: "",
            headers: {},
            method: HttpMethodType.GET
        }, $options);
        const config = this.detectProxy($options.url, $options.proxyConfig);
        let client;
        if (config.client === "ws" || config.client === "wss" || config.agent === "ws" || config.agent === "wss") {
            client = require("websocket").w3cwebsocket;
        }
        else {
            client = require(config.client);
        }
        if (config.noProxy) {
            return { client, options: $options };
        }
        else {
            let proxy = config.proxyUrl;
            let target = $options.url;
            if (ObjectValidator.IsString(config.proxyUrl)) {
                proxy = new URL(config.proxyUrl);
            }
            if (ObjectValidator.IsString($options.url)) {
                target = new URL($options.url);
            }
            if (!ObjectValidator.IsEmptyOrNull(proxy.auth)) {
                proxy.headers = JsonUtils.Extend(proxy.headers, {
                    "Proxy-Authorization": "Basic " + ObjectEncoder.Base64(proxy.auth)
                });
            }
            if (!ObjectValidator.IsEmptyOrNull($options.strictSSL)) {
                proxy.strictSSL = $options.url.strictSSL;
                proxy.rejectUnauthorized = $options.url.rejectUnauthorized;
            }
            let agent = null;
            if (config.client === "http" && config.agent === "") {
                $options.url = proxy;
                $options.url.method = $options.method;
                $options.url.headers = $options.headers;
                $options.url.headers.Host = target.hostname;
                $options.url.path = target.href;
            }
            else {
                if (config.agent === "http" || config.agent === "https") {
                    client = require(config.agent);
                }
                proxy.method = HttpMethodType.CONNECT;
                proxy.path = target.hostname + ":";
                if (ObjectValidator.IsEmptyOrNull(target.port)) {
                    proxy.path += (config.agent === "ws" || config.agent === "http" ? 80 : 443);
                }
                else {
                    proxy.path += target.port;
                }
                agent = require(config.agent === "wss" || config.agent === "https" ? "https" : "http").Agent;
            }
            return { client, options: $options, proxy, agent };
        }
    }
}
// generated-code-start
export const IProxyAttributes = globalThis.RegisterInterface(["client", "excluded", "noProxy", "agent", "proxyUrl"]);
export const IFetchAttributes = globalThis.RegisterInterface(["client", "options"]);
export const IFetchResolver = globalThis.RegisterInterface(["proxy", "agent"], IFetchAttributes);
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.HttpResolver", HttpResolver);
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.IProxyAttributes", IProxyAttributes);
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.IFetchAttributes", IFetchAttributes);
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.IFetchResolver", IFetchResolver);
//# sourceMappingURL=HttpResolver.js.map