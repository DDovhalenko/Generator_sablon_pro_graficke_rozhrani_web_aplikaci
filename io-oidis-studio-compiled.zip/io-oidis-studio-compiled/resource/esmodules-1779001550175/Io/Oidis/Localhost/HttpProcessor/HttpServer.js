/*! ******************************************************************************************************** *
 *
 * Copyright 2010-2013 Jakub Cieslar
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { DataFormatType } from "./../../../../Io/Oidis/Commons/Enums/DataFormatType.js";
import { EventType } from "./../../../../Io/Oidis/Commons/Enums/Events/EventType.js";
import { HttpMethodType } from "./../../../../Io/Oidis/Commons/Enums/HttpMethodType.js";
import { HttpStatusType } from "./../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { AsyncRequestEventArgs } from "./../../../../Io/Oidis/Commons/Events/Args/AsyncRequestEventArgs.js";
import { PersistenceFactory } from "./../../../../Io/Oidis/Commons/PersistenceApi/PersistenceFactory.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { Convert } from "./../../../../Io/Oidis/Commons/Utils/Convert.js";
import { JsonUtils } from "./../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectEncoder } from "./../../../../Io/Oidis/Commons/Utils/ObjectEncoder.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { CertsConnector } from "./../../../../Io/Oidis/Services/Connectors/CertsConnector.js";
import { Resources } from "./../../../../Io/Oidis/Services/DAO/Resources.js";
import { HttpServerEventType } from "../Enums/HttpServerEventType.js";
import { HttpServerEventArgs } from "../Events/Args/HttpServerEventArgs.js";
import { EventsManager } from "../Events/EventsManager.js";
import { Loader } from "../Loader.js";
import { CertsManager } from "../Utils/CertsManager.js";
import { Metrics } from "../Utils/Metrics.js";
import { HttpRequestParser } from "./HttpRequestParser.js";
import { ConnectorResponse } from "./Resolvers/ConnectorResponse.js";
import { WebResponse } from "./ResponseApi/Handlers/WebResponse.js";
import { ResponseFactory } from "./ResponseApi/ResponseFactory.js";
export class HttpServer extends BaseObject {
    static httpArgs = new ArrayList();
    ports;
    httpServers;
    wsServers;
    responseBuffer;
    environment;
    properties;
    onCloseHandler;
    responsePersistence;
    events;
    fileSystem;
    ssl;
    tunnels;
    certsPort;
    requestIndex;
    /**
     * @param {HttpRequestParser} $request Parsed HTTP request.
     * @param {WebResponse} $response Web response object.
     * @param {HttpStatusType} $status HTTP status code.
     * @param {any} $headers Response headers object.
     * @param {string} $data Response body data.
     */
    static SendData($request, $response, $status, $headers, $data) {
        if (ObjectValidator.IsEmptyOrNull($response) && !ObjectValidator.IsEmptyOrNull(HttpServer.httpArgs.getLast())) {
            $response = HttpServer.httpArgs.getLast().POST().getItem("Connector");
        }
        if (!Loader.getInstance().getEnvironmentArgs().HtmlOutputAllowed() && !ObjectValidator.IsEmptyOrNull($response)) {
            $response.Send({
                body: $data.replace(/<body(.*)>/gm, "<body>"),
                headers: $headers,
                status: $status
            });
        }
    }
    /**
     * @param {WebResponse} $response Web response object.
     * @returns {AsyncRequestEventArgs} Returns the request event arguments.
     */
    static getRequestArgs($response) {
        return this.httpArgs.getItem("arg_" + $response.getOwnerId());
    }
    constructor() {
        super();
        this.onCloseHandler = () => {
            // default handler
        };
        this.ports = [];
        this.httpServers = [];
        this.wsServers = [];
        this.responseBuffer = {};
        this.environment = Loader.getInstance().getEnvironmentArgs();
        this.properties = Loader.getInstance().getAppConfiguration();
        this.responsePersistence = PersistenceFactory.getPersistence(ConnectorResponse.ClassName());
        this.events = new EventsManager();
        this.fileSystem = Loader.getInstance().getFileSystemHandler();
        this.ssl = {
            cert: null,
            key: null
        };
        this.tunnels = {};
        if (!ObjectValidator.IsEmptyOrNull(this.properties.reverseProxy) &&
            !ObjectValidator.IsEmptyOrNull(this.properties.reverseProxy.tunnels)) {
            this.tunnels = this.properties.reverseProxy.tunnels;
        }
        this.certsPort = -1;
        this.requestIndex = 0;
    }
    /**
     * @param {() => void} $handler Close event handler function.
     */
    setOnCloseHandler($handler) {
        this.onCloseHandler = $handler;
    }
    Start() {
        if (!this.properties.reverseProxy.enabled && !this.properties.domain.ssl.enabled) {
            LogIt.Debug("HTTPS server has not been started due SSL server configuration.");
            this.createServer(this.properties.domain.ports.http, false, true, [Loader.getInstance().getProgramArgs().ProjectBase()]);
        }
        else {
            this.getCerts(this.properties.domain.location, ($cert, $key) => {
                this.ssl.cert = $cert;
                this.ssl.key = $key;
                if (this.properties.reverseProxy.enabled) {
                    this.createProxy(true, true);
                    if (this.properties.reverseProxy.withServer) {
                        let registerTunnel = true;
                        this.getEvents().OnStart(($eventArgs) => {
                            if (registerTunnel) {
                                registerTunnel = false;
                                this.tunnels[this.properties.domain.location] = {
                                    port: $eventArgs.Port(),
                                    ssl: {
                                        cert: this.ssl.cert,
                                        key: this.ssl.key
                                    }
                                };
                            }
                        });
                        this.createServer(0, false, true, [Loader.getInstance().getProgramArgs().ProjectBase()]);
                    }
                }
                else {
                    this.createServer(this.properties.domain.ports.http, false, true);
                    this.createServer(this.properties.domain.ports.https, true, true, [Loader.getInstance().getProgramArgs().ProjectBase()]);
                }
            });
        }
    }
    Stop() {
        this.wsServers.forEach(($server) => {
            try {
                $server.shutDown();
            }
            catch (ex) {
                LogIt.Warning("Unable to stop WS server. " + ex.stack);
            }
        });
        this.httpServers.forEach(($server) => {
            try {
                $server.close();
            }
            catch (ex) {
                LogIt.Warning("Unable to stop HTTP server. " + ex.stack);
            }
        });
        this.wsServers = [];
        this.httpServers = [];
        this.ports = [];
    }
    /**
     * @returns {IHttpServerEvents} Returns the server event handlers object.
     */
    getEvents() {
        return {
            OnConnect: ($handler) => {
                this.events.setEvent(this.getClassName(), HttpServerEventType.ON_CONNECT, $handler);
            },
            OnDisconnect: ($handler) => {
                this.events.setEvent(this.getClassName(), HttpServerEventType.ON_DISCONNECT, $handler);
            },
            OnStart: ($handler) => {
                this.events.setEvent(this.getClassName(), EventType.ON_START, $handler);
            }
        };
    }
    /**
     * @param {IResponse} $response Response object to remove from the buffer.
     */
    Clear($response) {
        const responseId = "res_" + ResponseFactory.getResponse($response).getId();
        try {
            if (this.responseBuffer.hasOwnProperty(responseId)) {
                // eslint-disable-next-line @typescript-eslint/no-array-delete
                delete this.responseBuffer[responseId];
            }
        }
        catch (ex) {
            LogIt.Error("Failed to clean up response: " + responseId, ex);
        }
    }
    getCerts($domain, $callback) {
        $domain = StringUtils.Remove($domain, "https://", "http://");
        const handler = new CertsManager($domain, this.getTunnel($domain));
        const paths = handler.getCertPaths();
        if (this.fileSystem.Exists(paths.certificatePath) && this.fileSystem.Exists(paths.privateKeyPath)) {
            $callback(this.fileSystem.Read(paths.certificatePath), this.fileSystem.Read(paths.privateKeyPath));
        }
        else if (this.properties.certs.external) {
            new CertsConnector()
                .getCertsFor($domain)
                .Then(($cert, $key) => {
                if (!ObjectValidator.IsEmptyOrNull($cert)) {
                    this.fileSystem.Write(paths.certificatePath, $cert);
                }
                if (!ObjectValidator.IsEmptyOrNull($key)) {
                    this.fileSystem.Write(paths.privateKeyPath, $key);
                }
                $callback($cert, $key);
            });
        }
        else {
            let createServer = false;
            if (this.certsPort <= 0) {
                this.certsPort = this.properties.certs.port;
                if (!this.ports.includes(this.certsPort)) {
                    createServer = true;
                }
                else if (this.ports.includes(this.certsPort) && !this.properties.reverseProxy.withServer) {
                    createServer = true;
                    this.certsPort = 0;
                }
            }
            else if (!this.ports.includes(this.certsPort)) {
                createServer = true;
            }
            let serverStarted = false;
            const handleCerts = () => {
                handler.Create(($status, $cert, $key) => {
                    if (serverStarted) {
                        const index = this.ports.indexOf(this.certsPort);
                        if (index > -1) {
                            try {
                                this.httpServers[index].close();
                                this.httpServers.splice(index, 1);
                                this.ports.splice(index, 1);
                            }
                            catch (ex) {
                                LogIt.Warning("Unable to stop ACME server. " + ex.stack);
                            }
                        }
                    }
                    if ($status) {
                        $callback($cert, $key);
                    }
                    else {
                        $callback(null, null);
                    }
                });
            };
            if (createServer) {
                LogIt.Debug("> create certs server at: " + this.certsPort);
                if (this.certsPort === 0) {
                    this.getEvents().OnStart(($eventArgs) => {
                        if (this.certsPort === 0) {
                            this.certsPort = $eventArgs.Port();
                            handleCerts();
                        }
                    });
                }
                this.createServer(this.certsPort, false, false);
                serverStarted = true;
                if (this.certsPort > 0) {
                    handleCerts();
                }
            }
            else {
                handleCerts();
            }
        }
    }
    createServer($port, $isSecure, $includeWebSocket, $configPaths = []) {
        const metrics = Metrics.getInstance();
        const path = require("path");
        let config = {};
        const protocolName = "wuihost";
        const token = "";
        const serverIP = Loader.getInstance().getHttpManager().getRequest().getServerIP();
        const hostName = this.properties.domain.location !== "localhost" ?
            Loader.getInstance().getHttpManager().getRequest().getServerIP() : this.properties.domain.location;
        let protocol;
        let httpServer;
        try {
            if ($isSecure) {
                protocol = "https://";
                if (!ObjectValidator.IsEmptyOrNull(this.ssl.cert) && !ObjectValidator.IsEmptyOrNull(this.ssl.key)) {
                    httpServer = require("https").createServer({
                        cert: this.ssl.cert,
                        key: this.ssl.key
                    });
                }
                else {
                    LogIt.Warning("Failed to start HTTPS server. " +
                        "Certificates has not been found, please validate server configuration.");
                }
            }
            else {
                protocol = "http://";
                httpServer = require("http").createServer();
            }
        }
        catch (ex) {
            LogIt.Error("Failed to create server.", ex);
        }
        if (!ObjectValidator.IsEmptyOrNull(httpServer)) {
            this.httpServers.push(httpServer);
            httpServer.on("error", ($error) => {
                LogIt.Warning($error.toString());
            });
            httpServer.on("request", ($request, $response) => {
                const clientId = this.requestIndex++;
                let requestProtocol = protocol;
                if (!ObjectValidator.IsEmptyOrNull($request.headers.referer)) {
                    requestProtocol = StringUtils.Contains($request.headers.referer, "https://") ? "https://" : "http://";
                }
                $request.protocol = requestProtocol;
                let origin = requestProtocol + config.address;
                if (config.port !== 80 && config.port !== 433) {
                    origin += ":" + config.port;
                }
                let requestUrl = (new URL($request.url, "http://localhost")).pathname;
                if (StringUtils.OccurrenceCount(requestUrl, "/resource/") > 1) {
                    requestUrl = StringUtils.Substring(requestUrl, StringUtils.IndexOf(requestUrl, "/resource/", false));
                }
                if (!this.isRequestAllowed($request, hostName, requestProtocol, $port, serverIP)) {
                    this.sendHttpResponse(clientId, $response, 400, {}, "Request is not allowed", $request.headers["accept-encoding"]);
                    LogIt.Debug("rejected {0} request: {1}", $request.method, requestUrl);
                    return;
                }
                else {
                    let createLog = false;
                    if ($request.method === HttpMethodType.GET) {
                        createLog = true;
                        this.getHttpGetFilterPatterns().forEach(($pattern) => {
                            if (createLog && StringUtils.PatternMatched($pattern, requestUrl)) {
                                createLog = false;
                            }
                        });
                    }
                    else {
                        createLog = true;
                    }
                    if (createLog) {
                        LogIt.Debug("{0} request: {1}", $request.method, requestUrl);
                        metrics.Start(origin + requestUrl, $request.method);
                    }
                }
                try {
                    if ($request.method === HttpMethodType.TRACE) {
                        Metrics.getInstance().AddMeasurement({
                            type: "http",
                            inbound: true,
                            size: 0
                        });
                        this.sendHttpResponse(clientId, $response, HttpStatusType.NOT_ALLOWED, {}, "", $request.headers["accept-encoding"]);
                    }
                    else if (this.isRequestWithBody($request)) {
                        let messageData = "";
                        $request.on("data", ($message) => {
                            messageData += $message.toString();
                        });
                        $request.on("end", () => {
                            Metrics.getInstance().AddMeasurement({
                                type: "http",
                                inbound: true,
                                size: messageData.length
                            });
                            this.resolveHttpRequest(requestUrl, messageData, clientId, $request, $response, origin, token);
                            messageData = "";
                            metrics.End();
                        });
                    }
                    else if ($request.method === HttpMethodType.OPTIONS && StringUtils.StartsWith(requestUrl, "/xorigin")) {
                        Metrics.getInstance().AddMeasurement({
                            type: "http",
                            inbound: true,
                            size: 0
                        });
                        this.sendHttpResponse(clientId, $response, HttpStatusType.SUCCESS, {
                            "access-control-allow-origin": requestProtocol + hostName,
                            "access-control-allow-methods": "POST, GET, OPTIONS",
                            "access-control-allow-headers": "X-PINGOTHER, Content-Type",
                            "access-control-max-age": 86400,
                            "content-length": 0,
                            "content-type": "text/plain"
                        }, "", $request.headers["accept-encoding"]);
                        metrics.End();
                    }
                    else {
                        Metrics.getInstance().AddMeasurement({
                            type: "http",
                            inbound: true,
                            size: 0
                        });
                        this.resolveHttpRequest(requestUrl, config, clientId, $request, $response, origin, token);
                        metrics.End();
                    }
                }
                catch (ex) {
                    this.sendHttpResponse(clientId, $response, HttpStatusType.ERROR, {}, "Internal server error: " + ex.stack, $request.headers["accept-encoding"]);
                }
            });
            httpServer.once("error", ($error) => {
                if ($error.code === "EADDRINUSE" || $error.code === "EACCES") {
                    LogIt.Error("Cannot start server, because required port " + $port + " is already in use.");
                }
            });
            httpServer.listen($port, () => {
                if (ObjectValidator.IsEmptyOrNull(this.properties.domain.location)) {
                    this.properties.domain.location = hostName;
                }
                const port = httpServer.address().port;
                this.ports.push(port);
                config = {
                    accept: this.properties.lcpConfig.accept,
                    address: this.properties.domain.location,
                    base: "/" + protocolName,
                    location: __dirname,
                    port,
                    responseUrl: protocol + this.properties.domain.location + ":" + port + "/{0}/response.jsonp",
                    timeout: httpServer.timeout / 1000,
                    version: this.properties.version
                };
                const fileSystem = Loader.getInstance().getFileSystemHandler();
                const configFileName = "connector.config" + (Loader.getInstance().getProgramArgs().IsDebug() ? ".js" : ".jsonp");
                const createdConfigs = [];
                $configPaths.forEach(($path) => {
                    let directory = $path;
                    if (this.fileSystem.Exists(directory) && !this.fileSystem.IsDirectory(directory)) {
                        directory = path.dirname($path);
                    }
                    if (!this.fileSystem.Exists(directory) &&
                        StringUtils.Contains(directory, Loader.getInstance().getProgramArgs().ProjectBase())) {
                        this.fileSystem.CreateDirectory(directory);
                    }
                    if (this.fileSystem.Exists(directory)) {
                        if (!StringUtils.EndsWith(directory, "/" + configFileName)) {
                            $path = directory + "/" + configFileName;
                        }
                        if (!createdConfigs.includes($path)) {
                            if (fileSystem.Write($path, "JsonpData(" + JSON.stringify(config) + ");")) {
                                createdConfigs.push($path);
                            }
                            else {
                                LogIt.Warning("Failed to create config file at: \"" + $path + "\"");
                            }
                        }
                    }
                    else {
                        LogIt.Warning("Creation of config file at \"" + $path + "\" skipped: path does not exist");
                    }
                });
                LogIt.Info(($isSecure ? "SECURE server" : "Server") + " " +
                    this.environment.getAppName() + " has been started at: " +
                    protocol + ($isSecure ? this.properties.domain.location : hostName) + ":" + port);
                this.events.FireEvent(this.getClassName(), EventType.ON_START, new HttpServerEventArgs(port));
            });
            if ($includeWebSocket) {
                const targetPath = Loader.getInstance().getProgramArgs().TargetBase();
                let configPath = targetPath + "/resource/libs/OidisConnector/connector.config.jsonp";
                if (!this.fileSystem.Exists(configPath)) {
                    configPath = targetPath + "/resource/libs/WuiConnector/connector.config.jsonp";
                }
                let configData;
                if (this.fileSystem.Exists(configPath) && this.properties.connectorProxy) {
                    try {
                        let config = this.fileSystem.Read(configPath).toString();
                        config = StringUtils.Substring(config, StringUtils.IndexOf(config, "({") + 1, StringUtils.IndexOf(config, "});", false) + 1);
                        configData = JSON.parse(config);
                    }
                    catch (ex) {
                        LogIt.Error("Unable to parse " + configPath, ex);
                    }
                }
                if (!ObjectValidator.IsEmptyOrNull(configData)) {
                    httpServer.on("upgrade", ($serverRequest, $serverResponse, $serverHead) => {
                        LogIt.Debug("Started target WS communication at: {0}", "ws://" + configData.address + ":" + configData.port + $serverRequest.url);
                        this.createWsProxyClient($serverRequest, $serverResponse, $serverHead, this.getRequestOptions($serverRequest, {
                            location: "http://" + configData.address,
                            port: configData.port
                        }, {
                            origin: configData.address
                        }));
                    });
                }
                else {
                    const webSocketServer = require("websocket").server;
                    const wsServer = new webSocketServer({
                        autoAcceptConnections: false,
                        httpServer,
                        /// TODO: can it be more for binary data?
                        maxReceivedFrameSize: 1024 * 1024,
                        maxReceivedMessageSize: 1024 * 1024 * 1024
                    });
                    this.wsServers.push(wsServer);
                    let wsRequestIndex = 0;
                    wsServer.on("request", ($request) => {
                        if (!this.isRequestAllowed($request, hostName, protocol, $port, serverIP)) {
                            $request.reject();
                            LogIt.Info((new Date()) + " Connection from origin \"" + $request.origin + "\" rejected.");
                            return;
                        }
                        let connection;
                        try {
                            connection = $request.accept(protocolName, $request.origin);
                        }
                        catch ($ex) {
                            LogIt.Error("Unable to accept connection.", $ex);
                            $request.reject();
                            return;
                        }
                        const clientId = wsRequestIndex++;
                        LogIt.Debug((new Date()) + " Connection accepted.");
                        this.events.FireEvent(this.getClassName(), HttpServerEventType.ON_CONNECT, new HttpServerEventArgs($port, clientId));
                        const threadsRegister = [];
                        let isChunked = false;
                        const processRawData = ($data, isBinary) => {
                            isChunked = false;
                            let headers = $request.httpRequest.headers;
                            if (ObjectValidator.IsEmptyOrNull(headers)) {
                                headers = {};
                            }
                            if (!ObjectValidator.IsEmptyOrNull(headers.referer)) {
                                $isSecure = StringUtils.Contains(headers.referer, "https://");
                            }
                            let address = config.address;
                            let port = config.port;
                            if (!ObjectValidator.IsEmptyOrNull(headers.host) && !StringUtils.Contains(headers.host, hostName)) {
                                port = $isSecure ? 443 : 80;
                                if (!ObjectValidator.IsEmptyOrNull(headers["x-forwarded-host"])) {
                                    address = headers["x-forwarded-host"];
                                }
                                if (StringUtils.Contains(address, ":")) {
                                    port = StringUtils.ToInteger(StringUtils.Substring(address, StringUtils.IndexOf(address, ":") + 1));
                                    address = StringUtils.Substring(address, 0, StringUtils.IndexOf(address, ":"));
                                }
                            }
                            let origin = (!$isSecure ? "ws://" : "wss://") + address;
                            if (port !== 80 && port !== 433) {
                                origin += ":" + port;
                            }
                            threadsRegister.push(setTimeout(() => {
                                try {
                                    this.resolveRequest("/xorigin", $data, {
                                        Send($data) {
                                            try {
                                                if (!ObjectValidator.IsString($data)) {
                                                    $data.origin = origin;
                                                    $data.token = token;
                                                }
                                                if (isBinary) {
                                                    $data = JsonUtils.ToBuffer($data);
                                                    connection.sendBytes($data);
                                                }
                                                else {
                                                    if (!ObjectValidator.IsString($data)) {
                                                        $data = JSON.stringify($data);
                                                    }
                                                    connection.sendUTF($data);
                                                }
                                                metrics.AddMeasurement({
                                                    type: "ws",
                                                    size: $data.length,
                                                    format: isBinary ? DataFormatType.BINARY : DataFormatType.UTF8
                                                });
                                            }
                                            catch (ex) {
                                                metrics.Error(ex);
                                                LogIt.Info(ex.stack);
                                            }
                                        },
                                        getOwnerId: () => {
                                            return clientId + "";
                                        },
                                        getParentProcess: () => {
                                            return this;
                                        }
                                    }, $request, true);
                                    $data = null;
                                }
                                catch (ex) {
                                    metrics.Error(ex);
                                    let message;
                                    if (isBinary) {
                                        message = JsonUtils.ToBuffer(this.getErrorProtocol(ex, origin, token, false));
                                        connection.sendBytes(message);
                                    }
                                    else {
                                        message = JSON.stringify(this.getErrorProtocol(ex, origin, token));
                                        connection.sendUTF(message);
                                    }
                                    metrics.AddMeasurement({
                                        type: "ws",
                                        size: message.length,
                                        format: isBinary ? DataFormatType.BINARY : DataFormatType.UTF8
                                    });
                                    message = null;
                                }
                            }));
                        };
                        let messageLength = -1;
                        let chunkLength = -1;
                        let messageData = "";
                        const readChunk = ($data, isBinary) => {
                            let initStream = true;
                            if (messageLength === -1) {
                                const info = $data.split("\n");
                                messageLength = parseInt(info[0], 10);
                                chunkLength = parseInt(info[1], 10);
                                messageData = "";
                            }
                            else if (messageLength > chunkLength && messageData.length < messageLength) {
                                messageData += $data;
                                if (messageData.length >= messageLength) {
                                    initStream = false;
                                }
                            }
                            else {
                                messageData = $data;
                                initStream = false;
                            }
                            if (messageData.length >= messageLength) {
                                messageData = messageData.slice(0, messageLength);
                                messageLength = -1;
                                metrics.AddMeasurement({
                                    type: "ws",
                                    inbound: true,
                                    size: messageData.length,
                                    format: isBinary ? DataFormatType.BINARY : DataFormatType.UTF8
                                });
                                processRawData(messageData, isBinary);
                            }
                            else if (!initStream) {
                                setTimeout(() => {
                                    const errorMessage = "Received message with incorrect length: " + messageData.length;
                                    metrics.Error(errorMessage);
                                    LogIt.Info(errorMessage);
                                    let message;
                                    if (isBinary) {
                                        message = JsonUtils.ToBuffer(this.getErrorProtocol(errorMessage, origin, token, false));
                                        connection.sendBytes(message);
                                    }
                                    else {
                                        message = JSON.stringify(this.getErrorProtocol(errorMessage, origin, token));
                                        connection.sendUTF(message);
                                    }
                                    metrics.AddMeasurement({
                                        type: "ws",
                                        size: message.length,
                                        format: isBinary ? DataFormatType.BINARY : DataFormatType.UTF8
                                    });
                                    message = null;
                                });
                            }
                            if (!initStream) {
                                connection.sendUTF("OK");
                                metrics.AddMeasurement({
                                    type: "ws",
                                    size: 2,
                                    format: DataFormatType.UTF8
                                });
                            }
                        };
                        connection.on("message", ($message) => {
                            const isBinary = $message.type === "binary";
                            const data = isBinary ? JsonUtils.ToJson($message.binaryData) : $message.utf8Data;
                            if (data === "Server.Stop") {
                                wsServer.shutDown();
                                this.onCloseHandler();
                            }
                            else {
                                if (!isChunked && messageLength === -1 && ObjectValidator.IsString(data) && data.endsWith("\n35000")) {
                                    isChunked = true;
                                }
                                if (isChunked) {
                                    readChunk(data, isBinary);
                                }
                                else {
                                    metrics.AddMeasurement({
                                        type: "ws",
                                        inbound: true,
                                        size: isBinary ? $message.binaryData.length : data.length,
                                        format: isBinary ? DataFormatType.BINARY : DataFormatType.UTF8
                                    });
                                    processRawData(data, isBinary);
                                    connection.sendUTF("OK");
                                    metrics.AddMeasurement({
                                        type: "ws",
                                        size: 2,
                                        format: DataFormatType.UTF8
                                    });
                                }
                            }
                        });
                        connection.on("close", ($reasonCode, $description) => {
                            try {
                                threadsRegister.forEach(($threadId) => {
                                    clearTimeout($threadId);
                                });
                                let responseId;
                                // eslint-disable-next-line @typescript-eslint/no-for-in-array
                                for (responseId in this.responseBuffer) {
                                    if (this.responseBuffer.hasOwnProperty(responseId) && StringUtils.StartsWith(responseId, "res_")) {
                                        if (this.responseBuffer[responseId].getOwnerId() === clientId + "") {
                                            LogIt.Debug("Abort response: " + responseId);
                                            this.responseBuffer[responseId].Abort();
                                            // eslint-disable-next-line @typescript-eslint/no-array-delete
                                            delete this.responseBuffer[responseId];
                                        }
                                    }
                                }
                            }
                            catch (ex) {
                                LogIt.Warning(ex.stack);
                            }
                            LogIt.Debug("Peer " + connection.remoteAddress + " disconnected. [" + $reasonCode + "]: " + $description);
                            this.events.FireEvent(this.getClassName(), HttpServerEventType.ON_DISCONNECT, new HttpServerEventArgs($port, clientId));
                        });
                        connection.on("error", ($error) => {
                            if (!StringUtils.Contains($error.message, "ECONNRESET")) {
                                metrics.Error($error);
                                LogIt.Warning($error.stack);
                            }
                        });
                    });
                    wsServer.on("error", ($error) => {
                        LogIt.Warning($error);
                    });
                }
            }
        }
    }
    createProxy($isSecure, $includeWebSocket) {
        const Readable = require("stream").Readable;
        const http = require("http");
        const https = require("https");
        const tls = require("tls");
        const initServer = ($isSecure, $server, $port) => {
            this.ports.push($port);
            this.httpServers.push($server);
            $server.on("request", ($serverRequest, $serverResponse) => {
                const proxy = ($config, $body) => {
                    try {
                        let options = this.getRequestOptions($serverRequest, $config);
                        if (StringUtils.Contains($serverRequest.url, ".well-known/acme-challenge")) {
                            if (ObjectValidator.IsEmptyOrNull(this.properties.certs.location)) {
                                this.properties.certs.location = "http://localhost";
                            }
                            options = this.getRequestOptions($serverRequest, {
                                location: this.properties.certs.location,
                                port: this.certsPort
                            });
                            LogIt.Debug("proxy challenge for: {0}", $config.name);
                        }
                        else {
                            LogIt.Debug("proxy {0}: {1}", $serverRequest.method, $config.location + ":" + $config.port + $serverRequest.url);
                        }
                        const client = (options.protocol === "https:" ? https : http)
                            .request(options, ($targetResponse) => {
                            const data = [];
                            $targetResponse.on("data", ($chunk) => {
                                data.push($chunk);
                            });
                            $targetResponse.on("end", () => {
                                try {
                                    const body = new Readable();
                                    body._read = () => {
                                        // mock _read
                                    };
                                    body.push(Buffer.concat(data));
                                    body.push(null);
                                    $serverResponse.writeHead($targetResponse.statusCode, $targetResponse.headers);
                                    body.pipe($serverResponse);
                                }
                                catch (ex) {
                                    LogIt.Warning(ex.stack);
                                }
                            });
                            $targetResponse.on("close", () => {
                                LogIt.Debug("Proxy request closed.");
                            });
                            $targetResponse.on("error", ($error) => {
                                LogIt.Warning("Proxy " + $error.stack);
                            });
                        });
                        $serverRequest.on("aborted", () => {
                            client.destroy();
                        });
                        client.on("error", ($ex) => {
                            LogIt.Warning("Proxy " + $ex.stack);
                        });
                        if (!ObjectValidator.IsEmptyOrNull($body)) {
                            client.write($body);
                        }
                        client.end();
                    }
                    catch (ex) {
                        LogIt.Warning(ex.stack);
                    }
                };
                const config = this.getTunnel($serverRequest);
                if (!ObjectValidator.IsEmptyOrNull(config)) {
                    if (this.isRequestWithBody($serverRequest)) {
                        const data = [];
                        $serverRequest.on("data", ($chunk) => {
                            data.push($chunk);
                        });
                        $serverRequest.on("end", () => {
                            proxy(config, Buffer.concat(data));
                        });
                    }
                    else {
                        proxy(config);
                    }
                }
            });
            if ($includeWebSocket) {
                $server.on("upgrade", ($serverRequest, $serverResponse, $serverHead) => {
                    const config = this.getTunnel($serverRequest);
                    if (!ObjectValidator.IsEmptyOrNull(config)) {
                        LogIt.Debug("proxy WS: " + config.location + ":" + config.port + $serverRequest.url);
                        this.createWsProxyClient($serverRequest, $serverResponse, $serverHead, this.getRequestOptions($serverRequest, config));
                    }
                });
            }
            $server.once("error", ($error) => {
                if ($error.code === "EADDRINUSE" || $error.code === "EACCES") {
                    LogIt.Error("Cannot start proxy, because required port " + $port + " is already in use.");
                }
            });
            $server.listen($port, () => {
                LogIt.Debug("Proxy has been started at: " + ($isSecure ? "https://" : "http://") +
                    Loader.getInstance().getHttpManager().getRequest().getServerIP() + ":" + $port);
            });
        };
        initServer(false, http.createServer(), this.properties.domain.ports.http);
        if ($isSecure) {
            initServer(true, https.createServer({
                SNICallback: ($hostname, $callback) => {
                    const config = this.getTunnel($hostname);
                    if (ObjectValidator.IsEmptyOrNull(config)) {
                        $callback(null, tls.createSecureContext({}));
                    }
                    else {
                        if ((ObjectValidator.IsEmptyOrNull(config.ssl.cert) || ObjectValidator.IsEmptyOrNull(config.ssl.key)) &&
                            !config.requested) {
                            this.getCerts(config.name, ($cert, $key) => {
                                config.requested = true;
                                if (!ObjectValidator.IsEmptyOrNull($cert) && !ObjectValidator.IsEmptyOrNull($key)) {
                                    config.ssl.cert = $cert;
                                    config.ssl.key = $key;
                                    $callback(null, tls.createSecureContext(config.ssl));
                                }
                                else {
                                    LogIt.Warning("Certificates for " + config.name + " has not been found, " +
                                        "please validate proxy configuration.");
                                    $callback(null, tls.createSecureContext({}));
                                }
                            });
                        }
                        else if (!ObjectValidator.IsEmptyOrNull(config.ssl.cert) && !ObjectValidator.IsEmptyOrNull(config.ssl.key)) {
                            $callback(null, tls.createSecureContext(config.ssl));
                        }
                        else {
                            $callback(null, tls.createSecureContext({}));
                        }
                    }
                },
                cert: this.ssl.cert,
                key: this.ssl.key
            }), this.properties.domain.ports.https);
        }
    }
    isRequestAllowed($request, $hostName, $protocol, $port, $ip) {
        const origins = [
            "file://",
            $protocol + "127.0.0.1",
            this.properties.domain.location,
            $protocol + this.properties.domain.location,
            $protocol + this.properties.domain.location + ":" + $port,
            $protocol + $hostName,
            $protocol + $hostName + ":" + $port
        ];
        if (!ObjectValidator.IsEmptyOrNull($ip)) {
            if (!origins.includes($ip)) {
                origins.push($ip);
                origins.push($protocol + $ip);
                origins.push($protocol + $ip + ":" + $port);
            }
        }
        if (!ObjectValidator.IsEmptyOrNull(this.properties.domain.origins)) {
            this.properties.domain.origins.forEach(($origin) => {
                if (!origins.includes($origin)) {
                    origins.push($origin);
                    origins.push($protocol + $origin);
                    origins.push($protocol + $origin + ":" + $port);
                }
            });
        }
        const origin = $request.origin;
        return (ObjectValidator.IsEmptyOrNull(origin) || origin === "null" ||
            origins.includes(origin) || origins.includes($request.host) ||
            StringUtils.StartsWith(origin, $protocol + "localhost")) &&
            !StringUtils.EndsWith($request.url, ".php");
    }
    resolveRequest($url, $data, $connector, $request, $keepAlive) {
        try {
            if (StringUtils.StartsWith($url, "/xorigin") &&
                ((ObjectValidator.IsString($data) && !ObjectValidator.IsEmptyOrNull($data)) ||
                    (ObjectValidator.IsSet($data.format) && $data.format === DataFormatType.JSON))) {
                let requestProtocol = ObjectValidator.IsString($data) ? JSON.parse($data) : $data;
                /// TODO: keepAlive should be also part of LCP
                requestProtocol.language = this.getRequestLanguage($request.httpRequest);
                let response = new WebResponse($connector, requestProtocol);
                let responseId = "res_" + response.getId();
                const responseExists = this.responseBuffer.hasOwnProperty(responseId);
                const responseReinvoke = responseExists &&
                    this.responseBuffer[responseId].data.status === HttpStatusType.NOT_AUTHORIZED;
                if (!ObjectValidator.IsEmptyOrNull(requestProtocol.type) && (!responseExists || responseReinvoke)) {
                    if ($keepAlive && !responseReinvoke) {
                        this.responseBuffer[responseId] = response;
                    }
                    let args = new AsyncRequestEventArgs("/liveContent/");
                    args.POST().Add(requestProtocol, "LiveProtocol");
                    args.POST().Add(response, "LiveResponse");
                    args.POST().Add($data, "Protocol");
                    args.POST().Add($connector, "Connector");
                    Loader.getInstance().getHttpResolver().ResolveRequest(args);
                    args = null;
                }
                else if (responseExists) {
                    this.responseBuffer[responseId].OnMessage(requestProtocol);
                }
                else {
                    LogIt.Info("Received message with incorrect protocol: " + $data);
                    response.OnError("Incorrect request data.");
                }
                response = null;
                responseId = "";
                requestProtocol = null;
            }
            else {
                let resolveEnabled = true;
                if ($url === "/") {
                    const filePath = this.fileSystem.NormalizePath(Loader.getInstance().getProgramArgs().TargetBase() + "/index.html");
                    if (this.fileSystem.Exists(filePath)) {
                        LogIt.Debug("Fetch index page from: {0}", filePath);
                        resolveEnabled = false;
                        $connector.Send(require("fs").createReadStream(filePath));
                    }
                }
                if (resolveEnabled) {
                    const args = new AsyncRequestEventArgs($url);
                    if (!ObjectValidator.IsString($data)) {
                        $data.nonce = this.getUID();
                    }
                    args.POST().Add($data, "Protocol");
                    args.POST().Add($connector, "Connector");
                    args.Owner(new HttpRequestParser("", $request));
                    HttpServer.httpArgs.Add(args, "arg_" + $connector.getOwnerId());
                    Loader.getInstance().getHttpResolver().ResolveRequest(args);
                }
            }
        }
        catch (ex) {
            LogIt.Info("Received message in incorrect format: \"" + $data + "\"");
            LogIt.Info(ex.stack);
            $connector.Send(this.getErrorProtocol("Unable to parse request data."));
        }
    }
    getAppConfiguration() {
        return this.properties;
    }
    getDefaultHeaders() {
        const os = require("os");
        const defaultHeaders = {
            "date": Convert.TimeToGMTformat(new Date()),
            "server": this.environment.getAppName() + "/" + this.environment.getProjectVersion() + " (" + os.platform() + ")",
            "vary": "Accept-Encoding, Origin",
            "keep-alive": "timeout=2, max=100",
            "connection": "Keep-Alive",
            "content-type": "text/html"
        };
        this.getDefaultHeaders = () => {
            return defaultHeaders;
        };
        return defaultHeaders;
    }
    getCSPPatterns() {
        const config = this.getAppConfiguration().domain.csp;
        const output = {};
        let patternsCount = 0;
        // eslint-disable-next-line @typescript-eslint/no-for-in-array
        for (const policyGroup in config.policies) {
            if (config.policies.hasOwnProperty(policyGroup)) {
                const groups = config.policies[policyGroup];
                for (const groupName in groups) {
                    if (groups.hasOwnProperty(groupName)) {
                        const group = groups[groupName];
                        if (!ObjectValidator.IsSet(group.enabled) || group.enabled) {
                            if (group.isDefault) {
                                group.pattern = "__DEFAULT__";
                                if (output.hasOwnProperty(group.pattern)) {
                                    LogIt.Warning("Found more than one default CSP group. Overriding by: " + policyGroup + "." + groupName);
                                }
                            }
                            if (!output.hasOwnProperty(group.pattern)) {
                                patternsCount++;
                            }
                            output[group.pattern] = JsonUtils.Clone(group.policy);
                        }
                    }
                }
            }
        }
        if (patternsCount === 0) {
            LogIt.Warning("Missing at least one enabled CSP group. CSP headers will be not applied even that CSP is enabled.");
        }
        else if (ObjectValidator.IsEmptyOrNull(output.__DEFAULT__)) {
            LogIt.Warning("Missing default CSP group. URLs not matching group patterns will be without CSP headers.");
        }
        this.getCSPPatterns = () => {
            return output;
        };
        return output;
    }
    getCSPHeaders($clientId) {
        const args = HttpServer.httpArgs.getItem("arg_" + $clientId);
        if (ObjectValidator.IsEmptyOrNull(args)) {
            return {};
        }
        const url = args.Url();
        const config = this.getAppConfiguration().domain.csp;
        if (StringUtils.ContainsIgnoreCase(url, config.reportUri)) {
            return {};
        }
        const request = args.Owner();
        const protocol = args.POST().getItem("Protocol");
        if (ObjectValidator.IsEmptyOrNull(request) || ObjectValidator.IsEmptyOrNull(protocol) || ObjectValidator.IsString(protocol)) {
            return {};
        }
        const nonce = protocol.nonce;
        if (ObjectValidator.IsEmptyOrNull(nonce)) {
            return {};
        }
        const clientAddress = request.owner.socket.remoteAddress;
        const patterns = this.getCSPPatterns();
        let csp = {};
        let patternFound = false;
        for (const pattern in patterns) {
            if (patterns.hasOwnProperty(pattern) && (StringUtils.PatternMatched(pattern, url) || pattern === clientAddress)) {
                JsonUtils.Extend(csp, patterns[pattern]);
                patternFound = true;
            }
        }
        if (!patternFound) {
            csp = patterns.__DEFAULT__;
        }
        let reportEndpoint = config.reportUri;
        if (!StringUtils.ContainsIgnoreCase(reportEndpoint, "http://", "https://")) {
            if (!StringUtils.StartsWith(reportEndpoint, "/")) {
                reportEndpoint = "/" + reportEndpoint;
            }
            let origin = this.getAppConfiguration().domain.location;
            if (!ObjectValidator.IsEmptyOrNull(request.owner.headers.host)) {
                if (!ObjectValidator.IsEmptyOrNull(request.owner.headers["x-forwarded-host"])) {
                    origin = request.owner.headers["x-forwarded-host"];
                }
                else {
                    origin = request.owner.headers.host;
                }
            }
            let schema = "http://";
            if (!ObjectValidator.IsEmptyOrNull(request.owner.protocol)) {
                schema = request.owner.protocol;
            }
            if (!ObjectValidator.IsEmptyOrNull(request.owner.headers.referer) &&
                StringUtils.StartsWith(request.owner.headers.referer, "https://")) {
                schema = "https://";
            }
            reportEndpoint = schema + origin + reportEndpoint;
        }
        csp = JsonUtils.Extend({
            "report-to": "csp-endpoint",
            "report-uri": reportEndpoint
        }, csp);
        const sourceStandardValues = [
            "none", "self", "unsafe-eval", "wasm-unsafe-eval", "unsafe-hashes", "unsafe-inline", "strict-dynamic", "report-sample",
            "inline-speculation-rules"
        ];
        let cspHeader = "";
        for (const key in csp) {
            if (csp.hasOwnProperty(key)) {
                if (ObjectValidator.IsBoolean(csp[key])) {
                    if (csp[key]) {
                        cspHeader += key + ";";
                    }
                }
                else {
                    if (ObjectValidator.IsString(csp[key])) {
                        csp[key] = [csp[key]];
                    }
                    cspHeader += key + " " + csp[key].map(($value) => {
                        $value = StringUtils.Replace($value, "<? @var response.nonce ?>", nonce);
                        if ($value[0] !== "'") {
                            if (sourceStandardValues.includes($value) ||
                                StringUtils.StartsWith($value, "nonce-") ||
                                StringUtils.StartsWith($value, "sha256-") ||
                                StringUtils.StartsWith($value, "sha384-") ||
                                StringUtils.StartsWith($value, "sha512-")) {
                                return "'" + $value + "'";
                            }
                        }
                        return $value;
                    }).join(" ") + ";";
                }
            }
        }
        return {
            "content-security-policy": cspHeader,
            "report-to": JSON.stringify({
                endpoints: [{ url: reportEndpoint }],
                group: "csp-endpoint",
                max_age: 10886400
            })
        };
    }
    serializeHeaders($line, $headers) {
        return Object.keys($headers)
            .reduce(($head, $key) => {
            const values = $headers[$key];
            if (!ObjectValidator.IsArray(values)) {
                $head.push($key + ": " + values);
                return $head;
            }
            for (const value of values) {
                $head.push($key + ": " + value);
            }
            return $head;
        }, [$line])
            .join("\r\n") + "\r\n\r\n";
    }
    getTunnel($nameOrRequest) {
        let name;
        if (!ObjectValidator.IsString($nameOrRequest)) {
            if (!ObjectValidator.IsEmptyOrNull($nameOrRequest.headers.host)) {
                name = $nameOrRequest.headers.host;
            }
            else if (!ObjectValidator.IsEmptyOrNull($nameOrRequest.headers.origin)) {
                name = $nameOrRequest.headers.origin;
            }
        }
        else {
            name = $nameOrRequest;
        }
        name = StringUtils.Remove(name, "https://", "http://");
        if (!ObjectValidator.IsEmptyOrNull(name) && this.tunnels.hasOwnProperty(name)) {
            const output = this.tunnels[name];
            output.name = name;
            if (ObjectValidator.IsEmptyOrNull(output.location)) {
                output.location = "http://localhost";
            }
            if (!ObjectValidator.IsSet(output.ssl)) {
                output.ssl = {
                    cert: "",
                    key: ""
                };
            }
            if (ObjectValidator.IsEmptyOrNull(output.port)) {
                output.port = 80;
            }
            if (!ObjectValidator.IsSet(output.requested)) {
                output.requested = false;
            }
            return output;
        }
        else {
            return null;
        }
    }
    sendHttpResponse($clientId, $response, $status, $headers, $body, $encoding, $normalizeHeaders = false) {
        const Readable = require("stream").Readable;
        const zlib = require("zlib");
        if (ObjectValidator.IsEmptyOrNull($status)) {
            $status = HttpStatusType.SUCCESS;
        }
        if (ObjectValidator.IsEmptyOrNull($headers)) {
            $headers = {};
        }
        let stream;
        if (ObjectValidator.IsString($body)) {
            stream = new Readable();
            stream.push($body);
            stream.push(null);
        }
        else if (Buffer.isBuffer($body)) {
            stream = new Readable();
            stream.push($body, "binary");
            stream.push(null);
        }
        else {
            stream = $body;
        }
        // TODO: this is without compression so real transferred data will be different
        const size = stream.readableLength;
        const defaultHeaders = JsonUtils.Clone(this.getDefaultHeaders());
        if (this.getAppConfiguration().domain.csp.enabled) {
            try {
                const cspHeaders = JsonUtils.Clone(this.getCSPHeaders($clientId));
                JsonUtils.Extend(defaultHeaders, cspHeaders);
            }
            catch (ex) {
                LogIt.Error("Failed to extend headers by CSP.", ex);
            }
        }
        let key;
        for (key in defaultHeaders) {
            if (!$headers.hasOwnProperty(key) && !$headers.hasOwnProperty(StringUtils.ToLowerCase(key)) &&
                defaultHeaders.hasOwnProperty(key)) {
                $headers[key] = defaultHeaders[key];
            }
        }
        if ($normalizeHeaders) {
            const normalized = {};
            for (key in $headers) {
                if ($headers.hasOwnProperty(key)) {
                    normalized[StringUtils.ToLowerCase(key)] = $headers[key];
                }
            }
            $headers = normalized;
        }
        let encodingKey = "content-encoding";
        if (ObjectValidator.IsEmptyOrNull($headers[encodingKey])) {
            encodingKey = "Content-Encoding";
        }
        if (ObjectValidator.IsEmptyOrNull($headers[encodingKey])) {
            if (StringUtils.Contains($encoding, "gzip")) {
                $headers[encodingKey] = "gzip";
                $response.writeHead($status, $headers);
                stream.pipe(zlib.createGzip()).pipe($response);
            }
            else if (StringUtils.Contains($encoding, "deflate")) {
                $headers[encodingKey] = "deflate";
                $response.writeHead($status, $headers);
                stream.pipe(zlib.createDeflate()).pipe($response);
            }
            else {
                $response.writeHead($status, $headers);
                stream.on("end", () => {
                    $response.end();
                });
                stream.pipe($response);
            }
        }
        else {
            $response.writeHead($status, $headers);
            stream.pipe($response);
        }
        HttpServer.httpArgs.RemoveAt(HttpServer.httpArgs.getKeys().indexOf("arg_" + $clientId));
        Metrics.getInstance().AddMeasurement({
            type: "http",
            size
        });
    }
    resolveHttpRequest($url, $data, $clientId, $request, $response, $origin, $token) {
        try {
            if (ObjectValidator.IsString($data) && StringUtils.StartsWith($data, "jsonData={")) {
                $data = StringUtils.Substring($data, 9);
            }
            let responseSend = false;
            let connector = {
                Send: ($data) => {
                    const liveProtocol = $data;
                    if (responseSend) {
                        LogIt.Debug("Data has been already send.");
                    }
                    else if (ObjectValidator.IsSet(liveProtocol.id)) {
                        liveProtocol.origin = $origin;
                        liveProtocol.token = $token;
                        liveProtocol.language = this.getRequestLanguage($request);
                        const data = JSON.stringify(liveProtocol);
                        if (!ObjectValidator.IsEmptyOrNull(liveProtocol.clientId)) {
                            this.responsePersistence.Variable(liveProtocol.clientId.toString(), data);
                        }
                        this.sendHttpResponse($clientId, $response, HttpStatusType.SUCCESS, { "content-type": "application/javascript" }, data, $request.headers["accept-encoding"]);
                        responseSend = true;
                    }
                    else {
                        let staticProtocol = $data;
                        if (!ObjectValidator.IsSet(staticProtocol.body)) {
                            staticProtocol = {
                                body: $data,
                                headers: {},
                                status: HttpStatusType.SUCCESS
                            };
                        }
                        if (!ObjectValidator.IsSet(staticProtocol.status)) {
                            staticProtocol.status = HttpStatusType.SUCCESS;
                        }
                        if (!ObjectValidator.IsSet(staticProtocol.headers)) {
                            staticProtocol.headers = {};
                        }
                        if (!ObjectValidator.IsSet(staticProtocol.normalize)) {
                            staticProtocol.normalize = false;
                        }
                        if ($request.method === HttpMethodType.HEAD) {
                            staticProtocol.body = "";
                        }
                        this.sendHttpResponse($clientId, $response, staticProtocol.status, staticProtocol.headers, staticProtocol.body, $request.headers["accept-encoding"], staticProtocol.normalize);
                        responseSend = true;
                    }
                },
                getOwnerId: () => {
                    return $clientId + "";
                },
                getParentProcess: () => {
                    return this;
                }
            };
            this.resolveRequest($url, $data, connector, $request, false);
            connector = null;
        }
        catch (ex) {
            if (StringUtils.StartsWith($url, "/xorigin")) {
                this.sendHttpResponse($clientId, $response, HttpStatusType.SUCCESS, { "content-type": "application/javascript" }, JSON.stringify(this.getErrorProtocol(ex, $origin, $token)), $request.headers["accept-encoding"]);
            }
            else {
                this.sendHttpResponse($clientId, $response, HttpStatusType.ERROR, {}, "Internal server error: " + ex.stack, $request.headers["accept-encoding"]);
            }
        }
    }
    setupWsResponse($response, $head) {
        $response.setTimeout(0);
        $response.setNoDelay(true);
        $response.setKeepAlive(true, 0);
        if ($head?.length) {
            $response.unshift($head);
        }
    }
    // TODO(mkelnar) there should be output type defined (extension from URL?)
    getRequestOptions($request, $config, $headers) {
        const headers = JSON.parse(JSON.stringify($request.headers));
        headers["x-forwarded-host"] = headers.host;
        headers.origin = headers.host;
        headers.referer = ($request.connection.encrypted ? "https://" : "http://") +
            headers.host + $request.url;
        headers.host = StringUtils.Remove($config.location, "https://", "http://") + ":" + $config.port;
        if (!ObjectValidator.IsEmptyOrNull($headers)) {
            Resources.Extend(headers, $headers);
        }
        const options = new URL($config.location + ":" + $config.port + $request.url);
        options.method = $request.method;
        options.headers = headers;
        options.rejectUnauthorized = false;
        return options;
    }
    getRequestLanguage($request) {
        let language = this.properties.domain.localization.default;
        if (this.properties.domain.localization.requestDriven) {
            const languages = StringUtils.Split($request.headers["accept-language"], ",");
            let currentWeight = 0;
            languages.forEach(($definition) => {
                $definition = $definition.trim();
                if ($definition !== "*") {
                    const values = StringUtils.Split($definition, ";q=");
                    const lang = StringUtils.Split(values[0], "-")[0];
                    let weight = StringUtils.ToDouble(values[1]) * 100;
                    if (!ObjectValidator.IsDigit(weight)) {
                        weight = 100;
                    }
                    if (weight >= currentWeight) {
                        currentWeight = weight;
                        language = lang;
                    }
                }
            });
        }
        return language;
    }
    createWsProxyClient($serverRequest, $serverResponse, $serverHead, $options) {
        if (ObjectValidator.IsEmptyOrNull($options.headers)) {
            $options.headers = {};
        }
        $options.headers.upgrade = "websocket";
        const onErrorHandler = ($error) => {
            LogIt.Warning("Proxy " + $error.stack);
        };
        this.setupWsResponse($serverResponse, $serverHead);
        const client = ($options.protocol === "https:" ? require("https") : require("http"))
            .request($options, ($targetResponse) => {
            if (!$targetResponse.upgrade) {
                $serverResponse.write(this.serializeHeaders("HTTP/" + $targetResponse.httpVersion + " " +
                    $targetResponse.statusCode + " " + $targetResponse.statusMessage, $targetResponse.headers));
                $targetResponse.pipe($serverResponse);
            }
        });
        $serverRequest.on("aborted", () => {
            client.destroy();
        });
        client.on("error", ($error) => {
            onErrorHandler($error);
            $serverResponse.end();
        });
        client.on("upgrade", ($targetRequest, $targetResponse, $targetHead) => {
            $targetResponse.on("error", ($error) => {
                onErrorHandler($error);
                $serverResponse.end();
            });
            $serverResponse.on("error", ($error) => {
                onErrorHandler($error);
                $targetResponse.end();
            });
            this.setupWsResponse($targetResponse, $targetHead);
            $serverResponse.write(this.serializeHeaders("HTTP/1.1 101 Switching Protocols", $targetRequest.headers));
            $targetResponse.pipe($serverResponse).pipe($targetResponse);
        });
        client.end();
    }
    getErrorProtocol($message, $origin, $token, $encoded = true) {
        let data = {};
        if (ObjectValidator.IsString($message)) {
            data = {
                code: 0,
                file: $encoded ? ObjectEncoder.Base64(__filename) : __filename,
                line: 0,
                message: $encoded ? ObjectEncoder.Base64($message) : $message,
                stack: ""
            };
        }
        else {
            const ex = $message;
            data = {
                code: ex.code,
                file: $encoded ? ObjectEncoder.Base64(ex.message) : ex.message,
                line: ex.line,
                message: $encoded ? ObjectEncoder.Base64(ex.message) : ex.message,
                stack: $encoded ? ObjectEncoder.Base64(ex.stack) : ex.stack
            };
        }
        if (ObjectValidator.IsEmptyOrNull($origin)) {
            $origin = "http://localhost";
        }
        if (ObjectValidator.IsEmptyOrNull($token)) {
            $token = "";
        }
        return {
            data,
            origin: $origin,
            status: HttpStatusType.ERROR,
            token: $token,
            type: "Server.Exception"
        };
    }
    isRequestWithBody($request) {
        if ($request.method === HttpMethodType.GET) {
            return false;
        }
        if ($request.method === HttpMethodType.POST ||
            $request.method === HttpMethodType.PUT ||
            $request.method === HttpMethodType.PATCH ||
            $request.method === HttpMethodType.DELETE) {
            return true;
        }
        const knownTypes = ["Transfer-Encoding", "Content-Length"];
        for (const $type of knownTypes) {
            let value = $request.headers[$type];
            if (ObjectValidator.IsEmptyOrNull(value)) {
                value = $request.headers[StringUtils.ToLowerCase($type)];
            }
            if (!ObjectValidator.IsEmptyOrNull(value)) {
                return !($type === knownTypes[1] && value === "0");
            }
        }
        return false;
    }
    getHttpGetFilterPatterns() {
        const output = [];
        // eslint-disable-next-line @typescript-eslint/no-for-in-array
        for (const scope in this.properties.logger.httpGetFilterPatterns) {
            if (this.properties.logger.httpGetFilterPatterns.hasOwnProperty(scope)) {
                const patterns = this.properties.logger.httpGetFilterPatterns[scope];
                patterns.forEach(($pattern) => {
                    if (!output.includes($pattern)) {
                        output.push($pattern);
                    }
                });
            }
        }
        this.getHttpGetFilterPatterns = () => {
            return output;
        };
        return output;
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.HttpServer", HttpServer);
//# sourceMappingURL=HttpServer.js.map