var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2018-2019 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpStatusType } from "./../../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { Loader } from "../../Loader.js";
import { CertsManager } from "../../Utils/CertsManager.js";
import { BaseHttpResolver } from "./BaseHttpResolver.js";
import { Resolver } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
let AcmeResolver = class AcmeResolver extends BaseHttpResolver {
    token;
    argsHandler($GET, $POST) {
        if ($GET.KeyExists("token")) {
            this.token = $GET.getItem("token");
        }
        super.argsHandler($GET, $POST);
    }
    resolver() {
        const dataPath = CertsManager.getInstance().getStoragePath() + "/" + this.token;
        if (Loader.getInstance().getFileSystemHandler().Exists(dataPath)) {
            this.getConnector().Send({
                body: require("fs").createReadStream(dataPath),
                headers: { "content-type": "text/plain" },
                status: HttpStatusType.SUCCESS
            });
        }
        else {
            this.getConnector().Send({
                body: "Data for ACME challenge has not been found.",
                status: HttpStatusType.NOT_FOUND
            });
        }
    }
};
AcmeResolver = __decorate([
    Resolver("/.well-known/acme-challenge/{token}")
], AcmeResolver);
export { AcmeResolver };
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.AcmeResolver", AcmeResolver);
//# sourceMappingURL=AcmeResolver.js.map