/*! ******************************************************************************************************** *
 *
 * Copyright 2010-2013 Jakub Cieslar
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseHttpResolver as Parent } from "./../../../../../Io/Oidis/Commons/HttpProcessor/Resolvers/BaseHttpResolver.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { EventType } from "./../../../../../Io/Oidis/Gui/Enums/Events/EventType.js";
import { GeneralEventOwner } from "./../../../../../Io/Oidis/Gui/Enums/Events/GeneralEventOwner.js";
import { StaticPageContentManager } from "./../../../../../Io/Oidis/Gui/Utils/StaticPageContentManager.js";
import { HttpServer } from "../HttpServer.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
export class BaseHttpResolver extends Parent {
    connector;
    protocol;
    Process() {
        super.Process();
        if (!this.getEnvironmentArgs().HtmlOutputAllowed()) {
            this.getEventsManager().setEvent(GeneralEventOwner.BODY, EventType.ON_LOAD, () => {
                this.afterLoad();
            });
        }
    }
    argsHandler($GET, $POST) {
        if ($POST.KeyExists("Connector")) {
            this.connector = $POST.getItem("Connector");
        }
        if ($POST.KeyExists("Protocol")) {
            this.protocol = $POST.getItem("Protocol");
        }
    }
    getRequest() {
        return super.getRequest();
    }
    getConnector() {
        if (ObjectValidator.IsEmptyOrNull(this.connector) && !this.getEnvironmentArgs().HtmlOutputAllowed()) {
            this.connector = HttpServer.httpArgs.getLast().POST().getItem("Connector");
        }
        return this.connector;
    }
    getProtocol() {
        return this.protocol;
    }
    afterLoad() {
        this.getConnector().Send(StaticPageContentManager.ToString());
    }
    getHostUrl() {
        const headers = this.getRequest().getHeaders();
        if (headers.KeyExists("host")) {
            let address = headers.getItem("host");
            let scheme = this.getRequest().getScheme();
            if (!ObjectValidator.IsEmptyOrNull(headers.getItem("referer"))) {
                scheme = StringUtils.Contains(headers.getItem("referer"), "https://") ? "https://" : "http://";
            }
            if (!ObjectValidator.IsEmptyOrNull(headers.getItem("x-forwarded-host"))) {
                address = headers.getItem("x-forwarded-host");
            }
            let host = scheme + address;
            if (!StringUtils.EndsWith(host, "/")) {
                host += "/";
            }
            return host.trim();
        }
        return this.getHttpManager().getRequest().getHostUrl();
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.BaseHttpResolver", BaseHttpResolver);
//# sourceMappingURL=BaseHttpResolver.js.map