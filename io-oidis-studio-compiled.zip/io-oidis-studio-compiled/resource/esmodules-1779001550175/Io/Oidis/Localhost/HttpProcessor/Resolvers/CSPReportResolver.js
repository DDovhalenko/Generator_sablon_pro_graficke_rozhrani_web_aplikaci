var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2024-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpStatusType } from "./../../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Loader } from "../../Loader.js";
import { BaseHttpResolver } from "./BaseHttpResolver.js";
import { SentryTunnelResolver } from "./SentryTunnelResolver.js";
import { Resolver } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
let CSPReportResolver = class CSPReportResolver extends BaseHttpResolver {
    async resolver() {
        const data = this.getProtocol();
        const config = Loader.getInstance().getEnvironmentArgs().getProjectConfig().sentry;
        if (!ObjectValidator.IsEmptyOrNull(config.dsn) && config.cspReportTunnel) {
            this.getConnector().Send(await (new SentryTunnelResolver()).Proxy(data, true));
        }
        else {
            try {
                LogIt.Warning(JSON.stringify(JSON.parse(data), null, 2));
            }
            catch (ex) {
                LogIt.Warning(data);
                LogIt.Error(ex);
            }
            this.getConnector().Send({
                body: "CSP Report received successfully.",
                status: HttpStatusType.SUCCESS
            });
        }
    }
};
CSPReportResolver = __decorate([
    Resolver("/cspReport")
], CSPReportResolver);
export { CSPReportResolver };
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.CSPReportResolver", CSPReportResolver);
//# sourceMappingURL=CSPReportResolver.js.map