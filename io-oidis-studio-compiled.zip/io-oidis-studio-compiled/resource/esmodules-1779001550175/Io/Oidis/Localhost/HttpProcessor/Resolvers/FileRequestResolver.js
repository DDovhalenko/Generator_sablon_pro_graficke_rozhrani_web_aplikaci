var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var FileRequestResolver_1;
/*! ******************************************************************************************************** *
 *
 * Copyright 2010-2013 Jakub Cieslar
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpStatusType } from "./../../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { Convert } from "./../../../../../Io/Oidis/Commons/Utils/Convert.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectEncoder } from "./../../../../../Io/Oidis/Commons/Utils/ObjectEncoder.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { ScriptHandler } from "../../IOApi/Handlers/ScriptHandler.js";
import { Loader } from "../../Loader.js";
import { BaseHttpResolver } from "./BaseHttpResolver.js";
import { Resolver } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
let FileRequestResolver = class FileRequestResolver extends BaseHttpResolver {
    static { FileRequestResolver_1 = this; }
    static patterns;
    static targetAppDataPath;
    Process() {
        if (!this.browserValidator()) {
            LogIt.Error("Unsupported browser. User Agent: " + this.getRequest().getUserAgent());
            this.getHttpManager().ReloadTo("/ServerError/Browser", null, true);
            this.stop();
        }
        else {
            this.resolver();
        }
    }
    browserValidator() {
        return true;
    }
    async filePathResolver() {
        const fs = require("fs");
        const path = require("path");
        let url = this.getRequest().getUrl();
        if (StringUtils.Contains(url, "?")) {
            url = StringUtils.Substring(url, 0, StringUtils.IndexOf(url, "?"));
        }
        const resourcePath = "/resource/";
        if ((!StringUtils.StartsWith(url, resourcePath) && StringUtils.Contains(url, resourcePath) &&
            !StringUtils.Contains(url, "/sass/")) ||
            StringUtils.OccurrenceCount(url, resourcePath) > 1) {
            const searchFor = StringUtils.Contains(url, "/test" + resourcePath) ? "/test/" + resourcePath : resourcePath;
            url = StringUtils.Substring(url, StringUtils.IndexOf(url, searchFor, false));
        }
        let filePath = Loader.getInstance().getProgramArgs().TargetBase() + url;
        if (!fs.existsSync(filePath)) {
            if (url === "/favicon.ico") {
                filePath = Loader.getInstance().getProgramArgs().TargetBase() + resourcePath + "graphics/icon.ico";
                if (!fs.existsSync(filePath)) {
                    filePath = Loader.getInstance().getProgramArgs().ProjectBase() + resourcePath + "graphics/icon.ico";
                }
            }
            else {
                filePath = FileRequestResolver_1.targetAppDataPath + "/" + url;
            }
        }
        const name = path.basename(filePath);
        let extension = name;
        extension = StringUtils.Substring(extension, StringUtils.IndexOf(name, ".", false) + 1, StringUtils.Length(name));
        extension = StringUtils.ToLowerCase(extension);
        if (extension === "scss") {
            extension = "sass";
        }
        if (extension === "ts" || extension === "tsx" || extension === "sass") {
            filePath = Loader.getInstance().getProgramArgs().TargetBase() + "/../.." + url;
        }
        filePath = path.normalize(filePath);
        return {
            extension,
            name,
            path: filePath,
            url
        };
    }
    getAllowedPatterns() {
        if (ObjectValidator.IsSet(FileRequestResolver_1.patterns)) {
            return FileRequestResolver_1.patterns;
        }
        let patterns = [
            "/connector.config.js*",
            "/LICENSE.txt",
            "/favicon.ico",
            "/resource/css/*",
            "/resource/graphics/*",
            "/resource/esmodules-*/*",
            "/resource/javascript/*",
            "/resource/data/Io/Oidis/Services/*",
            "/resource/libs/FontOxygen/*",
            "/test/resource/data/*",
            "*.ts",
            "*.tsx",
            "*.scss",
            "*.sass"
        ];
        const loader = Loader.getInstance();
        const properties = loader.getAppConfiguration();
        const fileSystem = loader.getFileSystemHandler();
        const targetPath = loader.getProgramArgs().TargetBase();
        let appDataPath = loader.getProgramArgs().AppDataPath();
        let config = properties.target.requestPatterns;
        if (ObjectValidator.IsString(config)) {
            config = StringUtils.Split(config, ",");
        }
        if (!ObjectValidator.IsEmptyOrNull(config)) {
            patterns = patterns.concat(config);
        }
        const configPath = targetPath + "/wuirunner.config.jsonp";
        if (properties.connectorProxy && fileSystem.Exists(configPath)) {
            const handler = new ScriptHandler();
            handler.Path(configPath);
            handler.SuccessHandler(() => {
                const runnerConfig = handler.Data();
                config = runnerConfig.requestPatterns;
                if (ObjectValidator.IsString(config)) {
                    config = StringUtils.Split(config, ",");
                }
                if (!ObjectValidator.IsEmptyOrNull(config)) {
                    patterns = patterns.concat(config);
                }
                if (!ObjectValidator.IsEmptyOrNull(runnerConfig.appDataPath)) {
                    appDataPath = runnerConfig.appDataPath;
                }
            });
            handler.ErrorHandler(($error) => {
                LogIt.Error("Unable to load " + configPath, $error);
            });
        }
        FileRequestResolver_1.patterns = patterns;
        FileRequestResolver_1.targetAppDataPath = appDataPath;
        this.getAllowedPatterns = () => {
            return patterns;
        };
        return patterns;
    }
    resolver() {
        const fs = require("fs");
        const patterns = this.getAllowedPatterns();
        this.filePathResolver().then(($filePath) => {
            const requiredUrl = StringUtils.Replace($filePath.url, "\\", "/");
            if (!StringUtils.Contains(requiredUrl, "/resource/esmodules-")) {
                LogIt.Debug("file request for: {0}", $filePath.path);
            }
            if (!ObjectValidator.IsEmptyOrNull($filePath.blob) ||
                (ObjectValidator.IsEmptyOrNull($filePath.blob) && fs.existsSync($filePath.path))) {
                let allowedPath = false;
                patterns.forEach(($pattern) => {
                    if (StringUtils.PatternMatched($pattern, requiredUrl)) {
                        allowedPath = true;
                    }
                });
                if (allowedPath) {
                    let type = "text/html";
                    let lastModifiedTime;
                    let fileSize;
                    if (!ObjectValidator.IsEmptyOrNull($filePath.blob)) {
                        lastModifiedTime = $filePath.blob.mtime;
                        fileSize = $filePath.blob.size;
                    }
                    else {
                        const stats = fs.statSync($filePath.path);
                        lastModifiedTime = stats.mtime.getTime();
                        fileSize = stats.size;
                    }
                    const lastModifiedTimeGMT = Convert.TimeToGMTformat(lastModifiedTime);
                    const eTag = this.getEtag($filePath, lastModifiedTime);
                    let isCached = true;
                    if (this.getRequest().getUrlArgs().KeyExists("refresh") ||
                        StringUtils.Contains(this.getRequest().getUrl(), "/forceRefresh")) {
                        isCached = false;
                    }
                    if (this.getRequest().getLastModifiedTime() !== lastModifiedTimeGMT) {
                        isCached = false;
                    }
                    if (!this.getRequest().getEtags().IsEmpty() && !this.getRequest().getEtags().Contains(eTag)) {
                        isCached = false;
                    }
                    if (!isCached) {
                        const headers = {
                            "pragma": "public",
                            "expires": 0,
                            "etag": eTag,
                            "Last-Modified": lastModifiedTimeGMT
                        };
                        switch ($filePath.extension) {
                            case "htm":
                            case "html":
                                type = "text/html";
                                break;
                            case "txt":
                            case "ts":
                            case "tsx":
                            case "sass":
                            case "log":
                            case "obj":
                                type = "text/plain";
                                break;
                            case "css":
                                headers["accept-ranges"] = "bytes";
                                type = "text/css";
                                break;
                            case "js":
                            case "jsonp":
                            case "map":
                                headers["accept-ranges"] = "bytes";
                                type = "application/javascript";
                                break;
                            case "json":
                                headers["accept-ranges"] = "bytes";
                                type = "application/json";
                                break;
                            case "pdf":
                                type = "application/pdf";
                                break;
                            case "bmp":
                                headers["accept-ranges"] = "bytes";
                                type = "image/bmp";
                                break;
                            case "jpg":
                            case "jpe":
                            case "jpeg":
                                headers["accept-ranges"] = "bytes";
                                type = "image/jpeg";
                                break;
                            case "png":
                                headers["accept-ranges"] = "bytes";
                                type = "image/png";
                                break;
                            case "gif":
                                headers["accept-ranges"] = "bytes";
                                type = "image/gif";
                                break;
                            case "ico":
                            case "icon":
                                type = "image/x-icon";
                                break;
                            case "woff":
                                type = "application/font-woff";
                                break;
                            case "woff2":
                                type = "application/font-woff2";
                                break;
                            case "eot":
                                type = "application/vnd.ms-fontobject";
                                break;
                            case "otf":
                                type = "font/opentype";
                                break;
                            case "ttf":
                                type = "application/x-font-ttf";
                                break;
                            case "svg":
                                type = "image/svg+xml";
                                break;
                            case "xhml":
                            case "xml":
                                type = "text/xml";
                                break;
                            case "wasm":
                                type = "application/wasm";
                                break;
                            default:
                                if ($filePath.extension !== "ts" && $filePath.extension !== "tsx" && $filePath.extension !== "sass") {
                                    const fileName = ObjectEncoder.Url($filePath.name);
                                    headers["cache-control"] = "no-store, no-cache, must-revalidate, post-check=0, pre-check=0";
                                    headers["accept-ranges"] = "bytes";
                                    headers["content-encoding"] = "identity";
                                    headers["content-transfer-encoding"] = "binary";
                                    headers["content-description"] = "File Transfer";
                                    headers["Content-Length"] = fileSize;
                                    headers["content-range"] = "0-" + (fileSize - 1) + "/" + fileSize;
                                    headers["content-disposition"] =
                                        "attachment; filename*=UTF-8''" + fileName + "; filename=\"" + fileName + "\"";
                                    headers["x-xss-protection"] = "1; mode=block";
                                    headers["x-content-type-options"] = "nosniff";
                                    headers["x-frame-options"] = "SAMEORIGIN";
                                    headers["x-robots-tag"] = "none";
                                    headers["x-download-options"] = "noopen";
                                    headers["x-permitted-cross-domain-policies"] = "none";
                                    type = "application/octet-stream";
                                }
                        }
                        headers["content-type"] = type;
                        this.getConnector().Send({
                            body: !ObjectValidator.IsEmptyOrNull($filePath.blob) ? $filePath.blob.data :
                                this.streamProcessor($filePath.path),
                            headers,
                            status: HttpStatusType.SUCCESS
                        });
                    }
                    else {
                        this.getConnector().Send({
                            body: "",
                            status: HttpStatusType.CACHED
                        });
                    }
                }
                else {
                    LogIt.Debug("Access denied from: {0}", $filePath.url);
                    this.getConnector().Send({
                        body: "Access denied for: " +
                            (ObjectValidator.IsEmptyOrNull($filePath.path) ? $filePath.url : $filePath.path),
                        status: HttpStatusType.FORBIDDEN
                    });
                }
            }
            else {
                this.getConnector().Send({
                    body: "Unable to locate: " + (ObjectValidator.IsEmptyOrNull($filePath.path) ? $filePath.url : $filePath.path),
                    status: HttpStatusType.NOT_FOUND
                });
            }
        }).catch((error) => {
            throw error;
        });
    }
    streamProcessor($filePath) {
        return require("fs").createReadStream($filePath);
    }
    getEtag($file, $lastModifiedTime) {
        return StringUtils.getSha1($lastModifiedTime + $file.path);
    }
};
FileRequestResolver = FileRequestResolver_1 = __decorate([
    Resolver("/favicon.ico", [
        "*.htm", "*.html",
        "*.txt", "*.log", "*.pdf",
        "*.min.css", "*.css", "*.scss", "*.sass",
        "*.min.js", "*.js", "*.json", "*.jsonp", "*.map", "*.ts", "*.tsx",
        "*.bmp", "*.jpg", "*.jpe", "*.jpeg", "*.png", "*.gif", "*.ico", "*.icon", "*.svg",
        "*.woff", "*.woff2", "*.eot", "*.otf", "*.ttf",
        "*.xml", "*.xhml",
        "*.wasm"
    ].map(($extension) => "/**/" + $extension))
], FileRequestResolver);
export { FileRequestResolver };
// generated-code-start
export const IFilePath = globalThis.RegisterInterface(["url", "path", "name", "extension", "blob"]);
export const IFileBlob = globalThis.RegisterInterface(["size", "mtime", "data"]);
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.FileRequestResolver", FileRequestResolver);
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.IFilePath", IFilePath);
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.IFileBlob", IFileBlob);
//# sourceMappingURL=FileRequestResolver.js.map