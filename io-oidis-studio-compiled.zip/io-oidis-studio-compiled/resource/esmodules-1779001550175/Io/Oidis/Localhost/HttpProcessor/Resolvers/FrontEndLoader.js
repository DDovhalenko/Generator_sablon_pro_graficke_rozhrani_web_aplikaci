var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpStatusType } from "./../../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { PageContentBundles, PageContentBundleType } from "./../../../../../Io/Oidis/Gui/Utils/PageContentBundles.js";
import { StaticPageContentManager } from "./../../../../../Io/Oidis/Gui/Utils/StaticPageContentManager.js";
import { BaseHttpResolver } from "./BaseHttpResolver.js";
import { Resolver } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
import { Loader } from "../../Loader.js";
let FrontEndLoader = class FrontEndLoader extends BaseHttpResolver {
    Process() {
        if (!this.getEnvironmentArgs().HtmlOutputAllowed()) {
            if (!this.browserValidator()) {
                this.getHttpManager().ReloadTo("/ServerError/Browser", null, true);
                this.stop();
            }
            StaticPageContentManager.Nonce(this.getNonce());
            StaticPageContentManager.Clear(true);
            this.setContent();
            this.getConnector().Send({
                body: StaticPageContentManager.ToString(),
                status: this.getResponseStatus()
            });
        }
        else {
            LogIt.Error(this.getClassName() + " can be used only as front-end loader. " +
                "Validate that HttpResolvers are configured correctly for front-end section.");
        }
    }
    setContent() {
        StaticPageContentManager.FaviconSource("resource/graphics/icon.ico");
        StaticPageContentManager.License(this.getLicense());
        PageContentBundles.getInstance().Apply(PageContentBundleType.FONTAWESOME);
        PageContentBundles.getInstance().Apply(PageContentBundleType.SENTRY);
        const buildTime = new Date(this.getEnvironmentArgs().getBuildTime()).getTime();
        StaticPageContentManager.BodyEventsEnabled(false);
        StaticPageContentManager.BodyAppend(this.getNoScript());
        StaticPageContentManager.BodyAppend(`
                    <section data-oidis-bind="PageLoader" style="display: none;">
                        ${this.getPageLoader()}
                    </section>
                    <section data-oidis-bind="PageContentHolder" style="display: none;"></section>
                    <script nonce="${this.getNonce()}" type="text/javascript">
                        globalThis.nonce = "${this.getNonce()}";
                        var loader = document.querySelector("[data-oidis-bind=\\"PageLoader\\"]");
                        if (loader) {
                            loader.style.display = "block";
                        }
                    </script>
                    <script nonce="${StaticPageContentManager.Nonce()}" type="module" src="resource/javascript/loader.min.js?v=${buildTime}"></script>
                `);
        this.setMetadata();
    }
    setMetadata() {
        const config = Loader.getInstance().getAppConfiguration();
        const meta = config.target?.meta || {};
        const title = meta.title || config.target?.name || config.name || this.getEnvironmentArgs().getProjectName();
        const description = meta.description || config.description || "";
        const author = meta.author || config.author?.name || "";
        const url = meta.url || this.getHostUrl();
        const canonical = meta.canonical || url;
        const siteName = meta.siteName || title;
        const type = meta.type || "website";
        const robots = meta.robots || "index,follow";
        const locale = meta.locale || config.domain?.localization?.default || "";
        StaticPageContentManager.Title(title);
        this.addOptionalMeta("description", description);
        this.addOptionalMeta("author", author);
        this.addMeta("robots", robots);
        this.addOptionalMeta("keywords", meta.keywords);
        this.addOptionalMeta("theme-color", meta.themeColor);
        this.addOgTag("title", title);
        this.addOptionalOgTag("description", description);
        this.addOgTag("url", url);
        this.addOgTag("site_name", siteName);
        this.addOgTag("type", type);
        if (!ObjectValidator.IsEmptyOrNull(locale)) {
            this.addOgTag("locale", locale);
        }
        if (!ObjectValidator.IsEmptyOrNull(meta.logoUrl)) {
            this.addOgTag("image", meta.logoUrl);
            this.addOptionalOgTag("image:alt", meta.imageAlt);
            if (meta.imageWidth) {
                this.addOgTag("image:width", String(meta.imageWidth));
            }
            if (meta.imageHeight) {
                this.addOgTag("image:height", String(meta.imageHeight));
            }
        }
        this.addOptionalOgTag("fb:app_id", meta.fbAppId, false);
        if (!ObjectValidator.IsEmptyOrNull(meta.twitterSite) || !ObjectValidator.IsEmptyOrNull(meta.twitterCreator)) {
            this.addTwitterTag("card", meta.twitterCard || "summary_large_image");
            this.addOptionalTwitterTag("site", meta.twitterSite);
            this.addOptionalTwitterTag("creator", meta.twitterCreator);
            this.addTwitterTag("title", title);
            this.addOptionalTwitterTag("description", description);
            if (!ObjectValidator.IsEmptyOrNull(meta.logoUrl)) {
                this.addTwitterTag("image", meta.logoUrl);
                this.addOptionalTwitterTag("image:alt", meta.imageAlt);
            }
        }
        const link = document.createElement("link");
        link.rel = "canonical";
        link.href = canonical;
        StaticPageContentManager.HeadLinkAppend(link, "canonical");
        this.addJsonLd(meta, title, description, url, author);
    }
    addJsonLd($meta, $title, $description, $url, $author) {
        let jsonLd = $meta.jsonLd;
        if (ObjectValidator.IsEmptyOrNull(jsonLd)) {
            jsonLd = {
                "@context": "https://schema.org",
                "@type": "WebSite",
                "name": $title,
                "url": $url
            };
            if (!ObjectValidator.IsEmptyOrNull($description)) {
                jsonLd.description = $description;
            }
            if (!ObjectValidator.IsEmptyOrNull($author)) {
                jsonLd.author = {
                    "@type": "Organization",
                    "name": $author
                };
            }
        }
        const script = document.createElement("script");
        script.type = "application/ld+json";
        script.text = JSON.stringify(jsonLd);
        StaticPageContentManager.HeadScriptAppend(script, "application/ld+json");
    }
    addMeta($name, $value) {
        const meta = document.createElement("meta");
        meta.name = $name;
        meta.content = $value;
        StaticPageContentManager.HeadMetaDataAppend(meta);
    }
    addOptionalMeta($name, $value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.addMeta($name, $value);
        }
    }
    addOgTag($name, $value, $prefixed = true) {
        const meta = document.createElement("meta");
        meta.setAttribute("property", ($prefixed ? "og:" : "") + $name);
        meta.content = $value;
        StaticPageContentManager.HeadMetaDataAppend(meta);
    }
    addOptionalOgTag($name, $value, $prefixed = true) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.addOgTag($name, $value, $prefixed);
        }
    }
    addTwitterTag($name, $value) {
        const meta = document.createElement("meta");
        meta.name = "twitter:" + $name;
        meta.content = $value;
        StaticPageContentManager.HeadMetaDataAppend(meta);
    }
    addOptionalTwitterTag($name, $value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.addTwitterTag($name, $value);
        }
    }
    getLicense() {
        return `
<!--

Copyright 2010-2013 Jakub Cieslar
Copyright 2014-2016 Freescale Semiconductor, Inc.
Copyright 2017-2019 NXP
Copyright ${StringUtils.YearFrom(2019)} Oidis

SPDX-License-Identifier: BSD-3-Clause
The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution

or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText

-->
<!-- version: ${this.getEnvironmentArgs().getProjectVersion()}, build: ${this.getEnvironmentArgs().getBuildTime()} -->
`;
    }
    getNoScript() {
        return `
                    <noscript>
                    This library requires enabled JavaScript in the browser. See link below for more information:
                    <br>
                    <a href="http://www.enable-javascript.com/" target="_blank">How to enable JavaScript?</a>
                    </noscript>
                `;
    }
    getPageLoader() {
        return `
            <div class="row g-0" style="background: var(--bs-white);height: 100%;">
                <div class="col text-center align-self-center">
                    <span role="status" class="spinner-grow textsecondary text-secondary"></span>
                    <span role="status" class="spinner-grow textsecondary text-secondary"></span>
                    <span role="status" class="spinner-grow textsecondary text-secondary"></span>
                </div>
            </div>`;
    }
    getResponseStatus() {
        return HttpStatusType.SUCCESS;
    }
    browserValidator() {
        return super.browserValidator() || this.getRequest().IsSearchBot();
    }
};
FrontEndLoader = __decorate([
    Resolver("/")
], FrontEndLoader);
export { FrontEndLoader };
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.FrontEndLoader", FrontEndLoader);
//# sourceMappingURL=FrontEndLoader.js.map