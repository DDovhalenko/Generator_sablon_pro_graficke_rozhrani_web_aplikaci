var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var LiveContentResolver_1;
/*! ******************************************************************************************************** *
 *
 * Copyright 2010-2013 Jakub Cieslar
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { DataFormatType } from "./../../../../../Io/Oidis/Commons/Enums/DataFormatType.js";
import { HttpStatusType } from "./../../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Reflection } from "./../../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { IConnector } from "../../Interfaces/IConnector.js";
import { Loader } from "../../Loader.js";
import { Metrics } from "../../Utils/Metrics.js";
import { LiveContentResponse } from "../ResponseApi/Handlers/LiveContentResponse.js";
import { BaseHttpResolver } from "./BaseHttpResolver.js";
import { Resolver } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
let LiveContentResolver = class LiveContentResolver extends BaseHttpResolver {
    static { LiveContentResolver_1 = this; }
    static eventSubscribers;
    requestProtocol;
    response;
    /**
     * @param {string} $name The event name.
     * @param {any} $args Optional event arguments.
     */
    static FireEvent($name, $args) {
        if (ObjectValidator.IsEmptyOrNull($args)) {
            $args = "";
        }
        if (ObjectValidator.IsEmptyOrNull(LiveContentResolver_1.eventSubscribers)) {
            LiveContentResolver_1.eventSubscribers = {};
        }
        if (LiveContentResolver_1.eventSubscribers.hasOwnProperty($name)) {
            let index;
            for (index = 0; index < LiveContentResolver_1.eventSubscribers[$name].length; index++) {
                const subscriber = LiveContentResolver_1.eventSubscribers[$name][index];
                subscriber.protocol.status = HttpStatusType.SUCCESS;
                subscriber.protocol.type = "FireEvent";
                if (subscriber.protocol.format !== DataFormatType.JSON) {
                    subscriber.protocol.data = Buffer.from(JSON.stringify({
                        args: Buffer.from(JSON.stringify($args)).toString("base64"),
                        name: $name
                    })).toString("base64");
                }
                else {
                    subscriber.protocol.data = {
                        args: $args,
                        name: $name
                    };
                }
                subscriber.connector.Send(subscriber.protocol);
            }
        }
    }
    Process() {
        this.resolver();
    }
    argsHandler($GET, $POST) {
        super.argsHandler($GET, $POST);
        if ($POST.KeyExists("LiveProtocol")) {
            this.requestProtocol = $POST.getItem("LiveProtocol");
        }
        if ($POST.KeyExists("LiveResponse")) {
            this.response = $POST.getItem("LiveResponse");
        }
    }
    resolver() {
        const metrics = Metrics.getInstance();
        let data = null;
        let isJson = this.requestProtocol.format === DataFormatType.JSON;
        if (ObjectValidator.IsString(this.requestProtocol.data)) {
            try {
                data = JSON.parse(Buffer.from(this.requestProtocol.data, "base64").toString("utf8"));
                isJson = false;
            }
            catch (ex) {
                LogIt.Info("Received message in incorrect format: " + this.requestProtocol);
                this.response.OnError(ex);
            }
        }
        else {
            data = this.requestProtocol.data;
        }
        if (data !== null) {
            try {
                let requestData = data;
                metrics.Start(requestData.name, "LiveContent");
                if (StringUtils.StartsWith(this.requestProtocol.type, "LiveContentWrapper.")) {
                    let namespaceName = requestData.name.slice(0, requestData.name.lastIndexOf("."));
                    let memberName = requestData.name.replace(namespaceName + ".", "");
                    let args = isJson ? requestData.args : ObjectValidator.IsString(requestData.args) ?
                        JSON.parse(Buffer.from(requestData.args, "base64").toString("utf8")) :
                        requestData.args;
                    let classPrototype = null;
                    try {
                        classPrototype = Reflection.getInstance().getClass(namespaceName);
                    }
                    catch (ex) {
                        LogIt.Warning("Reflection for required class failed: " + ex.message);
                    }
                    if (!ObjectValidator.IsEmptyOrNull(classPrototype)) {
                        try {
                            if (Reflection.getInstance().ClassHasInterface(classPrototype, IConnector)) {
                                let liveResponse = new LiveContentResponse(this.response);
                                let instance = Loader.getInstance().getConnectorsRegister()
                                    .getConnectorForToken(this.requestProtocol.token, namespaceName, this.requestProtocol.type);
                                if (!ObjectValidator.IsEmptyOrNull(instance)) {
                                    switch (this.requestProtocol.type) {
                                        case "LiveContentWrapper.InvokeMethod": {
                                            memberName += "_Extern";
                                            if (ObjectValidator.IsFunction(classPrototype[memberName])) {
                                                this.invokeMethod(classPrototype, args, liveResponse, memberName);
                                            }
                                            else if (ObjectValidator.IsFunction(instance[memberName])) {
                                                this.invokeMethod(instance, args, liveResponse, memberName);
                                            }
                                            else {
                                                liveResponse.OnError("Required method \"" + memberName + "\" " +
                                                    "does not exist in class \"" + namespaceName + "\".");
                                            }
                                            break;
                                        }
                                        case "LiveContentWrapper.setProperty": {
                                            if (ObjectValidator.IsSet(classPrototype[memberName])) {
                                                classPrototype[memberName] = args[0];
                                                liveResponse.Send(true);
                                            }
                                            else {
                                                liveResponse.OnError("Required property \"" + memberName + "\" " +
                                                    "does not exist in class \"" + namespaceName + "\".");
                                            }
                                            break;
                                        }
                                        case "LiveContentWrapper.getProperty": {
                                            if (ObjectValidator.IsSet(classPrototype[memberName])) {
                                                liveResponse.Send(classPrototype[memberName]);
                                            }
                                            else {
                                                liveResponse.OnError("Required property \"" + memberName + "\" " +
                                                    "does not exist in class \"" + namespaceName + "\".");
                                            }
                                            break;
                                        }
                                        case "LiveContentWrapper.AddEventHandler": {
                                            liveResponse.OnError("Unsupported \"AddEventHandler\" request.");
                                            break;
                                        }
                                        case "LiveContentWrapper.getEvent": {
                                            liveResponse.OnError("Unsupported \"getEvent\" request.");
                                            break;
                                        }
                                        default: {
                                            liveResponse.OnError("Unsupported live content request type: " +
                                                "\"" + this.requestProtocol.type + "\"");
                                        }
                                    }
                                    metrics.End(HttpStatusType.SUCCESS, true);
                                }
                                else {
                                    metrics.End(HttpStatusType.ERROR, true);
                                    this.response.OnError("Unable to load class \"" + namespaceName + "\"");
                                }
                                liveResponse = null;
                                instance = null;
                            }
                            else {
                                metrics.End(HttpStatusType.NOT_AUTHORIZED, true);
                                this.response.OnError("Unable to call any method from required class \"" + namespaceName +
                                    "\" due to security restrictions.");
                            }
                        }
                        catch (ex) {
                            metrics.Error(ex);
                            this.response.OnError(ex);
                        }
                    }
                    else {
                        metrics.End(HttpStatusType.ERROR, true);
                        this.response.OnError("Required class \"" + namespaceName + "\" does not exist.");
                    }
                    namespaceName = "";
                    memberName = "";
                    args = null;
                    classPrototype = null;
                }
                else {
                    if (this.requestProtocol.type !== "FireEvent") {
                        if (this.requestProtocol.type === "AddEventListener") {
                            LogIt.Info("Events hook for: " + data.name);
                        }
                        else {
                            LogIt.Info("Resolving request: " + this.requestProtocol.type);
                        }
                    }
                    switch (this.requestProtocol.type) {
                        case "AddEventListener":
                            if (ObjectValidator.IsEmptyOrNull(LiveContentResolver_1.eventSubscribers)) {
                                LiveContentResolver_1.eventSubscribers = {};
                            }
                            if (!LiveContentResolver_1.eventSubscribers.hasOwnProperty(requestData.name)) {
                                LiveContentResolver_1.eventSubscribers[requestData.name] = [];
                            }
                            LiveContentResolver_1.eventSubscribers[requestData.name].push({
                                connector: this.response,
                                protocol: this.requestProtocol
                            });
                            this.response.Send(true);
                            break;
                        case "FireEvent":
                            LiveContentResolver_1.FireEvent(requestData.name, isJson ? requestData.args : ObjectValidator.IsString(requestData.args) ?
                                JSON.parse(Buffer.from(requestData.args, "base64").toString("utf8")) :
                                requestData.args);
                            this.response.Send(true);
                            break;
                        default:
                            this.resolveCustomProtocol(this.requestProtocol.type, data, this.response);
                            break;
                    }
                    metrics.End(HttpStatusType.SUCCESS, true);
                }
                requestData = null;
            }
            catch (ex) {
                metrics.Error(ex);
                this.response.OnError(ex);
            }
        }
        else if (ObjectValidator.IsEmptyOrNull(this.requestProtocol.type)) {
            const message = "Received message with incorrect protocol: " + this.requestProtocol;
            metrics.Error(message);
            LogIt.Info(message);
            this.response.OnError("Incorrect request data.");
        }
        data = null;
    }
    isAuthorizedFor($token, $method, $callback) {
        // override this method if token authorization should be implemented
        $callback(true);
    }
    resolveCustomProtocol($type, $args, $response) {
        LogIt.Info("Received undefined protocol: " + this.requestProtocol);
        this.response.OnError("Requested protocol \"" + $type + "\" has not been found.");
    }
    invokeMethod($entity, $args, $liveResponse, $memberName) {
        $args.push($liveResponse);
        let promise = $entity[$memberName].apply($entity, $args); // eslint-disable-line prefer-spread
        if (!ObjectValidator.IsEmptyOrNull(promise) &&
            !ObjectValidator.IsEmptyOrNull(promise.auth) &&
            !ObjectValidator.IsEmptyOrNull(promise.resolve)) {
            this.isAuthorizedFor(this.requestProtocol.token, promise.auth, ($status) => {
                if ($status) {
                    try {
                        promise.resolve.apply($entity, [
                            this.requestProtocol.token, this.requestProtocol.version, this.requestProtocol.format
                        ]);
                    }
                    catch (ex) {
                        Metrics.getInstance().Error(ex);
                        this.response.OnError(ex);
                    }
                    promise = null;
                }
                else {
                    this.requestProtocol.status = HttpStatusType.NOT_AUTHORIZED;
                    $liveResponse.SendObject(this.requestProtocol);
                }
            });
        }
        else {
            promise = null;
        }
    }
};
LiveContentResolver = LiveContentResolver_1 = __decorate([
    Resolver("/liveContent/")
], LiveContentResolver);
export { LiveContentResolver };
// generated-code-start
export const IEventSubscriber = globalThis.RegisterInterface(["protocol", "connector"]);
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.LiveContentResolver", LiveContentResolver);
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.IEventSubscriber", IEventSubscriber);
//# sourceMappingURL=LiveContentResolver.js.map