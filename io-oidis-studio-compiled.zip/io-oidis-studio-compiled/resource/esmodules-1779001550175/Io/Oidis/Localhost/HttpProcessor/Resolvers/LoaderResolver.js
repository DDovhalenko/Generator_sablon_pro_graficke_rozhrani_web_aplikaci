var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var LoaderResolver_1;
/*! ******************************************************************************************************** *
 *
 * Copyright 2024-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { JsonUtils } from "./../../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Loader } from "../../Loader.js";
import { FileRequestResolver } from "./FileRequestResolver.js";
import { Resolver } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
let LoaderResolver = class LoaderResolver extends FileRequestResolver {
    static { LoaderResolver_1 = this; }
    static clientConfig;
    getEtag($file, $lastModifiedTime) {
        const config = this.resolveClientConfig();
        const currentSha = StringUtils.getSha1($lastModifiedTime + JSON.stringify(LoaderResolver_1.clientConfig) + $file.path);
        const newSha = StringUtils.getSha1($lastModifiedTime + JSON.stringify(config) + $file.path);
        if (currentSha !== newSha) {
            LoaderResolver_1.clientConfig = config;
        }
        return newSha;
    }
    streamProcessor($filePath) {
        const ReadableClass = require("stream").Readable;
        let content = Loader.getInstance().getFileSystemHandler().Read(Loader.getInstance().getProgramArgs().ProjectBase() + "/resource/javascript/loader.min.js").toString();
        content = StringUtils.Replace(content, JSON.stringify(globalThis.clientConfig), `"{}"`);
        content = StringUtils.Replace(content, globalThis.clientConfig, `{}`);
        const beStartMark = `"beLoaderStart"`;
        let beEndMark = `"beLoaderEnd")`;
        if (!content.includes(beEndMark)) {
            beEndMark = `"beLoaderEnd";`;
        }
        const beStart = content.indexOf(beStartMark) + beStartMark.length;
        const beEnd = content.indexOf(beEndMark) + beEndMark.length;
        const beCode = content.substring(beStart, beEnd);
        content = StringUtils.Remove(content, beCode);
        content = StringUtils.Replace(content, beStartMark, `""`);
        const patterns = [
            "*pass*",
            "*token*"
        ];
        const ignorePatterns = []
            .concat(Object.keys(Loader.getInstance().getAppConfiguration().logger.reportIgnoreList))
            .concat(Loader.getInstance().getAppConfiguration().sentry.ignoreErrors);
        let loaderContent = JSON.stringify(LoaderResolver_1.clientConfig, ($key, $value) => {
            let passed = true;
            patterns.forEach(($pattern) => {
                if (passed && StringUtils.PatternMatched($pattern, StringUtils.ToLowerCase($key))) {
                    passed = false;
                }
            });
            if (!passed && StringUtils.Contains($key, " ") && ignorePatterns.includes($key)) {
                passed = true;
            }
            if (!passed && !ObjectValidator.IsEmptyOrNull($value)) {
                LogIt.Warning("Client config contains sensitive information. " +
                    "Please validate project configuration and settings of embedFeatures. Value removed for key: " + $key);
                return undefined;
            }
            return $value;
        });
        loaderContent = JSON.stringify(loaderContent);
        content += `
globalThis.clientConfig = JSON.parse("${loaderContent.substring(1, loaderContent.length - 1)}");
`;
        const stream = new ReadableClass();
        stream.push(content);
        stream.push(null);
        return stream;
    }
    resolveClientConfig() {
        const clientConfig = JSON.parse(globalThis.clientConfig);
        globalThis.embedFeatures.forEach(($feature) => {
            let source = {
                project: JsonUtils.Clone(this.getEnvironmentArgs().getProjectConfig())
            };
            const namespaces = StringUtils.Split($feature, ".");
            let found = false;
            for (const item of namespaces) {
                if (source.hasOwnProperty(item)) {
                    source = source[item];
                    found = true;
                }
                else {
                    found = false;
                }
            }
            if (found) {
                const target = { project: {} };
                let index;
                let item = target;
                for (index = 0; index < namespaces.length; index++) {
                    if (index < namespaces.length - 1) {
                        item = item[namespaces[index]] = {};
                    }
                    else {
                        item[namespaces[index]] = source;
                    }
                }
                JsonUtils.Extend(clientConfig, target.project);
            }
        });
        return clientConfig;
    }
};
LoaderResolver = LoaderResolver_1 = __decorate([
    Resolver("/resource/javascript/loader.min.js")
], LoaderResolver);
export { LoaderResolver };
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.LoaderResolver", LoaderResolver);
//# sourceMappingURL=LoaderResolver.js.map