var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2022 NXP
 * Copyright 2022-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpStatusType } from "./../../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { BaseHttpResolver } from "./BaseHttpResolver.js";
import { Resolver } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
let MapFilesPatchResolver = class MapFilesPatchResolver extends BaseHttpResolver {
    Process() {
        if (!this.getEnvironmentArgs().HtmlOutputAllowed()) {
            this.getConnector().Send({
                body: JSON.stringify({
                    version: 3,
                    sources: [],
                    names: [],
                    mappings: "",
                    file: ""
                }),
                status: HttpStatusType.SUCCESS
            });
        }
        else {
            super.Process();
        }
    }
};
MapFilesPatchResolver = __decorate([
    Resolver(["/**/*.min.js.map", "/**/*.min.css.map"])
], MapFilesPatchResolver);
export { MapFilesPatchResolver };
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.MapFilesPatchResolver", MapFilesPatchResolver);
//# sourceMappingURL=MapFilesPatchResolver.js.map