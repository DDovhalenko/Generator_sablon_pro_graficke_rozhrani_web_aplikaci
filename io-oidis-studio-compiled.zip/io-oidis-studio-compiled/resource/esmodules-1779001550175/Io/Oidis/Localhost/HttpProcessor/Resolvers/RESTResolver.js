var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var RESTResolver_1;
/*! ******************************************************************************************************** *
 *
 * Copyright 2020-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpMethodType } from "./../../../../../Io/Oidis/Commons/Enums/HttpMethodType.js";
import { HttpStatusType } from "./../../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { LanguageType } from "./../../../../../Io/Oidis/Commons/Enums/LanguageType.js";
import { LogSeverity } from "./../../../../../Io/Oidis/Commons/Enums/LogSeverity.js";
import { ArrayList } from "./../../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Loader } from "../../Loader.js";
import { RESTResponse } from "../ResponseApi/Handlers/RESTResponse.js";
import { BaseHttpResolver } from "./BaseHttpResolver.js";
import { Resolver } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
let RESTResolver = RESTResolver_1 = class RESTResolver extends BaseHttpResolver {
    options;
    token;
    /**
     * @returns {IRoute[]} Returns the sorted array of route definitions.
     */
    static getRoutes() {
        const routes = globalThis.oidisAPIRoutes.map(($function) => $function());
        const loaderNamespaces = Loader.getInstance().getNamespaceHierarchy();
        loaderNamespaces.pop();
        loaderNamespaces.reverse();
        let sorted = [];
        for (const loaderNamespace of loaderNamespaces) {
            for (const route of routes) {
                if (StringUtils.StartsWith(route.ClassName(), loaderNamespace)) {
                    const register = sorted.find(($route) => $route.route === route.route && $route.options.httpMethod === route.options.httpMethod);
                    if (ObjectValidator.IsEmptyOrNull(register)) {
                        sorted.push(route);
                    }
                    else {
                        LogIt.Info("Route " + route.schema + " from " + register.ClassName() + " overrides " + route.ClassName(), LogSeverity.LOW);
                        sorted[sorted.indexOf(register)] = route;
                    }
                }
            }
        }
        sorted = sorted.sort(($a, $b) => {
            return ($a.options.priority < $b.options.priority) ? -1 : ($a.options.priority > $b.options.priority) ? 1 : 0;
        });
        RESTResolver_1.getRoutes = () => {
            return sorted;
        };
        return sorted;
    }
    constructor() {
        super();
        this.token = null;
        this.options = {
            created: new Date().getTime(),
            section: "",
            subsections: [],
            method: HttpMethodType.GET,
            lang: LanguageType.EN,
            force: false,
            requestType: "",
            acceptType: "",
            etags: new ArrayList(),
            keys: new ArrayList()
        };
    }
    async accessValidator() {
        this.token = null;
        if (!this.getEnvironmentArgs().HtmlOutputAllowed()) {
            this.token = StringUtils.Remove(this.getRequest().getHeaders().getItem("authorization"), "Bearer ");
        }
        else {
            LogIt.Error("REST resolver is suitable only for back-end calls.");
            return false;
        }
        return await super.accessValidator();
    }
    argsHandler($GET, $POST) {
        super.argsHandler($GET, $POST);
        this.options.section = "/" + $GET.getItem("section");
        this.options.subsections = [];
        for (let index = 1; index <= 5; index++) {
            if ($GET.KeyExists("subsection" + index)) {
                this.options.subsections.push($GET.getItem("subsection" + index));
            }
        }
        if (!ObjectValidator.IsEmptyOrNull(this.options.subsections)) {
            this.options.section = this.options.section + "/" + this.options.subsections.join("/");
        }
        this.options.force = $GET.KeyExists("force");
        /// TODO: $GET values are sometimes overridden by concurrent request, so getUrlArgs are more stable - root cause is unknown
        this.options.keys = this.getRequest().getUrlArgs();
        const headers = this.getRequest().getHeaders();
        this.options.method = this.getRequest().getOwner().method;
        if (this.options.method === HttpMethodType.POST) {
            const methodOverride = headers.getItem("x-http-method-override");
            if (!ObjectValidator.IsEmptyOrNull(methodOverride)) {
                this.options.method = methodOverride;
            }
        }
        this.options.requestType = "json";
        if (headers.KeyExists("content-type")) {
            if (StringUtils.Contains(headers.getItem("content-type"), "/xml")) {
                this.options.requestType = "xml";
            }
            else if (StringUtils.Contains(headers.getItem("content-type"), "x-www-form-urlencoded")) {
                this.options.requestType = "urlencoded";
            }
        }
        this.options.acceptType = headers.getItem("accept");
        this.options.etags = this.getRequest().getEtags();
    }
    async resolver() {
        this.options.lang = this.getRequest().getHeaders().getItem("accept-language");
        if (ObjectValidator.IsEmptyOrNull(this.options.lang)) {
            this.options.lang = LanguageType.EN;
        }
        this.options.lang = StringUtils.ToLowerCase(this.options.lang);
        if (this.options.lang === "cs") {
            this.options.lang = "cz";
        }
        const data = await this.formatRequest();
        const response = this.getConnector();
        response.setOptions(this.options);
        if (ObjectValidator.IsEmptyOrNull(this.options.section) ||
            this.options.section === "/doc" || this.options.section === "/documentation") {
            response.Send(this.getServerLocation() + " REST API documentation: https://whoknows.where.com");
        }
        else {
            try {
                const route = RESTResolver_1.getRoutes().find(($route) => $route.route === this.options.section && $route.options.httpMethod === this.options.method);
                if (ObjectValidator.IsEmptyOrNull(route)) {
                    response.SendError("Unsupported method " + this.options.method + " for section " + this.options.section, HttpStatusType.NOT_FOUND);
                }
                else {
                    const args = [];
                    // TODO(mkelnar) get arg values from $GET based on args array[*].Key, while array[*].Value is default value
                    const missingKeys = [];
                    const reservedKeys = [
                        "force", "section", "subsection1", "subsection2", "subsection3", "subsection4", "subsection5"
                    ];
                    this.options.keys.getKeys().forEach(($key) => {
                        if (!reservedKeys.includes($key)) {
                            let keyFound = false;
                            route.options.args.forEach(($value) => {
                                if ($value.Key === $key) {
                                    keyFound = true;
                                }
                            });
                            if (!keyFound) {
                                missingKeys.push($key);
                            }
                        }
                    });
                    if (!ObjectValidator.IsEmptyOrNull(missingKeys)) {
                        throw new Error("Passed parameters [" + missingKeys.join(", ") + "] " +
                            "not declared in route schema: " + route.schema);
                    }
                    route.options.args.forEach(($value) => {
                        const routeArg = $value;
                        const keyValue = this.options.keys.getItem(routeArg.Key);
                        if (!ObjectValidator.IsEmptyOrNull(keyValue)) {
                            args.push(routeArg.ResolveValue(keyValue));
                        }
                        else if (reservedKeys.includes(routeArg.Key) || !ObjectValidator.IsEmptyOrNull(routeArg.Value)) {
                            args.push(routeArg.Value);
                        }
                        else {
                            args.push(undefined);
                        }
                    });
                    if (this.options.method === HttpMethodType.POST || this.options.method === HttpMethodType.PUT) {
                        args.push(route.options.inputFormatter.format(data));
                    }
                    const methodName = route.methodName();
                    await this.invokeMethod(Loader.getInstance().getConnectorsRegister().getConnectorForToken(this.getCurrentToken(), methodName.slice(0, StringUtils.IndexOf(methodName, ".", false)), route.schema), args, response, route);
                }
            }
            catch (ex) {
                LogIt.Error(ex.message);
                // LogIt.Debug(ex.stack);
                response.OnError(ex.message, ex);
            }
        }
    }
    getProtocol() {
        let data = super.getProtocol();
        if (this.options.method === HttpMethodType.GET) {
            // suppress web response data for GET to propagate into invoker
            data = [];
        }
        return data;
    }
    convertValue($value, $key) {
        return $value;
    }
    normalizeRequestBody($value) {
        return $value;
    }
    getServerLocation() {
        let location = this.getRequest().getUrl();
        if (!StringUtils.Contains(location, "http://", "https://")) {
            let host = Loader.getInstance().getAppConfiguration().domain.location;
            const requestHeaders = this.getRequest().getHeaders();
            if (requestHeaders.KeyExists("host")) {
                if (!ObjectValidator.IsEmptyOrNull(requestHeaders.getItem("x-forwarded-host"))) {
                    host = requestHeaders.getItem("x-forwarded-host");
                }
                else {
                    host = requestHeaders.getItem("host");
                }
            }
            location = host + location;
        }
        return location;
    }
    async isAuthorizedFor($token, $method) {
        return true;
    }
    getCurrentToken() {
        return this.token;
    }
    getConnector() {
        return new RESTResponse(super.getConnector());
    }
    browserValidator() {
        return !this.getRequest().IsSearchBot();
    }
    afterLoad() {
        // suppress static page served by afterload default implementation
    }
    async formatRequest() {
        let data = super.getProtocol();
        /// TODO: xml etc. should be done in import way, supported by format adapters
        if (this.options.requestType === "xml") {
            try {
                const result = await require("xml2js").parseStringPromise(Buffer.from(data).toString("utf-8"), {
                    explicitArray: false,
                    explicitRoot: false,
                    parseBooleans: true,
                    parseNumbers: true,
                    strict: true,
                    valueProcessors: [
                        ($value, $name) => {
                            return this.convertValue($value, $name);
                        }
                    ]
                });
                data = this.normalizeRequestBody(JSON.parse(JSON.stringify(result)));
            }
            catch (ex) {
                LogIt.Warning(ex.stack);
            }
        }
        else if (this.options.requestType === "urlencoded") {
            let lastKey = "";
            data = this.normalizeRequestBody(require("qs").parse(data, {
                decoder: ($value, $defaultEncoder, $charset, $type) => {
                    $value = $defaultEncoder($value);
                    if ($type === "key") {
                        lastKey = StringUtils.Replace($value, "[", ".");
                        lastKey = StringUtils.Remove(lastKey, "]");
                        lastKey = StringUtils.Substring(lastKey, StringUtils.IndexOf(lastKey, ".", false) + 1);
                    }
                    else if ($type === "value") {
                        $value = this.convertValue($value, lastKey);
                    }
                    return $value;
                }
            }));
        }
        return data;
    }
    async invokeMethod($entity, $args, $response, $memberName) {
        $args.push($response);
        let promise = $memberName.method.apply($entity, $args);
        if (!ObjectValidator.IsEmptyOrNull(promise) &&
            !ObjectValidator.IsEmptyOrNull(promise.auth) &&
            !ObjectValidator.IsEmptyOrNull(promise.resolve)) {
            if (await this.isAuthorizedFor(this.getCurrentToken(), promise.auth)) {
                promise.resolve.apply($entity, [this.getCurrentToken()]);
                promise = null;
            }
            else {
                $response.SendError("Not authorized", HttpStatusType.NOT_AUTHORIZED);
            }
        }
        else {
            promise = null;
        }
    }
};
RESTResolver = RESTResolver_1 = __decorate([
    Resolver([
        "/api/{section}",
        "/api/{section}/{subsection1}",
        "/api/{section}/{subsection1}/{subsection2}",
        "/api/{section}/{subsection1}/{subsection2}/{subsection3}",
        "/api/{section}/{subsection1}/{subsection2}/{subsection3}/{subsection4}",
        "/api/{section}/{subsection1}/{subsection2}/{subsection3}/{subsection4}/{subsection5}"
    ]),
    __metadata("design:paramtypes", [])
], RESTResolver);
export { RESTResolver };
// generated-code-start
/* eslint-disable */
export const IRESTResolverOptions = globalThis.RegisterInterface(["created", "section", "subsections", "method", "lang", "force", "etags", "requestType", "acceptType", "keys"]);
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.RESTResolver", RESTResolver);
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.IRESTResolverOptions", IRESTResolverOptions);
//# sourceMappingURL=RESTResolver.js.map