var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2024-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpMethodType } from "./../../../../../Io/Oidis/Commons/Enums/HttpMethodType.js";
import { HttpStatusType } from "./../../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { JsonUtils } from "./../../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectEncoder } from "./../../../../../Io/Oidis/Commons/Utils/ObjectEncoder.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Loader } from "../../Loader.js";
import { BaseConnector } from "../../Primitives/BaseConnector.js";
import { Route } from "../../Primitives/Decorators.js";
import { BaseResponseFormatter } from "../ResponseApi/Formatters/BaseResponseFormatter.js";
import { StreamResponse } from "../ResponseApi/Handlers/StreamResponse.js";
export class SentryTunnelResolver extends BaseConnector {
    /**
     * @param {any} $data The report payload data.
     * @param {boolean} $isSecurityReport Whether the report is a CSP security report.
     * @returns {Promise<IHttpResponse>} Returns the proxy operation result.
     */
    async Proxy($data, $isSecurityReport = false) {
        try {
            const config = Loader.getInstance().getEnvironmentArgs().getProjectConfig().sentry;
            if (!$isSecurityReport && !$data.includes(config.dsn)) {
                return { body: "Invalid sentry dsn", status: HttpStatusType.FORBIDDEN };
            }
            const reports = [];
            const projectConfig = new URL(config.dsn);
            let url = projectConfig.protocol + "//" + projectConfig.host + "/api" + projectConfig.pathname;
            if (!$isSecurityReport) {
                url += "/envelope/";
                reports.push({
                    url,
                    body: $data
                });
            }
            else {
                url += "/security/?sentry_key=" + projectConfig.username +
                    "&sentry_release=" + ObjectEncoder.Url(Loader.getInstance().getEnvironmentArgs().getProjectVersion());
                if (!ObjectValidator.IsEmptyOrNull(config.environment) && config.environment !== "none") {
                    url += "&sentry_environment=" + ObjectEncoder.Url(config.environment);
                }
                /// TODO: this data normalization to deprecated serialization of violation report can be removed when
                //        sentry will support this content-type: "application/reports+json"
                //        more details at: https://w3c.github.io/webappsec-csp/#deprecated-serialize-violation and
                //                         https://w3c.github.io/webappsec-csp/#report-violation
                if (ObjectValidator.IsString($data)) {
                    $data = JSON.parse($data);
                }
                if (!ObjectValidator.IsArray($data)) {
                    $data = [$data];
                }
                if (ObjectValidator.IsArray($data)) {
                    $data.forEach(($report) => {
                        if ($report.type === "csp-violation") {
                            reports.push({
                                url,
                                body: JSON.stringify({
                                    "csp-report": {
                                        "document-uri": $report.body.documentURL,
                                        "blocked-uri": $report.body.blockedURL,
                                        "referrer": $report.body.referrer,
                                        "effective-directive": $report.body.effectiveDirective,
                                        "violated-directive": $report.body.violatedDirective,
                                        "original-policy": $report.body.originalPolicy,
                                        "disposition": $report.body.disposition,
                                        "status-code": $report.body.statusCode,
                                        "source-file": $report.body.sourceFile,
                                        "script-sample": $report.body.sample,
                                        "line-number": $report.body.lineNumber,
                                        "column-number": $report.body.columnNumber
                                    }
                                }),
                                headers: {
                                    "Content-Type": "application/csp-report"
                                }
                            });
                        }
                        else {
                            let known = true;
                            // List of IWebServiceConfigurationProtocol non-optional properties with version fallback
                            ["address", "base", "location", "responseUrl", "timeout"].forEach(($key) => {
                                if (!$report.hasOwnProperty($key)) {
                                    known = false;
                                }
                            });
                            if (!known) {
                                LogIt.Warning("Unrecognized violation report type: " + $report.type + "\n" + JSON.stringify($report));
                            }
                        }
                    });
                }
                else {
                    LogIt.Warning("Invalid csp report format: " + JSON.stringify($data));
                }
            }
            for await (const report of reports) {
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const result = await Loader.getInstance().getFileSystemHandler().DownloadAsync(JsonUtils.Extend({
                    method: HttpMethodType.POST,
                    streamOutput: true,
                    verbose: false,
                    strictSSL: config.useStrictSSL
                }, report));
                // LogIt.Debug(result.bodyOrPath);
            }
        }
        catch (ex) {
            LogIt.Error("Failed to tunnel to sentry", ex);
            return { body: "Failed to tunnel to sentry", status: HttpStatusType.ERROR };
        }
        return { body: "Data successfully sent to sentry", status: HttpStatusType.SUCCESS };
    }
}
__decorate([
    Route("POST /sentry", { responseHandler: new StreamResponse(), inputFormatter: new BaseResponseFormatter() }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Boolean]),
    __metadata("design:returntype", Promise)
], SentryTunnelResolver.prototype, "Proxy", null);
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.SentryTunnelResolver", SentryTunnelResolver);
//# sourceMappingURL=SentryTunnelResolver.js.map