var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2010-2013 Jakub Cieslar
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { StaticPageContentManager } from "./../../../../../Io/Oidis/Gui/Utils/StaticPageContentManager.js";
import { BaseHttpResolver } from "./BaseHttpResolver.js";
import { Resolver } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
let XOriginInterface = class XOriginInterface extends BaseHttpResolver {
    resolver() {
        const EOL = StringUtils.NewLine(false);
        StaticPageContentManager.Clear(true);
        StaticPageContentManager.Title("Oidis - REST services");
        StaticPageContentManager.License("<!--" + EOL +
            EOL +
            "Copyright 2010-2013 Jakub Cieslar" + EOL +
            "Copyright 2014-2016 Freescale Semiconductor, Inc." + EOL +
            "Copyright 2017-2019 NXP" + EOL +
            "Copyright " + StringUtils.YearFrom(2019) + " Oidis" + EOL +
            EOL +
            "SPDX-License-Identifier: BSD-3-Clause" + EOL +
            "The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution" + EOL +
            "or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText" + EOL +
            EOL +
            "-->");
        StaticPageContentManager.getHeadLinks().Clear();
        StaticPageContentManager.HeadScriptAppend("/resource/javascript/xservices.js?version=" +
            this.getEnvironmentArgs().getProjectVersion());
        StaticPageContentManager.BodyAppend("Oidis Cross-origin REST service interface");
        StaticPageContentManager.Draw();
    }
};
XOriginInterface = __decorate([
    Resolver(["/wuihost/", "/xorigin/", "/xorigin/Request"])
], XOriginInterface);
export { XOriginInterface };
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.XOriginInterface", XOriginInterface);
//# sourceMappingURL=XOriginInterface.js.map