var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var XOriginServices_1;
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Loader } from "../../Loader.js";
import { FileRequestResolver } from "./FileRequestResolver.js";
import { Resolver } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
let XOriginServices = class XOriginServices extends FileRequestResolver {
    static { XOriginServices_1 = this; }
    static origin;
    static schema;
    getEtag($file, $lastModifiedTime) {
        let origin = Loader.getInstance().getAppConfiguration().domain.location;
        const headers = this.getRequest().getHeaders();
        if (headers.KeyExists("host")) {
            if (!ObjectValidator.IsEmptyOrNull(headers.getItem("x-forwarded-host"))) {
                origin = headers.getItem("x-forwarded-host");
            }
            else {
                origin = headers.getItem("host");
            }
        }
        let schema = "http://";
        if (headers.KeyExists("referer")) {
            if (StringUtils.StartsWith(headers.getItem("referer"), "https://")) {
                schema = "https://";
            }
        }
        else {
            schema = this.getRequest().getScheme();
        }
        if (XOriginServices_1.origin !== origin) {
            XOriginServices_1.origin = origin;
        }
        if (XOriginServices_1.schema !== schema) {
            XOriginServices_1.schema = schema;
        }
        return StringUtils.getSha1($lastModifiedTime + JSON.stringify({
            origin: XOriginServices_1.origin,
            schema: XOriginServices_1.schema
        }) + $file.path);
    }
    streamProcessor($filePath) {
        const fs = require("fs");
        const ReadableClass = require("stream").Readable;
        let content = fs.readFileSync($filePath).toString();
        content = StringUtils.Replace(content, "<? @var build.year ?>", new Date(Loader.getInstance().getEnvironmentArgs().getBuildTime()).getFullYear() + "");
        content = StringUtils.Replace(content, "<? @var xservices.origin ?>", XOriginServices_1.origin + "/xorigin/");
        content = StringUtils.Replace(content, "<? @var xservices.request ?>", XOriginServices_1.schema + XOriginServices_1.origin + "/xorigin/");
        const stream = new ReadableClass();
        stream.push(content);
        stream.push(null);
        return stream;
    }
};
XOriginServices = XOriginServices_1 = __decorate([
    Resolver("/resource/javascript/xservices.js")
], XOriginServices);
export { XOriginServices };
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.Resolvers.XOriginServices", XOriginServices);
//# sourceMappingURL=XOriginServices.js.map