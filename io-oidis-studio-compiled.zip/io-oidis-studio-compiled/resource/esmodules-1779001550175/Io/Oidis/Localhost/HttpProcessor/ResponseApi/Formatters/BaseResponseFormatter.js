/*! ******************************************************************************************************** *
 *
 * Copyright 2023-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IBaseObject } from "./../../../../../../Io/Oidis/Commons/Interfaces/IBaseObject.js";
import { BaseObject } from "./../../../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
export class BaseResponseFormatter extends BaseObject {
    /**
     * @param {any} $data Data to format.
     * @returns {any} Returns the data as-is.
     */
    format($data) {
        return $data;
    }
}
// generated-code-start
export const IResponseFormatter = globalThis.RegisterInterface(["format"], IBaseObject);
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.ResponseApi.Formatters.IResponseFormatter", IResponseFormatter);
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.ResponseApi.Formatters.BaseResponseFormatter", BaseResponseFormatter);
//# sourceMappingURL=BaseResponseFormatter.js.map