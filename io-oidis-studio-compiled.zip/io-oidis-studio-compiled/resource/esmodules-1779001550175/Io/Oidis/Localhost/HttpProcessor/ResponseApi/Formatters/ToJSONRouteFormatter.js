/*! ******************************************************************************************************** *
 *
 * Copyright 2023-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { LogIt } from "./../../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { BaseResponseFormatter } from "./BaseResponseFormatter.js";
export class ToJSONRouteFormatter extends BaseResponseFormatter {
    /**
     * @param {string} $data JSON string to parse.
     * @returns {any} Returns the parsed object, or null on parse failure.
     */
    format($data) {
        let data = $data;
        if (ObjectValidator.IsString(data)) {
            try {
                data = JSON.parse($data);
            }
            catch ($e) {
                LogIt.Warning("JSONRoute formatter JSON.parse failed.");
                data = null;
            }
        }
        return data;
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.ResponseApi.Formatters.ToJSONRouteFormatter", ToJSONRouteFormatter);
//# sourceMappingURL=ToJSONRouteFormatter.js.map