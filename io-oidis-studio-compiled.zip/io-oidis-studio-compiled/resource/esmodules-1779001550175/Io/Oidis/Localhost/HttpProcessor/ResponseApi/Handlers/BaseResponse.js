/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2026 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseObject } from "./../../../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { LogIt } from "./../../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../../../Io/Oidis/Commons/Utils/Property.js";
export class BaseResponse extends BaseObject {
    owner;
    callbacks;
    keepAlive;
    threadsRegister;
    constructor() {
        super();
        this.owner = () => {
            // declare owner
        };
        this.callbacks = {
            onsend(...$args) {
                // declare promise callback
            },
            onstart(...$args) {
                // declare promise callback
            },
            onchange(...$args) {
                // declare promise callback
            },
            oncomplete(...$args) {
                // declare promise callback
            }
        };
        this.threadsRegister = [];
        this.keepAlive = false;
    }
    /**
     * @param {IResponse} $instance Source response to clone from.
     */
    Clone($instance) {
        this.owner = $instance.owner;
        this.callbacks = $instance.callbacks;
        this.threadsRegister = $instance.threadsRegister;
    }
    /**
     * @param {any[]} $args Arguments to pass to the callback.
     * @returns {IResponsePromise} Returns a promise-like object with Then() method.
     */
    Send(...$args) {
        return {
            Then: ($callback) => {
                this.callbacks.onsend = $callback;
            }
        };
    }
    /**
     * @param {any[]} $args Arguments to pass to the callback.
     * @returns {IResponsePromise} Returns a promise-like object with Then() method.
     */
    OnStart(...$args) {
        return {
            Then: ($callback) => {
                this.callbacks.onstart = $callback;
            }
        };
    }
    /**
     * @param {any[]} $args Arguments to pass to the callback.
     * @returns {IResponsePromise} Returns a promise-like object with Then() method.
     */
    OnChange(...$args) {
        return {
            Then: ($callback) => {
                this.callbacks.onchange = $callback;
            }
        };
    }
    /**
     * @param {any[]} $args Arguments to pass to the callback.
     * @returns {IResponsePromise} Returns a promise-like object with Then() method.
     */
    OnComplete(...$args) {
        return {
            Then: ($callback) => {
                this.callbacks.oncomplete = $callback;
            }
        };
    }
    /**
     * @param {string | Error} $message Error message string or Error instance.
     * @param {any[]} $args Additional context arguments.
     */
    OnError($message, ...$args) {
        if (ObjectValidator.IsString($message)) {
            LogIt.Error($message);
        }
        else {
            LogIt.Error(this.getClassName(), $message);
        }
    }
    /**
     * @param {any} $data Incoming message data.
     */
    OnMessage($data) {
        if (!ObjectValidator.IsArray($data)) {
            $data = [$data];
        }
        this.callbacks.onsend.apply(this, $data);
        this.callbacks.onstart.apply(this, $data);
        this.callbacks.onchange.apply(this, $data);
        this.callbacks.oncomplete.apply(this, $data);
    }
    /**
     * @param {string} $name Event name to fire.
     * @param {any} $args Optional event arguments.
     * @returns {Promise<void>} Returns a promise that resolves when the event is dispatched.
     */
    async FireEvent($name, $args) {
        const LiveContentResolver = (await import("../../Resolvers/LiveContentResolver.js")).LiveContentResolver;
        LiveContentResolver.FireEvent($name, $args);
    }
    /**
     * @returns {number} Returns -1 for base responses without a specific ID.
     */
    getId() {
        return -1;
    }
    /**
     * @returns {string} Returns an empty string for base responses without an owner.
     */
    getOwnerId() {
        return "";
    }
    /**
     * @param {() => void} $handler Callback to invoke on abort.
     */
    AddAbortHandler($handler) {
        this.KeepAlive(true);
        this.threadsRegister.push($handler);
    }
    Abort() {
        this.threadsRegister.forEach(($handler) => {
            $handler();
        });
    }
    /**
     * @param {boolean} $value Optional value to set; omit to read the current flag.
     * @returns {boolean} Returns the current keep-alive state.
     */
    KeepAlive($value) {
        return this.keepAlive = Property.Boolean(this.keepAlive, $value);
    }
    Dispatch() {
        if (ObjectValidator.IsSet(this.owner.getParentProcess) && !ObjectValidator.IsEmptyOrNull(this.owner.getParentProcess())) {
            this.owner.getParentProcess().Clear(this);
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.ResponseApi.Handlers.BaseResponse", BaseResponse);
//# sourceMappingURL=BaseResponse.js.map