import { BaseResponse } from "./BaseResponse.js";
export class CallbackResponse extends BaseResponse {
    constructor($owner) {
        super();
        this.owner = $owner;
    }
    /**
     * @param {any[]} $args Arguments forwarded to the owner callback.
     * @returns {IResponsePromise} Returns a promise-like object with Then() method.
     */
    Send(...$args) {
        setTimeout(() => {
            this.owner.apply(this, $args); // eslint-disable-line prefer-spread
        }, 0);
        return {
            Then: ($callback) => {
                this.callbacks.onsend = $callback;
            }
        };
    }
    /**
     * @param {any[]} $args Arguments forwarded to the owner callback.
     * @returns {IResponsePromise} Returns a promise-like object with Then() method.
     */
    OnComplete(...$args) {
        setTimeout(() => {
            this.owner.apply(this, $args); // eslint-disable-line prefer-spread
        }, 0);
        return {
            Then: ($callback) => {
                this.callbacks.oncomplete = $callback;
            }
        };
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.ResponseApi.Handlers.CallbackResponse", CallbackResponse);
//# sourceMappingURL=CallbackResponse.js.map