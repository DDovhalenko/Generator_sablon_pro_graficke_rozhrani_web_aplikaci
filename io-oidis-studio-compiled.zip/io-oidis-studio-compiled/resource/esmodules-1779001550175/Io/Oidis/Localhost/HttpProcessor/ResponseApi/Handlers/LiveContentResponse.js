/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2026 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpStatusType } from "./../../../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { LogIt } from "./../../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { EventType } from "./../../../../../../Io/Oidis/Gui/Enums/Events/EventType.js";
import { WebResponse } from "./WebResponse.js";
export class LiveContentResponse extends WebResponse {
    started;
    changed;
    completed;
    sent;
    constructor($owner, $data) {
        super($owner, $data);
        this.started = false;
        this.changed = false;
        this.completed = false;
        this.sent = false;
    }
    /**
     * @param {any[]} $args First argument is the return value; remaining arguments are event args.
     * @returns {IResponsePromise} Returns a promise-like object with Then() method.
     */
    Send(...$args) {
        const response = {
            args: "",
            name: this.data.data.name,
            returnValue: null
        };
        if (ObjectValidator.IsSet($args[0])) {
            response.returnValue = $args[0];
            $args.shift();
        }
        if ($args.length > 0) {
            response.args = $args;
        }
        if (!ObjectValidator.IsString(response.returnValue)) {
            if (!ObjectValidator.IsEmptyOrNull(response.returnValue) && !ObjectValidator.IsEmptyOrNull(response.returnValue.type)) {
                if (response.returnValue.type === EventType.ON_START) {
                    if (this.started) {
                        throw new Error("LCP Error: onstart notify can be send only once");
                    }
                    this.started = true;
                    if (this.completed) {
                        throw new Error("LCP Error: cannot notify onstart after oncomplete");
                    }
                    else if (this.changed) {
                        throw new Error("LCP Error: cannot notify onstart after onchange");
                    }
                }
                else if (response.returnValue.type === EventType.ON_CHANGE) {
                    this.changed = true;
                    if (this.completed) {
                        throw new Error("LCP Error: cannot notify onchange after oncomplete");
                    }
                }
                else if (response.returnValue.type === EventType.ON_COMPLETE) {
                    if (this.completed) {
                        throw new Error("LCP Error: oncomplete notify can be send only once");
                    }
                    this.completed = true;
                }
                else if (this.completed) {
                    // TODO: maybe it needs to include also other type like "Request.Exception"
                    LogIt.Debug(">other:" + response.returnValue.type);
                }
            }
        }
        else {
            if (this.sent) {
                throw new Error("LCP Error: raw message can be send only once");
            }
            this.sent = true;
        }
        this.data.data = response;
        this.data.status = HttpStatusType.SUCCESS;
        return this.SendObject(this.data);
    }
    /**
     * @param {IWebServiceProtocol} $object Protocol object to transmit.
     * @returns {IResponsePromise} Returns a promise-like object with Then() method.
     */
    SendObject($object) {
        $object.keepAlive = this.KeepAlive();
        this.owner.Send($object);
        if (!this.keepAlive) {
            this.Dispatch();
        }
        return {
            Then: ($callback) => {
                this.callbacks.oncomplete = $callback;
            }
        };
    }
    /**
     * @param {IWebServiceProtocol} $data Incoming protocol message.
     */
    OnMessage($data) {
        if (!ObjectValidator.IsArray($data)) {
            $data = [$data];
        }
        this.callbacks.onsend.apply(this, $data);
        this.callbacks.onstart.apply(this, $data);
        this.callbacks.onchange.apply(this, $data);
        this.callbacks.oncomplete.apply(this, $data);
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.ResponseApi.Handlers.LiveContentResponse", LiveContentResponse);
//# sourceMappingURL=LiveContentResponse.js.map