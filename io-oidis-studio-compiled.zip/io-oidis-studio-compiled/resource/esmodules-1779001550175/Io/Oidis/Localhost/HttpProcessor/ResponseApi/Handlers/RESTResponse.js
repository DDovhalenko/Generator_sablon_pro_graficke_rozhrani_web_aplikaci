/*! ******************************************************************************************************** *
 *
 * Copyright 2022-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpMethodType } from "./../../../../../../Io/Oidis/Commons/Enums/HttpMethodType.js";
import { HttpStatusType } from "./../../../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { ArrayList } from "./../../../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { JsonUtils } from "./../../../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { ObjectValidator } from "./../../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { HttpServer } from "../../HttpServer.js";
import { WebResponse } from "./WebResponse.js";
export class RESTResponse extends WebResponse {
    acceptType;
    etags;
    force;
    constructor($owner, $data) {
        super($owner, $data);
    }
    /**
     * @param {IRESTResponseOptions} $value Options object to apply.
     */
    setOptions($value) {
        if (ObjectValidator.IsSet($value.acceptType)) {
            this.acceptType = $value.acceptType;
        }
        if (ObjectValidator.IsSet($value.etags)) {
            this.etags = $value.etags;
        }
        if (ObjectValidator.IsSet($value.force)) {
            this.force = $value.force;
        }
    }
    /**
     * @returns {IRESTResponseOptions} Returns the accept type, ETags, and force flag.
     */
    getOptions() {
        return {
            acceptType: this.acceptType,
            etags: this.etags,
            force: this.force
        };
    }
    /**
     * @param {any} $args Response payload to format and send.
     * @returns {IResponsePromise} Returns a promise-like object with Then() method.
     */
    Send($args) {
        const response = this.formatContent(this.formatResponse($args, HttpStatusType.SUCCESS));
        if (response.status === HttpStatusType.SUCCESS ||
            response.status === HttpStatusType.CONTINUE) {
            const eTag = StringUtils.getSha1(JSON.stringify(response.body));
            if (this.etags.IsEmpty() || !this.etags.Contains(eTag) || this.force) {
                if ((this.owner.method === HttpMethodType.POST || this.owner.method === HttpMethodType.GET)) {
                    JsonUtils.Extend(response.headers, {
                        etag: eTag
                    });
                }
                this.owner.Send(response);
            }
            else {
                this.owner.Send({
                    body: "",
                    status: HttpStatusType.CACHED
                });
            }
        }
        else {
            this.owner.Send(response);
        }
        return {
            Then: ($callback) => {
                this.callbacks.onsend = $callback;
            }
        };
    }
    /**
     * @param {string | Error} $message Error message string or Error instance.
     * @param {HttpStatusType} $status HTTP status code to return.
     */
    SendError($message, $status) {
        let message = $message;
        if (!ObjectValidator.IsString($message)) {
            message = $message.message;
        }
        this.owner.Send({
            body: message,
            status: $status
        });
    }
    /**
     * @param {string | Error} $message Error message string or Error instance.
     * @param {any[]} $args Additional context arguments encoded in the error body.
     */
    OnError($message, ...$args) {
        // TODO(mkelnar) should we send stack or not, I think than no and just log it as warning
        let stack = null;
        if (ObjectValidator.IsSet($message.message)) {
            if (ObjectValidator.IsSet($message.stack)) {
                stack = Buffer.from($message.stack).toString("base64");
            }
            if (ObjectValidator.IsSet($message.localizations) &&
                $message.localizations.hasOwnProperty(this.data.language)) {
                $message = $message.localizations[this.data.language];
            }
            else {
                $message = $message.message;
            }
        }
        else if (!ObjectValidator.IsString($message)) {
            $message = JSON.stringify($message);
        }
        if (ObjectValidator.IsEmptyOrNull($message)) {
            $message = "";
        }
        let response;
        if (!ObjectValidator.IsEmptyOrNull($args)) {
            response = this.formatResponse({
                args: Buffer.from(JSON.stringify($args)).toString("base64"),
                message: $message,
                stack
            }, HttpStatusType.ERROR);
        }
        else {
            response = this.formatResponse($message, HttpStatusType.ERROR);
        }
        response = this.formatContent(response);
        response.status = HttpStatusType.ERROR;
        this.owner.Send(response);
    }
    /**
     * @returns {ArrayList<string>} Returns the list of request headers, or an empty list.
     */
    getRequestHeaders() {
        const args = HttpServer.getRequestArgs(this);
        if (!ObjectValidator.IsEmptyOrNull(args)) {
            return args.Owner().getHeaders();
        }
        return new ArrayList();
    }
    formatResponse($data, $status) {
        return {
            status: $status,
            headers: {},
            body: $data
        };
    }
    formatContent($response) {
        if (StringUtils.ContainsIgnoreCase(this.acceptType, "/xml")) {
            $response.headers = JsonUtils.Extend(this.owner.headers, {
                "content-type": "application/xml; charset=UTF-8"
            });
            $response.body = new (require("xml2js")).Builder().buildObject($response.body);
        }
        else if (StringUtils.ContainsIgnoreCase(this.acceptType, "/x-www-form-urlencoded")) {
            $response.headers = JsonUtils.Extend($response.headers, {
                "content-type": "application/x-www-form-urlencoded; charset=UTF-8"
            });
            $response.body = require("qs").stringify($response.body);
        }
        else {
            $response.headers = JsonUtils.Extend($response.headers, {
                "content-type": "application/json; charset=UTF-8"
            });
            $response.body = JSON.stringify($response.body);
        }
        return $response;
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.ResponseApi.Handlers.RESTResponse", RESTResponse);
//# sourceMappingURL=RESTResponse.js.map