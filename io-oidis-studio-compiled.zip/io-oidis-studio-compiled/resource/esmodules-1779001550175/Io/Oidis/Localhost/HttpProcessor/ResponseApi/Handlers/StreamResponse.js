/*! ******************************************************************************************************** *
 *
 * Copyright 2023-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { JsonUtils } from "./../../../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { ObjectValidator } from "./../../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { RESTResponse as Parent } from "./RESTResponse.js";
export class StreamResponse extends Parent {
    /**
     * @param {IResponseProtocol} $args Response protocol object containing body, headers, and normalize flag.
     * @returns {IResponsePromise} Returns a promise-like object with Then() method.
     */
    Send($args) {
        if (!ObjectValidator.IsEmptyOrNull($args.body) && !Buffer.isBuffer($args.body) &&
            (!ObjectValidator.IsSet($args.normalize) || $args.normalize)) {
            if (ObjectValidator.IsObject($args.body)) {
                $args.body = JSON.stringify($args.body);
            }
            else {
                $args.body = JSON.stringify({ message: $args.body, status: $args.status });
            }
            $args.headers = JsonUtils.Extend({
                "content-type": "application/json; charset=utf-8"
            }, $args.headers);
        }
        this.owner.Send($args);
        return {
            Then: ($callback) => {
                this.callbacks.onsend = $callback;
            }
        };
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.ResponseApi.Handlers.StreamResponse", StreamResponse);
//# sourceMappingURL=StreamResponse.js.map