/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2026 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { DataFormatType } from "./../../../../../../Io/Oidis/Commons/Enums/DataFormatType.js";
import { HttpStatusType } from "./../../../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { JsonUtils } from "./../../../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { LogIt } from "./../../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { BaseResponse } from "./BaseResponse.js";
export class WebResponse extends BaseResponse {
    data;
    constructor($owner, $data) {
        super();
        if (!ObjectValidator.IsEmptyOrNull($owner) && $owner instanceof WebResponse) {
            this.Clone($owner);
        }
        else {
            this.data = $data;
            this.owner = $owner;
        }
    }
    /**
     * @param {IResponse} $instance Source response to clone from.
     */
    Clone($instance) {
        super.Clone($instance);
        if (ObjectValidator.IsSet($instance.data)) {
            this.data = $instance.data;
            if (!ObjectValidator.IsEmptyOrNull(this.data)) {
                try {
                    if (ObjectValidator.IsString(this.data.data)) {
                        this.data.format = DataFormatType.BASE64;
                        this.data.data = JSON.parse(Buffer.from(this.data.data, "base64").toString("utf8"));
                    }
                    else if (this.data.data instanceof ArrayBuffer) {
                        this.data.format = DataFormatType.JSON;
                        try {
                            this.data.data = JsonUtils.ToJson(this.data.data);
                        }
                        catch (ex) {
                            LogIt.Warning("Failed to convert data from ArrayBuffer");
                            LogIt.Debug(ex.stack);
                        }
                    }
                }
                catch (ex) {
                    // pass data as is, because they can be already in correct format
                }
            }
        }
    }
    /**
     * @param {any[]} $args Response payload arguments to encode and transmit.
     * @returns {IResponsePromise} Returns a promise-like object with Then() method.
     */
    Send(...$args) {
        if (this.data.format !== DataFormatType.JSON) {
            this.data.format = DataFormatType.BASE64;
            this.data.data = Buffer.from(JSON.stringify($args)).toString("base64");
        }
        else {
            this.data.data = $args;
        }
        this.data.status = HttpStatusType.SUCCESS;
        this.data.keepAlive = this.KeepAlive();
        this.owner.Send(this.data);
        return {
            Then: ($callback) => {
                this.callbacks.onsend = $callback;
            }
        };
    }
    /**
     * @param {any[]} $args Arguments to include in the onstart event payload.
     * @returns {IResponsePromise} Returns a promise-like object with Then() method.
     */
    OnStart(...$args) {
        this.KeepAlive(true);
        this.Send(this.normalizeArgs($args, "onstart"));
        return {
            Then: ($callback) => {
                this.callbacks.onstart = $callback;
            }
        };
    }
    /**
     * @param {any[]} $args Arguments to include in the onchange event payload.
     * @returns {IResponsePromise} Returns a promise-like object with Then() method.
     */
    OnChange(...$args) {
        this.KeepAlive(true);
        this.Send(this.normalizeArgs($args, "onchange"));
        return {
            Then: ($callback) => {
                this.callbacks.onchange = $callback;
            }
        };
    }
    /**
     * @param {any[]} $args Arguments to include in the oncomplete event payload.
     * @returns {IResponsePromise} Returns a promise-like object with Then() method.
     */
    OnComplete(...$args) {
        this.KeepAlive(false);
        this.Send(this.normalizeArgs($args, "oncomplete"));
        return {
            Then: ($callback) => {
                this.callbacks.oncomplete = $callback;
            }
        };
    }
    /**
     * @param {string | Error} $message Error message string or Error instance.
     * @param {any[]} $args Additional context arguments encoded in the error body.
     */
    OnError($message, ...$args) {
        const isJson = this.data.format === DataFormatType.JSON;
        let stack = null;
        let logMessage = "";
        if (ObjectValidator.IsSet($message.message)) {
            if (ObjectValidator.IsSet($message.stack)) {
                if (!isJson) {
                    stack = Buffer.from($message.stack).toString("base64");
                }
                else {
                    stack = $message.stack;
                }
            }
            logMessage = $message;
            if (ObjectValidator.IsSet($message.localizations) &&
                $message.localizations.hasOwnProperty(this.data.language)) {
                $message = $message.localizations[this.data.language];
            }
            else {
                $message = $message.message;
            }
        }
        else if (!ObjectValidator.IsString($message)) {
            logMessage = JSON.stringify($message);
            if (!isJson) {
                $message = logMessage;
            }
        }
        if (ObjectValidator.IsEmptyOrNull($message)) {
            $message = "";
        }
        LogIt.Error(logMessage);
        if (!isJson) {
            $message = Buffer.from($message.replace(/[\n]/gmi, "<br/>")).toString("base64");
        }
        this.data.status = HttpStatusType.ERROR;
        this.data.type = "Request.Exception";
        if (!ObjectValidator.IsEmptyOrNull($args)) {
            this.data.data = {
                args: isJson ? $args : Buffer.from(JSON.stringify($args)).toString("base64"),
                message: $message,
                stack
            };
        }
        else {
            this.data.data = $message;
        }
        this.owner.Send(this.data);
    }
    /**
     * @param {IWebServiceProtocol} $data Incoming protocol message to decode and dispatch.
     */
    OnMessage($data) {
        let data = $data;
        if (this.data.format !== DataFormatType.JSON) {
            data = Buffer.from($data.data, "base64").toString("utf8");
            try {
                data = JSON.parse(data);
            }
            catch (ex) {
                // provide data as is
            }
        }
        super.OnMessage(data);
    }
    /**
     * @returns {number} Returns the protocol message ID.
     */
    getId() {
        return this.data.id;
    }
    /**
     * @returns {string} Returns the owner's ID.
     */
    getOwnerId() {
        return this.owner.getOwnerId();
    }
    Abort() {
        super.Abort();
        this.data = null;
    }
    normalizeArgs($args, $type) {
        let data = "";
        if ($args.length > 0) {
            data = $args.length === 1 ? $args[0] : $args;
        }
        return {
            data,
            type: $type
        };
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.ResponseApi.Handlers.WebResponse", WebResponse);
//# sourceMappingURL=WebResponse.js.map