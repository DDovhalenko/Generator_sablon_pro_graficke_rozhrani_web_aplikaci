/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2026 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseObject } from "./../../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { BaseResponse } from "./Handlers/BaseResponse.js";
import { CallbackResponse } from "./Handlers/CallbackResponse.js";
export class ResponseFactory extends BaseObject {
    /**
     * @param {((...$args : any[]) => void) | IResponse} $callback Callback function or response instance.
     * @returns {IResponse} Returns the normalized response object.
     */
    static getResponse($callback) {
        let response;
        if (!($callback instanceof BaseResponse)) {
            if (ObjectValidator.IsFunction($callback)) {
                response = new CallbackResponse($callback);
            }
            else {
                response = new BaseResponse();
            }
        }
        else {
            response = $callback;
        }
        return response;
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.HttpProcessor.ResponseApi.ResponseFactory", ResponseFactory);
//# sourceMappingURL=ResponseFactory.js.map