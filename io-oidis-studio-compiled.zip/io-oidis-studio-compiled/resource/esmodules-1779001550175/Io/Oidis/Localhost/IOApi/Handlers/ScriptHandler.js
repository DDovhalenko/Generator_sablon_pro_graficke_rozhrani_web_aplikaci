/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { JsonpFileReader } from "./../../../../../Io/Oidis/Commons/IOApi/Handlers/JsonpFileReader.js";
import { ScriptHandler as Parent } from "./../../../../../Io/Oidis/Commons/IOApi/Handlers/ScriptHandler.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { ProtectionType } from "../../Enums/ProtectionType.js";
import { EnvironmentArgs } from "../../EnvironmentArgs.js";
import { ResourceVerifier } from "../../Utils/ResourceVerifier.js";
import { VMHandler } from "./VMHandler.js";
let strip = {};
if (!globalThis.isBrowser) {
    strip = (await import("./../../../../../../nodejs/node_modules/strip-json-comments/index.js")).default;
}
export class ScriptHandler extends Parent {
    protectionMap = null;
    protectionType = ProtectionType.NONE;
    publicKey;
    /**
     * @param {any} [$value] The data value to set.
     * @returns {any} Returns the current data, decrypted or verified as configured.
     */
    Data($value) {
        if (this.protectionMap === null || this.protectionType === ProtectionType.NONE) {
            return super.Data($value);
        }
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            return super.Data($value);
        }
        let data = null;
        if (this.protectionType === ProtectionType.ENCRYPTION) {
            data = Buffer.from(super.Data($value), "hex");
        }
        else if (this.protectionType === ProtectionType.SIGNATURE || this.protectionType === ProtectionType.HASH) {
            data = Buffer.from(super.Data($value), "utf8");
        }
        else {
            throw new Error("Unsupported protection type: " + this.protectionType);
        }
        if (data === null) {
            throw new Error("Data invalid.");
        }
        if (this.protectionType === ProtectionType.ENCRYPTION) {
            if (this.protectionMap.includes(this.Path())) {
                data = ResourceVerifier.DecryptResource(data, Buffer.alloc(32));
            }
        }
        if (this.protectionType === ProtectionType.SIGNATURE) {
            if (!ResourceVerifier.VerifyByName(data, this.publicKey, this.protectionMap, this.Path())) {
                throw new Error("Verification failed.");
            }
        }
        if (this.protectionType === ProtectionType.HASH) {
            if (!ResourceVerifier.VerifyHash(data, this.protectionMap, this.Path())) {
                throw new Error("Verification failed.");
            }
        }
        return data;
    }
    /**
     * @param {string} $publicKey The public key string for resource verification.
     */
    setPublicKey($publicKey) {
        this.publicKey = $publicKey;
    }
    /**
     * @param {any} $map The protection map containing resource paths and their verification data.
     * @param {ProtectionType} protectionType The type of protection to apply.
     */
    setMap($map, protectionType) {
        if (ObjectValidator.IsEmptyOrNull($map)) {
            return;
        }
        this.protectionType = protectionType;
        this.protectionMap = $map;
    }
    /** @returns {void} */
    Load() {
        const fs = require("fs");
        const path = require("path");
        if (ObjectValidator.IsEmptyOrNull(this.Path()) && ObjectValidator.IsEmptyOrNull(this.Data())) {
            this.errorHandler(new Error("Path or body for resource must be defined before load."));
        }
        else {
            const executeScript = ObjectValidator.IsEmptyOrNull(this.Path());
            let filepath = "";
            if (!executeScript) {
                filepath = path.normalize(this.Path());
            }
            const execute = () => {
                try {
                    const vm = new VMHandler();
                    const reader = ($data) => {
                        this.Data($data);
                    };
                    if (ObjectValidator.IsEmptyOrNull(JsonpFileReader.Data)) {
                        JsonpFileReader.Data = reader;
                    }
                    EnvironmentArgs.AppConfigData = reader;
                    vm.Path(filepath);
                    vm.Data(this.Data());
                    vm.Sandbox({
                        Io: globalThis.Io
                    });
                    vm.ErrorHandler(this.errorHandler);
                    vm.SuccessHandler(() => {
                        this.Data();
                        this.successHandler();
                    });
                    vm.Load();
                }
                catch (ex) {
                    this.errorHandler(ex);
                }
            };
            if (executeScript) {
                execute();
            }
            else if (fs.existsSync(filepath)) {
                this.Data(fs.readFileSync(filepath).toString());
                if (StringUtils.EndsWith(filepath, ".json")) {
                    try {
                        this.Data(JSON.parse(strip(this.Data())));
                        this.successHandler();
                    }
                    catch (ex) {
                        this.errorHandler(ex);
                    }
                }
                else if (StringUtils.EndsWith(filepath, ".jsonp") || StringUtils.EndsWith(filepath, ".js")) {
                    execute();
                }
                else {
                    this.errorHandler(new Error("Unsupported script extension."));
                }
            }
            else {
                this.errorHandler(new Error("Unable to find script."));
            }
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.IOApi.Handlers.ScriptHandler", ScriptHandler);
//# sourceMappingURL=ScriptHandler.js.map