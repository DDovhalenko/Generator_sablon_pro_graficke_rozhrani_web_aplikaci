// generated-code-start
export const IHttpServerEvents = globalThis.RegisterInterface(["OnStart", "OnConnect", "OnDisconnect"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.Events.IHttpServerEvents", IHttpServerEvents);
//# sourceMappingURL=IHttpServerEvents.js.map