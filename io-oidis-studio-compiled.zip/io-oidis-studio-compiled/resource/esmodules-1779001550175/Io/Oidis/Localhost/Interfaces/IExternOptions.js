export var ExternResponseType;
(function (ExternResponseType) {
    ExternResponseType[ExternResponseType["DEFAULT"] = 0] = "DEFAULT";
    ExternResponseType[ExternResponseType["IMPLICIT_RETURN"] = 1] = "IMPLICIT_RETURN";
    ExternResponseType[ExternResponseType["WITH_PROGRESS"] = 2] = "WITH_PROGRESS";
    ExternResponseType[ExternResponseType["FULL_CONTROL"] = 3] = "FULL_CONTROL";
    ExternResponseType[ExternResponseType["RESPONSE_PROTOCOL"] = 4] = "RESPONSE_PROTOCOL";
})(ExternResponseType || (ExternResponseType = {}));
// generated-code-start
export const IExternOptions = globalThis.RegisterInterface(["responseType", "responseHandler", "outputFormatter"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IExternOptions", IExternOptions);
//# sourceMappingURL=IExternOptions.js.map