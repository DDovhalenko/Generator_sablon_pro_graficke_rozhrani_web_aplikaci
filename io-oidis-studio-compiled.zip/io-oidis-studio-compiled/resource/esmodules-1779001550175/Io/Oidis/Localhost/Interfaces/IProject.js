/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ILCPConfiguration as CommonsILCPConfiguration, ILoggerConfiguration as CommonsILoggerConfiguration, IProject as Parent, IProjectTarget as CommonsIProjectTarget } from "./../../../../Io/Oidis/Commons/Interfaces/IProject.js";
// generated-code-start
/* eslint-disable */
export const IProject = globalThis.RegisterInterface(["domain", "httpProxy", "forceHttpProxy", "httpsProxy", "noProxy", "reverseProxy", "connectorProxy", "certs", "target", "disableStrictSSL", "elastic", "logger", "cron", "lcpConfig"], Parent);
export const IProjectTarget = globalThis.RegisterInterface(["projectBase", "appDataPath", "tmpPath", "requestPatterns", "metrics", "meta"], CommonsIProjectTarget);
export const ITargetMetadata = globalThis.RegisterInterface(["title", "description", "author", "keywords", "robots", "url", "canonical", "logoUrl", "imageWidth", "imageHeight", "imageAlt", "siteName", "type", "locale", "fbAppId", "twitterCard", "twitterSite", "twitterCreator", "themeColor", "jsonLd"]);
export const IServerConfigurationDomain = globalThis.RegisterInterface(["location", "ports", "ssl", "origins", "localization", "csp"]);
export const IServerConfigurationPorts = globalThis.RegisterInterface(["http", "https"]);
export const IServerConfigurationSSL = globalThis.RegisterInterface(["enabled", "certificatePath", "privateKeyPath"]);
export const IServerLocalization = globalThis.RegisterInterface(["default", "requestDriven"]);
export const IMetricsConfiguration = globalThis.RegisterInterface(["enabled", "location", "port"]);
export const ICertsConfiguration = globalThis.RegisterInterface(["external", "mail", "port", "location"]);
export const IReverseProxyConfiguration = globalThis.RegisterInterface(["enabled", "withServer", "tunnels"]);
export const IProxyTunnelsConfiguration = globalThis.RegisterInterface(["port", "ssl", "location"]);
export const IElasticConfiguration = globalThis.RegisterInterface(["location", "index", "user", "pass", "cert", "mapping"]);
export const ILoggerConfiguration = globalThis.RegisterInterface(["httpGetFilterPatterns"], CommonsILoggerConfiguration);
export const ICSPConfiguration = globalThis.RegisterInterface(["enabled", "reportUri", "policies"]);
export const IContentSecurityPolicy = globalThis.RegisterInterface(["enabled", "isDefault", "pattern", "policy"]);
export const ICronConfig = globalThis.RegisterInterface(["enabled", "scheduler", "timezone"]);
export const ILCPConfiguration = globalThis.RegisterInterface(["accept"], CommonsILCPConfiguration);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IProject", IProject);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IProjectTarget", IProjectTarget);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.ITargetMetadata", ITargetMetadata);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IServerConfigurationDomain", IServerConfigurationDomain);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IServerConfigurationPorts", IServerConfigurationPorts);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IServerConfigurationSSL", IServerConfigurationSSL);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IServerLocalization", IServerLocalization);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IMetricsConfiguration", IMetricsConfiguration);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.ICertsConfiguration", ICertsConfiguration);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IReverseProxyConfiguration", IReverseProxyConfiguration);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IProxyTunnelsConfiguration", IProxyTunnelsConfiguration);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IElasticConfiguration", IElasticConfiguration);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.ILoggerConfiguration", ILoggerConfiguration);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.ICSPConfiguration", ICSPConfiguration);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IContentSecurityPolicy", IContentSecurityPolicy);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.ICronConfig", ICronConfig);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.ILCPConfiguration", ILCPConfiguration);
//# sourceMappingURL=IProject.js.map