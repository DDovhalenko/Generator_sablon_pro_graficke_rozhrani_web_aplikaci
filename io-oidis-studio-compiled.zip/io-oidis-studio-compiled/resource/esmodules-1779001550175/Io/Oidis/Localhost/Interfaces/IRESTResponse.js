// generated-code-start
export const IRESTResponse = globalThis.RegisterInterface(["code", "status", "message", "data", "errors"]);
export const IRESTError = globalThis.RegisterInterface(["message", "field", "value"]);
export const IRESTResponseOptions = globalThis.RegisterInterface(["force", "etags", "acceptType"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IRESTResponse", IRESTResponse);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IRESTError", IRESTError);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IRESTResponseOptions", IRESTResponseOptions);
//# sourceMappingURL=IRESTResponse.js.map