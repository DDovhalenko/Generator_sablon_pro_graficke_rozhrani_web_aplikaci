// generated-code-start
export const IRequestConnector = globalThis.RegisterInterface(["Send", "getOwnerId", "getParentProcess"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IRequestConnector", IRequestConnector);
//# sourceMappingURL=IRequestConnector.js.map