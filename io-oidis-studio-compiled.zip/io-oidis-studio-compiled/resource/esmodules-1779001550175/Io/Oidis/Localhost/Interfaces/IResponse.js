// generated-code-start
/* eslint-disable */
export const IResponse = globalThis.RegisterInterface(["Send", "OnStart", "OnChange", "OnComplete", "OnError", "OnMessage", "FireEvent", "getId", "getOwnerId", "AddAbortHandler", "Abort", "KeepAlive", "Dispatch"]);
export const IMessage = globalThis.RegisterInterface(["OnChange"]);
export const IProgress = globalThis.RegisterInterface(["OnChange"]);
export const IResponsePromise = globalThis.RegisterInterface(["Then"]);
export const IResponseProtocol = globalThis.RegisterInterface(["status", "headers", "body", "normalize"]);
export const IAuthPromise = globalThis.RegisterInterface(["resolve", "auth"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IResponse", IResponse);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IMessage", IMessage);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IProgress", IProgress);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IResponsePromise", IResponsePromise);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IResponseProtocol", IResponseProtocol);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IAuthPromise", IAuthPromise);
//# sourceMappingURL=IResponse.js.map