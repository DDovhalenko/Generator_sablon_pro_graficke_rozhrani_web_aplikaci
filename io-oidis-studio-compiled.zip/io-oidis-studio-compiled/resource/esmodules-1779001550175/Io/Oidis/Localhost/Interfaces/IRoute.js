import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { Convert } from "./../../../../Io/Oidis/Commons/Utils/Convert.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { IExternOptions } from "./IExternOptions.js";
export class BaseRouteArgument extends BaseObject {
    key;
    value;
    converter;
    /**
     * @param {string} $key Argument key name.
     * @param $value Initial value, optionally with a type cast expression.
     */
    constructor($key, $value) {
        super();
        this.converter = ($val) => {
            return $val;
        };
        this.key = $key;
        if (ObjectValidator.IsString($value)) {
            const group = /(\w+)\((.*)\)/.exec($value);
            if (ObjectValidator.IsArray(group) && group.length === 3) { // exactly [fullmatch, type-keyword, value] nothing more
                switch (group[1].toLowerCase()) {
                    case "int":
                    case "integer":
                    case "number":
                        this.converter = Convert.StringToInteger;
                        break;
                    case "float":
                    case "double":
                        this.converter = Convert.StringToDouble;
                        break;
                    case "bool":
                    case "boolean":
                        this.converter = Convert.StringToBoolean;
                        break;
                    case "string":
                        this.converter = ($value) => {
                            return $value;
                        };
                        break;
                    default:
                }
                $value = this.converter(group[2]);
            }
        }
        this.value = $value;
    }
    /** @returns {string} Returns the argument key name. */
    get Key() {
        return this.key;
    }
    /** @returns {any} Returns the current argument value. */
    get Value() {
        return this.value;
    }
    /**
     * @param $value New raw value to store.
     */
    UpdateValue($value) {
        if (ObjectValidator.IsFunction(this.converter)) {
            this.value = this.converter($value);
        }
    }
    /**
     * @param $value Raw value to convert.
     * @returns {any} Returns the converted value.
     */
    ResolveValue($value) {
        if (ObjectValidator.IsFunction(this.converter)) {
            return this.converter($value);
        }
        return $value;
    }
}
// generated-code-start
/* eslint-disable */
export const IRoute = globalThis.RegisterInterface(["method", "methodName", "route", "options", "schema", "ClassName"]);
export const IRouteOptions = globalThis.RegisterInterface(["httpMethod", "version", "autoResponse", "inputFormatter", "args", "priority"], IExternOptions);
export const IHttpResponse = globalThis.RegisterInterface(["status", "headers", "body"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IRoute", IRoute);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IRouteOptions", IRouteOptions);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.IHttpResponse", IHttpResponse);
globalThis.RegisterClass("Io.Oidis.Localhost.Interfaces.BaseRouteArgument", BaseRouteArgument);
//# sourceMappingURL=IRoute.js.map