var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IOHandlerType } from "./../../../Io/Oidis/Commons/Enums/IOHandlerType.js";
import { LogLevel } from "./../../../Io/Oidis/Commons/Enums/LogLevel.js";
import { LogSeverity } from "./../../../Io/Oidis/Commons/Enums/LogSeverity.js";
import { ExceptionsManager } from "./../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { IOHandlerFactory } from "./../../../Io/Oidis/Commons/IOApi/IOHandlerFactory.js";
import { Loader as CommonsLoader } from "./../../../Io/Oidis/Commons/Loader.js";
import { Echo } from "./../../../Io/Oidis/Commons/Utils/Echo.js";
import { JsonUtils } from "./../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { LogIt } from "./../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectEncoder } from "./../../../Io/Oidis/Commons/Utils/ObjectEncoder.js";
import { ObjectValidator } from "./../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Resources } from "./../../../Io/Oidis/Services/DAO/Resources.js";
import { Loader as Parent } from "./../../../Io/Oidis/Services/Loader.js";
import { ConnectorsRegister } from "./Connectors/ConnectorsRegister.js";
import { FileSystemHandler } from "./Connectors/FileSystemHandler.js";
import { Terminal } from "./Connectors/Terminal.js";
import { LogAdapterType } from "./Enums/LogAdapterType.js";
import { EnvironmentArgs } from "./EnvironmentArgs.js";
import "./ForceCompile.js";
import { HttpResolver } from "./HttpProcessor/HttpResolver.js";
import { HttpServer } from "./HttpProcessor/HttpServer.js";
import { RESTResolver } from "./HttpProcessor/Resolvers/RESTResolver.js";
import { CallbackResponse } from "./HttpProcessor/ResponseApi/Handlers/CallbackResponse.js";
import { ResponseFactory } from "./HttpProcessor/ResponseApi/ResponseFactory.js";
import { VMHandler } from "./IOApi/Handlers/VMHandler.js";
import { StdAdapter } from "./LogProcessor/Adapters/StdAdapter.js";
import { Logger } from "./LogProcessor/Logger.js";
import { IntegrityCheck } from "./Primitives/Decorators.js";
import { ProgramArgs } from "./Structures/ProgramArgs.js";
import { EnvironmentHelper } from "./Utils/EnvironmentHelper.js";
import { FirewallManager } from "./Utils/FirewallManager.js";
import { Metrics } from "./Utils/Metrics.js";
import { WebSocket } from "./WebServiceApi/Clients/WebSocket.js";
import { Cron } from "./Utils/Cron.js";
export class Loader extends Parent {
    logger;
    fileSystem;
    terminal;
    server;
    appArgs;
    isClosing;
    connectorsRegister;
    cron;
    startTime;
    /**
     * @param {string | IProject} $appConfig The application configuration object or path.
     */
    static Load($appConfig) {
        try {
            const instance = new this();
            CommonsLoader.singleton = instance;
            instance.isClosing = false;
            if (process.argv.includes("--debug")) {
                console.log("Loading application config..."); // eslint-disable-line no-console
            }
            if (!ObjectValidator.IsSet(globalThis.Io.Oidis.Builder)) {
                globalThis.Io.Oidis.Builder = {
                    DAO: {
                        Resources
                    }
                };
            }
            instance.logger = new Logger();
            instance.Process($appConfig);
            EnvironmentHelper.NormalizeProxySetting(instance.getAppConfiguration());
            instance.initDOM();
            instance.initLogIt();
            const exitHandler = () => {
                instance.Exit();
            };
            process.on("exit", exitHandler);
            process.on("SIGINT", exitHandler);
            process.on("SIGTERM", exitHandler);
            process.on("uncaughtException", ($ex) => {
                Metrics.Error($ex);
                ExceptionsManager.HandleException($ex);
            });
            process.on("warning", ($data) => {
                if ($data.name !== "ExperimentalWarning") {
                    LogIt.Warning($data.toString());
                }
            });
            global.window.close = exitHandler;
            if (!EnvironmentHelper.IsDetached()) {
                try {
                    if (EnvironmentHelper.IsTTY()) {
                        require("readline").emitKeypressEvents(process.stdin);
                        process.stdin.setRawMode(true);
                        process.stdin.on("keypress", ($character, $key) => {
                            if ($key.ctrl && ($key.name === "c" || $key.name === "q" || $key.name === "x")) {
                                Loader.getInstance().Exit();
                            }
                        });
                    }
                    else {
                        process.stdin.on("data", ($value) => {
                            $value = $value.toString().trim();
                            if ($value === "exit" || $value === "quit") {
                                Loader.getInstance().Exit();
                            }
                        });
                    }
                }
                catch (ex) {
                    // unable to hook on stdin
                }
            }
            instance.appArgs = instance.initProgramArgs();
            instance.appArgs.Parse([].concat(process.argv));
            instance.prepareLoader();
            if (instance.appArgs.IsIntegrityCheck()) {
                setTimeout(() => {
                    LogIt.Info("Starting integrity check...");
                    // TODO(mkelnar) check if <binpath?>/resource/metadata.json exists
                    instance.processIntegrityCheck()
                        .then(() => {
                        LogIt.Info("Integrity check succeed.");
                        instance.Exit(0);
                    })
                        .catch(($error) => {
                        LogIt.Error($error.message);
                        instance.Exit(-1);
                    });
                }, 500);
            }
            else {
                instance.processProgramArgs();
            }
        }
        catch (ex) {
            process.stderr.write("Application start error. " + ex.stack);
            process.exit(1);
        }
    }
    /**
     * @returns {Loader} Returns the current Loader singleton.
     */
    static getInstance() {
        return super.getInstance();
    }
    static getIntegrityMetadata() {
        const retVal = JSON.parse(Loader.getInstance().getFileSystemHandler()
            .Read(Loader.getInstance().getProgramArgs().BinBase() + "/resource/metadata.json").toString());
        Loader.getIntegrityMetadata = () => {
            return retVal;
        };
        return retVal;
    }
    constructor() {
        super();
        this.startTime = new Date();
    }
    static async npmModules() {
        const report = { name: "npmModules", cases: [] };
        const modules = Loader.getIntegrityMetadata().modules;
        LogIt.Info("validate modules: {0}", Object.keys(modules).length);
        let issues = 0;
        for (const module of Object.keys(modules)) {
            if (Loader.getInstance().getProgramArgs().getIgnoredChecks().includes(module)) {
                report.cases.push({ name: module, skipped: true });
                LogIt.Warning("Check for '" + module + "' module ignored by CLI option.");
                continue;
            }
            if (!StringUtils.Contains(module, "@types", "source-map-support")) {
                LogIt.Info("validating module: {0}", module);
                try {
                    await import(module);
                    report.cases.push({ name: module });
                }
                catch ($e) {
                    report.cases.push({ name: module, error: $e });
                    issues++; // eslint-disable-line @typescript-eslint/no-unused-vars
                    LogIt.Warning(module + ": " + $e.message);
                }
            }
        }
        return report;
    }
    static async npmNativeModules() {
        const report = { name: "npmNativeModules", cases: [] };
        const modules = Loader.getIntegrityMetadata().native;
        let issues = 0;
        let osKey = "/linux";
        if (EnvironmentHelper.IsWindows()) {
            osKey = "/win";
        }
        else if (EnvironmentHelper.IsMac()) {
            osKey = "/darwin";
        }
        for (const module of modules) {
            if (Loader.getInstance().getProgramArgs().getIgnoredChecks().includes(module)) {
                report.cases.push({ name: module, skipped: true });
                LogIt.Warning("Check for '" + module + "' module ignored by CLI option.");
                continue;
            }
            if (!StringUtils.ContainsIgnoreCase(module, osKey)) {
                report.cases.push({ name: module, skipped: true });
                LogIt.Warning("Check for '" + module + "' module skipped, different platform.");
                continue;
            }
            LogIt.Info("validating native module: {0}", module);
            try {
                require(module);
                report.cases.push({ name: module });
            }
            catch ($e) {
                report.cases.push({ name: module, error: $e });
                issues++; // eslint-disable-line @typescript-eslint/no-unused-vars
                LogIt.Warning(module + ": " + $e.message);
            }
        }
        return report;
    }
    /**
     * @returns {HttpResolver} Returns the typed HttpResolver instance.
     */
    getHttpResolver() {
        return super.getHttpResolver();
    }
    /**
     * @returns {HttpManager} Returns the typed HttpManager instance.
     */
    getHttpManager() {
        return super.getHttpManager();
    }
    /**
     * @returns {EnvironmentArgs} Returns the typed EnvironmentArgs instance.
     */
    getEnvironmentArgs() {
        return super.getEnvironmentArgs();
    }
    /**
     * @returns {IProject} Returns the project configuration object.
     */
    getAppConfiguration() {
        return this.getEnvironmentArgs().getProjectConfig();
    }
    /**
     * @returns {ProgramArgs} Returns the program arguments instance.
     */
    getProgramArgs() {
        return this.appArgs;
    }
    /**
     * @returns {FileSystemHandler} Returns the FileSystemHandler instance.
     */
    getFileSystemHandler() {
        if (!ObjectValidator.IsSet(this.fileSystem)) {
            this.fileSystem = this.initFileSystem();
            this.getFileSystemHandler = () => {
                return this.fileSystem;
            };
        }
        return this.fileSystem;
    }
    /**
     * @returns {Terminal} Returns the Terminal instance.
     */
    getTerminal() {
        if (!ObjectValidator.IsSet(this.terminal)) {
            this.terminal = this.initTerminal();
            this.getTerminal = () => {
                return this.terminal;
            };
        }
        return this.terminal;
    }
    /**
     * @param {any} [$patterns] The anonymization patterns to apply to log output.
     */
    setAnonymizer($patterns) {
        this.logger.setAnonymizer($patterns);
    }
    /**
     * @param {number} [$exitCode] The process exit code. Defaults to undefined (clean exit).
     */
    Exit($exitCode) {
        if (!this.isClosing) {
            this.isClosing = true;
            this.onCloseHandler(($handlerExitCode) => {
                if (ObjectValidator.IsSet($handlerExitCode)) {
                    $exitCode = $handlerExitCode;
                }
                process.exit($exitCode);
            });
        }
    }
    /**
     * @returns {number} Returns the uptime in milliseconds.
     */
    getUptime() {
        return new Date().getTime() - this.startTime.getTime();
    }
    /**
     * @returns {ConnectorsRegister} Returns the ConnectorsRegister instance.
     */
    getConnectorsRegister() {
        if (ObjectValidator.IsEmptyOrNull(this.connectorsRegister)) {
            this.connectorsRegister = this.initConnectorsRegister();
            this.getConnectorsRegister = () => {
                return this.connectorsRegister;
            };
        }
        return this.connectorsRegister;
    }
    /**
     * @returns {Cron} Returns the Cron singleton instance.
     */
    getCron() {
        if (!ObjectValidator.IsSet(this.cron)) {
            this.cron = this.initCron();
            this.getCron = () => {
                return this.cron;
            };
        }
        return this.cron;
    }
    async onEnvironmentLoad() {
        await super.onEnvironmentLoad();
        if (!this.getAppConfiguration().cron.enabled) {
            LogIt.Warning(`Cron scheduler has been disabled by project config "cron.enabled". Cron tasks will be not started automatically. Use Cron.StartTask API instead.`);
        }
    }
    selfCheck() {
        try {
            const response = ResponseFactory.getResponse(null);
            response.OnError = () => {
                this.Exit(1);
            };
            response.OnComplete = () => {
                this.Exit(0);
            };
            this.getFileSystemHandler().Download({
                streamOutput: true,
                url: "http://localhost:" + this.getAppConfiguration().domain.ports.http
            }, response, () => {
                this.Exit(1);
                return false;
            });
        }
        catch (ex) {
            this.Exit(1);
        }
    }
    initProgramArgs() {
        return new ProgramArgs();
    }
    initEnvironment() {
        return new EnvironmentArgs();
    }
    initHttpServer() {
        return new HttpServer();
    }
    initResolver() {
        return new HttpResolver("/");
    }
    initFileSystem() {
        return new FileSystemHandler();
    }
    initTerminal() {
        return new Terminal();
    }
    initConnectorsRegister() {
        return new ConnectorsRegister();
    }
    initCron() {
        return Cron.getSingleton();
    }
    prepareLoader() {
        if (this.appArgs.IsVerbose()) {
            LogIt.setLevel(LogLevel.ALL);
        }
        else if (this.appArgs.IsDebug()) {
            LogIt.setLevel(LogLevel.DEBUG);
        }
        const config = JsonUtils.Extend({}, this.getAppConfiguration().logger);
        if (this.appArgs.LogLevel() !== 0) {
            config.level = this.appArgs.LogLevel();
        }
        if (ObjectValidator.IsEmptyOrNull(config.debug) || this.appArgs.IsDebug()) {
            config.debug = this.appArgs.IsDebug();
        }
        if (ObjectValidator.IsEmptyOrNull(config.verbose) || this.appArgs.IsVerbose()) {
            config.verbose = this.appArgs.IsVerbose();
        }
        if (this.appArgs.IsDebug()) {
            this.getAppConfiguration().sentry.debug = true;
        }
        this.logger.setConfig(config);
        const target = this.getAppConfiguration().target;
        if (EnvironmentHelper.IsWindows()) {
            const driveLetterDir = __dirname.split(":")[0];
            const driveLetterCwd = process.cwd().split(":")[0];
            if (driveLetterDir !== driveLetterCwd && driveLetterDir.toLowerCase() === driveLetterCwd.toLowerCase()) {
                __dirname = __dirname.replace(driveLetterDir + ":\\", driveLetterCwd + ":\\");
            }
        }
        this.appArgs.BinBase(this.getFileSystemHandler().NormalizePath(__dirname + "/../.."));
        this.appArgs.ProjectBase(this.getCwd());
        this.appArgs.AppDataPath(target.appDataPath);
        if (ObjectValidator.IsEmptyOrNull(this.appArgs.AppDataPath()) || !this.getFileSystemHandler().Exists(this.appArgs.AppDataPath())) {
            if (!StringUtils.Contains(this.appArgs.ProjectBase(), "/build/target")) {
                this.appArgs.AppDataPath(this.getFileSystemHandler().getTempPath() + "/" + this.getEnvironmentArgs().getProjectName());
            }
            else {
                this.appArgs.AppDataPath(this.appArgs.ProjectBase());
            }
        }
        if (ObjectValidator.IsEmptyOrNull(this.appArgs.TargetBase())) {
            if (ObjectValidator.IsEmptyOrNull(target.projectBase)) {
                target.projectBase = this.appArgs.BinBase();
            }
            const fs = require("fs");
            const targetPath = target.projectBase;
            if (!ObjectValidator.IsEmptyOrNull(targetPath) && fs.existsSync(targetPath)) {
                this.appArgs.TargetBase(this.getFileSystemHandler().NormalizePath(StringUtils.Remove(targetPath, "/index.html")));
            }
            else if (fs.existsSync(__dirname + "/../../../index.html")) {
                this.appArgs.TargetBase(this.getFileSystemHandler().NormalizePath(__dirname + "/../../.."));
            }
            else {
                this.appArgs.TargetBase(this.appArgs.BinBase());
            }
        }
        else if (StringUtils.EndsWith(this.appArgs.TargetBase(), "index.html")) {
            this.appArgs.TargetBase(StringUtils.Remove(this.getFileSystemHandler().NormalizePath(this.appArgs.TargetBase()), "/index.html"));
        }
        target.projectBase = this.appArgs.TargetBase();
        this.setAnonymizer({
            appData: this.getProgramArgs().AppDataPath(),
            binBase: this.getProgramArgs().BinBase(),
            projectBase: this.getProgramArgs().ProjectBase(),
            targetBase: this.getProgramArgs().TargetBase()
        });
        process.env.PATH = this.getTerminal().NormalizeEnvironmentPath(this.getAppEnvironmentPath());
    }
    processProgramArgs() {
        let processed = false;
        if (this.appArgs.IsTestRun()) {
            processed = true;
            if (this.appArgs.IsDebug()) {
                Echo.Print("Detected --test-run argument: processing of other args will be skipped");
            }
        }
        else if (this.appArgs.IsHelp()) {
            this.appArgs.IsHelp(false);
            processed = true;
            this.appArgs.setStdinHandler(($data) => {
                if (ObjectValidator.IsEmptyOrNull($data)) {
                    this.Exit();
                }
                else {
                    Echo.Println("");
                    this.appArgs.Parse(StringUtils.Split($data, " "));
                    this.processProgramArgs();
                }
            });
            this.appArgs.PrintHelp();
        }
        else if (this.appArgs.IsVersion()) {
            this.appArgs.PrintVersion();
            this.Exit();
        }
        else if (this.appArgs.IsPath()) {
            this.appArgs.PrintPath();
            this.Exit();
        }
        else if (this.appArgs.IsSelfCheck()) {
            processed = true;
            this.selfCheck();
        }
        else if (this.appArgs.ListRoutes()) {
            Echo.Printf("REST API routes: ");
            RESTResolver.getRoutes().forEach(($value) => {
                Echo.Printf("    " + $value.options.httpMethod + " " + $value.route + " " + $value.methodName());
            });
            this.Exit(0);
            return;
        }
        else if (this.appArgs.StartServer() || this.appArgs.RestartServer()) {
            processed = true;
            if (!ObjectValidator.IsEmptyOrNull(this.server)) {
                this.server.Stop();
            }
            Echo.Print(this.printLogo());
            FirewallManager.AddServiceRule("Oidis", "Oidis Framework services", this.getEnvironmentArgs().getAppName(), "Allow incoming network traffic to Oidis Framework", this.appArgs.ProjectBase() + "/" + this.getEnvironmentArgs().getAppName(), () => {
                this.server = this.initHttpServer();
                this.server.setOnCloseHandler(() => {
                    LogIt.Info("Server thread has been terminated.");
                    this.Exit();
                });
                this.server.Start();
            });
        }
        else if (this.appArgs.StopServer()) {
            processed = true;
            if (!ObjectValidator.IsEmptyOrNull(this.server)) {
                this.server.Stop();
            }
        }
        return processed;
    }
    onCloseHandler($done) {
        if (!ObjectValidator.IsEmptyOrNull(this.server)) {
            this.server.Stop();
        }
        $done();
    }
    getHttpServer() {
        return this.server;
    }
    getAppEnvironmentPath() {
        return this.appArgs.ProjectBase();
    }
    getRequestPatterns() {
        let patterns = [
            process.cwd() + "/*",
            this.getCwd() + "/*",
            this.getProgramArgs().AppDataPath() + "/*",
            this.getProgramArgs().TargetBase() + "/*",
            this.getProgramArgs().BinBase() + "/*"
        ];
        const targetRequestPatterns = this.getAppConfiguration().target.requestPatterns;
        if (!ObjectValidator.IsEmptyOrNull(targetRequestPatterns)) {
            patterns = patterns.concat(targetRequestPatterns);
        }
        if (EnvironmentHelper.IsWindows()) {
            const output = [];
            patterns.forEach(($pattern) => {
                if (StringUtils.Contains($pattern, ":/")) {
                    $pattern = StringUtils.ToUpperCase($pattern[0]) + StringUtils.Substring($pattern, 1);
                }
                output.push($pattern);
            });
            patterns = output;
        }
        this.getRequestPatterns = () => {
            return patterns;
        };
        return patterns;
    }
    printLogo() {
        // https://patorjk.com/software/taag/#p=display&f=Doh&t=Oidis
        return "" +
            "                                                                             \n" +
            "                                          dddddddd                           \n" +
            "        OOOOOOOOO       iiii              d::::::d  iiii                     \n" +
            "      OO:::::::::OO    i::::i             d::::::d i::::i                    \n" +
            "    OO:::::::::::::OO   iiii              d::::::d  iiii                     \n" +
            "   O:::::::OOO:::::::O                    d:::::d                            \n" +
            "   O::::::O   O::::::Oiiiiiii     ddddddddd:::::d iiiiiii     ssssssssss     \n" +
            "   O:::::O     O:::::Oi:::::i   dd::::::::::::::d i:::::i   ss::::::::::s    \n" +
            "   O:::::O     O:::::O i::::i  d::::::::::::::::d  i::::i ss:::::::::::::s   \n" +
            "   O:::::O     O:::::O i::::i d:::::::ddddd:::::d  i::::i s::::::ssss:::::s  \n" +
            "   O:::::O     O:::::O i::::i d::::::d    d:::::d  i::::i  s:::::s  ssssss   \n" +
            "   O:::::O     O:::::O i::::i d:::::d     d:::::d  i::::i    s::::::s        \n" +
            "   O:::::O     O:::::O i::::i d:::::d     d:::::d  i::::i       s::::::s     \n" +
            "   O::::::O   O::::::O i::::i d:::::d     d:::::d  i::::i ssssss   s:::::s   \n" +
            "   O:::::::OOO:::::::Oi::::::id::::::ddddd::::::ddi::::::is:::::ssss::::::s  \n" +
            "    OO:::::::::::::OO i::::::i d:::::::::::::::::di::::::is::::::::::::::s   \n" +
            "      OO:::::::::OO   i::::::i  d:::::::::ddd::::di::::::i s:::::::::::ss    \n" +
            "        OOOOOOOOO     iiiiiiii   ddddddddd   dddddiiiiiiii  sssssssssss      \n" +
            "                                                                             \n" +
            `${this.getEnvironmentArgs().getAppName()} version: ${this.getEnvironmentArgs().getProjectVersion()}, build: ${this.getEnvironmentArgs().getBuildTime()}\n` +
            "                                                                             \n";
    }
    getCwd() {
        let cwd = EnvironmentHelper.getNodejsRoot();
        if (StringUtils.Contains(cwd, "/dependencies/nodejs")) {
            cwd = StringUtils.Replace(cwd, "/dependencies/nodejs", "/build/target");
        }
        this.getCwd = () => {
            return cwd;
        };
        return cwd;
    }
    initDOM() {
        const os = require("os");
        const fs = require("fs");
        const LocalStorage = require("node-localstorage").LocalStorage;
        globalThis.WebSocket = WebSocket;
        const { JSDOM, ResourceLoader, VirtualConsole } = require("jsdom");
        let localStoragePath;
        const cwd = this.getCwd();
        if (StringUtils.Contains(cwd, "/build/target")) {
            localStoragePath = cwd;
        }
        else {
            localStoragePath = this.getFileSystemHandler().getTempPath() + "/" +
                this.getEnvironmentArgs().getProjectName();
        }
        localStoragePath += "/localStorage";
        if (!fs.existsSync(localStoragePath)) {
            fs.mkdirSync(localStoragePath, { recursive: true });
        }
        const localStorageInstance = new LocalStorage(localStoragePath);
        this.patchResourceLoader(ResourceLoader);
        const virtualConsole = new VirtualConsole();
        virtualConsole.on("jsdomError", ($error) => {
            if (!StringUtils.ContainsIgnoreCase($error.message, "Could not load")) {
                LogIt.Warning($error.stack);
            }
        });
        let strictSSL = true;
        if (process.env.hasOwnProperty("DISABLE_STRICT_SSL") || Loader.getInstance().getAppConfiguration().disableStrictSSL) {
            strictSSL = false;
        }
        const dom = new JSDOM("", {
            url: "http://" + this.getHttpManager().getRequest().getServerIP() + "/?" +
                "AppName=" + ObjectEncoder.Url(this.getEnvironmentArgs().getAppName()) + "&" +
                "AppPid=" + process.pid + "&" +
                "Platform=" + this.getEnvironmentArgs().getPlatform() + "&" +
                "ReleaseName=" + this.getEnvironmentArgs().getReleaseName(),
            contentType: "text/html",
            userAgent: "Node.js/" + process.version + " (" + os.platform() + "; rv: " + process.version + ") " +
                "Chrome/52.0.2743.116",
            includeNodeLocations: true,
            resources: new ResourceLoader({
                strictSSL
            }),
            runScripts: "dangerously",
            virtualConsole
        });
        this.getEnvironmentArgs().getNamespaces().forEach(($namespace) => {
            const parts = StringUtils.Split($namespace, ".");
            if (parts.length >= 1 && global.hasOwnProperty(parts[0])) {
                dom.window[parts[0]] = global[parts[0]];
            }
        });
        dom.window.scrollTo = () => {
            // default handler
        };
        for (let i = 0; i < localStorageInstance.length; i++) {
            const key = localStorageInstance.key(i);
            dom.window.localStorage.setItem(key, localStorageInstance.getItem(key));
        }
        dom.window.JsonpData = globalThis.JsonpData;
        dom.window.WebSocket = WebSocket;
        window.location = {
            __href: ""
        };
        Object.defineProperty(window.location, "href", {
            get() {
                return this.__href;
            },
            set($value) {
                this.__href = $value;
                const parsedUrl = new URL($value);
                let property;
                for (property in parsedUrl) {
                    if (parsedUrl.hasOwnProperty(property) && property !== "href") {
                        this[property] = parsedUrl[property];
                    }
                }
            }
        });
        let domProperty;
        for (domProperty in dom.window) {
            if (domProperty !== "location") {
                window[domProperty] = dom.window[domProperty];
            }
        }
        for (domProperty in dom.window.location) {
            if (dom.window.location.hasOwnProperty(domProperty) && domProperty !== "href") {
                window.location[domProperty] = dom.window.location[domProperty];
            }
        }
        globalThis.localStorage = new LocalStorage(localStoragePath);
        for (let i = 0; i < localStorageInstance.length; i++) {
            const key = localStorageInstance.key(i);
            globalThis.localStorage.setItem(key, localStorageInstance.getItem(key));
        }
        globalThis.NodeList = dom.window.NodeList;
        document = window.document;
        global.window = window;
        global.document = document;
        Object.keys(global.window).forEach(($property) => {
            if (typeof global[$property] === "undefined") {
                global[$property] = global.window[$property];
                globalThis[$property] = global[$property];
            }
        });
        const element = document.createElement("span");
        element.id = "Content";
        document.body.appendChild(element);
        dom.reconfigure({ url: "file://" + (EnvironmentHelper.IsWindows() ? "/" : "") + this.getCwd() + "/" });
        return dom;
    }
    async processIntegrityCheck() {
        let junitContent = "";
        const escapeXmlData = ($value) => {
            $value = StringUtils.Replace($value, this.getProgramArgs().AppDataPath(), "");
            $value = StringUtils.Replace($value, "&", "&amp;");
            $value = StringUtils.Replace($value, "'", "&apos;");
            $value = StringUtils.Replace($value, "<", "&lt;");
            $value = StringUtils.Replace($value, ">", "&gt;");
            $value = StringUtils.Replace($value, "\"", "&quot;");
            return $value;
        };
        const casePass = ($suite, $name) => {
            junitContent += `
    <testcase classname="${$suite}" name="${$name}"/>`;
        };
        const caseSkip = ($suite, $name) => {
            junitContent += `
    <testcase classname="${$suite}" name="${$name}">
        <skipped />
    </testcase>`;
        };
        const caseFail = ($suite, $name, $error) => {
            junitContent += `
    <testcase classname="${$suite}" name="${$name}">
        <failure message="${escapeXmlData($error.message)}" type="failure">
            ${escapeXmlData($error.stack)}
        </failure>
    </testcase>`;
        };
        if (!Loader.getInstance().getFileSystemHandler()
            .Exists(Loader.getInstance().getProgramArgs().BinBase() + "/resource/metadata.json")) {
            throw new Error("Metadata file not found.");
        }
        else {
            LogIt.Debug("integrity metadata: " + Loader.getInstance().getFileSystemHandler()
                .Read(Loader.getInstance().getProgramArgs().BinBase() + "/resource/metadata.json").toString());
        }
        if (!ObjectValidator.IsEmptyOrNull(window.oidisIntegrityCheckSteps)) {
            let issueCounter = 0;
            let casesTotal = 0;
            let timeoutId = null;
            const steps = [];
            // expect that last method in chain will be lastly generated by decorator, this is not bullet-proof but should be OK
            window.oidisIntegrityCheckSteps.map(($function) => $function()).forEach(($item) => {
                const index = steps.findIndex(($element) => $element.name === $item.name);
                if (index === -1) {
                    steps.push($item);
                }
                else {
                    steps[index].method = $item.method;
                }
            });
            const processCheck = async () => {
                for await (const step of steps) {
                    try {
                        LogIt.Info(step.name + "...");
                        const report = await Promise.race([
                            step.method(),
                            new Promise(($resolve, $reject) => {
                                timeoutId = setTimeout(() => {
                                    $reject(new Error("Integrity check timeout limit expired."));
                                }, 60000); // TODO(mkelnar) apply configurable timeout per step here
                            })
                        ]);
                        if (!ObjectValidator.IsEmptyOrNull(timeoutId)) {
                            clearTimeout(timeoutId);
                        }
                        LogIt.Info(step.name + " succeed\n");
                        if (!ObjectValidator.IsEmptyOrNull(report)) {
                            report.cases.forEach(($item) => {
                                casesTotal++;
                                if (!ObjectValidator.IsEmptyOrNull($item.error)) {
                                    issueCounter++;
                                    caseFail(report.name, $item.name, $item.error);
                                }
                                else if (!ObjectValidator.IsEmptyOrNull($item.skipped) && $item.skipped) {
                                    caseSkip(report.name, $item.name);
                                }
                                else {
                                    casePass(report.name, $item.name);
                                }
                            });
                        }
                        else {
                            casesTotal++;
                            casePass(step.name, step.name);
                        }
                    }
                    catch ($e) {
                        casesTotal++;
                        issueCounter++;
                        casePass(step.name, step.name, $e);
                        LogIt.Warning(step.name + " failed: " + $e.message);
                    }
                }
            };
            await Promise.race([
                processCheck(),
                new Promise(($resolve, $reject) => {
                    timeoutId = setTimeout(() => {
                        $reject(new Error("Integrity checks timeout limit expired. At least one check step takes too long."));
                    }, 65000); // TODO(mkelnar) apply configurable timeout for whole check here
                })
            ]);
            if (!ObjectValidator.IsEmptyOrNull(timeoutId)) {
                clearTimeout(timeoutId);
            }
            const junitData = `<?xml version="1.0" encoding="UTF-8"?>
<testsuites name="Integrity tests" tests="${casesTotal}" failures="${issueCounter}" errors="${issueCounter}">${junitContent}
</testsuites>`;
            this.fileSystem.Write("integrityCheck.xml", junitData);
            if (issueCounter > 0 && !!process.env.OIDIS_CI_RUN) {
                throw Error("Integrity checks (" + issueCounter + ") failed.");
            }
        }
    }
    patchResourceLoader($original) {
        const fs = require("fs");
        const path = require("path");
        const os = require("os");
        const origResourceFetch = $original.prototype.fetch;
        const instance = this; // eslint-disable-line @typescript-eslint/no-this-alias
        let patterns = null;
        let lastUrl = "";
        $original.prototype._fetch = origResourceFetch;
        $original.prototype.fetch = function ($url, $options) {
            try {
                let isRemote = false;
                if (!StringUtils.Contains($url, "http://", "https://")) {
                    if (EnvironmentHelper.IsWindows()) {
                        $url = StringUtils.Remove($url, "file:///");
                        if (StringUtils.Contains($url, ":/")) {
                            $url = StringUtils.ToUpperCase($url[0]) + StringUtils.Substring($url, 1);
                        }
                    }
                    $url = StringUtils.Remove($url, "file://");
                    if (StringUtils.Contains($url, "?")) {
                        $url = StringUtils.Substring($url, 0, StringUtils.IndexOf($url, "?"));
                    }
                    $url = path.resolve($url);
                    $url = StringUtils.Replace($url, "\\", "/");
                    const shapshotKey = "/snapshot/";
                    if (StringUtils.Contains($url, shapshotKey) && !StringUtils.StartsWith($url, shapshotKey)) {
                        $url = StringUtils.Substring($url, StringUtils.IndexOf($url, shapshotKey));
                    }
                    let error;
                    if (!fs.existsSync($url)) {
                        if (lastUrl !== $url) {
                            LogIt.Debug("Resource has not been found at: {0} with cwd: {1}", $url, process.cwd());
                            lastUrl = $url;
                        }
                        error = new Error("Resource has not been found at: " + $url);
                    }
                    else {
                        let accessAllowed = false;
                        if (patterns === null) {
                            patterns = instance.getRequestPatterns();
                        }
                        patterns.forEach(($pattern) => {
                            if (StringUtils.PatternMatched($pattern, $url)) {
                                accessAllowed = true;
                            }
                        });
                        if (!accessAllowed) {
                            if (lastUrl !== $url) {
                                LogIt.Debug("Access denied for resource at: {0} not in match with: {1}", $url, JSON.stringify(patterns));
                                lastUrl = $url;
                            }
                            error = new Error("Access denied for resource at: " + $url);
                        }
                    }
                    if (!ObjectValidator.IsEmptyOrNull(error)) {
                        return new Promise(($resolve, $reject) => {
                            $reject(error);
                        });
                    }
                    if (!StringUtils.StartsWith($url, "file://")) {
                        $url = "file:///" + $url;
                    }
                }
                else {
                    isRemote = true;
                }
                if (StringUtils.Contains($url, ".js")) {
                    return new Promise(($resolve, $reject) => {
                        const process = ($data) => {
                            try {
                                const vm = new VMHandler();
                                vm.Path($url);
                                vm.Data($data);
                                vm.Load();
                                vm.ErrorHandler(($ex) => {
                                    LogIt.Debug("Failed to execute resource from: {0}", $url + os.EOL + $ex.stack);
                                    $reject($ex);
                                });
                                $resolve(Buffer.from(""));
                            }
                            catch (ex) {
                                LogIt.Debug("Failed to process VM for resource from: {0}", $url + os.EOL + ex.stack);
                                $reject(ex);
                            }
                        };
                        const headers = {};
                        if (isRemote &&
                            StringUtils.StartsWith($url, "https://") &&
                            !StringUtils.StartsWith($options.referrer, "https://")) {
                            JsonUtils.Extend(headers, {
                                referrer: "https://localhost.oidis.io"
                            });
                        }
                        if (isRemote) {
                            const responseHandler = new CallbackResponse(($headers, $body) => {
                                process($body);
                            });
                            responseHandler.OnError = () => {
                                LogIt.Debug("Failed to load resource from: {0}", $url);
                                $reject(new Error("Failed to load resource from: " + $url));
                            };
                            Loader.getInstance().getFileSystemHandler().Download({
                                headers,
                                streamOutput: true,
                                streamReturnsBuffer: true,
                                url: $url,
                                verbose: false
                            }, responseHandler);
                        }
                        else {
                            JsonUtils.Extend($options, headers);
                            origResourceFetch
                                .apply(this, [$url, $options])
                                .then(($data) => {
                                process($data);
                            })
                                .catch(() => {
                                LogIt.Debug("Failed to load resource from: {0}", $url);
                                $reject(new Error("Failed to load resource from: " + $url));
                            });
                        }
                    });
                }
                else if (isRemote &&
                    StringUtils.ToLowerCase($options.element.nodeName) === "script" &&
                    $options.element.scriptType === "ScriptHandler") {
                    return origResourceFetch.apply(this, [$url, $options]);
                }
                else {
                    return new Promise(($resolve, $reject) => {
                        $reject(null);
                    });
                }
            }
            catch (ex) {
                LogIt.Debug("Failed request for resource from: {0}", $url + os.EOL + ex.message);
                return new Promise(($resolve, $reject) => {
                    $reject(ex);
                });
            }
        };
    }
    initLogIt() {
        this.logger.setProjectBase(this.getCwd());
        this.logger.setAppDataPath(this.getAppConfiguration().target.appDataPath);
        this.logger.getAdapter(LogAdapterType.FILE).setProjectBase(this.getCwd());
        this.logger.getAdapter(LogAdapterType.JSON).setProjectBase(this.getCwd());
        this.logger.setConfig(this.getAppConfiguration().logger);
        LogIt.Init(this.logger);
        const echoLogger = new StdAdapter(false);
        echoLogger.Enabled(this.logger.getAdapter(LogAdapterType.STD).Enabled());
        Echo.Init(IOHandlerFactory.getHandler(IOHandlerType.CONSOLE), true);
        Echo.output.Print = ($message) => {
            echoLogger.Process({
                entryPoint: null,
                level: LogLevel.INFO,
                message: $message,
                severity: LogSeverity.HIGH,
                time: new Date().getTime(),
                trace: null
            });
        };
        Echo.output.save = ($message) => {
            Echo.Init();
            Echo.output.Print($message);
        };
        Echo.Println = ($message) => {
            Echo.Print($message + echoLogger.NewLineType());
        };
    }
}
__decorate([
    IntegrityCheck(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], Loader, "npmModules", null);
__decorate([
    IntegrityCheck(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], Loader, "npmNativeModules", null);
// generated-code-start
export const IIntegrityReport = globalThis.RegisterInterface(["name", "cases"]);
export const IIntegrityCase = globalThis.RegisterInterface(["name", "error", "skipped"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Loader", Loader);
globalThis.RegisterClass("Io.Oidis.Localhost.IIntegrityReport", IIntegrityReport);
globalThis.RegisterClass("Io.Oidis.Localhost.IIntegrityCase", IIntegrityCase);
//# sourceMappingURL=Loader.js.map