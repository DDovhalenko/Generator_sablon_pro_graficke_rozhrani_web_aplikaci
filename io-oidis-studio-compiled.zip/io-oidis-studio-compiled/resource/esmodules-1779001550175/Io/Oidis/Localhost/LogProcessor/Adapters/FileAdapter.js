/*! ******************************************************************************************************** *
 *
 * Copyright 2021-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { LogLevel } from "./../../../../../Io/Oidis/Commons/Enums/LogLevel.js";
import { BaseAdapter } from "./../../../../../Io/Oidis/Commons/LogProcessor/Adapters/BaseAdapter.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { isMainThread } from "../../Utils/EnvironmentHelper.js";
export class FileAdapter extends BaseAdapter {
    os;
    fs;
    colors;
    logsBackup;
    logPath;
    logFile;
    projectBase;
    autoPath;
    constructor() {
        super();
        this.os = require("os");
        this.fs = require("fs");
        this.colors = isMainThread ? require("colors") : {
            stripColors: ($value) => {
                return $value;
            }
        };
        this.logsBackup = "";
        this.autoPath = true;
    }
    /**
     * @param {string} $value Project base directory path.
     */
    setProjectBase($value) {
        this.projectBase = Property.String(this.projectBase, $value);
    }
    /**
     * @param {string} $value Optional explicit log file path to set.
     * @returns {string} Returns the current log file path.
     */
    LogPath($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.autoPath = false;
            this.logPath = Property.String(this.logPath, $value);
            this.logPath = StringUtils.Replace(this.logPath, "\\", "/");
            this.logFile = this.logPath;
            this.logPath = StringUtils.Substring(this.logPath, 0, StringUtils.IndexOf(this.logPath, "/", false) + 1);
        }
        else if (this.autoPath) {
            const date = new Date();
            const year = date.getUTCFullYear() + "";
            const day = date.getUTCDate() < 10 ? "0" + date.getUTCDate() : date.getUTCDate() + "";
            const monthNumber = date.getUTCMonth() + 1;
            const month = monthNumber < 10 ? "0" + monthNumber : monthNumber + "";
            this.logPath = this.projectBase + "/log/" + year + "/" + month;
            this.logPath = StringUtils.Replace(this.logPath, "\\", "/");
            this.logFile = this.logPath + "/" + day + "_" + month + "_" + year + ".txt";
        }
        return this.logFile;
    }
    /**
     * @returns {NewLineType | string} Returns the platform newline string.
     */
    NewLineType() {
        return this.os.EOL;
    }
    /**
     * @param {ILoggerTrace} $trace Log trace entry to process.
     */
    Process($trace) {
        if (!this.fs.existsSync(this.LogPath())) {
            this.fs.mkdirSync(this.logPath, { recursive: true });
        }
        super.Process($trace);
    }
    timeToString($value) {
        return new Date($value).toUTCString();
    }
    traceBackToString($traceback) {
        return $traceback.at + " from " + $traceback.from;
    }
    getHandler() {
        return this.fs;
    }
    formatter($trace) {
        $trace.message = StringUtils.Format(this.verbose ? "[{0}][{1}] {3} -- {2}" : "[{0}][{1}] {3}", $trace.time, LogLevel[$trace.level], $trace.entryPoint, this.colors.stripColors($trace.message));
        return $trace;
    }
    print($trace, $handler) {
        const data = this.logsBackup + $trace.message + this.NewLineType();
        try {
            $handler.appendFileSync(this.LogPath(), data);
            this.logsBackup = "";
        }
        catch (ex) {
            console.error(ex); // eslint-disable-line no-console
            this.logsBackup += data;
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.LogProcessor.Adapters.FileAdapter", FileAdapter);
//# sourceMappingURL=FileAdapter.js.map