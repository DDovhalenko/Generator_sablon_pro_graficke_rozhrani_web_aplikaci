/*! ******************************************************************************************************** *
 *
 * Copyright 2021-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { LogLevel } from "./../../../../../Io/Oidis/Commons/Enums/LogLevel.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { TraceBack } from "./../../../../../Io/Oidis/Commons/Utils/TraceBack.js";
import { FileAdapter } from "./FileAdapter.js";
export class JsonAdapter extends FileAdapter {
    traces;
    withMeta;
    metaPrinted;
    constructor() {
        super();
        this.traces = [];
        this.withMeta = false;
        this.metaPrinted = false;
    }
    /**
     * @param {string} $value Optional explicit log file path to set.
     * @returns {string} Returns the current log file path with .json extension.
     */
    LogPath($value) {
        if (ObjectValidator.IsEmptyOrNull($value)) {
            return StringUtils.Replace(super.LogPath(), ".txt", ".json");
        }
        else {
            this.metaPrinted = false;
        }
        return super.LogPath($value);
    }
    /**
     * @param {boolean} $value Optional flag to enable or disable metadata output.
     * @returns {boolean} Returns the current metadata inclusion flag.
     */
    IncludeMetadata($value) {
        return this.withMeta = Property.Boolean(this.withMeta, $value);
    }
    traceBackToString($traceback) {
        return $traceback;
    }
    formatter($trace) {
        if ($trace.level === LogLevel.ERROR) {
            $trace.trace = TraceBack.Parse({ stack: $trace.message });
            $trace.message = $trace.message.split("\n")[0];
        }
        else if (!this.verbose) {
            delete $trace.trace;
        }
        if (!this.verbose) {
            delete $trace.entryPoint;
        }
        return $trace;
    }
    getOwner() {
        return super.getOwner();
    }
    print($trace, $handler) {
        this.traces.push($trace);
        $handler.writeFileSync(this.LogPath(), JSON.stringify(this.traces));
        if ((this.withMeta || this.debug) && !this.metaPrinted) {
            $handler.writeFileSync(this.LogPath() + ".dat", JSON.stringify(this.getOwner().getAnonymizerSymbols()));
            this.metaPrinted = true;
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.LogProcessor.Adapters.JsonAdapter", JsonAdapter);
//# sourceMappingURL=JsonAdapter.js.map