/*! ******************************************************************************************************** *
 *
 * Copyright 2021-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { LogLevel } from "./../../../../../Io/Oidis/Commons/Enums/LogLevel.js";
import { BaseAdapter } from "./../../../../../Io/Oidis/Commons/LogProcessor/Adapters/BaseAdapter.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { ColorType } from "../../Enums/ColorType.js";
import { EnvironmentHelper } from "../../Utils/EnvironmentHelper.js";
export class StdAdapter extends BaseAdapter {
    os;
    printNewLine;
    symbols;
    constructor($withNewLine = true) {
        super();
        this.os = require("os");
        this.printNewLine = $withNewLine;
        if (!EnvironmentHelper.IsTTY()) {
            this.symbols = {
                ARROW: ">",
                BAR: "=",
                FAIL: "x",
                OK: "+"
            };
        }
        else {
            this.symbols = {
                ARROW: "→",
                BAR: EnvironmentHelper.IsWindows() ? "█" : "▇",
                FAIL: "×",
                OK: "✓"
            };
        }
    }
    /**
     * @returns {NewLineType | string} Returns the platform newline string.
     */
    NewLineType() {
        return this.os.EOL;
    }
    formatter($trace) {
        $trace.message = StringUtils.Replace($trace.message, "[__BAR__]", this.symbols.BAR);
        $trace.message = StringUtils.Replace($trace.message, "[__FAIL__]", this.symbols.FAIL);
        $trace.message = StringUtils.Replace($trace.message, "[__OK__]", this.symbols.OK);
        $trace.message = StringUtils.Replace($trace.message, "[__ARROW__]", this.symbols.ARROW);
        if (this.printNewLine) {
            $trace.message += this.NewLineType();
        }
        if (EnvironmentHelper.IsTTY()) {
            if ($trace.level === LogLevel.ERROR) {
                $trace.message = $trace.message[ColorType.RED];
            }
            else if ($trace.level === LogLevel.WARNING) {
                $trace.message = $trace.message[ColorType.YELLOW];
            }
        }
        return super.formatter($trace);
    }
    getHandler() {
        const handler = EnvironmentHelper.IsDetached() ? console : process.stdout.write.bind(process.stdout);
        this.getHandler = () => {
            return handler;
        };
        return handler;
    }
    print($trace) {
        try {
            ($trace.level === LogLevel.ERROR ? this.stderr() : this.stdout())($trace.message);
        }
        catch (ex) {
            if ($trace.level === LogLevel.ERROR) {
                console.error($trace.message); // eslint-disable-line no-console
            }
            else {
                console.log($trace.message); // eslint-disable-line no-console
            }
        }
    }
    stdout() {
        const handler = EnvironmentHelper.IsDetached() ? this.getHandler().log.bind(console) : this.getHandler();
        this.stdout = () => {
            return handler;
        };
        return handler;
    }
    stderr() {
        const handler = EnvironmentHelper.IsDetached() ? this.getHandler().error.bind(console) : this.getHandler();
        this.stderr = () => {
            return handler;
        };
        return handler;
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.LogProcessor.Adapters.StdAdapter", StdAdapter);
//# sourceMappingURL=StdAdapter.js.map