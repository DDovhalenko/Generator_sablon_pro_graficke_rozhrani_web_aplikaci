import { SentryAdapter } from "./../../../../Io/Oidis/Commons/LogProcessor/Adapters/SentryAdapter.js";
import { Logger as Parent } from "./../../../../Io/Oidis/Commons/LogProcessor/Logger.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { LogAdapterType } from "../Enums/LogAdapterType.js";
import { EnvironmentHelper } from "../Utils/EnvironmentHelper.js";
import { FileAdapter } from "./Adapters/FileAdapter.js";
import { JsonAdapter } from "./Adapters/JsonAdapter.js";
import { StdAdapter } from "./Adapters/StdAdapter.js";
export class Logger extends Parent {
    projectBase;
    appDataPath;
    anonymizerSymbols;
    /**
     * @param {string} $value Project base directory path.
     */
    setProjectBase($value) {
        this.projectBase = $value;
    }
    /**
     * @param {string} $value Application data directory path.
     */
    setAppDataPath($value) {
        this.appDataPath = $value;
    }
    /**
     * @param {boolean} $force Forces rebuilding the symbol map.
     * @returns {any} Returns the anonymizer symbols map.
     */
    getAnonymizerSymbols($force = false) {
        if (ObjectValidator.IsEmptyOrNull(this.anonymizerSymbols) || $force) {
            let anonymizeMap;
            let keyFormat;
            if (EnvironmentHelper.IsWindows()) {
                keyFormat = "%{0}%";
                anonymizeMap = [
                    "TMP", "USERPROFILE", "HOMEPATH", "USERDOMAIN", "COMPUTERNAME", "USERNAME"
                ];
            }
            else {
                keyFormat = "${0}";
                anonymizeMap = [
                    "HOME", "HOSTNAME", "LOGNAME", "USER"
                ];
            }
            const binBase = StringUtils.Replace(require("path").normalize(__dirname + "/../.."), "\\", "/");
            const winProjectBase = StringUtils.Replace(this.projectBase, "/", "\\");
            const anonymizeValues = {
                BINBASE: StringUtils.Replace(binBase, "/", "\\"),
                PROJECTBASE: winProjectBase,
                SOURCEBASE: StringUtils.Remove(winProjectBase, "\\build\\target"),
                appData: this.appDataPath,
                binBase,
                projectBase: this.projectBase,
                sourceBase: StringUtils.Remove(this.projectBase, "/build/target")
            };
            anonymizeMap.forEach(($key) => {
                if (process.env.hasOwnProperty($key)) {
                    anonymizeValues[$key] = process.env[$key];
                    anonymizeMap.forEach(($key) => {
                        if (process.env.hasOwnProperty($key)) {
                            anonymizeValues[$key] = process.env[$key];
                            if (StringUtils.Contains(anonymizeValues[$key], "\\")) {
                                anonymizeValues[StringUtils.ToLowerCase($key)] =
                                    StringUtils.Replace(anonymizeValues[$key], "\\", "/");
                            }
                        }
                    });
                }
            });
            this.anonymizerSymbols = {
                format: keyFormat,
                values: anonymizeValues
            };
        }
        return this.anonymizerSymbols;
    }
    /**
     * @param {LogAdapterType} $type Adapter type to retrieve.
     * @returns {BaseAdapter} Returns the adapter instance or null if type is unknown.
     */
    getAdapter($type) {
        const name = "adapter" + $type;
        switch ($type) {
            case LogAdapterType.STD:
                if (ObjectValidator.IsEmptyOrNull(this[name])) {
                    this[name] = new StdAdapter();
                }
                return this[name];
            case LogAdapterType.FILE:
                if (ObjectValidator.IsEmptyOrNull(this[name])) {
                    this[name] = new FileAdapter();
                }
                return this[name];
            case LogAdapterType.JSON:
                if (ObjectValidator.IsEmptyOrNull(this[name])) {
                    this[name] = new JsonAdapter();
                }
                return this[name];
            case LogAdapterType.SENTRY:
                if (ObjectValidator.IsEmptyOrNull(this[name])) {
                    this[name] = new SentryAdapter();
                }
                return this[name];
            default:
                return null;
        }
    }
    buildInAdapters() {
        return [LogAdapterType.STD, LogAdapterType.FILE, LogAdapterType.JSON, LogAdapterType.SENTRY];
    }
    defaultAdapters() {
        return [LogAdapterType.STD, LogAdapterType.FILE, LogAdapterType.SENTRY];
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.LogProcessor.Logger", Logger);
//# sourceMappingURL=Logger.js.map