/*! ******************************************************************************************************** *
 *
 * Copyright 2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { DataFormatType } from "./../../../../Io/Oidis/Commons/Enums/DataFormatType.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { ResponseFactory } from "../HttpProcessor/ResponseApi/ResponseFactory.js";
export class BaseConnector extends BaseObject {
    isExternCall;
    isInvocable;
    /**
     * @returns {TConnector} Returns the singleton connector instance.
     */
    static getInstance() {
        const singleton = "__Singleton." + this.ClassName();
        if (this.hasOwnProperty(singleton)) {
            return this[singleton];
        }
        return this[singleton] = (new this());
    }
    static currentToken() {
        // this is placeholder for token from LCP by which the @Extern method has been invoked
        return "";
    }
    static pipe($callback) {
        const instance = this.getInstance();
        const wrapper = {};
        instance.getMethods().forEach(($method) => {
            wrapper[$method] = (...$args) => {
                // eslint-disable-next-line prefer-spread
                ResponseFactory.getResponse($callback).Send(instance[$method].apply(instance, $args));
            };
        });
        return wrapper;
    }
    constructor() {
        super();
        this.isInvocable = true;
        this.isExternCall = false;
    }
    /**
     * @param {boolean} $value Optional value to set invocable state.
     * @returns {boolean} Returns current invocable state.
     */
    ExternInvokeEnabled($value) {
        return this.isInvocable = Property.Boolean(this.isInvocable, $value);
    }
    /**
     * @returns {Promise<void>} Returns a promise that resolves when destruction is complete.
     */
    async Destroy() {
        LogIt.Debug("Removing instance of " + this.getClassName() + " for token: " + this.getCurrentToken());
        const singleton = "__Singleton." + this.getClassName();
        if (this.hasOwnProperty(singleton)) {
            delete this[singleton];
        }
        await this.terminate();
    }
    getCurrentToken() {
        // this is placeholder for token from LCP by which the @Extern method has been invoked
        return "";
    }
    getProtocolVersion() {
        // this is placeholder for LCP version by which the @Extern method has been invoked
        return "";
    }
    getProtocolFormat() {
        return DataFormatType.UTF8;
    }
    async terminate() {
        // override this if some routine should be executed before connector will be removed from register
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.Primitives.BaseConnector", BaseConnector);
//# sourceMappingURL=BaseConnector.js.map