import { HttpMethodType } from "./../../../../Io/Oidis/Commons/Enums/HttpMethodType.js";
import { Convert } from "./../../../../Io/Oidis/Commons/Utils/Convert.js";
import { JsonUtils } from "./../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { LiveContentArgumentType } from "./../../../../Io/Oidis/Services/Enums/LiveContentArgumentType.js";
import { BaseResponseFormatter } from "../HttpProcessor/ResponseApi/Formatters/BaseResponseFormatter.js";
import { ToJSONRouteFormatter } from "../HttpProcessor/ResponseApi/Formatters/ToJSONRouteFormatter.js";
import { ResponseFactory } from "../HttpProcessor/ResponseApi/ResponseFactory.js";
import { ExternResponseType } from "../Interfaces/IExternOptions.js";
import { BaseRouteArgument } from "../Interfaces/IRoute.js";
export function Extern($options) {
    const options = {
        outputFormatter: new BaseResponseFormatter(),
        responseHandler: null,
        responseType: ExternResponseType.DEFAULT
    };
    if (ObjectValidator.IsBoolean($options) && !$options) {
        options.responseType = ExternResponseType.FULL_CONTROL;
    }
    else if (ObjectValidator.IsInteger($options)) {
        options.responseType = $options;
    }
    else {
        JsonUtils.Extend(options, $options);
    }
    return function ($target, $propertyKey, $descriptor) {
        $target[$propertyKey + "_Extern"] = function (...$args) {
            return {
                auth: Convert.ToType(this) + "." + $propertyKey,
                resolve($token, $version, $format) {
                    resolveResponse(this, {
                        args: $args, descriptor: $descriptor, noVoidSymbol: false, propertyKey: $propertyKey, target: this
                    }, {
                        format: $format, options, token: $token, version: $version
                    });
                }
            };
        };
    };
}
/**
 * @param {IIntegrityCheckOption} $options Specify integrity check test options.
 * @returns {Function} Returns decorator which enables to generate interface expected by integrity test processor.
 */
export function IntegrityCheck($options) {
    return function ($target, $propertyKey, $descriptor) {
        $target[$propertyKey + "_IntegrityCheck"] = () => {
            let name = $target.ClassName() + "." + $propertyKey;
            if (!ObjectValidator.IsEmptyOrNull($options) && !ObjectValidator.IsEmptyOrNull($options.name)) {
                name = $options.name;
            }
            return {
                method: async () => {
                    return $descriptor.value.apply(this, []);
                },
                name
            };
        };
        if (!window.hasOwnProperty("oidisIntegrityCheckSteps")) {
            window.oidisIntegrityCheckSteps = [];
        }
        window.oidisIntegrityCheckSteps.push($target[$propertyKey + "_IntegrityCheck"]);
    };
}
/**
 * @param {string} $path Route path definition including optional HTTP method and query parameters.
 * @param {IRouteOptions} $options Optional route configuration options.
 * @returns {Function} Returns decorator which registers the method as an HTTP route handler.
 */
export function Route($path, $options) {
    return function ($target, $propertyKey, $descriptor) {
        let pathRoute = StringUtils.Split($path, "#", "?")[0];
        let pathRequest = $path;
        let method = HttpMethodType.GET;
        if (pathRoute.includes(" ")) {
            const subs = pathRoute.split(" ");
            if (subs.length !== 2) {
                throw new Error("Invalid syntax for @Route definition string: " + pathRoute + ". " +
                    "Only <method> /<path>?<key>=<type>(value) with optional parts method|key|type|value is allowed.");
            }
            method = HttpMethodType[subs[0].toUpperCase()];
            const types = Object.keys(HttpMethodType);
            if (ObjectValidator.IsEmptyOrNull(method) || !types.includes(method)) {
                throw new Error("Unsupported HTTP method defined in route: \"" + pathRoute + "\". Only " +
                    types.sort().join("|") + " are supported by HTTP standard.");
            }
            pathRoute = subs[1];
            pathRequest = $path.substring(subs[0].length + 1);
        }
        const key = $propertyKey + "_" + pathRoute + "_Route";
        $target[key] = () => {
            if (ObjectValidator.IsEmptyOrNull($options)) {
                $options = {};
            }
            if (ObjectValidator.IsEmptyOrNull($options.httpMethod)) {
                $options.httpMethod = method;
            }
            if (ObjectValidator.IsEmptyOrNull($options.args)) {
                $options.args = [];
                const parser = new (require("url").URL)("https://oidis.io" + pathRequest);
                parser.searchParams.forEach(($value, $key) => {
                    $options.args.push(new BaseRouteArgument($key, $value));
                });
            }
            $options.args = $options.args.map(($value) => {
                if (ObjectValidator.IsString($value)) {
                    const items = StringUtils.Split($value, "=");
                    return new BaseRouteArgument(items[0], items[1]);
                }
                else if (Reflection.getInstance().IsInstanceOf($value, BaseRouteArgument)) {
                    return $value;
                }
                return null;
            });
            if (ObjectValidator.IsEmptyOrNull($options.inputFormatter)) {
                if ($options.httpMethod === HttpMethodType.PUT || $options.httpMethod === HttpMethodType.POST) {
                    $options.inputFormatter = new ToJSONRouteFormatter();
                }
                else {
                    $options.inputFormatter = new BaseResponseFormatter();
                }
            }
            if (ObjectValidator.IsEmptyOrNull($options.outputFormatter)) {
                $options.outputFormatter = new BaseResponseFormatter();
            }
            const resolveOptions = {
                outputFormatter: $options.outputFormatter,
                responseHandler: $options.responseHandler,
                responseType: ExternResponseType.DEFAULT
            };
            if (!ObjectValidator.IsEmptyOrNull($options.responseType)) {
                resolveOptions.responseType = $options.responseType;
            }
            return {
                ClassName: () => {
                    if ($target.isPartial && ObjectValidator.IsSet($target.__partialTarget)) {
                        return $target.__partialTarget.getClassName();
                    }
                    if (ObjectValidator.IsSet($target.getClassName)) {
                        return $target.getClassName();
                    }
                    return $target.ClassName();
                },
                method(...$args) {
                    return {
                        auth: Convert.ToType(this) + "." + $propertyKey,
                        resolve($token) {
                            if ($options.args.length > $descriptor.value.length) {
                                throw new Error("Passed more arguments then declared in route schema: " + $path);
                            }
                            // eslint-disable-next-line @typescript-eslint/no-deprecated
                            if (!ObjectValidator.IsEmptyOrNull($options.autoResponse) && !$options.autoResponse) {
                                resolveOptions.responseType = ExternResponseType.FULL_CONTROL;
                                LogIt.Warning("Usage of deprecated option autoResponse for " +
                                    Convert.ToType(this) + "." + $propertyKey +
                                    ", please migrate to responseType. Automatically switching to FULL_CONTROL responseType option now.");
                            }
                            resolveResponse(this, {
                                args: $args, descriptor: $descriptor, noVoidSymbol: true, propertyKey: $propertyKey, target: this
                            }, {
                                options: resolveOptions, token: $token
                            });
                        }
                    };
                },
                methodName() {
                    return this.ClassName() + "." + $propertyKey;
                },
                options: $options,
                route: pathRoute,
                schema: $path
            };
        };
        if (!globalThis.hasOwnProperty("oidisAPIRoutes")) {
            globalThis.oidisAPIRoutes = [];
        }
        globalThis.oidisAPIRoutes.push($target[key]);
    };
}
function resolveResponse($self, $decoratorParams, $invokeParams) {
    if (ObjectValidator.IsSet($self.currentToken)) {
        // replace static method
        $self.currentToken = () => {
            return $invokeParams.token;
        };
    }
    else {
        // replace getter inside instance
        $self.getCurrentToken = () => {
            return $invokeParams.token;
        };
    }
    if (!ObjectValidator.IsEmptyOrNull($invokeParams.version)) {
        $self.getProtocolVersion = () => {
            return $invokeParams.version;
        };
    }
    if (!ObjectValidator.IsEmptyOrNull($invokeParams.format)) {
        $self.getProtocolFormat = () => {
            return $invokeParams.format;
        };
    }
    /// TODO: probably will not work after minification as args will be renamed
    const args = [...$decoratorParams.args];
    if ($invokeParams.options.responseType === ExternResponseType.DEFAULT &&
        $decoratorParams.descriptor.value.length === args.length &&
        StringUtils.ContainsIgnoreCase($decoratorParams.descriptor.value, "$callback", "$handler", "$response")) {
        LogIt.Error("Incorrect definition of IResponse for " +
            Convert.ToType($decoratorParams.target) + "." + $decoratorParams.propertyKey +
            " marked as Extern without FULL_CONTROL option. " +
            "Falling back to FULL_CONTROL response due to detected parameter with name [$callback|$handler|$response].");
        $invokeParams.options.responseType = ExternResponseType.FULL_CONTROL;
    }
    if (!Reflection.getInstance().Implements(args[args.length - 1], "Io.Oidis.Localhost.Interfaces.IResponse")) {
        // this should never happen as IResponse is automatically generated by LiceContentResolver
        LogIt.Error("IResponse parameter is missing for " +
            Convert.ToType($decoratorParams.target) + "." + $decoratorParams.propertyKey +
            ". This method will never respond, but root cause needs to be investigated.");
    }
    let response = ResponseFactory.getResponse(args[args.length - 1]);
    if ($invokeParams.options.responseType === ExternResponseType.IMPLICIT_RETURN ||
        $invokeParams.options.responseType === ExternResponseType.DEFAULT) {
        args.pop();
    }
    const retVal = $decoratorParams.descriptor.value.apply($self, args);
    if (!ObjectValidator.IsEmptyOrNull($invokeParams.options.responseHandler)) {
        response = new (Reflection.getInstance().getClass($invokeParams.options.responseHandler.getClassName()))(response);
    }
    const sendResponse = ($retVal) => {
        $retVal = $invokeParams.options.outputFormatter.format($retVal);
        if ($invokeParams.options.responseType !== ExternResponseType.FULL_CONTROL) {
            if (!ObjectValidator.IsSet($retVal)) {
                $retVal = $decoratorParams.noVoidSymbol ? "" : LiveContentArgumentType.RETURN_VOID;
            }
            else if ($retVal === null) {
                $retVal = null;
            }
            else if (typeof $retVal === "object" && $retVal.constructor.name === "Buffer") {
                $retVal = $retVal.toString();
            }
            else if ($invokeParams.options.responseType === ExternResponseType.RESPONSE_PROTOCOL && typeof $retVal === "object") {
                if (!ObjectValidator.IsSet($retVal.body) ||
                    !ObjectValidator.IsSet($retVal.status)) {
                    LogIt.Error("Method " + Convert.ToType($decoratorParams.target) + "." + $decoratorParams.propertyKey +
                        " requires IResponseProtocol format for return value. Without body or status property can't be guaranteed that " +
                        "response will be sent with expected result.");
                }
            }
            response.Send($retVal);
            $retVal = null;
        }
        else if (ObjectValidator.IsSet($retVal)) {
            LogIt.Error("Method " + Convert.ToType($decoratorParams.target) + "." + $decoratorParams.propertyKey +
                " is not void even that response is in FULL_CONTROL mode. Return value will never be send " +
                "in this use case and must be handle by IResponse manually in method body.");
        }
        else {
            // returned value should be processed by autoResponse or IResponse in method body,
            // however some processing of retVal could be inserted also here in future
        }
    };
    if (retVal instanceof Promise ||
        (!ObjectValidator.IsEmptyOrNull(retVal) && retVal.constructor.name === "Promise")) {
        try {
            retVal.then(($retVal) => {
                sendResponse($retVal);
            }).catch(($error) => {
                response.OnError($error);
            });
        }
        catch (ex) {
            response.OnError(ex);
        }
    }
    else {
        sendResponse(retVal);
    }
}
// generated-code-start
export const IIntegrityCheckOption = globalThis.RegisterInterface(["name"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Primitives.IIntegrityCheckOption", IIntegrityCheckOption);
//# sourceMappingURL=Decorators.js.map