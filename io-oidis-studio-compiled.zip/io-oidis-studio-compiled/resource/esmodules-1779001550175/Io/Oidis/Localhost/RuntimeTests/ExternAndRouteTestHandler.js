var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2023-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { Convert } from "./../../../../Io/Oidis/Commons/Utils/Convert.js";
import { ResponseFactory } from "../HttpProcessor/ResponseApi/ResponseFactory.js";
import { ExternResponseType } from "../Interfaces/IExternOptions.js";
import { IMessage, IResponse } from "../Interfaces/IResponse.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
import { Extern, Route } from "../Primitives/Decorators.js";
export class ExternAndRouteTestHandler extends BaseConnector {
    /**
     * @returns {string} Returns the protocol version string.
     */
    getVersion() {
        return "v" + this.getProtocolVersion();
    }
    /**
     * @returns {string} Returns the test response string.
     */
    SyncValueNoArgs() {
        return "testSyncValueNoArgs";
    }
    /**
     * @param {string} $param The string parameter to include in the response.
     * @returns {string} Returns the test response string.
     */
    SyncValueWithArgs($param) {
        return "testSyncValue:" + $param;
    }
    /**
     * @param {any} $param The JSON parameter to serialize into the response.
     * @returns {string} Returns the test response string.
     */
    SyncValueWithJsonArgs($param) {
        return "testSyncValue:" + JSON.stringify($param);
    }
    /**
     * @param {any} $param The JSON parameter to echo.
     * @returns {any} Returns the parameter unchanged.
     */
    SyncJsonWithJsonArgs($param) {
        return $param;
    }
    /**
     * @param {string} $param The string to encode into a buffer.
     * @returns {Buffer} Returns the buffer containing the parameter bytes.
     */
    SyncBufferWithArgs($param) {
        return Buffer.from($param);
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @param {IResponse} $callback The response callback for streaming events.
     */
    SyncVoidWithIncorrectIResponse($param, $callback) {
        const response = ResponseFactory.getResponse($callback);
        response.OnStart("testSyncIResponse:Start");
        response.OnChange("testSyncIResponse:Message");
        // response.OnComplete("testSyncIResponse:" + $param); // requires assert to object {type, data}
        response.Send("testSyncIResponse:" + $param);
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @param {IMessage} $callback The message callback for progress notifications.
     * @returns {string} Returns the test response string.
     */
    SyncWithProgress($param, $callback) {
        $callback.OnChange("testSyncIResponse:Message");
        return "testSyncIResponse:" + $param;
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @param {IResponse} $callback The response callback used as a progress notifier.
     * @returns {string} Returns the test response string.
     */
    SyncWithIncorrectProgress($param, $callback) {
        // simulate usage of IResponse instead of IMessage
        $callback.OnStart("testSyncIResponse:Start");
        $callback.OnChange("testSyncIResponse:Message");
        $callback.Send("testSyncIResponse:" + $param);
        return "testSyncAutoResponse:" + $param; // should never reach due to previous send
    }
    /**
     * @param {IResponse} $callback The response callback for streaming events.
     */
    SyncWithStartAfterChange($callback) {
        $callback.OnChange("testSyncIResponse:Message1");
        $callback.OnStart("testSyncIResponse:Start");
        $callback.OnChange("testSyncIResponse:Message2");
    }
    /**
     * @param {IResponse} $callback The response callback for streaming events.
     */
    SyncWithStartAfterComplete($callback) {
        $callback.OnChange("testSyncIResponse:Message1");
        $callback.OnComplete("testSyncIResponse:End1");
        $callback.OnStart("testSyncIResponse:Start");
        $callback.OnChange("testSyncIResponse:Message2");
    }
    /**
     * @param {IResponse} $callback The response callback for streaming events.
     */
    SyncWithChangeAfterComplete($callback) {
        $callback.OnStart("testSyncIResponse:Start");
        $callback.OnChange("testSyncIResponse:Message1");
        $callback.OnComplete("testSyncIResponse:End1");
        $callback.OnChange("testSyncIResponse:Message2");
    }
    /**
     * @param {IResponse} $callback The response callback for streaming events.
     */
    SyncWithMultipleStarts($callback) {
        $callback.OnStart("testSyncIResponse:Start");
        $callback.OnStart("testSyncIResponse:Start2");
        $callback.OnChange("testSyncIResponse:Message1");
        $callback.OnChange("testSyncIResponse:Message2");
        $callback.OnComplete("testSyncIResponse:End1");
    }
    /**
     * @param {IResponse} $callback The response callback for streaming events.
     */
    SyncWithMultipleCompletes($callback) {
        $callback.OnChange("testSyncIResponse:Message1");
        $callback.OnChange("testSyncIResponse:Message2");
        $callback.OnComplete("testSyncIResponse:End1");
        $callback.OnComplete("testSyncIResponse:End2");
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @param {IResponse} $callback The response callback for the send operation.
     * @returns {string} Returns a fallback string that is superseded by the callback.
     */
    SyncValueWithIncorrectIResponseNoVoid($param, $callback) {
        const response = ResponseFactory.getResponse($callback);
        // response.OnStart("testSyncIResponse:Start"); // may cause errors if FE not implemented correctly
        // response.OnChange("testSyncIResponse:Message"); // may cause errors if FE not implemented correctly
        response.Send("testSyncIResponse:" + $param);
        return "testSyncAutoResponse:" + $param; // should never reach due to $callback detection
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @param {IResponse} $callback The response callback for the send operation.
     * @returns {string} Returns a fallback string that is superseded by the callback.
     */
    SyncValueWithIResponseNoVoid($param, $callback) {
        const response = ResponseFactory.getResponse($callback);
        // response.OnStart("testSyncIResponse:Start"); // may cause errors if FE not implemented correctly
        response.Send("testSyncIResponse:" + $param);
        return "testSyncAutoResponse:" + $param; // should never reach as callback has higher priority
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @param {IResponse} $callback The response callback for the send operation.
     */
    SyncValueWithIResponse($param, $callback) {
        const response = ResponseFactory.getResponse($callback);
        // response.OnStart("testSyncIResponse:Start"); // may cause errors if FE not implemented correctly
        response.Send("testSyncIResponse:" + $param);
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @returns {string} Returns the test response string.
     */
    SyncValueWithoutIResponse($param) {
        return "testSyncIResponse:" + $param;
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @param {IResponse} $callback The response callback for streaming events.
     * @returns {string} Returns a fallback string that is superseded by the callback.
     */
    SyncValueWithFullIResponseNoVoid($param, $callback) {
        const response = ResponseFactory.getResponse($callback);
        response.OnStart("testSyncIResponse:Start"); // may cause errors if FE not implemented correctly
        response.OnChange("testSyncIResponse:Message");
        response.OnComplete("testSyncIResponse:" + $param);
        return "testSyncAutoResponse:" + $param; // should never reach as callback has higher priority
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @param {IResponse} $callback The response callback for streaming events.
     */
    SyncValueWithFullIResponse($param, $callback) {
        const response = ResponseFactory.getResponse($callback);
        response.OnStart("testSyncIResponse:Start"); // may cause errors if FE not implemented correctly
        response.OnChange("testSyncIResponse:Message");
        response.OnComplete("testSyncIResponse:" + $param);
    }
    /**
     * @param {...string} $params The variadic string parameters.
     * @returns {string} Returns the test response string with all parameters joined.
     */
    SyncValueWithOpenArgs(...$params) {
        return "testSyncValues:" + $params.join(",");
    }
    /**
     * @param {string} $param The required string parameter.
     * @param {string} [$optional] The optional string parameter.
     * @returns {string} Returns the test response string.
     */
    SyncValueWithOptionArgs($param, $optional) {
        return "testSyncValueOptional:" + $param + ", optional: " + $optional;
    }
    /**
     * @returns {Promise<string>} Returns a promise resolving to the test response string.
     */
    AsyncValueNoArgs() {
        return new Promise(($resolve) => {
            $resolve("testAsyncValueNoArgs");
        });
    }
    /**
     * @param {string} $param The string parameter to include in the response.
     * @returns {Promise<string>} Returns a promise resolving to the test response string.
     */
    AsyncValueWithArgs($param) {
        return new Promise(($resolve) => {
            $resolve("testAsyncValue:" + $param);
        });
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @param {IResponse} $callback The response callback for the send operation.
     * @returns {Promise<void>} Returns a promise that resolves after the callback is sent.
     */
    AsyncValueWithIResponse($param, $callback) {
        return new Promise(($resolve) => {
            const response = ResponseFactory.getResponse($callback);
            // response.OnStart("testAsyncIResponse:Start"); // may cause errors if FE not implemented correctly
            response.Send("testAsyncIResponse:" + $param);
            $resolve(); // should never reach as callback has higher priority - just ends await
        });
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @param {IResponse} $callback The response callback for the send operation.
     * @returns {Promise<string>} Returns a promise with a fallback string superseded by the callback.
     */
    AsyncValueWithIResponseNoVoid($param, $callback) {
        return new Promise(($resolve) => {
            const response = ResponseFactory.getResponse($callback);
            // response.OnStart("testAsyncIResponse:Start"); // may cause errors if FE not implemented correctly
            response.Send("testAsyncIResponse:" + $param);
            $resolve("testAsyncAutoResolve:" + $param); // should never reach as callback has higher priority
        });
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @param {IResponse} $callback The response callback for the send operation.
     * @returns {Promise<void>} Returns a promise that resolves after the callback is sent.
     */
    AsyncValueWithIncorrectIResponse($param, $callback) {
        return new Promise(($resolve) => {
            const response = ResponseFactory.getResponse($callback);
            // response.OnStart("testAsyncAutoResponse:Start"); // may cause errors if FE not implemented correctly
            response.Send("testAsyncAutoResponse:" + $param);
            $resolve(); // should never reach as callback has higher priority - just ends await
        });
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @param {IResponse} $callback The response callback for the send operation.
     * @returns {Promise<string>} Returns a promise with a fallback string superseded by the callback.
     */
    AsyncValueWithIncorrectIResponseNoVoid($param, $callback) {
        return new Promise(($resolve) => {
            const response = ResponseFactory.getResponse($callback);
            // response.OnStart("testAsyncAutoResponse:Start"); // may cause errors if FE not implemented correctly
            response.Send("testAsyncAutoResponse:" + $param);
            $resolve("testAsyncAutoResolve:" + $param); // should never reach due to $callback detection
        });
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @returns {Promise<string>} Returns a promise resolving to the test response string.
     */
    AsyncValueWithoutIResponse($param) {
        return new Promise(($resolve) => {
            $resolve("testAsyncAutoResolve:" + $param); // should never reach as callback has not been defined
        });
    }
    /**
     * @param {...string} $params The variadic string parameters.
     * @returns {Promise<string>} Returns a promise resolving to the test response string.
     */
    AsyncValueWithOpenArgs(...$params) {
        return new Promise(($resolve) => {
            $resolve("testAsyncValues:" + $params.join(","));
        });
    }
    /**
     * @param {string} $param The required string parameter.
     * @param {string} [$optional] The optional string parameter.
     * @returns {Promise<string>} Returns a promise resolving to the test response string.
     */
    AsyncValueWithOptionArgs($param, $optional) {
        return new Promise(($resolve) => {
            $resolve("testAsyncValueOptional:" + $param + ", optional: " + $optional);
        });
    }
    /**
     * @param {string} $param The string parameter used in the response data.
     * @param {IMessage} $onChange The message callback for progress notifications.
     * @returns {Promise<string>} Returns a promise resolving to the test response string.
     */
    AsyncValueWithProgress($param, $onChange) {
        $onChange.OnChange("testAsyncAutoResponse:Message");
        return new Promise(($resolve) => {
            $resolve("testAsyncAutoResolve:" + $param);
        });
    }
    RouteValueWithTypedArgs($param) {
        return "testRouteValue:" + Convert.ObjectToString($param, "", false);
    }
    RouteValueWithMultipleArgs($param, $valueAssignedByOrder) {
        return "testRouteValues:" + $param + ", " + $valueAssignedByOrder;
    }
}
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", String)
], ExternAndRouteTestHandler.prototype, "getVersion", null);
__decorate([
    Extern(),
    Route("GET /test/syncNoArgs"),
    Route("GET /test/altEndpointForSyncNoArgs"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", String)
], ExternAndRouteTestHandler.prototype, "SyncValueNoArgs", null);
__decorate([
    Extern(),
    Route("GET /test/syncValueWithArgs?param"),
    Route("DELETE /test/syncValueWithArgs?param"),
    Route("GET /test/syncValueWithUrlArgs/{param}"),
    Route("GET /test/syncValueWithHashArgs#{param}"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", String)
], ExternAndRouteTestHandler.prototype, "SyncValueWithArgs", null);
__decorate([
    Extern(),
    Route("POST /test/SyncValueWithJsonArgs"),
    Route("PUT /test/SyncValueWithJsonArgs"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", String)
], ExternAndRouteTestHandler.prototype, "SyncValueWithJsonArgs", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Object)
], ExternAndRouteTestHandler.prototype, "SyncJsonWithJsonArgs", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Buffer)
], ExternAndRouteTestHandler.prototype, "SyncBufferWithArgs", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ExternAndRouteTestHandler.prototype, "SyncVoidWithIncorrectIResponse", null);
__decorate([
    Extern(ExternResponseType.WITH_PROGRESS),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", String)
], ExternAndRouteTestHandler.prototype, "SyncWithProgress", null);
__decorate([
    Extern(ExternResponseType.WITH_PROGRESS),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", String)
], ExternAndRouteTestHandler.prototype, "SyncWithIncorrectProgress", null);
__decorate([
    Extern(ExternResponseType.FULL_CONTROL),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ExternAndRouteTestHandler.prototype, "SyncWithStartAfterChange", null);
__decorate([
    Extern(ExternResponseType.FULL_CONTROL),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ExternAndRouteTestHandler.prototype, "SyncWithStartAfterComplete", null);
__decorate([
    Extern(ExternResponseType.FULL_CONTROL),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ExternAndRouteTestHandler.prototype, "SyncWithChangeAfterComplete", null);
__decorate([
    Extern(ExternResponseType.FULL_CONTROL),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ExternAndRouteTestHandler.prototype, "SyncWithMultipleStarts", null);
__decorate([
    Extern(ExternResponseType.FULL_CONTROL),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], ExternAndRouteTestHandler.prototype, "SyncWithMultipleCompletes", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", String)
], ExternAndRouteTestHandler.prototype, "SyncValueWithIncorrectIResponseNoVoid", null);
__decorate([
    Extern(false),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", String)
], ExternAndRouteTestHandler.prototype, "SyncValueWithIResponseNoVoid", null);
__decorate([
    Extern(false),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ExternAndRouteTestHandler.prototype, "SyncValueWithIResponse", null);
__decorate([
    Extern(false),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", String)
], ExternAndRouteTestHandler.prototype, "SyncValueWithoutIResponse", null);
__decorate([
    Extern(false),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", String)
], ExternAndRouteTestHandler.prototype, "SyncValueWithFullIResponseNoVoid", null);
__decorate([
    Extern(false),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], ExternAndRouteTestHandler.prototype, "SyncValueWithFullIResponse", null);
__decorate([
    Extern(ExternResponseType.IMPLICIT_RETURN),
    Route("GET /test/syncValueWithOpenArgs?param1&param2"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", String)
], ExternAndRouteTestHandler.prototype, "SyncValueWithOpenArgs", null);
__decorate([
    Extern(ExternResponseType.DEFAULT),
    Route("GET /test/syncValueWithOptionArgs?param&optional"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", String)
], ExternAndRouteTestHandler.prototype, "SyncValueWithOptionArgs", null);
__decorate([
    Extern(ExternResponseType.IMPLICIT_RETURN),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ExternAndRouteTestHandler.prototype, "AsyncValueNoArgs", null);
__decorate([
    Extern(ExternResponseType.DEFAULT),
    Route("GET /test/asyncValueWithArgs?param"),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ExternAndRouteTestHandler.prototype, "AsyncValueWithArgs", null);
__decorate([
    Extern(false),
    Route("GET /test/asyncValueWithIResponse?param", { autoResponse: false }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ExternAndRouteTestHandler.prototype, "AsyncValueWithIResponse", null);
__decorate([
    Extern(false),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ExternAndRouteTestHandler.prototype, "AsyncValueWithIResponseNoVoid", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ExternAndRouteTestHandler.prototype, "AsyncValueWithIncorrectIResponse", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ExternAndRouteTestHandler.prototype, "AsyncValueWithIncorrectIResponseNoVoid", null);
__decorate([
    Extern(false),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ExternAndRouteTestHandler.prototype, "AsyncValueWithoutIResponse", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ExternAndRouteTestHandler.prototype, "AsyncValueWithOpenArgs", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], ExternAndRouteTestHandler.prototype, "AsyncValueWithOptionArgs", null);
__decorate([
    Extern(ExternResponseType.WITH_PROGRESS)
    // route with progress does not make a sense so expected output is from OnChange
    ,
    Route("GET /test/asyncValueWithProgress?param", { responseType: ExternResponseType.WITH_PROGRESS }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ExternAndRouteTestHandler.prototype, "AsyncValueWithProgress", null);
__decorate([
    Route("GET /test/routeValueWithIntParam?param=int()"),
    Route("GET /test/routeValueWithDefaultIntDefaultParam?param=integer(5)"),
    Route("GET /test/routeValueWithDefaultNumberDefaultParam?param=number(8)"),
    Route("GET /test/routeValueWithDefaultFloatDefaultParam?param=float(1.1)"),
    Route("GET /test/routeValueWithDefaultDoubleDefaultParam?param=double(2.2)"),
    Route("GET /test/routeValueWithBoolParam?param=bool()"),
    Route("GET /test/routeValueWithDefaultBoolDefaultParam?param=boolean(false)"),
    Route("GET /test/routeValueWithKeywordParam?param=int"),
    Route("GET /test/routeValueWithStringParam?param=string(test)")
    /**
     * @param {any} $param The typed parameter coerced by the route schema.
     * @returns {string} Returns the test response string with the type and value.
     */
    ,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", String)
], ExternAndRouteTestHandler.prototype, "RouteValueWithTypedArgs", null);
__decorate([
    Route("GET /test/routeValueWithMultipleArgs?param1=boolean(false)&param2")
    /**
     * @param {boolean} $param The boolean parameter from the route schema.
     * @param {string} $valueAssignedByOrder The string parameter assigned by position order.
     * @returns {string} Returns the test response string.
     */
    ,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean, String]),
    __metadata("design:returntype", String)
], ExternAndRouteTestHandler.prototype, "RouteValueWithMultipleArgs", null);
globalThis.RegisterClass("Io.Oidis.Localhost.RuntimeTests.ExternAndRouteTestHandler", ExternAndRouteTestHandler);
//# sourceMappingURL=ExternAndRouteTestHandler.js.map