var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2023-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ResponseFactory } from "../HttpProcessor/ResponseApi/ResponseFactory.js";
import { ExternResponseType } from "../Interfaces/IExternOptions.js";
import { IResponse } from "../Interfaces/IResponse.js";
import { Loader } from "../Loader.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
import { Extern } from "../Primitives/Decorators.js";
export class MockAuthConnector extends BaseConnector {
    /**
     * @param {IResponse} $callback The response callback to send the result through.
     */
    static AuthMethodStaticWithCallback($callback) {
        LogIt.Debug("AuthMethodStaticWithCallback called");
        ResponseFactory.getResponse($callback).Send(true);
    }
    /**
     * @returns {boolean} Returns true to indicate successful authentication.
     */
    static AuthMethodStaticWithReturn() {
        LogIt.Debug("AuthMethodStaticWithReturn called");
        return true;
    }
    /**
     * @param {IResponse} $callback The response callback to send the result through.
     */
    AuthMethodWithCallback($callback) {
        LogIt.Debug("AuthMethodWithCallback called, q: {0}", this.AuthMethodWithReturn());
        ResponseFactory.getResponse($callback).Send(true);
    }
    /**
     * @returns {boolean} Returns true to indicate successful authentication.
     */
    AuthMethodWithReturn() {
        LogIt.Debug("AuthMethodWithReturn called");
        return true;
    }
    AuthMethodVoid() {
        LogIt.Debug("AuthMethodVoid called");
    }
    /**
     * @returns {any} Returns null.
     */
    AuthMethodNull() {
        LogIt.Debug("AuthMethodNull called");
        return null;
    }
    /**
     * @returns {any} Returns an empty object.
     */
    AuthMethodEmpty() {
        LogIt.Debug("AuthMethodEmpty called");
        return {};
    }
    /**
     * @returns {string | Buffer} Returns the buffer containing the test file contents.
     */
    AuthMethodBuffer() {
        LogIt.Debug("AuthMethodBuffer called");
        const fileSystem = Loader.getInstance().getFileSystemHandler();
        const path = fileSystem.getTempPath() + "/" + Loader.getInstance().getAppConfiguration().name + "/test.txt";
        fileSystem.Write(path, "hello world");
        return fileSystem.Read(path);
    }
}
__decorate([
    Extern(ExternResponseType.FULL_CONTROL),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MockAuthConnector.prototype, "AuthMethodWithCallback", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Boolean)
], MockAuthConnector.prototype, "AuthMethodWithReturn", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], MockAuthConnector.prototype, "AuthMethodVoid", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Object)
], MockAuthConnector.prototype, "AuthMethodNull", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Object)
], MockAuthConnector.prototype, "AuthMethodEmpty", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Object)
], MockAuthConnector.prototype, "AuthMethodBuffer", null);
__decorate([
    Extern(ExternResponseType.FULL_CONTROL),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], MockAuthConnector, "AuthMethodStaticWithCallback", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Boolean)
], MockAuthConnector, "AuthMethodStaticWithReturn", null);
globalThis.RegisterClass("Io.Oidis.Localhost.RuntimeTests.MockAuthConnector", MockAuthConnector);
//# sourceMappingURL=MockAuthConnector.js.map