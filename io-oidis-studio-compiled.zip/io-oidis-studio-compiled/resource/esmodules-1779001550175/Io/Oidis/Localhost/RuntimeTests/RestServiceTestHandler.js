var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2023-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ResponseFactory } from "../HttpProcessor/ResponseApi/ResponseFactory.js";
import { ExternResponseType } from "../Interfaces/IExternOptions.js";
import { IResponse } from "../Interfaces/IResponse.js";
import { Loader } from "../Loader.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
import { Extern } from "../Primitives/Decorators.js";
export class RestServiceTestHandler extends BaseConnector {
    /**
     * @param {string} $message The message to log.
     * @returns {boolean} Returns true to indicate successful invocation.
     */
    SelfCallMethod($message) {
        Echo.Printf("SelfCallMethod message: {0}", $message);
        return true;
    }
    /**
     * @param {string} $message The error message to throw.
     */
    ExceptionTest($message) {
        throw new Error($message);
    }
    /**
     * @param {string} $message The error message to include in the response.
     * @param {IResponse} [$callback] The response callback for the error notification.
     */
    ErrorTest($message, $callback) {
        ResponseFactory.getResponse($callback).OnError($message, { responseType: 404 }, "additional message");
    }
    /**
     * @param {string} $path The file path of the archive to unpack.
     * @param {IResponse} [$callback] The response callback for unpack progress events.
     */
    UnpackTest($path, $callback) {
        Loader.getInstance().getFileSystemHandler().Unpack($path, null, $callback);
    }
    /**
     * @param {IResponse} [$callback] The response callback for download progress events.
     */
    DownloadTest($callback) {
        Loader.getInstance().getFileSystemHandler().Download("https://github.com/git-for-windows/git/releases/download/v2.21.0.windows.1/Git-2.21.0-64-bit.exe", $callback);
    }
    /**
     * @param {string} $data The data string to measure.
     * @returns {number} Returns the length of the data string.
     */
    DataTransferTest($data) {
        return $data.length;
    }
}
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Boolean)
], RestServiceTestHandler.prototype, "SelfCallMethod", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], RestServiceTestHandler.prototype, "ExceptionTest", null);
__decorate([
    Extern(ExternResponseType.FULL_CONTROL),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], RestServiceTestHandler.prototype, "ErrorTest", null);
__decorate([
    Extern(ExternResponseType.FULL_CONTROL),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", void 0)
], RestServiceTestHandler.prototype, "UnpackTest", null);
__decorate([
    Extern(ExternResponseType.FULL_CONTROL),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], RestServiceTestHandler.prototype, "DownloadTest", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Number)
], RestServiceTestHandler.prototype, "DataTransferTest", null);
globalThis.RegisterClass("Io.Oidis.Localhost.RuntimeTests.RestServiceTestHandler", RestServiceTestHandler);
//# sourceMappingURL=RestServiceTestHandler.js.map