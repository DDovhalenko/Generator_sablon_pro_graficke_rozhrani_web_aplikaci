/*! ******************************************************************************************************** *
 *
 * Copyright 2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Loader } from "../Loader.js";
import { StdinManager } from "../Utils/StdinManager.js";
export class ProgramArgs extends BaseObject {
    stdinHandler;
    isVersion;
    isHelp;
    isPath;
    startServer;
    stopServer;
    isSelfCheck;
    restartServer;
    targetBase;
    binBase;
    projectBase;
    appDataPath;
    isDebug;
    isVerbose;
    isTestRun;
    elasticMapping;
    logLevel;
    isIntegrityCheck;
    ignoreIntegrityChecks;
    listRoutes;
    constructor() {
        super();
        this.stdinHandler = () => {
            // default handler
        };
        this.isVersion = false;
        this.isHelp = false;
        this.isPath = false;
        this.startServer = false;
        this.stopServer = false;
        this.isSelfCheck = false;
        this.restartServer = false;
        this.targetBase = "";
        this.binBase = "";
        this.projectBase = "";
        this.appDataPath = "";
        this.isDebug = false;
        this.isVerbose = false;
        this.isTestRun = false;
        this.elasticMapping = false;
        this.logLevel = 0;
        this.isIntegrityCheck = false;
        this.ignoreIntegrityChecks = [];
        this.listRoutes = false;
    }
    /**
     * @param {string[]} $args Raw argument list to normalize.
     * @returns {string[]} Returns the normalized argument array.
     */
    Normalize($args) {
        const output = [];
        let index;
        const length = $args.length;
        let key = "";
        let value = "";
        const assignPair = () => {
            if (!ObjectValidator.IsEmptyOrNull(key) && ObjectValidator.IsEmptyOrNull(value) && StringUtils.Contains(key, "=")) {
                const index = StringUtils.IndexOf(key, "=");
                value = StringUtils.Substring(key, index + 1);
                key = StringUtils.Substring(key, 0, index);
            }
            if (!ObjectValidator.IsEmptyOrNull(value)) {
                if (StringUtils.Contains(value, " ")) {
                    if ((StringUtils.StartsWith(value, "\"") && StringUtils.EndsWith(value, "\"")) ||
                        (StringUtils.StartsWith(value, "'") && StringUtils.EndsWith(value, "'"))) {
                        value = StringUtils.Substring(value, 1, StringUtils.Length(value) - 1);
                    }
                    value = "\"" + value + "\"";
                }
                output.push(key + "=" + value);
                value = "";
            }
            else if (!ObjectValidator.IsEmptyOrNull(key)) {
                output.push(key);
            }
        };
        for (index = 0; index < length; index++) {
            const arg = $args[index];
            if ((StringUtils.StartsWith(arg, "-") ||
                (StringUtils.StartsWith(arg, "/") && StringUtils.Length(arg) === 2) ||
                StringUtils.Contains(arg, "=")) &&
                !ObjectValidator.IsDigit(arg)) {
                assignPair();
                key = arg;
            }
            else {
                if (!ObjectValidator.IsEmptyOrNull(key)) {
                    if (!ObjectValidator.IsEmptyOrNull(value)) {
                        value += " ";
                    }
                    value += arg;
                }
                else {
                    output.push(arg);
                }
            }
        }
        assignPair();
        return output;
    }
    /**
     * @param {string[]} $args Argument list to parse.
     */
    Parse($args) {
        $args = this.Normalize($args);
        if (StringUtils.ContainsIgnoreCase($args[1], "loader.min.js", "worker eval")) {
            $args.shift();
            $args.shift();
        }
        if ($args.length > 0) {
            const pairs = new ArrayList();
            for (const arg of $args) {
                let key = arg;
                let value = "";
                if (StringUtils.Contains(arg, "=")) {
                    key = StringUtils.Substring(arg, 0, StringUtils.IndexOf(arg, "="));
                    value = StringUtils.Substring(arg, StringUtils.IndexOf(arg, "=") + 1);
                    if (StringUtils.StartsWith(value, "\"")) {
                        value = StringUtils.Substring(value, 1);
                    }
                    if (StringUtils.EndsWith(value, "\"")) {
                        value = StringUtils.Substring(value, 0, StringUtils.Length(value) - 1);
                    }
                }
                pairs.Add(value, key);
            }
            this.processArgs(pairs);
        }
        else {
            this.processDefaultArgs();
        }
    }
    /**
     * @param {($data: string) => void} $handler Callback invoked with user stdin input.
     */
    setStdinHandler($handler) {
        if (ObjectValidator.IsFunction($handler)) {
            this.stdinHandler = $handler;
        }
    }
    /**
     * @param {boolean} $value Optional value to set.
     * @returns {boolean} Returns the current version flag value.
     */
    IsVersion($value) {
        return this.isVersion = Property.Boolean(this.isVersion, $value);
    }
    /**
     * @param {boolean} $value Optional value to set.
     * @returns {boolean} Returns the current help flag value.
     */
    IsHelp($value) {
        return this.isHelp = Property.Boolean(this.isHelp, $value);
    }
    /**
     * @param {boolean} $value Optional value to set.
     * @returns {boolean} Returns the current path flag value.
     */
    IsPath($value) {
        return this.isPath = Property.Boolean(this.isPath, $value);
    }
    /**
     * @param {boolean} $value Optional value to set.
     * @returns {boolean} Returns the current start server flag value.
     */
    StartServer($value) {
        return this.startServer = Property.Boolean(this.startServer, $value);
    }
    /**
     * @param {boolean} $value Optional value to set.
     * @returns {boolean} Returns the current stop server flag value.
     */
    StopServer($value) {
        return this.stopServer = Property.Boolean(this.stopServer, $value);
    }
    /**
     * @param {boolean} $value Optional value to set.
     * @returns {boolean} Returns the current restart server flag value.
     */
    RestartServer($value) {
        return this.restartServer = Property.Boolean(this.restartServer, $value);
    }
    /**
     * @param {string} $value Optional path value to set.
     * @returns {string} Returns the current binary base path.
     */
    BinBase($value) {
        return this.binBase = Property.String(this.binBase, $value);
    }
    /**
     * @param {string} $value Optional path value to set.
     * @returns {string} Returns the current project base path.
     */
    ProjectBase($value) {
        return this.projectBase = Property.String(this.projectBase, $value);
    }
    /**
     * @param {string} $value Optional path value to set.
     * @returns {string} Returns the current target base path.
     */
    TargetBase($value) {
        return this.targetBase = Property.String(this.targetBase, $value);
    }
    /**
     * @param {string} $value Optional path value to set.
     * @returns {string} Returns the current application data path.
     */
    AppDataPath($value) {
        return this.appDataPath = Property.String(this.appDataPath, $value);
    }
    /**
     * @param {boolean} $value Optional value to set.
     * @returns {boolean} Returns the current debug flag value.
     */
    IsDebug($value) {
        return this.isDebug = Property.Boolean(this.isDebug, $value);
    }
    /**
     * @param {boolean} $value Optional value to set.
     * @returns {boolean} Returns the current verbose flag value.
     */
    IsVerbose($value) {
        return this.isVerbose = Property.Boolean(this.isVerbose, $value);
    }
    /**
     * @param {boolean} $value Optional value to set.
     * @returns {boolean} Returns true if test run mode is active.
     */
    IsTestRun($value) {
        this.isTestRun = Property.Boolean(this.isTestRun, $value);
        return this.isTestRun || process.env.IS_WUI_TEST_RUN;
    }
    /**
     * @param {boolean} $value Optional value to set.
     * @returns {boolean} Returns the current elastic mapping flag value.
     */
    ElasticMapping($value) {
        return this.elasticMapping = Property.Boolean(this.elasticMapping, $value);
    }
    /**
     * @param {number} $value Optional level value to set.
     * @returns {number} Returns the current log level.
     */
    LogLevel($value) {
        return this.logLevel = Property.Integer(this.logLevel, $value);
    }
    PrintVersion() {
        Echo.Print(Loader.getInstance().getEnvironmentArgs().getAppName() +
            " v" + Loader.getInstance().getEnvironmentArgs().getProjectVersion());
    }
    PrintPath() {
        Echo.Print(this.ProjectBase());
    }
    /**
     * @param {boolean} $value Optional value to set.
     * @returns {boolean} Returns the current self check flag value.
     */
    IsSelfCheck($value) {
        return this.isSelfCheck = Property.Boolean(this.isSelfCheck, $value);
    }
    /**
     * @param {boolean} $value Optional value to set.
     * @returns {boolean} Returns the current integrity check flag value.
     */
    IsIntegrityCheck($value) {
        return this.isIntegrityCheck = Property.Boolean(this.isIntegrityCheck, $value);
    }
    /**
     * @returns {string[]} Returns the array of ignored integrity check names.
     */
    getIgnoredChecks() {
        return this.ignoreIntegrityChecks;
    }
    /**
     * @param {boolean} $value Optional value to set.
     * @returns {boolean} Returns the current list routes flag value.
     */
    ListRoutes($value) {
        return this.listRoutes = Property.Boolean(this.listRoutes, $value);
    }
    PrintHelp() {
        this.getHelp("" +
            "Oidis Framework Localhost                                                    \n" +
            "   - Localhost service for Oidis Framework with websockets support           \n" +
            "                                                                             \n" +
            "   copyright:         Copyright 2010-2013 Jakub Cieslar                      \n" +
            "                      Copyright 2014-2016 Freescale Semiconductor, Inc.      \n" +
            "                      Copyright 2017-2019 NXP                                \n" +
            "                      Copyright " + StringUtils.YearFrom(2019) + " Oidis                              \n" +
            "   author:            Oidis z.s., info@oidis.io                              \n" +
            "   license:           BSD-3-Clause License distributed with this material    \n", "" +
            "Basic options:                                                               \n" +
            "   -h [ --help ]        Prints application help description.                 \n" +
            "   -v [ --version ]     Prints application version message.                  \n" +
            "   -p [ --path ]        Print current Oidis Host location.                   \n" +
            "   --debug              Run current Oidis Host instance in debug mode.       \n" +
            "   --verbose            Run current Oidis Host instance in verbose mode.     \n" +
            "   --selfcheck          Run self health check.                               \n" +
            "   --integrity-check    Run assembly integrity check.                        \n" +
            "   --ignored-checks=*   Comma separated list of integrity checks to skip.    \n" +
            "                                                                             \n" +
            "Server options:                                                              \n" +
            "   start              Start localhost service.                               \n" +
            "   stop               Stop localhost service.                                \n" +
            "   restart            Restart localhost service.                             \n" +
            "   list-routes        List available routes.                                 \n" +
            "                                                                             \n" +
            "Other options:                                                               \n" +
            "   --target=<path>    Specify target *.html file to host by localhost.       \n");
    }
    processDefaultArgs() {
        this.IsHelp(true);
    }
    processArgs($args) {
        $args.foreach(($value, $key) => {
            if (!this.processArg($key, $value)) {
                Echo.Printf("Unrecognized program option: {0}", $key);
                Loader.getInstance().Exit(-1);
            }
        });
    }
    processArg($key, $value) {
        switch (StringUtils.ToLowerCase($key)) {
            case "--help":
            case "-h":
            case "/h":
            case "/?":
            case "help":
            case "?":
                this.IsHelp(true);
                break;
            case "--version":
            case "-v":
            case "/v":
            case "version":
                this.IsVersion(true);
                break;
            case "--path":
            case "-p":
            case "/p":
            case "path":
                this.IsPath(true);
                break;
            case "--debug":
                this.IsDebug(true);
                break;
            case "--verbose":
                this.IsVerbose(true);
                break;
            case "start":
                this.StartServer(true);
                break;
            case "stop":
                this.StopServer(true);
                break;
            case "restart":
                this.RestartServer(true);
                break;
            case "--target":
                this.TargetBase($value);
                break;
            case "--test-run":
                this.IsTestRun(true);
                break;
            case "--with-mapping":
            case "--elastic-mapping":
                this.ElasticMapping(true);
                break;
            case "--log-level":
                this.LogLevel(StringUtils.ToInteger($value));
                break;
            case "--selfcheck":
                this.IsSelfCheck(true);
                break;
            case "--integrity":
            case "--integrity-check":
                this.IsIntegrityCheck(true);
                break;
            case "--ignored-checks":
                if (!ObjectValidator.IsEmptyOrNull($value)) {
                    this.ignoreIntegrityChecks = $value.split(",").filter(($value) => $value.length > 0);
                }
                break;
            case "list-routes":
                this.ListRoutes(true);
                break;
            default:
                return false;
        }
        return true;
    }
    getHelp($header, $body, $footer, $question) {
        if (ObjectValidator.IsEmptyOrNull($footer)) {
            $footer =
                "NOTE:                                                                        \n" +
                    "    This program can depends on several prerequisites for more               \n" +
                    "    info see README.md distributed with this material.                       \n";
        }
        Echo.Print("" +
            "_____________________________________________________________________________\n" +
            "                                                                             \n" +
            $header +
            "_____________________________________________________________________________\n" +
            "/////////////////////////////////////////////////////////////////////////////\n" +
            "                                                                             \n" +
            $body +
            "                                                                             \n" +
            $footer +
            "                                                                             \n" +
            "-----------------------------------------------------------------------------\n");
        if (ObjectValidator.IsEmptyOrNull($question)) {
            $question = "Hit Enter for exit or specify program options";
        }
        let value = "";
        StdinManager.Process([
            {
                callback: ($task, $callback) => {
                    value = $task;
                    $callback(true);
                },
                prefix: $question
            }
        ], () => {
            this.stdinHandler(value);
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.Structures.ProgramArgs", ProgramArgs);
//# sourceMappingURL=ProgramArgs.js.map