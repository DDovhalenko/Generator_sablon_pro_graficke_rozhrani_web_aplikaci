/*! ******************************************************************************************************** *
 *
 * Copyright 2018-2026 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Loader } from "../Loader.js";
export class CertsManager extends BaseObject {
    greenlock;
    fileSystem;
    properties;
    appArgs;
    domain;
    config;
    /**
     * @returns {CertsManager} Returns the singleton instance.
     */
    static getInstance() {
        const instance = new CertsManager();
        this.getInstance = () => {
            return instance;
        };
        return instance;
    }
    constructor($domain, $config) {
        super();
        const instance = Loader.getInstance();
        this.fileSystem = instance.getFileSystemHandler();
        this.properties = instance.getAppConfiguration();
        this.appArgs = instance.getProgramArgs();
        try {
            this.greenlock = require("greenlock").create({
                server: this.appArgs.IsDebug() ?
                    "https://acme-staging-v02.api.letsencrypt.org/directory" : "https://acme-v02.api.letsencrypt.org/directory",
                store: require("greenlock-store-fs"),
                version: "draft-12"
            });
            if (ObjectValidator.IsEmptyOrNull($domain)) {
                this.domain = this.properties.domain.location;
            }
            else {
                this.domain = $domain;
            }
            if (ObjectValidator.IsEmptyOrNull($config)) {
                this.config = {
                    certificatePath: "",
                    privateKeyPath: ""
                };
            }
            else {
                this.config = $config;
            }
        }
        catch (ex) {
            LogIt.Warning(ex.stack);
            this.config = {
                certificatePath: "",
                privateKeyPath: ""
            };
        }
    }
    /**
     * @param {($status : boolean, $cert? : string, $key? : string) => void} $callback Callback invoked with certificate status and data.
     */
    Create($callback) {
        const domains = [this.domain];
        const generate = () => {
            LogIt.Debug("Generating certs for: {0}", this.domain);
            this.greenlock
                .register({
                agreeTos: true,
                debug: this.appArgs.IsDebug(),
                domains,
                email: this.properties.certs.mail,
                webrootPath: this.getStoragePath()
            })
                .then(($results) => {
                try {
                    $callback(true, $results.cert + $results.chain, $results.privkey);
                }
                catch (ex) {
                    LogIt.Warning(ex.stack);
                    $callback(false);
                }
            }, ($error) => {
                LogIt.Warning($error.stack);
                $callback(false);
            });
        };
        if (!this.appArgs.IsDebug()) {
            LogIt.Debug("Check certs validity for: {0}", this.domain);
            this.greenlock.check({ domains }).then(($results) => {
                if ($results) {
                    LogIt.Debug("> Certs are valid for: {0}", this.domain);
                    $callback(true, $results.cert + $results.chain, $results.privkey);
                }
                else {
                    generate();
                }
            });
        }
        else {
            generate();
        }
    }
    /**
     * @returns {string} Returns the ACME challenge storage path.
     */
    getStoragePath() {
        return this.appArgs.AppDataPath() + "/resource/data/acme-challenge";
    }
    /**
     * @returns {IServerConfigurationSSL} Returns the SSL configuration with resolved paths.
     */
    getCertPaths() {
        const output = this.config;
        const binBase = this.appArgs.BinBase();
        const targetBase = this.appArgs.TargetBase();
        if (ObjectValidator.IsObject(this.properties.domain.ssl)) {
            const ssl = this.properties.domain.ssl;
            output.certificatePath = ssl.certificatePath;
            if (!this.fileSystem.Exists(output.certificatePath)) {
                output.certificatePath = binBase + "/" + ssl.certificatePath;
            }
            if (!this.fileSystem.Exists(output.certificatePath)) {
                output.certificatePath = targetBase + "/" + ssl.certificatePath;
            }
            output.privateKeyPath = ssl.privateKeyPath;
            if (!this.fileSystem.Exists(output.privateKeyPath)) {
                output.privateKeyPath = binBase + "/" + ssl.privateKeyPath;
            }
            if (!this.fileSystem.Exists(output.privateKeyPath)) {
                output.privateKeyPath = targetBase + "/" + ssl.privateKeyPath;
            }
        }
        else {
            let sslBasePath = this.properties.domain.ssl;
            if (!this.fileSystem.Exists(sslBasePath)) {
                sslBasePath = binBase + "/" + sslBasePath;
            }
            if (!this.fileSystem.Exists(sslBasePath)) {
                sslBasePath = targetBase + "/" + sslBasePath;
            }
            const domain = StringUtils.Replace(this.domain, ".", "_");
            output.certificatePath = sslBasePath + "/" + domain + ".crt";
            if (!this.fileSystem.Exists(output.certificatePath)) {
                const sslBasePathCp = sslBasePath + "/" + this.domain;
                output.certificatePath = sslBasePathCp + "/" + domain + ".crt";
                if (!this.fileSystem.Exists(output.certificatePath)) {
                    output.certificatePath = sslBasePathCp + "/fullchain.pem";
                }
            }
            output.privateKeyPath = sslBasePath + "/" + domain + ".key";
            if (!this.fileSystem.Exists(output.privateKeyPath)) {
                const sslBasePathKp = sslBasePath + "/" + this.domain;
                output.privateKeyPath = sslBasePathKp + "/" + domain + ".key";
                if (!this.fileSystem.Exists(output.privateKeyPath)) {
                    output.privateKeyPath = sslBasePathKp + "/privkey.pem";
                }
            }
        }
        this.getCertPaths = () => {
            return output;
        };
        return output;
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.Utils.CertsManager", CertsManager);
//# sourceMappingURL=CertsManager.js.map