var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2025-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
import { Extern } from "../Primitives/Decorators.js";
import { Loader } from "../Loader.js";
import { JsonUtils } from "./../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
export class CronConnector extends BaseConnector {
    instance;
    constructor() {
        super();
        this.instance = Loader.getInstance().getCron();
    }
    /**
     * @param {boolean} $active Whether to activate the master stop.
     * @returns {Promise<boolean>} Returns true when the operation completes.
     */
    async MasterStop($active) {
        return await this.instance.MasterStop($active);
    }
    /**
     * @returns {ICronTaskDescriptor[]} Returns the array of task descriptors.
     */
    ListTasks() {
        return this.instance.ListTasks();
    }
    /**
     * @param {string} $idOrName Task identifier or name.
     * @param {boolean} $instant Whether to execute the task immediately.
     * @returns {boolean} Returns true if the task was found and started.
     */
    StartTask($idOrName, $instant = false) {
        return this.instance.StartTask($idOrName, $instant);
    }
    /**
     * @param {string} $idOrName Task identifier or name.
     * @returns {boolean} Returns true if the task was found and stopped.
     */
    StopTask($idOrName) {
        return this.instance.StopTask($idOrName);
    }
}
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean]),
    __metadata("design:returntype", Promise)
], CronConnector.prototype, "MasterStop", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Array)
], CronConnector.prototype, "ListTasks", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Boolean]),
    __metadata("design:returntype", Boolean)
], CronConnector.prototype, "StartTask", null);
__decorate([
    Extern(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Boolean)
], CronConnector.prototype, "StopTask", null);
export class Cron extends BaseObject {
    static cronModule;
    static cronInlineTaskClass;
    static cronRegister = [];
    masterStopActive;
    stateChangeHandler;
    config;
    /**
     * @returns {Cron} Returns the singleton instance.
     */
    static getSingleton() {
        const instance = new Cron();
        Cron.getSingleton = () => {
            return instance;
        };
        return instance;
    }
    constructor() {
        super();
        this.config = Loader.getInstance().getAppConfiguration().cron;
        this.masterStopActive = !this.config.enabled;
        this.stateChangeHandler = async ($state) => {
            // do nothing
        };
    }
    /**
     * @param {($state : boolean) => Promise<void>} $handler Async handler invoked on state change.
     */
    OnStateChange($handler) {
        if (!ObjectValidator.IsEmptyOrNull($handler)) {
            this.stateChangeHandler = $handler;
        }
    }
    AddTask($task, $nameOrOptions) {
        const options = {
            scheduled: false
        };
        if (ObjectValidator.IsString($nameOrOptions)) {
            options.name = $nameOrOptions;
        }
        else {
            JsonUtils.Extend(options, $nameOrOptions);
        }
        const id = this.getUID();
        if (ObjectValidator.IsEmptyOrNull(options.name)) {
            options.name = id;
        }
        if (ObjectValidator.IsEmptyOrNull(options.cronTime)) {
            options.cronTime = this.config.scheduler[options.name];
        }
        if (ObjectValidator.IsEmptyOrNull(options.cronTime)) {
            options.cronTime = "* * * * *";
        }
        if (ObjectValidator.IsEmptyOrNull(options.timezone) && !ObjectValidator.IsEmptyOrNull(this.config.timezone)) {
            options.timezone = this.config.timezone;
        }
        if (!this.getCronModule().validate(options.cronTime)) {
            LogIt.Error(`Task "${options.name}" has not been scheduled due to incorrect cronTime expression: ${options.cronTime}`);
            return;
        }
        const InlineScheduledTask = this.getCronInlineTaskClass();
        const scheduledTask = new InlineScheduledTask(options.cronTime, $task, options);
        Cron.cronRegister.push({
            active: false,
            cronTime: options.cronTime,
            id,
            name: options.name,
            task: scheduledTask
        });
        LogIt.Info(`Task added with cronTime: ${options.cronTime}, name: ${options.name}`);
        if (!this.masterStopActive) {
            this.StartTask(id);
        }
    }
    /**
     * @param {boolean} $active Whether to activate the master stop.
     * @returns {Promise<boolean>} Returns true when the operation completes.
     */
    async MasterStop($active) {
        if (this.masterStopActive !== $active) {
            await this.stateChangeHandler($active);
        }
        this.masterStopActive = $active;
        if (!$active) {
            LogIt.Info("Cron: deactivated MASTER STOP!");
            Cron.cronRegister.forEach(($item) => {
                if (!$item.active) {
                    $item.task.start();
                }
            });
        }
        else {
            LogIt.Warning("Cron: activated MASTER STOP!");
            Cron.cronRegister.forEach(($item) => {
                if ($item.active) {
                    $item.task.stop();
                }
            });
        }
        return true;
    }
    /**
     * @returns {ICronTaskDescriptor[]} Returns the array of task descriptors.
     */
    ListTasks() {
        return Cron.cronRegister.map(({ cronTime, name, task }) => ({ cronTime, name, timezone: task.timezone }));
    }
    /**
     * @param {string} $idOrName Task identifier or name.
     * @param {boolean} $instant Whether to execute the task immediately.
     * @returns {boolean} Returns true if the task was found and started.
     */
    StartTask($idOrName, $instant = false) {
        let index = Cron.cronRegister.findIndex((task) => task.id === $idOrName);
        if (index < 0) {
            index = Cron.cronRegister.findIndex((task) => task.name === $idOrName);
        }
        if (index !== -1) {
            if ($instant) {
                Cron.cronRegister[index].task.execute();
            }
            else {
                Cron.cronRegister[index].task.start();
                Cron.cronRegister[index].active = true;
            }
            LogIt.Info(`Task started: ${$idOrName}`);
            return true;
        }
        else {
            LogIt.Warning(`Task not found: ${$idOrName}`);
            return false;
        }
    }
    /**
     * @param {string} $idOrName Task identifier or name.
     * @returns {boolean} Returns true if the task was found and stopped.
     */
    StopTask($idOrName) {
        let index = Cron.cronRegister.findIndex((task) => task.id === $idOrName);
        if (index < 0) {
            index = Cron.cronRegister.findIndex((task) => task.name === $idOrName);
        }
        if (index !== -1) {
            Cron.cronRegister[index].task.stop();
            Cron.cronRegister[index].active = false;
            LogIt.Info(`Task stopped: ${$idOrName}`);
            return true;
        }
        else {
            LogIt.Warning(`Task not found: ${$idOrName}`);
            return false;
        }
    }
    /**
     * @param {string} $idOrName Task identifier or name.
     * @returns {boolean} Returns true if the task was found and removed.
     */
    RemoveTask($idOrName) {
        let index = Cron.cronRegister.findIndex((task) => task.id === $idOrName);
        if (index < 0) {
            index = Cron.cronRegister.findIndex((task) => task.name === $idOrName);
        }
        if (index !== -1) {
            Cron.cronRegister[index].task.stop();
            Cron.cronRegister.splice(index, 1);
            LogIt.Info(`Task removed: ${$idOrName}`);
            return true;
        }
        else {
            LogIt.Warning(`Task not found: ${$idOrName}`);
            return false;
        }
    }
    getCronModule() {
        if (ObjectValidator.IsEmptyOrNull(Cron.cronModule)) {
            Cron.cronModule = require("node-cron");
        }
        return Cron.cronModule;
    }
    getCronInlineTaskClass() {
        if (ObjectValidator.IsEmptyOrNull(Cron.cronInlineTaskClass)) {
            Cron.cronInlineTaskClass = require("node-cron/dist/cjs/tasks/inline-scheduled-task").InlineScheduledTask;
        }
        return Cron.cronInlineTaskClass;
    }
}
// generated-code-start
export const ICronRegister = globalThis.RegisterInterface(["active", "cronTime", "id", "name", "task"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Utils.CronConnector", CronConnector);
globalThis.RegisterClass("Io.Oidis.Localhost.Utils.Cron", Cron);
globalThis.RegisterClass("Io.Oidis.Localhost.Utils.ICronRegister", ICronRegister);
//# sourceMappingURL=Cron.js.map