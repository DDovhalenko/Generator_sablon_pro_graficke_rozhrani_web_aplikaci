/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { isBrowser } from "./../../../../Io/Oidis/Commons/Utils/EnvironmentHelper.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
const nodejsRoot = globalThis.nodejsRoot;
const isMainThread = true; // TODO: validate how it should be connected with globalThis
if (isBrowser) {
    require = (() => {
        return {};
    });
    module = {
        exports: {
            Load() {
                // loader declare
            }
        }
    };
    Buffer = {};
}
else {
    WebSocket = {}; // eslint-disable-line no-global-assign
    if (process.env.IS_OIDIS_DETACHED_PROCESS !== undefined && process.env.IS_OIDIS_DETACHED_PROCESS === "1") {
        if (!process.stdout.write) {
            process.stdout = {
                write: console.log // eslint-disable-line no-console
            };
            process.stderr = {
                write: console.log // eslint-disable-line no-console
            };
        }
        else {
            const Writable = require("stream").Writable;
            const stream = new Writable({
                write($chunk, $encoding, $callback) {
                    console.log($chunk.toString()); // eslint-disable-line no-console
                    $callback();
                }
            });
            process.stdout.write = stream.write.bind(stream);
            process.stderr.write = stream.write.bind(stream);
        }
    }
}
export class EnvironmentHelper extends BaseObject {
    /**
     * @returns {boolean} Returns true if the process has TTY access.
     */
    static IsTTY() {
        let status = false;
        if (!this.IsDetached() && process.stdout.isTTY) {
            try {
                process.stdin.setRawMode(true);
                status = true;
            }
            catch ($ex) {
                // runtime has not been detected as TTY
            }
        }
        EnvironmentHelper.IsTTY = () => {
            return status;
        };
        return status;
    }
    /**
     * @returns {boolean} Returns true if running on Windows.
     */
    static IsWindows() {
        const os = require("os");
        const status = os.platform().toString() === "win32" || os.platform().toString() === "win64";
        EnvironmentHelper.IsWindows = () => {
            return status;
        };
        return status;
    }
    /**
     * @returns {boolean} Returns true if running on Linux.
     */
    static IsLinux() {
        const status = !EnvironmentHelper.IsWindows() && !EnvironmentHelper.IsMac();
        EnvironmentHelper.IsLinux = () => {
            return status;
        };
        return status;
    }
    /**
     * @returns {boolean} Returns true if running on macOS.
     */
    static IsMac() {
        const status = require("os").platform() === "darwin";
        EnvironmentHelper.IsMac = () => {
            return status;
        };
        return status;
    }
    /**
     * @returns {boolean} Returns true if running on a 64-bit architecture.
     */
    static Is64bit() {
        const status = StringUtils.Contains(process.arch, "64") || process.env.hasOwnProperty("PROCESSOR_ARCHITEW6432") ||
            StringUtils.Contains(require("os").arch(), "64") ||
            EnvironmentHelper.IsMac();
        EnvironmentHelper.Is64bit = () => {
            return status;
        };
        return status;
    }
    /**
     * @returns {boolean} Returns true if running on ARM architecture.
     */
    static IsArm() {
        const status = StringUtils.ContainsIgnoreCase(require("os").arch(), "arm");
        EnvironmentHelper.IsArm = () => {
            return status;
        };
        return status;
    }
    /**
     * @returns {number} Returns the CPU core count.
     */
    static getCores() {
        const cores = require("os").cpus().length;
        EnvironmentHelper.getCores = () => {
            return cores;
        };
        return cores;
    }
    /**
     * @param {($status : boolean) => void} $callback Callback invoked with the elevation status.
     */
    static IsElevated($callback) {
        let status = false;
        (async () => {
            return await (await import("./../../../../../nodejs/node_modules/is-elevated/index.js")).default();
        })().then(($elevated) => {
            status = $elevated;
            EnvironmentHelper.IsElevated = ($callback) => {
                $callback(status);
            };
            $callback(status);
        }).catch((error) => {
            throw error;
        });
    }
    /**
     * @returns {boolean} Returns true if running from an embedded snapshot.
     */
    static IsEmbedded() {
        const status = StringUtils.StartsWith(__dirname, "/snapshot/");
        this.IsEmbedded = () => {
            return status;
        };
        return status;
    }
    /**
     * @returns {boolean} Returns true if running as a detached process.
     */
    static IsDetached() {
        const status = !ObjectValidator.IsEmptyOrNull(process.env.IS_OIDIS_DETACHED_PROCESS) &&
            process.env.IS_OIDIS_DETACHED_PROCESS === "1";
        this.IsDetached = () => {
            return status;
        };
        return status;
    }
    /**
     * @returns {string} Returns the Node.js root path.
     */
    static getNodejsRoot() {
        return nodejsRoot;
    }
    /**
     * @param {IProxyConfig} $config Proxy configuration to normalize.
     * @returns {IProxyConfig} Returns the normalized proxy configuration.
     */
    static NormalizeProxySetting($config) {
        const URL = require("url").URL;
        // ALL_PROXY env is accepted by curl, and it means that HTTP_PROXY=HTTPS_PROXY=ALL_PROXY if http/https are not specified
        //  and some other application uses all_proxy for ftp/ws/etc and http/https proxy then only for these protocols
        //  but this is super-corner-case supported only by some tools (rhel, partially curl+ftp,..)
        // 1: project config has higher priority
        // 2: process.env needs to have synced to its lower and upper case equivalent because some tools supports both, some only
        //      one case, and some like curl/wget are mixed (differs also over different version of the same tool [gitlab guidelines])
        // 3: no_proxy = comma separated list of machine/domain names with optional port
        //   (if no port part is present then applied for all ports for domains). Domain names should be in lowercase (except Go)
        //   and some other tools so DO NOT APPLY any toLower/toUpper to enable user to specify whatever case (but handle matching
        //   as ignorecase in JS).
        // 4: *_proxy envs will be just synced without any manipulation
        //   throw error if http_proxy and HTTP_PROXY exists in env and has different data -> user will need to fix it or
        //   if httpProxy is in config then simply override both (with warning)
        // 5: no_proxy filter: applied separately based on destination protocol (with handling of :<port> <=> protocol).
        //     pattern matching needs to be supported in order to support "*" for any count of chars, ignore leading "."
        // 6: if proxy settings are in env and not in config then sync them in (env should automatically turn on proxy)
        const checkEnvVar = ($envVar) => {
            if (ObjectValidator.IsEmptyOrNull($envVar)) {
                throw new Error("Internal error occurred, env variable is not specified for check.");
            }
            let envValue = "";
            const envVarLC = $envVar.toLowerCase();
            const envVarUC = $envVar.toUpperCase();
            if (!ObjectValidator.IsEmptyOrNull(process.env[envVarLC]) && !ObjectValidator.IsEmptyOrNull(process.env[envVarUC])) {
                if (process.env[envVarLC] !== process.env[envVarUC]) {
                    throw new Error("process.env contains both of " + envVarLC + " and " + envVarUC + " with different values");
                }
                envValue = process.env[envVarLC];
            }
            else if (!ObjectValidator.IsEmptyOrNull(process.env[envVarLC])) {
                envValue = process.env[envVarLC];
            }
            else if (!ObjectValidator.IsEmptyOrNull(process.env[envVarUC])) {
                envValue = process.env[envVarUC];
            }
            return envValue;
        };
        let httpProxy = "";
        let httpsProxy = "";
        let noProxy = "";
        if (!ObjectValidator.IsEmptyOrNull($config.httpProxy)) {
            httpProxy = $config.httpProxy;
        }
        else {
            httpProxy = checkEnvVar("http_proxy");
        }
        if (!ObjectValidator.IsEmptyOrNull($config.httpsProxy)) {
            httpsProxy = $config.httpsProxy;
        }
        else {
            httpsProxy = checkEnvVar("https_proxy");
        }
        if (!ObjectValidator.IsEmptyOrNull($config.noProxy)) {
            noProxy = $config.noProxy;
        }
        else {
            noProxy = checkEnvVar("no_proxy");
        }
        if (!ObjectValidator.IsEmptyOrNull(httpProxy)) {
            const url = new URL(httpProxy);
            if (StringUtils.StartsWith(url.protocol, "https")) {
                throw new Error("Secured proxy is not supported, please use http://<proxy>:<port> for http_proxy instead.");
            }
        }
        if (!ObjectValidator.IsEmptyOrNull(httpsProxy)) {
            const url = new URL(httpsProxy);
            if (StringUtils.StartsWith(url.protocol, "https")) {
                throw new Error("Secured proxy is not supported, please use http://<proxy>:<port> for https_proxy instead.");
            }
        }
        if (!ObjectValidator.IsEmptyOrNull(noProxy)) {
            // eslint-disable-next-line no-useless-escape
            if (!ObjectValidator.IsEmptyOrNull(noProxy.match(/[ ;\\\/!@#$%^&()_+{}\[\]]/gi))) {
                throw new Error("no_proxy option contains unsupported symbols: " + noProxy);
            }
            StringUtils.Split(noProxy, ",")
                .forEach(($part) => {
                if (!ObjectValidator.IsEmptyOrNull($part) && StringUtils.Contains($part, ":") &&
                    !($part.match(/:\d{1,5}/gi))) {
                    throw new Error("no_proxy option contains host with wrong port definition: " + $part);
                }
            });
        }
        // sync resolved env back
        process.env.http_proxy = process.env.HTTP_PROXY = $config.httpProxy = httpProxy;
        process.env.https_proxy = process.env.HTTPS_PROXY = $config.httpsProxy = httpsProxy;
        process.env.no_proxy = process.env.NO_PROXY = $config.noProxy = noProxy;
        return $config;
    }
}
export { nodejsRoot, isMainThread };
globalThis.RegisterClass("Io.Oidis.Localhost.Utils.EnvironmentHelper", EnvironmentHelper);
//# sourceMappingURL=EnvironmentHelper.js.map