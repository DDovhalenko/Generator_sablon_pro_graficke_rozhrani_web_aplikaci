/*! ******************************************************************************************************** *
 *
 * Copyright 2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { LogSeverity } from "./../../../../Io/Oidis/Commons/Enums/LogSeverity.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Loader } from "../Loader.js";
import { EnvironmentHelper } from "./EnvironmentHelper.js";
export class FirewallManager extends BaseObject {
    /**
     * @param {string} $groupName Firewall rule group name.
     * @param {string} $serviceName Windows service name.
     * @param {string} $appName Display name for the firewall rule.
     * @param {string} $description Description of the firewall rule.
     * @param {string} $servicePath Path to the service executable.
     * @param {() => void} $callback Callback invoked after the operation completes.
     */
    static AddServiceRule($groupName, $serviceName, $appName, $description, $servicePath, $callback) {
        const release = parseFloat(require("os").release);
        if (EnvironmentHelper.IsWindows() && release >= 6.0) {
            EnvironmentHelper.IsElevated(($status) => {
                if ($status) {
                    if (!StringUtils.EndsWith($servicePath, ".exe")) {
                        $servicePath += ".exe";
                    }
                    $servicePath = Loader.getInstance().getFileSystemHandler().NormalizePath($servicePath, true);
                    Loader.getInstance().getTerminal().Execute("netsh.exe", [
                        "advfirewall", "firewall", "show", "rule",
                        "name=\"" + $appName + "\"",
                        "verbose"
                    ], { verbose: false }, ($exitCode, $std) => {
                        if (($exitCode === 0 && !StringUtils.IsEmpty($std[0])) ||
                            ($exitCode === 1 && StringUtils.Contains($std[0], "No rules match the specified criteria"))) {
                            if (!StringUtils.Contains($std[0], $servicePath)) {
                                Loader.getInstance().getTerminal().Spawn("netsh.exe", [
                                    "advfirewall", "firewall", "add", "rule",
                                    "name=\"" + $appName + "\"",
                                    "dir=in",
                                    "action=allow",
                                    "program=\"" + $servicePath + "\"",
                                    "service=\"" + $serviceName + "\"",
                                    "description=\"" + $description + "\"",
                                    "enable=yes",
                                    "profile=any"
                                ], null, ($exitCode, $std) => {
                                    if ($exitCode !== 0) {
                                        LogIt.Warning("Firewall Rule Add failed.");
                                    }
                                    $callback();
                                });
                            }
                            else {
                                LogIt.Warning("Adding of service rule skipped: rule already exists");
                                $callback();
                            }
                        }
                        else {
                            LogIt.Warning("Unable to get list of Firewall rules.");
                            $callback();
                        }
                    });
                }
                else {
                    LogIt.Info("Add firewall rule skipped: running without admin rights", LogSeverity.LOW);
                    $callback();
                }
            });
        }
        else {
            LogIt.Debug("Add firewall rule skipped: supported only on WINDOWS 7+");
            $callback();
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.Utils.FirewallManager", FirewallManager);
//# sourceMappingURL=FirewallManager.js.map