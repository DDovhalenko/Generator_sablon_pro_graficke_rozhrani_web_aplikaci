/*! ******************************************************************************************************** *
 *
 * Copyright 2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpStatusType } from "./../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { IHttpRequestResolver } from "./../../../../Io/Oidis/Commons/Interfaces/IHttpRequestResolver.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { Loader } from "../Loader.js";
import { JsonUtils } from "./../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { DataFormatType } from "./../../../../Io/Oidis/Commons/Enums/DataFormatType.js";
export class Metrics extends BaseObject {
    static apm;
    instrumented;
    isStarted;
    stats;
    /**
     * @returns {Metrics} Returns the singleton instance.
     */
    static getInstance() {
        const instance = new Metrics();
        this.getInstance = () => {
            return instance;
        };
        return instance;
    }
    /**
     * @param {string | Error} $message Error message or Error object to capture.
     */
    static Error($message) {
        this.getInstance().Error($message);
    }
    constructor() {
        super();
        this.instrumented = [];
        this.isStarted = false;
        const config = Loader.getInstance().getAppConfiguration().target.metrics;
        const serverUrl = "http://" + config.location + ":" + config.port;
        try {
            if (config.enabled) {
                if (ObjectValidator.IsEmptyOrNull(Metrics.apm)) {
                    Metrics.apm = require("elastic-apm-node").start({
                        active: true,
                        frameworkName: "Oidis Framework",
                        frameworkVersion: ">= 2019.0",
                        ignoreUrls: [/^\//i],
                        serverUrl,
                        serviceName: Loader.getInstance().getEnvironmentArgs().getAppName(),
                        serviceVersion: Loader.getInstance().getEnvironmentArgs().getProjectVersion()
                    });
                }
                LogIt.Info("Started sending of monitoring data to: " + serverUrl);
                this.isStarted = true;
                this.Instrument();
            }
            else {
                LogIt.Debug("Server monitoring has been disable for this instance.");
            }
        }
        catch (ex) {
            LogIt.Warning("Failed to start monitoring agent.\n" + ex.stack);
        }
        this.stats = {
            ws: {
                inbound: {
                    data: [],
                    count: 0,
                    max: 0,
                    sum: 0,
                    avg: 0,
                    binaryCount: 0
                },
                outbound: {
                    data: [],
                    count: 0,
                    max: 0,
                    sum: 0,
                    avg: 0,
                    binaryCount: 0
                }
            },
            http: {
                inbound: {
                    data: [],
                    count: 0,
                    max: 0,
                    sum: 0,
                    avg: 0,
                    binaryCount: 0
                },
                outbound: {
                    data: [],
                    count: 0,
                    max: 0,
                    sum: 0,
                    avg: 0,
                    binaryCount: 0
                }
            }
        };
    }
    /**
     * @param {any[]} $namespaces Optional additional namespaces to instrument.
     */
    Instrument($namespaces) {
        if (Loader.getInstance().getAppConfiguration().target.metrics.enabled && this.isStarted) {
            LogIt.Debug("Instrumenting code for monitoring...");
            try {
                if (ObjectValidator.IsEmptyOrNull($namespaces)) {
                    $namespaces = [];
                }
                $namespaces.push(IHttpRequestResolver, globalThis.Io.Oidis.Localhost.Connectors);
                const include = [];
                const collectClasses = ($namespaces) => {
                    $namespaces.forEach(($type) => {
                        if (!ObjectValidator.IsString($type)) {
                            if ($type.hasOwnProperty("ClassName")) {
                                $type = $type.ClassName();
                            }
                            else {
                                const subnamespaces = [];
                                let property;
                                for (property in $type) {
                                    if ($type.hasOwnProperty(property)) {
                                        subnamespaces.push($type[property]);
                                    }
                                }
                                collectClasses(subnamespaces);
                            }
                        }
                        if (!include.includes($type)) {
                            include.push($type);
                        }
                    });
                };
                collectClasses($namespaces);
                let classesCount = 0;
                let methodsCount = 0;
                const wrapMethods = ($api, $class, $type) => {
                    let property;
                    for (property in $api) {
                        if ($api.hasOwnProperty(property) && ObjectValidator.IsFunction($api[property]) &&
                            !this.instrumented.includes($class + "." + property + "[" + $type + "]")) {
                            const origMethod = $api[property];
                            const trace = $class + "." + property;
                            $api[property] = function (...$args) {
                                const span = Metrics.apm.startSpan(trace, $type);
                                const returnValue = origMethod.apply(this, $args);
                                if (span) {
                                    span.end();
                                }
                                return returnValue;
                            };
                            methodsCount++;
                            this.instrumented.push($class + "." + property + "[" + $type + "]");
                        }
                    }
                };
                const reflection = Reflection.getInstance();
                reflection.getAllClasses().forEach(($class) => {
                    let instrument = false;
                    include.forEach(($type) => {
                        if ($class === $type || reflection.ClassHasInterface($class, $type)) {
                            instrument = true;
                        }
                    });
                    if (instrument) {
                        const definition = reflection.getClass($class);
                        wrapMethods(definition, $class, "static");
                        wrapMethods(definition.prototype, $class, "instance");
                        classesCount++;
                    }
                });
                LogIt.Debug("Instrumented {0} methods in {1} monitored classes.", methodsCount.toString(), classesCount.toString());
            }
            catch (ex) {
                LogIt.Warning(ex.stack);
            }
        }
    }
    /**
     * @param {string} $owner Transaction owner identifier.
     * @param {string} $type Transaction type.
     */
    Start($owner, $type) {
        if (this.isStarted) {
            Metrics.apm.startTransaction($owner, $type);
        }
    }
    /**
     * @param {HttpStatusType} $result Optional HTTP status result for the transaction.
     * @param {boolean} $force Whether to force-flush the APM data.
     */
    End($result, $force = false) {
        if (this.isStarted) {
            if (ObjectValidator.IsEmptyOrNull($result)) {
                $result = HttpStatusType.SUCCESS;
            }
            Metrics.apm.setCustomContext({
                heap: process.memoryUsage()
            });
            Metrics.apm.endTransaction($result);
            if ($force) {
                Metrics.apm.flush(($error) => {
                    if (!ObjectValidator.IsEmptyOrNull($error)) {
                        LogIt.Warning($error.stack);
                    }
                });
            }
        }
    }
    /**
     * @param {string | Error} $message Error message or Error object to capture.
     */
    Error($message) {
        if (this.isStarted) {
            Metrics.apm.captureError($message);
        }
    }
    /**
     * @param {IMetricsTrafficData} $data Traffic measurement data to record.
     */
    AddMeasurement($data) {
        const startType = this.stats[$data.type];
        const statRecord = $data.inbound ? startType.inbound : startType.outbound;
        statRecord.data.push({
            time: new Date().getTime(),
            size: $data.size
        });
        statRecord.count++;
        if ($data.format === DataFormatType.BINARY) {
            statRecord.binaryCount++;
        }
        statRecord.max = Math.max(statRecord.max, $data.size);
        statRecord.sum += $data.size;
        const newData = [];
        const now = new Date().getTime();
        statRecord.data.forEach(($item) => {
            if (now - $item.time < 60 * 1000) {
                newData.push($item);
            }
        });
        statRecord.data = newData;
        statRecord.avg = this.getAvg(statRecord.data);
    }
    /**
     * @returns {any} Returns the cloned statistics object.
     */
    getStats() {
        return JsonUtils.Clone(this.stats);
    }
    getAvg($values) {
        if ($values.length === 0) {
            return 0;
        }
        let sum = 0;
        $values.forEach(($value) => {
            sum += $value.size;
        });
        return Math.round(sum / $values.length);
    }
}
// generated-code-start
export const IMetricsTrafficData = globalThis.RegisterInterface(["type", "inbound", "size", "format"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Utils.Metrics", Metrics);
globalThis.RegisterClass("Io.Oidis.Localhost.Utils.IMetricsTrafficData", IMetricsTrafficData);
//# sourceMappingURL=Metrics.js.map