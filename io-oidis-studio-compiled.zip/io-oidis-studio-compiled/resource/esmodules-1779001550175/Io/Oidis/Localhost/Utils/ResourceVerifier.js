/*! ******************************************************************************************************** *
 *
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Loader } from "../Loader.js";
export class ResourceVerifier extends BaseObject {
    /**
     * @param {Buffer} $data Encrypted data buffer containing IV, auth tag, and ciphertext.
     * @param {Buffer} $key Decryption key.
     * @returns {Buffer} Returns the decrypted data buffer or null on failure.
     */
    static DecryptResource($data, $key) {
        const iv = $data.subarray(0, 16);
        const tag = $data.subarray(16, 32);
        const dataEnc = $data.subarray(32);
        const decipher = require("crypto").createDecipheriv("aes-256-gcm", $key, iv);
        decipher.setAuthTag(tag);
        let dec = null;
        try {
            const tmp = decipher.update(dataEnc);
            const final = decipher.final();
            dec = Buffer.concat([tmp, final]);
        }
        catch (ex) {
            LogIt.Error(this.ClassName(), ex);
        }
        return dec;
    }
    /**
     * @param {string} $publicKey Public key for signature verification.
     * @param {any} $map Map of resource names to their expected signatures.
     * @returns {boolean} Returns true if all resources pass verification.
     */
    static VerifyMap($publicKey, $map) {
        let success = true;
        const filesystem = Loader.getInstance().getFileSystemHandler();
        for (const resourceName in $map) {
            if (Object.prototype.hasOwnProperty.call($map, resourceName)) {
                if (!filesystem.Exists(resourceName)) {
                    success = false;
                    break;
                }
                if (!ResourceVerifier.VerifyByName(filesystem.Read(resourceName), $publicKey, $map, resourceName)) {
                    success = false;
                    break;
                }
            }
        }
        return success;
    }
    /**
     * @param {Buffer} $dataToVerify Data buffer to verify.
     * @param {string} $publicKey Public key for signature verification.
     * @param {any} $map Protection map containing expected signatures.
     * @param {string} $name Resource name to look up in the map.
     * @returns {boolean} Returns true if the signature is valid.
     */
    static VerifyByName($dataToVerify, $publicKey, $map, $name) {
        if (ObjectValidator.IsEmptyOrNull($map) || !$map.hasOwnProperty($name)) {
            return false;
        }
        return ResourceVerifier.VerifySignature($dataToVerify, $publicKey, $map[$name]);
    }
    /**
     * @param {Buffer} $dataToVerify Data buffer to verify.
     * @param {string} $publicKey Public key for verification.
     * @param {string} $signature Expected hex-encoded signature.
     * @returns {boolean} Returns true if the signature matches.
     */
    static VerifySignature($dataToVerify, $publicKey, $signature) {
        if (ObjectValidator.IsEmptyOrNull($publicKey) || ObjectValidator.IsEmptyOrNull($signature)) {
            return false;
        }
        const verify = require("crypto").createVerify("sha512");
        verify.write($dataToVerify);
        verify.end();
        return verify.verify($publicKey, $signature, "hex");
    }
    /**
     * @param {Buffer} $dataToVerify Data buffer to hash and verify.
     * @param {any} $protectionMap Map containing expected hash values.
     * @param {string} $name Resource name to look up in the protection map.
     * @returns {boolean} Returns true if the hash matches.
     */
    static VerifyHash($dataToVerify, $protectionMap, $name) {
        if (ObjectValidator.IsEmptyOrNull($protectionMap) || !$protectionMap.hasOwnProperty($name)) {
            return false;
        }
        const hashEngine = require("crypto").createHash("sha512");
        hashEngine.update($dataToVerify);
        return $protectionMap[$name] === hashEngine.digest().toString("hex");
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.Utils.ResourceVerifier", ResourceVerifier);
//# sourceMappingURL=ResourceVerifier.js.map