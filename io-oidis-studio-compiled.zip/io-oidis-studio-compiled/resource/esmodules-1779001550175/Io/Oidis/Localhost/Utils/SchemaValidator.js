/*! ******************************************************************************************************** *
 *
 * Copyright 2020-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { Convert } from "./../../../../Io/Oidis/Commons/Utils/Convert.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
export class SchemaValidator extends BaseObject {
    errorHandler;
    validator;
    schema;
    constructor() {
        super();
        const ZSchema = require("z-schema");
        this.validator = new ZSchema({
            assumeAdditional: true,
            noExtraKeywords: true
        });
        this.schema = {};
        this.errorHandler = ($error) => {
            throw $error;
        };
    }
    /**
     * @param {($error : Error | ErrorEvent) => void} $handler Error handler callback.
     */
    ErrorHandler($handler) {
        if (!ObjectValidator.IsEmptyOrNull($handler)) {
            this.errorHandler = $handler;
        }
    }
    /**
     * @param {any} $value Optional schema object or file path to load.
     * @param {any} $formats Optional custom format validators to register.
     * @returns {any} Returns the current schema object.
     */
    Schema($value, $formats) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            if (ObjectValidator.IsString($value)) {
                const fs = require("fs");
                $value = require("path").normalize($value);
                if (fs.existsSync($value)) {
                    try {
                        this.schema = JSON.parse(fs.readFileSync($value).toString());
                    }
                    catch (ex) {
                        this.errorHandler(new Error("> failed parsing of schema\n" + ex.stack));
                    }
                }
                else if (ObjectValidator.IsObject($value)) {
                    this.errorHandler(new Error("> schema not found at: " + $value));
                }
                else {
                    this.errorHandler(new Error("> unsupported schema type: " + Convert.ToType($value)));
                }
            }
            else {
                this.schema = $value;
            }
        }
        if (!ObjectValidator.IsEmptyOrNull($formats)) {
            const ZSchema = require("z-schema");
            let format;
            for (format in $formats) {
                if ($formats.hasOwnProperty(format)) {
                    ZSchema.registerFormat(format, $formats[format]);
                }
            }
        }
        return this.schema;
    }
    /**
     * @param {any} $value Value to validate.
     * @param {string} $parentKey Root path key for error reporting.
     * @returns {ISchemaError[]} Returns an array of validation errors.
     */
    Validate($value, $parentKey = "#") {
        try {
            const errors = [];
            this.validator.validate($value, this.schema);
            const schemaErrors = this.validator.getLastErrors();
            if (!ObjectValidator.IsEmptyOrNull(schemaErrors)) {
                schemaErrors.forEach(($schemaError) => {
                    const fields = StringUtils.Split(StringUtils.Remove($schemaError.path, "#/"), "/");
                    let value = $value;
                    const iterate = ($index = 0) => {
                        if ($index < fields.length) {
                            if (value.hasOwnProperty(fields[$index])) {
                                value = value[fields[$index]];
                                iterate($index + 1);
                            }
                        }
                    };
                    iterate();
                    if (ObjectValidator.IsObject(value) || ObjectValidator.IsArray(value)) {
                        value = JSON.stringify(value);
                    }
                    let fieldsToString = "";
                    fields.forEach(($field) => {
                        if (ObjectValidator.IsInteger($field)) {
                            fieldsToString += "[" + $field + "]";
                        }
                        else {
                            fieldsToString += "." + $field;
                        }
                    });
                    errors.push({
                        message: $schemaError.message,
                        field: $parentKey + fieldsToString,
                        value
                    });
                });
            }
            return errors;
        }
        catch (ex) {
            this.errorHandler(new Error("> failed processing of validation\n" + ex.stack));
            return [];
        }
    }
    /**
     * @param {ISchemaError[]} $errors Array of schema validation errors.
     * @param {boolean} $includeValue Whether to include the failing value in output.
     * @returns {string} Returns the formatted error string.
     */
    ErrorsToString($errors, $includeValue = false) {
        let messages = "";
        const singleError = $errors.length === 1;
        let index = 1;
        $errors.forEach(($error) => {
            messages +=
                (singleError ? "> " : "[" + index + "] ") + "field " + $error.field + ", error: " + $error.message + "\n" +
                    ($includeValue ? "    " + $error.value + "\n" : "");
            index++;
        });
        return messages;
    }
}
// generated-code-start
export const ISchemaError = globalThis.RegisterInterface(["message", "field", "value"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Utils.SchemaValidator", SchemaValidator);
globalThis.RegisterClass("Io.Oidis.Localhost.Utils.ISchemaError", ISchemaError);
//# sourceMappingURL=SchemaValidator.js.map