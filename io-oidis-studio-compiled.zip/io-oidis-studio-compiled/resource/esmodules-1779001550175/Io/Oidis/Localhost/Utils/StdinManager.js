/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { ColorType } from "../Enums/ColorType.js";
import { StdinType } from "../Enums/StdinType.js";
import { Loader } from "../Loader.js";
import { EnvironmentHelper } from "./EnvironmentHelper.js";
export class StdinManager extends BaseObject {
    questions;
    question;
    passwordCharacter;
    index;
    prefixLength;
    cursorPosition;
    onCompleteHandler;
    onKeyPressHandler;
    /**
     * @param {IStdinQuestion[]} $questions Array of questions to present.
     * @param {() => void} $callback Callback invoked after all questions are processed.
     */
    static Process($questions, $callback) {
        const manager = this.getInstance();
        manager.setQuestions($questions);
        manager.setOnComplete($callback);
        manager.NextQuestion();
    }
    /**
     * @param {IStdinQuestion[]} $questions Array of questions to present.
     * @returns {Promise<void>} Returns a promise that resolves when all questions are processed.
     */
    static async ProcessAsync($questions) {
        return await new Promise(($resolve) => {
            StdinManager.Process($questions, $resolve);
        });
    }
    /**
     * @returns {StdinManager} Returns the singleton instance.
     */
    static getInstance() {
        const instance = new StdinManager();
        this.getInstance = () => {
            return instance;
        };
        return instance;
    }
    constructor() {
        super();
        this.questions = [];
        this.index = 0;
        this.prefixLength = 0;
        this.cursorPosition = 0;
        this.passwordCharacter = "*";
        this.onCompleteHandler = () => {
            // default handler
        };
        this.onKeyPressHandler = ($value, $skipped) => {
            if (!$skipped) {
                process.stdout.write(" >>"[ColorType.YELLOW] + " processed");
                this.question.callback(this.question.value, ($status) => {
                    if ($status) {
                        this.NextQuestion();
                    }
                    else {
                        process.stdout.write("Unable to process cmd input."[ColorType.RED]);
                    }
                });
            }
            else {
                process.stdout.write(" >>"[ColorType.RED] + " skipped");
                this.NextQuestion();
            }
        };
        this.init();
    }
    /**
     * @param {string} $value Masking character.
     */
    setPasswordCharacter($value) {
        this.passwordCharacter = Property.String(this.passwordCharacter, $value);
    }
    /**
     * @param {IStdinQuestion[]} $value Array of questions to set.
     */
    setQuestions($value) {
        this.index = 0;
        this.questions = $value;
    }
    /**
     * @param {() => void} $callback Completion callback.
     */
    setOnComplete($callback) {
        if (ObjectValidator.IsFunction($callback)) {
            this.onCompleteHandler = $callback;
        }
    }
    /**
     * @param {($value : string, $skipped : boolean) => void} $callback Key press callback.
     */
    setOnKeyPress($callback) {
        if (ObjectValidator.IsFunction($callback)) {
            this.onKeyPressHandler = $callback;
        }
    }
    NextQuestion() {
        if (this.index < this.questions.length) {
            this.question = this.questions[this.index];
            this.index++;
            if (!process.env.IS_WUI_PROXY_TASK && !EnvironmentHelper.IsTTY() && this.question.hidden) {
                process.stdout.write(this.question.prefix + ":");
                process.stdout.write(" >>"[ColorType.RED] + " skipped. " +
                    "Hidden stdin can be processed only inside a text terminal (\"TTY\") context.");
                this.NextQuestion();
            }
            else {
                this.question.value = "";
                process.stdin.setEncoding("utf8");
                const prefix = this.question.prefix + ": ";
                if (process.env.IS_WUI_PROXY_TASK) {
                    if (this.question.hidden) {
                        process.stdout.write(prefix + StdinType.PASS);
                    }
                    else {
                        process.stdout.write(prefix + StdinType.STRING);
                    }
                }
                else {
                    this.prefixLength = prefix.length;
                    this.cursorPosition = this.prefixLength;
                    process.stdout.write(prefix);
                    process.stdin.resume();
                }
            }
        }
        else {
            this.onCompleteHandler();
        }
    }
    init() {
        if (EnvironmentHelper.IsTTY()) {
            const readline = require("readline");
            readline.emitKeypressEvents(process.stdin);
            process.stdin.setRawMode(true);
            const moveTo = ($index) => {
                readline.cursorTo(process.stdout, $index);
                this.cursorPosition = $index;
            };
            const printLine = ($message) => {
                readline.clearLine(process.stdout, 0);
                readline.cursorTo(process.stdout, 0);
                let line = this.question.prefix + ": ";
                if (this.question.hidden) {
                    line += Array($message.length + 1).join(this.passwordCharacter);
                }
                else {
                    line += $message;
                }
                process.stdout.write(line);
                readline.cursorTo(process.stdout, this.cursorPosition);
            };
            const removeAtCursorPosition = () => {
                if (this.question.value.length > 0) {
                    const index = this.cursorPosition - this.prefixLength + 1;
                    this.question.value = this.question.value.substring(0, index - 1) +
                        this.question.value.substring(index, this.question.value.length);
                    printLine(this.question.value);
                }
            };
            const getEndPosition = () => {
                return this.prefixLength + this.question.value.length;
            };
            process.stdin.on("keypress", ($character, $key) => {
                if ($key.ctrl && $key.name === "c" && EnvironmentHelper.IsDetached()) {
                    Loader.getInstance().Exit();
                }
                else if ($key.name === "escape" || ($key.name === "return" && this.question.value === "")) {
                    moveTo(getEndPosition());
                    this.onKeyPressHandler("", true);
                }
                else if ($key.name === "return") {
                    moveTo(getEndPosition());
                    this.onKeyPressHandler(this.question.value + "", false);
                }
                else if ($key.name === "left") {
                    this.cursorPosition--;
                    if (this.cursorPosition < this.prefixLength) {
                        this.cursorPosition = this.prefixLength;
                    }
                    moveTo(this.cursorPosition);
                }
                else if ($key.name === "right") {
                    this.cursorPosition++;
                    const maxPosition = getEndPosition();
                    if (this.cursorPosition > maxPosition) {
                        this.cursorPosition = maxPosition;
                    }
                    moveTo(this.cursorPosition);
                }
                else if ($key.name === "down" || $key.name === "home") {
                    moveTo(this.prefixLength);
                }
                else if ($key.name === "up" || $key.name === "end") {
                    moveTo(getEndPosition());
                }
                else if ($key.name === "backspace") {
                    if (this.cursorPosition > this.prefixLength) {
                        this.cursorPosition--;
                        removeAtCursorPosition();
                    }
                }
                else if ($key.name === "delete") {
                    removeAtCursorPosition();
                }
                else if (!ObjectValidator.IsEmptyOrNull($character)) {
                    const endPosition = getEndPosition();
                    if (this.cursorPosition < endPosition) {
                        const addAt = this.cursorPosition - this.prefixLength;
                        this.question.value =
                            this.question.value.substring(0, addAt) +
                                $character +
                                this.question.value.substring(addAt, this.question.value.length);
                        this.cursorPosition++;
                    }
                    else {
                        this.question.value += $character;
                        this.cursorPosition = getEndPosition();
                    }
                    printLine(this.question.value);
                }
            });
        }
        else {
            process.stdin.on("data", ($value) => {
                $value = $value.toString().trim();
                if (ObjectValidator.IsEmptyOrNull($value)) {
                    this.onKeyPressHandler("", true);
                }
                else {
                    this.question.value = $value;
                    this.onKeyPressHandler(this.question.value + "", false);
                }
            });
        }
    }
}
// generated-code-start
export const IStdinQuestion = globalThis.RegisterInterface(["prefix", "callback", "hidden", "value"]);
globalThis.RegisterClass("Io.Oidis.Localhost.Utils.StdinManager", StdinManager);
globalThis.RegisterClass("Io.Oidis.Localhost.Utils.IStdinQuestion", IStdinQuestion);
//# sourceMappingURL=StdinManager.js.map