/*! ******************************************************************************************************** *
 *
 * Copyright 2022-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseObject } from "./../../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { JsonUtils } from "./../../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { Loader } from "../../Loader.js";
export class WebSocket extends BaseObject {
    static CONNECTING = 0;
    static OPEN = 1;
    static CLOSING = 2;
    static CLOSED = 3;
    onopen;
    onclose;
    onmessage;
    onerror;
    readyState;
    client;
    static setLogItClass() {
        // fallback for older builder
    }
    constructor($url, $protocols, $requestOptions) {
        super();
        const options = new URL($url);
        if (process.env.hasOwnProperty("DISABLE_STRICT_SSL") || Loader.getInstance().getAppConfiguration().disableStrictSSL) {
            options.strictSSL = false;
            options.rejectUnauthorized = false;
        }
        // TODO(mkelnar) another workaround for latent object incompatibility with strictly defined URL type, reverted extend order
        //  (extend is not working with accessors), so resulting object is URL with latent extension
        //  -> TO BE properly fixed in comming future
        JsonUtils.Extend(options, $requestOptions);
        this.onopen = () => {
            // default handler
        };
        this.onclose = () => {
            // default handler
        };
        this.onmessage = () => {
            // default handler
        };
        this.onerror = () => {
            // default handler
        };
        this.initCommunication({
            protocols: $protocols,
            url: options
        });
    }
    close() {
        try {
            this.client.close();
        }
        catch (ex) {
            this.readyState = this.client.readyState;
            throw ex;
        }
    }
    /**
     * @param {any} $data The data to send through the connection.
     */
    send($data) {
        if (this.client.readyState === WebSocket.OPEN) {
            try {
                this.client.send($data);
            }
            catch (ex) {
                this.readyState = this.client.readyState;
                throw ex;
            }
        }
        else {
            throw new Error("Unable to send data to socket server: connection not open to " + this.client.url);
        }
    }
    initCommunication($options) {
        Loader.getInstance().getHttpResolver().FetchHelper($options)
            .then(($environment) => {
            const options = $environment.options;
            this.client = new ($environment.client)(options.url.href, options.protocols, false, false, {
                agent: options.url.agent,
                rejectUnauthorized: options.url.rejectUnauthorized,
                strictSSL: options.url.strictSSL
            });
            this.client.onopen = () => {
                this.readyState = this.client.readyState;
                this.onopen();
            };
            this.client.onclose = () => {
                this.readyState = this.client.readyState;
                this.onclose();
            };
            this.client.onmessage = ($event) => {
                this.readyState = this.client.readyState;
                this.onmessage($event);
            };
            this.client.onerror = () => {
                this.readyState = this.client.readyState;
                this.onerror();
            };
        })
            .catch(($error) => {
            this.readyState = WebSocket.CLOSED;
            this.onerror($error);
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Localhost.WebServiceApi.Clients.WebSocket", WebSocket);
//# sourceMappingURL=WebSocket.js.map