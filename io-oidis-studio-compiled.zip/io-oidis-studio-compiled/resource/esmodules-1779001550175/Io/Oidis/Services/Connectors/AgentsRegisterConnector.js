import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { EventType } from "./../../../../Io/Oidis/Gui/Enums/Events/EventType.js";
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
import { LiveContentWrapper } from "../WebServiceApi/LiveContentWrapper.js";
import { IAcknowledgePromise } from "./ReportServiceConnector.js";
/**
 * Abstract base implementing agent registration and communication operations shared by both
 * callback and async connector variants. Connects to the Oidis Hub AgentsRegister service
 * to manage agent lifecycle, forwarding, and status tracking via LCP.
 */
class BaseAgentsRegisterConnector extends BaseConnector {
    constructor($reconnect = true, $serverConfigurationSource) {
        super($reconnect, $serverConfigurationSource, WebServiceClientType.HUB_CONNECTOR);
    }
    /**
     * Register a new agent with the Hub, providing its capabilities descriptor.
     * @param {IAgentCapabilities} $capabilities Specify agent capabilities to register.
     * @returns {IAgentsRegisterPromise} Returns promise with registration result and streaming messages.
     */
    RegisterAgent($capabilities) {
        const callbacks = {
            onComplete($success) {
                // declare default callback
            },
            onError: null,
            onMessage($data) {
                // declare default callback
            }
        };
        LiveContentWrapper.InvokeMethod(this.getClient(), this.getServerNamespace(), "RegisterAgent", $capabilities)
            .OnError(($error, ...$args) => {
            this.errorHandler(callbacks.onError, $error, $args);
        })
            .Then(($result) => {
            if (ObjectValidator.IsSet($result.type)) {
                if ($result.type === EventType.ON_CHANGE) {
                    callbacks.onMessage($result.data);
                }
            }
            else if (ObjectValidator.IsBoolean($result)) {
                callbacks.onComplete($result);
            }
        });
        const promise = {
            OnError: ($callback) => {
                callbacks.onError = $callback;
                return promise;
            },
            OnMessage: ($callback) => {
                callbacks.onMessage = $callback;
                return promise;
            },
            Then: ($callback) => {
                callbacks.onComplete = $callback;
            }
        };
        return promise;
    }
    /**
     * Forward a message to a specific registered agent by its unique identifier.
     * @param {string} $agentId Specify the target agent identifier.
     * @param {any} $data Specify the message payload to forward.
     * @returns {IAcknowledgePromise} Returns promise with forwarding acknowledgement.
     */
    ForwardMessage($agentId, $data) {
        return this.invoke("ForwardMessage", $agentId, $data);
    }
    /**
     * Retrieve the list of all currently registered agents from the Hub.
     * @returns {IAgentsListPromise} Returns promise with the array of agent descriptors.
     */
    getAgentsList() {
        return this.invoke("getAgentsList");
    }
    /**
     * Start the WebSocket communication channel with the Hub for real-time agent messaging.
     */
    StartCommunication() {
        this.getClient().StartCommunication();
    }
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.HUB_CONNECTOR] = "Io.Oidis.Hub.Primitives.AgentsRegister";
        return namespaces;
    }
    resolveDefaultOptions($options) {
        const options = super.resolveDefaultOptions($options);
        if (ObjectValidator.IsEmptyOrNull(options.serverConfigurationSource)) {
            options.serverConfigurationSource = "https://hub.oidis.io/connector.config.jsonp";
        }
        return options;
    }
}
/**
 * AgentsRegisterConnector class provides wrapping of Oidis Hub register of connected agents.
 */
export class AgentsRegisterConnector extends BaseAgentsRegisterConnector {
    /**
     * Register a new agent with the Hub, providing its capabilities descriptor.
     * @param {IAgentCapabilities} $capabilities Specify agent capabilities to register.
     * @returns {IAgentsRegisterPromise} Returns promise with registration result and streaming messages.
     */
    RegisterAgent($capabilities) {
        return super.RegisterAgent($capabilities);
    }
    /**
     * Forward a message to a specific registered agent by its unique identifier.
     * @param {string} $agentId Specify the target agent identifier.
     * @param {any} $data Specify the message payload to forward.
     * @returns {IAcknowledgePromise} Returns promise with forwarding acknowledgement.
     */
    ForwardMessage($agentId, $data) {
        return super.ForwardMessage($agentId, $data);
    }
    /**
     * Retrieve the list of all currently registered agents from the Hub.
     * @returns {IAgentsListPromise} Returns promise with the array of agent descriptors.
     */
    getAgentsList() {
        return super.getAgentsList();
    }
}
/**
 * AgentsRegisterConnectorAsync provides the same wrapping as AgentsRegisterConnector
 * but with native Promise-based API for async/await usage.
 */
export class AgentsRegisterConnectorAsync extends BaseAgentsRegisterConnector {
    /**
     * Register a new agent with the Hub using native Promise.
     * @param {IAgentCapabilities} $capabilities Specify agent capabilities to register.
     * @param {IRegisterAgentHandlers} [$handlers] Specify optional handlers for streaming messages.
     * @returns {Promise<boolean>} Returns promise resolving to registration success status.
     */
    RegisterAgent($capabilities, $handlers) {
        return new Promise(($resolve, $reject) => {
            try {
                const promise = super.RegisterAgent($capabilities);
                if (!ObjectValidator.IsEmptyOrNull($handlers)) {
                    if (!ObjectValidator.IsEmptyOrNull($handlers.onMessage)) {
                        promise.OnMessage($handlers.onMessage);
                    }
                }
                if (!ObjectValidator.IsEmptyOrNull(promise.OnError)) {
                    promise.OnError(($error) => {
                        $reject(new Error($error.Message()));
                    });
                }
                promise.Then(($success) => {
                    $resolve($success);
                });
            }
            catch (ex) {
                $reject(ex);
            }
        });
    }
    /**
     * Forward a message to a specific registered agent.
     * @param {string} $agentId Specify the target agent identifier.
     * @param {any} $data Specify the message payload to forward.
     * @returns {Promise<boolean>} Returns promise resolving to forwarding success status.
     */
    ForwardMessage($agentId, $data) {
        return this.asyncInvoke(super.ForwardMessage, $agentId, $data);
    }
    /**
     * Retrieve the list of all currently registered agents.
     * @returns {Promise<IAgentInfo[]>} Returns promise resolving to array of agent descriptors.
     */
    getAgentsList() {
        return this.asyncInvoke(super.getAgentsList);
    }
    /**
     * Retrieve metadata (configuration and environment) for a specific agent.
     * @param {string} $agentId Specify the agent identifier.
     * @returns {Promise<IAgentMetadata>} Returns promise resolving to agent metadata.
     */
    getAgentsMetadata($agentId) {
        return this.asyncInvoke("getAgentsMetadata", $agentId);
    }
    /**
     * Update the operational status of a registered agent.
     * @param {string} $agentId Specify the agent identifier.
     * @param {IAgentStatus} $status Specify the new agent status.
     * @returns {Promise<void>} Returns promise resolving when status is updated.
     */
    setAgentStatus($agentId, $status) {
        return this.asyncInvoke("setAgentStatus", $agentId, $status);
    }
    /**
     * Validate an agent by its identifier on the Hub.
     * @param {string} $agentId Specify the agent identifier to validate.
     * @returns {Promise<void>} Returns promise resolving when validation completes.
     */
    ValidateAgent($agentId) {
        return this.asyncInvoke("ValidateAgent", $agentId);
    }
    /**
     * Set the authorization state (authorized/revoked) for a registered agent.
     * @param {string} $agentId Specify the agent identifier.
     * @param {boolean} $authorized Specify whether the agent is authorized.
     * @returns {Promise<void>} Returns promise resolving when authorization state is updated.
     */
    setAgentAuthorizedState($agentId, $authorized) {
        return this.asyncInvoke("setAgentAuthorizedState", $agentId, $authorized);
    }
    /**
     * Generate a handshake token for a specific agent used during agent authentication.
     * @param {string} $agentId Specify the agent identifier.
     * @returns {Promise<string>} Returns promise resolving to the handshake token string.
     */
    getAgentHandshakeToken($agentId) {
        return this.asyncInvoke("getAgentHandshakeToken", $agentId);
    }
}
/** Operational status of a registered agent. */
export var IAgentStatus;
(function (IAgentStatus) {
    IAgentStatus[IAgentStatus["Idle"] = 0] = "Idle";
    IAgentStatus[IAgentStatus["Running"] = 1] = "Running";
    IAgentStatus[IAgentStatus["Stopped"] = 2] = "Stopped";
})(IAgentStatus || (IAgentStatus = {}));
// generated-code-start
/* eslint-disable */
export const IAgentCapabilities = globalThis.RegisterInterface(["name", "platform", "domain", "version", "poolName", "tag", "credentials", "packageInfo", "withProtectedAPI", "metadata"]);
export const ICredentials = globalThis.RegisterInterface(["userName", "authToken", "groups"]);
export const IPackageInfo = globalThis.RegisterInterface(["name", "release", "platform", "version", "buildTime"]);
export const IAgentInfo = globalThis.RegisterInterface(["startTime", "id", "status", "footprintId", "authorized", "authorizedAt", "authorizedBy"], IAgentCapabilities);
export const IAgentMetadata = globalThis.RegisterInterface(["configuration", "environment"]);
export const IAgentsRegisterPromise = globalThis.RegisterInterface(["OnMessage"], IAcknowledgePromise);
export const IRegisterAgentHandlers = globalThis.RegisterInterface(["onMessage"]);
export const IAgentsListPromise = globalThis.RegisterInterface(["Then"]);
export const IRequestForwardingProtocol = globalThis.RegisterInterface(["protocol", "taskId"]);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.AgentsRegisterConnector", AgentsRegisterConnector);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.AgentsRegisterConnectorAsync", AgentsRegisterConnectorAsync);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IAgentCapabilities", IAgentCapabilities);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.ICredentials", ICredentials);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IPackageInfo", IPackageInfo);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IAgentInfo", IAgentInfo);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IAgentMetadata", IAgentMetadata);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IAgentsRegisterPromise", IAgentsRegisterPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IRegisterAgentHandlers", IRegisterAgentHandlers);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IAgentsListPromise", IAgentsListPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IRequestForwardingProtocol", IRequestForwardingProtocol);
//# sourceMappingURL=AgentsRegisterConnector.js.map