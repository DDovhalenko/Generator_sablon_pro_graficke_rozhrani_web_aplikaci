/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { PersistenceType } from "./../../../../Io/Oidis/Commons/Enums/PersistenceType.js";
import { CookiesHandler } from "./../../../../Io/Oidis/Commons/PersistenceApi/Handlers/CookiesHandler.js";
import { StorageHandler } from "./../../../../Io/Oidis/Commons/PersistenceApi/Handlers/StorageHandler.js";
import { PersistenceFactory } from "./../../../../Io/Oidis/Commons/PersistenceApi/PersistenceFactory.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { AuthHttpResolver } from "../ErrorPages/AuthHttpResolver.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
/**
 * Connector for the Oidis Hub authentication service. Provides user authentication,
 * registration, password management, auth token lifecycle, group/role management,
 * and organization administration. All methods use the async invocation pattern
 * and communicate exclusively with the Hub backend.
 */
export class AuthManagerConnector extends BaseConnector {
    /**
     * Gets or sets the current authentication token. When setting, persists
     * the token to client IP persistence, localStorage, or cookies.
     * @param {string} [$value] New token value to store
     * @returns {string} Returns the current authentication token
     */
    CurrentToken($value) {
        if (ObjectValidator.IsSet($value)) {
            PersistenceFactory.getPersistence(PersistenceType.CLIENT_IP, AuthHttpResolver.ClassName())
                .Variable("token", $value);
            if (StorageHandler.IsSupported()) {
                localStorage.setItem(AuthHttpResolver.getTokenName(), $value);
            }
            else if (this.httpManager.getRequest().IsCookieEnabled()) {
                CookiesHandler.setCookie(AuthHttpResolver.getTokenName(), $value);
            }
        }
        return AuthHttpResolver.getToken();
    }
    /**
     * Authenticates a user with credentials and returns a session token.
     * @param {string} $userNameOrEmail User name or email address
     * @param {string} $password Plain-text password (hashed with SHA-1 before transmission)
     * @param {boolean} [$noExpire=false] When true, the session token will not expire
     * @returns {Promise<string>} Returns the authentication token on success
     */
    LogIn($userNameOrEmail, $password, $noExpire = false) {
        return this.asyncInvoke("LogIn", $userNameOrEmail, StringUtils.getSha1($password), $noExpire);
    }
    /**
     * Invalidates an authentication token and clears local persistence.
     * @param {string} [$token] Token to invalidate (defaults to current token)
     * @returns {Promise<boolean>} Returns true on successful logout
     */
    LogOut($token = null) {
        if (ObjectValidator.IsEmptyOrNull($token)) {
            $token = this.CurrentToken();
        }
        this.CurrentToken("");
        return this.asyncInvoke("LogOut", $token);
    }
    /**
     * @param {string} [$token] Token to validate (defaults to current token)
     * @returns {Promise<boolean>} Returns true if the token represents a valid session
     */
    IsAuthenticated($token = null) {
        return this.asyncInvoke("IsAuthenticated", $token);
    }
    /**
     * @param {string} $method Fully qualified method namespace to check authorization for
     * @param {string} [$token] Token to validate (defaults to current token)
     * @returns {Promise<boolean>} Returns true if the user is authorized to call the method
     */
    IsAuthorizedFor($method, $token = null) {
        return this.asyncInvoke("IsAuthorizedFor", $method, $token);
    }
    /**
     * Registers a new user account. Password is hashed with SHA-1 before transmission.
     * @param {IUserRegisterOptions} $options Registration details including name, email, and password
     * @returns {Promise<boolean>} Returns true on successful registration
     */
    Register($options) {
        $options.password = StringUtils.getSha1($options.password);
        return this.asyncInvoke("Register", $options);
    }
    /**
     * @param {string} $token Activation token received via email
     * @returns {Promise<boolean>} Returns true on successful account activation
     */
    async ActivateUser($token) {
        return await this.asyncInvoke("ActivateUser", $token);
    }
    /**
     * @param {string} $id User ID to deactivate
     * @param {boolean} [$value=true] True to deactivate, false to reactivate
     * @returns {Promise<boolean>} Returns true on success
     */
    DeactivateUser($id, $value = true) {
        return this.asyncInvoke("DeactivateUser", $id, $value);
    }
    /**
     * Initiates a password reset flow by sending a reset email.
     * @param {string} $email Email address of the account
     * @returns {Promise<boolean>} Returns true if the reset email was sent
     */
    ResetPassword($email) {
        return this.asyncInvoke("ResetPassword", $email);
    }
    /**
     * Completes a password reset using the token from the reset email.
     * @param {string} $token Password reset token
     * @param {string} $newPassword New plain-text password (hashed before transmission)
     * @returns {Promise<boolean>} Returns true on success
     */
    ResetPasswordConfirm($token, $newPassword) {
        return this.asyncInvoke("ResetPasswordConfirm", $token, StringUtils.getSha1($newPassword));
    }
    /**
     * Changes the password for the current or specified user.
     * @param {string} $password New plain-text password (hashed before transmission)
     * @param {string} [$userId] Target user ID (defaults to current user)
     * @returns {Promise<string>} Returns the new authentication token
     */
    ChangePassword($password, $userId = null) {
        return this.asyncInvoke("ChangePassword", StringUtils.getSha1($password), $userId);
    }
    /**
     * Confirms an invitation and sets the initial password for an invited user.
     * @param {string} $token Invitation token received via email
     * @param {string} $newPassword Plain-text password (hashed before transmission)
     * @returns {Promise<boolean>} Returns true on success
     */
    InvitationConfirm($token, $newPassword) {
        return this.asyncInvoke("InvitationConfirm", $token, StringUtils.getSha1($newPassword));
    }
    /**
     * Soft-deletes one or more users (moves to trash).
     * @param {string|string[]} $userId User ID or array of user IDs to remove
     * @returns {Promise<boolean>} Returns true on success
     */
    RemoveUser($userId) {
        return this.asyncInvoke("RemoveUser", $userId);
    }
    /**
     * Permanently deletes a user account.
     * @param {string} $userId User ID to delete
     * @returns {Promise<boolean>} Returns true on success
     */
    DeleteUser($userId) {
        return this.asyncInvoke("DeleteUser", $userId);
    }
    /**
     * Restores a previously soft-deleted user.
     * @param {string} $userId User ID to restore
     * @returns {Promise<boolean>} Returns true on success
     */
    RestoreUser($userId) {
        return this.asyncInvoke("RestoreUser", $userId);
    }
    /**
     * @param {string} [$token] Auth token (defaults to current token)
     * @returns {Promise<string[]>} Returns the list of authorized method namespaces
     */
    getAuthorizedMethods($token = null) {
        return this.asyncInvoke("getAuthorizedMethods", $token);
    }
    /**
     * Sets authorized methods for a group. Replaces existing methods unless append is true.
     * @param {string} $group Group name
     * @param {string[]} $authMethods Method namespace patterns to authorize
     * @param {boolean} [$append=false] When true, adds to existing methods instead of replacing
     * @returns {Promise<boolean>} Returns true on success
     */
    setAuthorizedMethods($group, $authMethods, $append = false) {
        return this.asyncInvoke("setAuthorizedMethods", $group, $authMethods, $append);
    }
    /**
     * @param {string} $userId User ID to look up
     * @returns {Promise<string[]>} Returns the list of authorized method namespaces for the user
     */
    getAuthorizedMethodsFor($userId) {
        return this.asyncInvoke("getAuthorizedMethodsFor", $userId);
    }
    /**
     * Assigns a user to an authorization group.
     * @param {string} $groupName Group name to assign
     * @param {string} [$userId] User ID (defaults to current user)
     * @returns {Promise<boolean>} Returns true on success
     */
    AddGroup($groupName, $userId = null) {
        return this.asyncInvoke("AddGroup", $groupName, $userId);
    }
    /**
     * @param {string} [$userId] User ID (defaults to current user)
     * @returns {Promise<string[]>} Returns the list of groups the user belongs to
     */
    getGroups($userId = null) {
        return this.asyncInvoke("getGroups", $userId);
    }
    /**
     * Removes a user from an authorization group.
     * @param {string} $groupName Group name to remove
     * @param {string} [$userId] User ID (defaults to current user)
     * @returns {Promise<boolean>} Returns true on success
     */
    RemoveGroup($groupName, $userId = null) {
        return this.asyncInvoke("RemoveGroup", $groupName, $userId);
    }
    /**
     * @param {string} $id Group ID to restore
     * @returns {Promise<boolean>} Returns true on success
     */
    RestoreGroup($id) {
        return this.asyncInvoke("RestoreGroup", $id);
    }
    /**
     * Generates a named API token for programmatic access.
     * @param {string} [$name] Human-readable token name
     * @param {string} [$userId] Owner user ID (defaults to current user)
     * @param {boolean} [$noExpire=false] When true, the token will not expire
     * @returns {Promise<IAuthToken>} Returns the generated token details
     */
    GenerateAuthToken($name = "", $userId = null, $noExpire = false) {
        return this.asyncInvoke("GenerateAuthToken", $name, $userId, $noExpire);
    }
    /**
     * @param {string} $authToken Token value to revoke
     * @param {string} [$userId] Owner user ID (defaults to current user)
     * @returns {Promise<boolean>} Returns true on success
     */
    RevokeAuthToken($authToken, $userId = null) {
        return this.asyncInvoke("RevokeAuthToken", $authToken, $userId);
    }
    /**
     * @param {string} $authToken Token value to update
     * @param {IAuthTokenOptions} $options New token properties (name, expiration)
     * @param {string} [$userId] Owner user ID (defaults to current user)
     * @returns {Promise<boolean>} Returns true on success
     */
    UpdateAuthToken($authToken, $options, $userId = null) {
        return this.asyncInvoke("UpdateAuthToken", $authToken, $options, $userId);
    }
    /**
     * @param {string} $name Token name to look up
     * @param {string} [$userId] Owner user ID (defaults to current user)
     * @returns {Promise<string>} Returns the token value
     */
    async getAuthToken($name, $userId = null) {
        return await this.asyncInvoke("getAuthToken", $name, $userId);
    }
    /**
     * @param {string} $authToken Token value to validate
     * @param {string} [$userId] Owner user ID
     * @returns {Promise<boolean>} Returns true if the token is valid and not expired
     */
    IsAuthTokenValid($authToken, $userId = null) {
        return this.asyncInvoke("IsAuthTokenValid", $authToken, $userId);
    }
    /**
     * Validates a plain-text password against the user identified by the token.
     * @param {string} $token Authentication token identifying the user
     * @param {string} $password Plain-text password to verify (hashed before transmission)
     * @returns {Promise<boolean>} Returns true if the password matches
     */
    IsPasswordValid($token, $password) {
        return this.asyncInvoke("IsPasswordValid", $token, StringUtils.getSha1($password));
    }
    /**
     * Registers an application profile with its authorized methods.
     * @param {IAppRegisterOptions} $options Application profile and authorization details
     * @returns {Promise<boolean>} Returns true on success
     */
    RegisterApp($options) {
        return this.asyncInvoke("RegisterApp", $options);
    }
    /**
     * @param {string} $group Group name
     * @returns {Promise<string[]>} Returns the list of authorized method namespaces for the group
     */
    async getGroupMethods($group) {
        return await this.asyncInvoke("getGroupMethods", $group);
    }
    /**
     * @param {IAppProfileOptions} $options Application profile to look up
     * @returns {Promise<IAuthorizedMethods[]>} Returns authorized methods for the application
     */
    getAppMethods($options) {
        return this.asyncInvoke("getAppMethods", $options);
    }
    /**
     * Searches for users by ID or username filter with pagination.
     * @param {string|any} $idOrUserNameFilter User ID or filter object
     * @param {IAuthFindUsersOptions} [$options] Pagination and filtering options
     * @returns {Promise<IModelListResult>} Returns paginated user list
     */
    async FindUsers($idOrUserNameFilter, $options = null) {
        return await this.asyncInvoke("FindUsers", $idOrUserNameFilter, $options);
    }
    /**
     * Creates a new authorization group with optional initial method permissions.
     * @param {string} $name Group name
     * @param {string[]} [$methods] Initial authorized method namespaces
     * @param {boolean} [$force=false] When true, overwrites an existing group with the same name
     * @returns {Promise<string>} Returns the created group ID
     */
    async CreateGroup($name, $methods = [], $force = false) {
        return await this.asyncInvoke("CreateGroup", $name, $methods, $force);
    }
    /**
     * Searches for authorization groups by ID or name filter.
     * @param {string} $idOrNameFilter Group ID or name filter
     * @param {IAuthFindGroupsOptions} [$options] Pagination and filtering options
     * @returns {Promise<IModelListResult>} Returns paginated group list
     */
    async FindGroups($idOrNameFilter, $options = null) {
        return await this.asyncInvoke("FindGroups", $idOrNameFilter, $options);
    }
    /**
     * @param {string} $idOrName Group ID or name to delete
     * @returns {Promise<boolean>} Returns true on success
     */
    async DeleteGroup($idOrName) {
        return await this.asyncInvoke("DeleteGroup", $idOrName);
    }
    /**
     * @param {string} $tokenOrName Auth token or username
     * @returns {Promise<string>} Returns the user ID
     */
    async getUserId($tokenOrName) {
        return await this.asyncInvoke("getUserId", $tokenOrName);
    }
    /**
     * @param {boolean} [$withData=false] When true, includes extended profile data
     * @param {string} [$userIdOrToken] User ID or token (defaults to current user)
     * @returns {Promise<any>} Returns the user profile object
     */
    async getUserProfile($withData = false, $userIdOrToken = null) {
        return await this.asyncInvoke("getUserProfile", $withData, $userIdOrToken);
    }
    /**
     * @param {IUserProfileOptions} $options Profile fields to update
     * @param {string} [$userId] Target user ID (defaults to current user)
     * @returns {Promise<boolean>} Returns true on success
     */
    async setUserProfile($options, $userId = null) {
        return await this.asyncInvoke("setUserProfile", $options, $userId);
    }
    /**
     * Checks for duplicate email addresses across all user accounts.
     * @returns {Promise<any>} Returns duplicity check results
     */
    async CheckEmailDuplicity() {
        return await this.asyncInvoke("CheckEmailDuplicity");
    }
    /**
     * Registers a new organization, optionally creating an owner account.
     * @param {IOrganizationProfileOptions} $options Organization profile
     * @param {IUserRegisterOptions} [$owner] Owner user to create with the organization
     * @returns {Promise<string>} Returns the organization ID
     */
    RegisterOrganization($options, $owner) {
        if (!ObjectValidator.IsEmptyOrNull($owner)) {
            $owner.password = StringUtils.getSha1($owner.password);
        }
        return this.asyncInvoke("RegisterOrganization", $options, $owner);
    }
    /**
     * @param {IOrganizationProfileOptions} $options Organization fields to update
     * @param {string} $organizationId Organization ID
     * @returns {Promise<boolean>} Returns true on success
     */
    setOrganizationProfile($options, $organizationId) {
        return this.asyncInvoke("setOrganizationProfile", $options, $organizationId);
    }
    /**
     * @param {string} $idOrOwnerId Organization ID or owner user ID
     * @param {boolean} [$withData=false] When true, includes extended data
     * @returns {Promise<any>} Returns the organization profile
     */
    getOrganizationProfile($idOrOwnerId, $withData = false) {
        return this.asyncInvoke("getOrganizationProfile", $idOrOwnerId, $withData);
    }
    /**
     * @param {string} $organizationId Organization ID
     * @param {IModelListFilter} [$filter] Pagination filter
     * @param {boolean} [$activatedOnly] If true, only returns users with Activated === true
     * @returns {Promise<IModelListResult>} Returns the organization member chart
     */
    getOrganizationChart($organizationId, $filter, $activatedOnly) {
        return this.asyncInvoke("getOrganizationChart", $organizationId, $filter, $activatedOnly);
    }
    /**
     * @param {string} $userId User ID to add
     * @param {string} $organizationId Target organization ID
     * @returns {Promise<boolean>} Returns true on success
     */
    AddUserToOrganization($userId, $organizationId) {
        return this.asyncInvoke("AddUserToOrganization", $userId, $organizationId);
    }
    /**
     * @param {string} $userId User ID to remove
     * @param {string} $organizationId Organization ID
     * @returns {Promise<boolean>} Returns true on success
     */
    RemoveUserFromOrganization($userId, $organizationId) {
        return this.asyncInvoke("RemoveUserFromOrganization", $userId, $organizationId);
    }
    /**
     * @param {string|any} $filter Organization name or filter object
     * @param {IAuthFindOptions} [$options] Pagination and filtering options
     * @returns {Promise<IModelListResult>} Returns paginated organization list
     */
    FindOrganizations($filter, $options = null) {
        return this.asyncInvoke("FindOrganizations", $filter, $options);
    }
    /**
     * @param {string} $id Organization ID
     * @param {boolean} [$value=true] True to deactivate, false to reactivate
     * @returns {Promise<boolean>} Returns true on success
     */
    DeactivateOrganization($id, $value = true) {
        return this.asyncInvoke("DeactivateOrganization", $id, $value);
    }
    /**
     * @param {string} $id Organization ID to permanently delete
     * @returns {Promise<boolean>} Returns true on success
     */
    DeleteOrganization($id) {
        return this.asyncInvoke("DeleteOrganization", $id);
    }
    /**
     * @param {string} $id Organization ID to restore
     * @returns {Promise<boolean>} Returns true on success
     */
    RestoreOrganization($id) {
        return this.asyncInvoke("RestoreOrganization", $id);
    }
    getClientType() {
        return WebServiceClientType.HUB_CONNECTOR;
    }
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.HUB_CONNECTOR] = "Io.Oidis.Hub.Utils.AuthManager";
        return namespaces;
    }
}
// generated-code-start
/* eslint-disable */
export const IAuthToken = globalThis.RegisterInterface(["name", "value", "id", "expire"]);
export const IAuthTokenOptions = globalThis.RegisterInterface(["name", "expireTime"]);
export const IUserProfileOptions = globalThis.RegisterInterface(["name", "firstname", "lastname", "email", "phone", "image", "altEmails", "throwExceptions", "activated", "twoFA", "whatsNewSeen"]);
export const IUserRegisterOptions = globalThis.RegisterInterface(["password", "withActivation", "withInvitation"], IUserProfileOptions);
export const IAppProfileOptions = globalThis.RegisterInterface(["appName", "releaseName", "platform", "version", "buildTime"]);
export const IAppRegisterOptions = globalThis.RegisterInterface(["authMethods"], IAppProfileOptions);
export const IModelListFilter = globalThis.RegisterInterface(["offset", "limit"]);
export const IModelListResult = globalThis.RegisterInterface(["data", "size", "offset", "limit"]);
export const IAuthFindOptions = globalThis.RegisterInterface(["offset", "limit", "onlyActive", "withDeleted"]);
export const IAuthFindUsersOptions = globalThis.RegisterInterface(["onlyWithOwnPermissions"], IAuthFindOptions);
export const IAuthFindGroupsOptions = globalThis.RegisterInterface(["withHidden", "withReadonly", "withEmptyPermissions", "onlyWithAsterix", "onlySystem"], IAuthFindOptions);
export const IOrganizationProfileOptions = globalThis.RegisterInterface(["name", "image", "activated"]);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.AuthManagerConnector", AuthManagerConnector);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IAuthToken", IAuthToken);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IAuthTokenOptions", IAuthTokenOptions);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IUserProfileOptions", IUserProfileOptions);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IUserRegisterOptions", IUserRegisterOptions);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IAppProfileOptions", IAppProfileOptions);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IAppRegisterOptions", IAppRegisterOptions);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IModelListFilter", IModelListFilter);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IModelListResult", IModelListResult);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IAuthFindOptions", IAuthFindOptions);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IAuthFindUsersOptions", IAuthFindUsersOptions);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IAuthFindGroupsOptions", IAuthFindGroupsOptions);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IOrganizationProfileOptions", IOrganizationProfileOptions);
//# sourceMappingURL=AuthManagerConnector.js.map