/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
import { LiveContentWrapper } from "../WebServiceApi/LiveContentWrapper.js";
/**
 * COMproxyConnector provides wrapping of COM (Component Object Model) automation services
 * via the Oidis Connector Desktop backend. Enables creating, invoking, and managing COM
 * object instances from the browser environment through the LCP bridge.
 */
export class COMproxyConnector extends BaseConnector {
    /**
     * @param {string} $clsid Specify CLSID of COM object, which should be created.
     * @returns {ICOMproxyInstancePromise} Returns promise interface for handling of creation event.
     */
    CreateInstanceFromCLSID($clsid) {
        return this.invoke("CreateInstanceFromCLSID", $clsid);
    }
    /**
     * @param {string} $clsid Specify CLSID of COM object, which should be created.
     * @param {string} $instanceName Specify registration name for created instance.
     * @returns {ICOMproxyInstancePromise} Returns promise interface for handling of creation event.
     */
    CreateInstanceFromCLSIDas($clsid, $instanceName) {
        return this.invoke("CreateInstanceFromCLSIDas", $clsid, $instanceName);
    }
    /**
     * @param {string} $progid Specify PROGID of COM object, which should be created.
     * @returns {ICOMproxyInstancePromise} Returns promise interface for handling of creation event.
     */
    CreateInstanceFromProgID($progid) {
        return this.invoke("CreateInstanceFromProgID", $progid);
    }
    /**
     * @param {string} $progid Specify PROGID of COM object, which should be created.
     * @param {string} $instanceName Specify registration name for created instance.
     * @returns {ICOMproxyInstancePromise} Returns promise interface for handling of creation event.
     */
    CreateInstanceFromProgIDas($progid, $instanceName) {
        return this.invoke("CreateInstanceFromProgIDas", $progid, $instanceName);
    }
    /**
     * @param {string} $instanceName Specify registration name, which should be validated.
     * @returns {ICOMproxyBooleanPromise} Returns promise interface for handling of exists event.
     */
    Exists($instanceName) {
        return this.invoke("Exists", $instanceName);
    }
    /**
     * @param {string} $instanceName Specify registration name, which should be looked up.
     * @returns {ICOMproxyInstancePromise} Returns promise interface for handling of instance receive event.
     */
    getInstanceId($instanceName) {
        return this.invoke("getInstanceId", $instanceName);
    }
    /**
     * @param {number} $instanceId Specify instance id, which should be destroyed.
     * @returns {ICOMproxyVoidPromise} Returns promise interface for handling of destroy event.
     */
    Destroy($instanceId) {
        return this.invoke("Destroy", $instanceId);
    }
    /**
     * Trigger a test event on a COM instance for debugging purposes.
     * @param {number} $instanceId Specify instance id to target.
     * @param {number} $eventID Specify event identifier to test.
     * @returns {ICOMproxyVoidPromise} Returns promise interface for handling of test event.
     */
    TestEvent($instanceId, $eventID) {
        return this.invoke("TestEvent", $instanceId, $eventID);
    }
    /**
     * Frees all allocated instances, releases memory and Un-initializes to Co interface.
     * @returns {ILiveContentFormatterPromise} Returns promise interface for handling of tearDown event.
     */
    TearDown() {
        return this.invoke("TearDown");
    }
    /**
     * @param {number} $instanceId Specify instance id, which should be handled.
     * @param {string} $name Specify method name, which should be invoked.
     * @param {...any[]} [$args] Specify method arguments, which should be passed to the invoked method.
     * @returns {ICOMproxyMethodPromise} Returns promise interface for handling of invoke method event.
     */
    InvokeMethod($instanceId, $name, ...$args) {
        // eslint-disable-next-line prefer-spread
        return this.invoke.apply(this, ["InvokeMethod", $instanceId, $name].concat($args));
    }
    /**
     * @param {number} $instanceId Specify instance id, which should be handled.
     * @param {string} $name Specify property name, which should be invoked.
     * @returns {ICOMproxyPropertyPromise} Returns promise interface for handling of invoke property event.
     */
    getProperty($instanceId, $name) {
        return this.invoke("getProperty", $instanceId, $name);
    }
    /**
     * @param {number} $instanceId Specify instance id, which should be handled.
     * @param {string} $name Specify property name, which should be set.
     * @param {any} $value Specify value, which should be set to the property.
     * @returns {ICOMproxyVoidPromise} Returns promise interface for handling of property set event.
     */
    setProperty($instanceId, $name, $value) {
        return this.invoke("setProperty", $instanceId, $name, $value);
    }
    /**
     * @param {number} $instanceId Specify instance id, which should be handled.
     * @param {string} $name Specify event name, which should be handled.
     * @param {number} $eventId Specify event id, which reflects COM interface.
     * @param {Function} $handler Specify event handler callback, which should be asigned.
     * @returns {void}
     */
    AddEventHandler($instanceId, $name, $eventId, $handler) {
        LiveContentWrapper.AddEventHandler(this.getClient(), this.getServerNamespaces(), "OnCOMevent", ($eventInstanceId, $eventName, ...$args) => {
            if ($eventInstanceId === $instanceId && $eventName === $name) {
                $handler.apply(this, $args[0]);
            }
        });
        this.invoke("AddEventHandler", $instanceId, $name, $eventId);
    }
    getClientType() {
        return WebServiceClientType.DESKTOP_CONNECTOR;
    }
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.DESKTOP_CONNECTOR] = "Io.Oidis.Connector.Connectors.COMproxy";
        return namespaces;
    }
}
// generated-code-start
export const ICOMproxyVoidPromise = globalThis.RegisterInterface(["Then"]);
export const ICOMproxyBooleanPromise = globalThis.RegisterInterface(["Then"]);
export const ICOMproxyInstancePromise = globalThis.RegisterInterface(["Then"]);
export const ICOMproxyMethodPromise = globalThis.RegisterInterface(["Then"]);
export const ICOMproxyPropertyPromise = globalThis.RegisterInterface(["Then"]);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.COMproxyConnector", COMproxyConnector);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.ICOMproxyVoidPromise", ICOMproxyVoidPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.ICOMproxyBooleanPromise", ICOMproxyBooleanPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.ICOMproxyInstancePromise", ICOMproxyInstancePromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.ICOMproxyMethodPromise", ICOMproxyMethodPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.ICOMproxyPropertyPromise", ICOMproxyPropertyPromise);
//# sourceMappingURL=COMproxyConnector.js.map