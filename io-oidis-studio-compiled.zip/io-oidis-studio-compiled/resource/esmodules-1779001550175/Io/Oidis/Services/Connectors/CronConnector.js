/*! ******************************************************************************************************** *
 *
 * Copyright 2025-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
import { Loader } from "../Loader.js";
/**
 * CronConnector provides wrapping of scheduled task management services on the Oidis
 * Localhost CronConnector backend. Uses a singleton pattern via `getClient()` static factory.
 */
export class CronConnector extends BaseConnector {
    /**
     * Return the singleton CronConnector instance. On first call, creates a new connector
     * with reconnect enabled and the Hub-relative config URL. Subsequent calls return the
     * cached instance (self-replacing function pattern).
     * @returns {CronConnector} Returns the singleton CronConnector instance.
     */
    static getClient() {
        const instance = new CronConnector(true, Loader.getInstance().getHttpManager().CreateLink("/connector.config.jsonp"));
        CronConnector.getClient = () => {
            return instance;
        };
        return instance;
    }
    /**
     * Stop the cron master process, deactivating all scheduled tasks.
     * @param {string} $active Specify the active master identifier to stop.
     * @returns {Promise<boolean>} Returns promise resolving to stop success status.
     */
    async MasterStop($active) {
        return await this.asyncInvoke("MasterStop", $active);
    }
    /**
     * List all registered cron task descriptors.
     * @returns {Promise<ICronTaskDescriptor[]>} Returns promise resolving to array of task descriptors.
     */
    async ListTasks() {
        return await this.asyncInvoke("ListTasks");
    }
    /**
     * Start a cron task by its identifier or name.
     * @param {string} $idOrName Specify the task identifier or name to start.
     * @param {boolean} [$instant=false] Specify true to execute the task immediately instead of on schedule.
     * @returns {Promise<boolean>} Returns promise resolving to start success status.
     */
    async StartTask($idOrName, $instant = false) {
        return await this.asyncInvoke("StartTask", $idOrName, $instant);
    }
    /**
     * Stop a running cron task by its identifier or name.
     * @param {string} $idOrName Specify the task identifier or name to stop.
     * @returns {Promise<boolean>} Returns promise resolving to stop success status.
     */
    async StopTask($idOrName) {
        return await this.asyncInvoke("StopTask", $idOrName);
    }
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.HUB_CONNECTOR] = "Io.Oidis.Localhost.Utils.CronConnector";
        return namespaces;
    }
}
// generated-code-start
export const ICronTaskDescriptor = globalThis.RegisterInterface(["name", "cronTime"]);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.CronConnector", CronConnector);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.ICronTaskDescriptor", ICronTaskDescriptor);
//# sourceMappingURL=CronConnector.js.map