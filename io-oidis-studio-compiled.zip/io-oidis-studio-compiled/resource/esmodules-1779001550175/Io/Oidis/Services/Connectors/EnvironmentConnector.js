/*! ******************************************************************************************************** *
 *
 * Copyright 2022-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "./../../../../Io/Oidis/Commons/Enums/Events/EventType.js";
import { ErrorEventArgs } from "./../../../../Io/Oidis/Commons/Events/Args/ErrorEventArgs.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { ILiveContentErrorPromise } from "../Interfaces/ILiveContentPromise.js";
import { Loader } from "../Loader.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
import { LiveContentWrapper } from "../WebServiceApi/LiveContentWrapper.js";
/**
 * EnvironmentConnector provides wrapping for Hub environment lifecycle services.
 * Tracks environment loading state and type via the EnvironmentHelper backend.
 * Uses a singleton pattern via `getInstanceSingleton()` and memoizes positive
 * results from `InitPageEnabled()` and `IsEnvironmentLoaded()` for performance.
 */
export class EnvironmentConnector extends BaseConnector {
    /**
     * Return the singleton EnvironmentConnector instance. On first call, creates a new
     * connector with reconnect enabled and Hub-relative config URL. Subsequent calls
     * return the cached instance (self-replacing function pattern).
     * @returns {EnvironmentConnector} Returns the singleton instance.
     */
    static getInstanceSingleton() {
        const instance = new this(true, Loader.getInstance().getHttpManager().CreateLink("/connector.config.jsonp"));
        this.getInstanceSingleton = () => {
            return instance;
        };
        return instance;
    }
    /**
     * Retrieve the current environment type from the Hub backend.
     * @returns {Promise<EnvironmentType>} Returns promise resolving to the environment type enum value.
     */
    getEnvType() {
        return this.asyncInvoke("getEnvType");
    }
    /**
     * Check whether the initialization page is enabled on the Hub. Memoizes the result
     * after the first positive response — subsequent calls return the cached value.
     * @returns {Promise<boolean>} Returns promise resolving to init page enabled status.
     */
    async InitPageEnabled() {
        const status = await this.asyncInvoke("InitPageEnabled");
        if (status) {
            this.InitPageEnabled = async () => {
                return status;
            };
        }
        return status;
    }
    /**
     * Check whether the environment has finished loading. Memoizes the result after the
     * first positive response — subsequent calls return the cached value.
     * @returns {Promise<boolean>} Returns promise resolving to environment loaded status.
     */
    async IsEnvironmentLoaded() {
        const status = await this.asyncInvoke("IsEnvironmentLoaded");
        if (status) {
            this.IsEnvironmentLoaded = async () => {
                return status;
            };
        }
        return status;
    }
    /**
     * Subscribe to environment loading progress events. Provides streaming state
     * change notifications via OnChange and completion via Then.
     * @returns {ILoadingProcessPromise} Returns promise with OnChange/OnError/Then handlers.
     */
    AddLoadingListener() {
        const callbacks = {
            onChange($state) {
                // declare default callback
            },
            onError: null,
            then() {
                // declare default callback
            }
        };
        LiveContentWrapper.InvokeMethod(this.getClient(), this.getServerNamespace(), "AddLoadingListener")
            .OnError(($error, ...$args) => {
            this.errorHandler(callbacks.onError, $error, $args);
        })
            .Then(($result) => {
            if (!ObjectValidator.IsEmptyOrNull($result)) {
                if (ObjectValidator.IsObject($result) && ObjectValidator.IsSet($result.type)) {
                    if ($result.type === EventType.ON_CHANGE || $result.type === EventType.ON_START) {
                        callbacks.onChange($result.data);
                    }
                    else {
                        callbacks.then();
                    }
                }
                else {
                    LogIt.Debug("Incorrect result received: {0}", $result);
                    this.errorHandler(callbacks.onError, new ErrorEventArgs("Unrecognized state type received"), []);
                }
            }
        });
        const promise = {
            OnChange: ($callback) => {
                callbacks.onChange = $callback;
                return promise;
            },
            OnError: ($callback) => {
                callbacks.onError = $callback;
                return promise;
            },
            Then: ($callback) => {
                callbacks.then = $callback;
            }
        };
        return promise;
    }
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.HUB_CONNECTOR] = "Io.Oidis.Hub.Utils.EnvironmentHelper";
        return namespaces;
    }
}
// generated-code-start
export const ILoadingProcessPromise = globalThis.RegisterInterface(["OnChange", "Then"], ILiveContentErrorPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.EnvironmentConnector", EnvironmentConnector);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.ILoadingProcessPromise", ILoadingProcessPromise);
//# sourceMappingURL=EnvironmentConnector.js.map