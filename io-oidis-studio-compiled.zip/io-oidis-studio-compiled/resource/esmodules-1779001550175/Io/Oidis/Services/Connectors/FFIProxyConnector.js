import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
/**
 * FFIProxyConnector class provides wrapping of FFI proxy services provided by Oidis Connector instance.
 */
export class FFIProxyConnector extends BaseConnector {
    /**
     * @param {string|IFFIOptions} $fileOrOptions Specify name of the library file.
     * @returns {IFFIProxyMethodPromise} Returns promise interface for handling of creation event.
     */
    Load($fileOrOptions) {
        return this.invoke("Load", $fileOrOptions);
    }
    /**
     * @param {string} $name Specify method name, which should be invoked.
     * @param {LiveContentArgumentType} $returnType Specify return type for method, which should be invoked.
     * @param {...any[]} [$args] Specify method arguments, which should be passed to the invoked method.
     * @returns {IFFIProxyMethodPromise} Returns promise interface for handling of invoke method event.
     */
    InvokeMethod($name, $returnType, ...$args) {
        // eslint-disable-next-line prefer-spread
        return this.invoke.apply(this, ["InvokeMethod", $name, $returnType].concat($args));
    }
    /**
     * @returns {IFFIProxyMethodPromise} Returns promise interface for handling of release event.
     */
    Release() {
        return this.invoke.apply(this, ["Release"]);
    }
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.DESKTOP_CONNECTOR] = "Io.Oidis.Connector.Connectors.FFIProxy";
        namespaces[WebServiceClientType.BUILDER_CONNECTOR] = "Io.Oidis.Builder.Connectors.FFIProxy";
        namespaces[WebServiceClientType.FORWARD_CLIENT] = "Io.Oidis.Connector.Connectors.FFIProxy";
        return namespaces;
    }
}
// generated-code-start
export const IFFIProxyMethodPromise = globalThis.RegisterInterface(["Then"]);
export const IFFIArgumentArray = globalThis.RegisterInterface(["type", "items"]);
export const IFFIArgumentStruct = globalThis.RegisterInterface(["typeName", "fields"]);
export const IFFIArgumentCallback = globalThis.RegisterInterface(["typeName", "callback", "returnType", "args"]);
export const IFFIArgument = globalThis.RegisterInterface(["type", "value"]);
export const IFFIOptions = globalThis.RegisterInterface(["libraryPath", "env", "cwd"]);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.FFIProxyConnector", FFIProxyConnector);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFFIProxyMethodPromise", IFFIProxyMethodPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFFIArgumentArray", IFFIArgumentArray);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFFIArgumentStruct", IFFIArgumentStruct);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFFIArgumentCallback", IFFIArgumentCallback);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFFIArgument", IFFIArgument);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFFIOptions", IFFIOptions);
//# sourceMappingURL=FFIProxyConnector.js.map