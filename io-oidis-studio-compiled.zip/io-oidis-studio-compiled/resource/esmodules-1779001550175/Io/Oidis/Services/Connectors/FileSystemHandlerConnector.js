/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "./../../../../Io/Oidis/Commons/Enums/Events/EventType.js";
import { ProgressEventArgs } from "./../../../../Io/Oidis/Commons/Events/Args/ProgressEventArgs.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
import { LiveContentWrapper } from "../WebServiceApi/LiveContentWrapper.js";
/**
 * Abstract base implementing the file system operations shared by both callback
 * and async connector variants. Delegates each operation to the backend via
 * {@link BaseConnector.invoke} and wires up progress/error callback chains.
 */
class BaseFileSystemHandlerConnector extends BaseConnector {
    getTempPath() {
        return this.invoke("getTempPath")
            .DataFormatter(($data) => {
            return StringUtils.Replace(StringUtils.Replace(StringUtils.Remove($data, "\""), "\\", "/"), "//", "/");
        });
    }
    getProjectBasePath() {
        return this.invoke("getProjectBasePath");
    }
    getAppDataPath() {
        return this.invoke("getAppDataPath");
    }
    getLocalAppDataPath() {
        return this.invoke("getLocalAppDataPath");
    }
    getHostLocation() {
        return {
            Then: ($callBack) => {
                this.getClient().getServerPath($callBack);
            }
        };
    }
    getPathMap($path) {
        return this.invoke("getPathMap", $path)
            .DataFormatter(($data) => {
            if (!ObjectValidator.IsArray($data)) {
                return [];
            }
            return $data;
        });
    }
    getNetworkMap($additionalInfo = false) {
        return this.invoke("getNetworkMap", $additionalInfo)
            .DataFormatter(($data) => {
            if (!ObjectValidator.IsArray($data)) {
                return [];
            }
            return $data;
        });
    }
    getDirectoryContent($path) {
        return this.invoke("getDirectoryContent", $path)
            .DataFormatter(($data) => {
            if (!ObjectValidator.IsArray($data)) {
                return [];
            }
            return $data;
        });
    }
    Expand($pattern) {
        return this.invoke("Expand", $pattern);
    }
    Exists($path) {
        return this.invoke("Exists", $path);
    }
    Write($path, $data, $append = false, $stream = false) {
        return this.invoke(!$stream ? "Write" : "WriteStream", $path, $data, $append);
    }
    Read($path, $stream = false) {
        if ($stream) {
            return this.invoke("ReadStream", $path);
        }
        else {
            return this.invoke("Read", $path)
                .DataFormatter(($data) => {
                if (StringUtils.StartsWith($data, "\"") && StringUtils.EndsWith($data, "\"")) {
                    $data = StringUtils.Replace($data, "\\r", "\r");
                    $data = StringUtils.Replace($data, "\\n", "\n");
                    $data = StringUtils.Replace($data, "\r\n", "\n");
                    $data = StringUtils.Replace($data, "\\\"", "\"");
                    return StringUtils.Substring($data, 1, StringUtils.Length($data) - 2);
                }
                return $data;
            });
        }
    }
    Delete($path) {
        const callbacks = {
            onChange($args) {
                // declare default callback
            },
            onComplete($success) {
                // declare default callback
            }
        };
        this.invoke("Delete", $path)
            .Then(($result) => {
            if (ObjectValidator.IsSet($result.type)) {
                if ($result.type === EventType.ON_CHANGE) {
                    if (ObjectValidator.IsSet($result.data)) {
                        $result = $result.data;
                    }
                    const args = new ProgressEventArgs();
                    args.RangeStart($result.rangeStart);
                    args.RangeEnd($result.rangeEnd);
                    args.CurrentValue($result.currentValue);
                    callbacks.onChange(args);
                }
                else if ($result.type === EventType.ON_COMPLETE) {
                    callbacks.onComplete($result.data);
                }
            }
            else if (ObjectValidator.IsBoolean($result)) {
                callbacks.onComplete($result);
            }
        });
        const promise = {
            OnChange: ($callback) => {
                callbacks.onChange = $callback;
                return promise;
            },
            Then: ($callback) => {
                callbacks.onComplete = $callback;
            }
        };
        return promise;
    }
    CreateDirectory($path) {
        return this.invoke("CreateDirectory", $path);
    }
    Rename($oldPath, $newPath) {
        return this.invoke("Rename", $oldPath, $newPath);
    }
    Copy($sourcePath, $destinationPath) {
        const callbacks = {
            onChange($args) {
                // declare default callback
            },
            onComplete($success) {
                // declare default callback
            }
        };
        this.invoke("Copy", $sourcePath, $destinationPath)
            .Then(($result) => {
            if (ObjectValidator.IsSet($result.type)) {
                if ($result.type === EventType.ON_CHANGE) {
                    if (ObjectValidator.IsSet($result.data)) {
                        $result = $result.data;
                    }
                    const args = new ProgressEventArgs();
                    args.RangeStart($result.rangeStart);
                    args.RangeEnd($result.rangeEnd);
                    args.CurrentValue($result.currentValue);
                    callbacks.onChange(args);
                }
                else if ($result.type === EventType.ON_COMPLETE) {
                    callbacks.onComplete($result.data);
                }
            }
            else if (ObjectValidator.IsBoolean($result)) {
                callbacks.onComplete($result);
            }
        });
        const promise = {
            OnChange: ($callback) => {
                callbacks.onChange = $callback;
                return promise;
            },
            Then: ($callback) => {
                callbacks.onComplete = $callback;
            }
        };
        return promise;
    }
    Download($sourcePathOrOptions) {
        const callbacks = {
            connectionId: -1,
            onChange($args) {
                // declare default callback
            },
            onComplete($tmpPathOrHeaders, $bodyOrHeaders) {
                // declare default callback
            },
            onError: null,
            onStart($connectionId) {
                // declare default callback
            }
        };
        const methodCall = new LiveContentWrapper(this.getServerNamespace());
        this.getClient().Send(methodCall.getProtocolForInvokeMethod.apply(methodCall, [this.getId(), "Download", $sourcePathOrOptions]), ($data) => {
            callbacks.connectionId = $data.id;
            methodCall.getResponseHandler(methodCall, $data);
        });
        methodCall
            .OnError(($error, ...$args) => {
            this.errorHandler(callbacks.onError, $error, $args);
        })
            .Then(($result) => {
            if (!ObjectValidator.IsEmptyOrNull($result) && ObjectValidator.IsSet($result.type)) {
                if ($result.type === EventType.ON_START) {
                    callbacks.onStart(callbacks.connectionId);
                }
                else if ($result.type === EventType.ON_CHANGE) {
                    if (ObjectValidator.IsSet($result.data)) {
                        $result = $result.data;
                    }
                    const args = new ProgressEventArgs();
                    args.RangeStart($result.rangeStart);
                    args.RangeEnd($result.rangeEnd);
                    args.CurrentValue($result.currentValue);
                    callbacks.onChange(args);
                }
                else if ($result.type === EventType.ON_COMPLETE) {
                    $result.headers = {};
                    if (ObjectValidator.IsSet($result.data)) {
                        $result.headers = $result.data[0];
                        if (ObjectValidator.IsObject($sourcePathOrOptions) &&
                            $sourcePathOrOptions.streamOutput) {
                            $result.body = $result.data[1];
                        }
                        else {
                            $result.path = $result.data[1];
                        }
                    }
                    const headers = new ArrayList();
                    let parameter;
                    for (parameter in $result.headers) {
                        if ($result.headers.hasOwnProperty(parameter)) {
                            headers.Add($result.headers[parameter], parameter);
                        }
                    }
                    if (ObjectValidator.IsSet($result.path)) {
                        callbacks.onComplete($result.path, headers);
                    }
                    else {
                        callbacks.onComplete(headers, $result.body);
                    }
                }
            }
        });
        const promise = {
            OnChange: ($callback) => {
                callbacks.onChange = $callback;
                return promise;
            },
            OnComplete: ($callback) => {
                callbacks.onComplete = $callback;
                return promise;
            },
            OnError: ($callback) => {
                callbacks.onError = $callback;
                return promise;
            },
            OnStart: ($callback) => {
                callbacks.onStart = $callback;
                return promise;
            },
            Then: ($callback) => {
                callbacks.onComplete = $callback;
            }
        };
        return promise;
    }
    AbortDownload($id) {
        return this.invoke("AbortDownload", $id);
    }
    Unpack($path, $options) {
        const callbacks = {
            onError: null,
            then($data) {
                // declare default callback
            }
        };
        this.invoke("Unpack", $path, $options)
            .OnError(($error, ...$args) => {
            this.errorHandler(callbacks.onError, $error, $args);
        })
            .Then(($result) => {
            if (ObjectValidator.IsSet($result.type) && $result.type === EventType.ON_COMPLETE) {
                if (ObjectValidator.IsSet($result.path)) {
                    callbacks.then($result.path);
                }
                else {
                    callbacks.then($result.data);
                }
            }
        });
        const promise = {
            OnError: ($callback) => {
                callbacks.onError = $callback;
                return promise;
            },
            Then: ($callback) => {
                callbacks.then = $callback;
            }
        };
        return promise;
    }
    CreateShortcut($source, $destination, $options) {
        const callbacks = {
            onError: null,
            then($status) {
                // declare default callback
            }
        };
        this.invoke("CreateShortcut", $source, $destination, $options)
            .OnError(($error, ...$args) => {
            this.errorHandler(callbacks.onError, $error, $args);
        })
            .Then(($status) => {
            callbacks.then($status);
        });
        const promise = {
            OnError: ($callback) => {
                callbacks.onError = $callback;
                return promise;
            },
            Then: ($callback) => {
                callbacks.then = $callback;
            }
        };
        return promise;
    }
    getLinkTargetPath($path) {
        return this.invoke("getLinkTargetPath", $path);
    }
    IsEmpty($path) {
        return this.invoke("IsEmpty", $path);
    }
    Pack($path, $options) {
        const callbacks = {
            onError: null,
            then($data) {
                // declare default callback
            }
        };
        this.invoke("Pack", $path, $options)
            .OnError(($error, ...$args) => {
            this.errorHandler(callbacks.onError, $error, $args);
        })
            .Then(($data) => {
            callbacks.then($data);
        });
        const promise = {
            OnError: ($callback) => {
                callbacks.onError = $callback;
                return promise;
            },
            Then: ($callback) => {
                callbacks.then = $callback;
            }
        };
        return promise;
    }
    IsFile($path) {
        return this.invoke("IsFile", $path);
    }
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.DESKTOP_CONNECTOR] = "Io.Oidis.Connector.Connectors.FileSystemHandler";
        namespaces[WebServiceClientType.BUILDER_CONNECTOR] = "Io.Oidis.Builder.Connectors.FileSystemHandler";
        namespaces[WebServiceClientType.FORWARD_CLIENT] = "Io.Oidis.Connector.Connectors.FileSystemHandler";
        namespaces[WebServiceClientType.HOST_CLIENT] = "Io.Oidis.Connector.Connectors.FileSystemHandler";
        return namespaces;
    }
}
/**
 * FileSystemHandlerConnector class provides wrapping of local file system services provided by Oidis Connector instance.
 */
export class FileSystemHandlerConnector extends BaseFileSystemHandlerConnector {
    /**
     * @returns {IFileSystemFilePromise} Returns promise interface for handling of data receive event.
     */
    getTempPath() {
        return super.getTempPath();
    }
    /**
     * @returns {IFileSystemFilePromise} Returns promise interface for handling of data receive event.
     */
    getProjectBasePath() {
        return super.getProjectBasePath();
    }
    /**
     * @returns {IFileSystemFilePromise} Returns promise interface for handling of data receive event.
     */
    getAppDataPath() {
        return super.getAppDataPath();
    }
    /**
     * @returns {IFileSystemFilePromise} Returns promise interface for handling of data receive event.
     */
    getLocalAppDataPath() {
        return super.getLocalAppDataPath();
    }
    /**
     * @returns {IFileSystemFilePromise} Returns promise interface for handling of data receive event.
     */
    getHostLocation() {
        return super.getHostLocation();
    }
    /**
     * @param {string} [$path] Specify path, which should be looked up.
     * @returns {IFileSystemMapPromise} Returns promise interface for handling of data receive event.
     */
    getPathMap($path) {
        return super.getPathMap($path);
    }
    /**
     * @param {string} [$additionalInfo=false] Specify, if additional network information should be processed e.g. ARP with DNS lookup.
     * @returns {IFileSystemMapPromise} Returns promise interface for handling of data receive event.
     */
    getNetworkMap($additionalInfo = false) {
        return super.getNetworkMap($additionalInfo);
    }
    /**
     * @param {string} $path Specify path, which should be looked up.
     * @returns {IFileSystemMapPromise} Returns promise interface for handling of data receive event.
     */
    getDirectoryContent($path) {
        return super.getDirectoryContent($path);
    }
    /**
     * @param {string|string[]} $pattern Specify pattern for search.
     * @returns {IFileSystemExpandPromise} Returns a unique array of all file or directory paths that match the given $pattern.
     */
    Expand($pattern) {
        return super.Expand($pattern);
    }
    /**
     * @param {string} $path Specify path, which should be validated.
     * @returns {IFileSystemStatusPromise} Returns promise interface for handling of existence event.
     */
    Exists($path) {
        return super.Exists($path);
    }
    /**
     * @param {string} $path Specify file path, which should be used as data destination.
     * @param {string} $data Specify data, which should saved.
     * @param {boolean} [$append=false] Specify, if data should be appended to existing data in the file.
     * @param {boolean} [$stream=false] Specify, if data should be consumed as base64 stream.
     * @returns {IFileSystemStatusPromise} Returns promise interface for handling of write event.
     */
    Write($path, $data, $append = false, $stream = false) {
        return super.Write($path, $data, $append, $stream);
    }
    /**
     * @param {string} $path Specify file path, which should be read.
     * @param {boolean} [$stream=false] Specify, if output should be in base64 format.
     * @returns {IFileSystemFilePromise} Returns promise interface for handling of data receive event.
     */
    Read($path, $stream = false) {
        return super.Read($path, $stream);
    }
    /**
     * @param {string} $path Specify path, which should be deleted.
     * @returns {IFileSystemChangePromise} Returns promise interface for handling delete event.
     */
    Delete($path) {
        return super.Delete($path);
    }
    /**
     * @param {string} $path Specify path, which should be created.
     * @returns {IFileSystemStatusPromise} Returns promise interface for handling directory create event.
     */
    CreateDirectory($path) {
        return super.CreateDirectory($path);
    }
    /**
     * @param {string} $oldPath Specify path, which should be renamed.
     * @param {string} $newPath Specify new path value.
     * @returns {IFileSystemStatusPromise} Returns promise interface for handling rename event.
     */
    Rename($oldPath, $newPath) {
        return super.Rename($oldPath, $newPath);
    }
    /**
     * @param {string} $sourcePath Specify path, which should be used as data source.
     * @param {string} $destinationPath Specify path, where should be data stored.
     * @returns {IFileSystemChangePromise} Returns promise interface for handling copy event.
     */
    Copy($sourcePath, $destinationPath) {
        return super.Copy($sourcePath, $destinationPath);
    }
    /**
     * @param {string | IFileSystemDownloadOptions} $source Specify path or HTTP request options,
     * which should be used for download of data source.
     * @returns {IFileSystemStatusPromise} Returns promise interface for handling download event.
     */
    Download($source) {
        return super.Download($source);
    }
    /**
     * @param {number} $id Specify connection id, which should be closed.
     * @returns {IFileSystemStatusPromise} Returns promise interface for handling download abort event.
     */
    AbortDownload($id) {
        return super.AbortDownload($id);
    }
    /**
     * @param {string} $path Specify path, which should be unpacked.
     * @param {IArchiveOptions} [$options] Specify additional options for unpack process.
     * @returns {IFileSystemFilePromise} Returns promise interface for handling unpack event.
     */
    Unpack($path, $options) {
        return super.Unpack($path, $options);
    }
    /**
     * @param {string} $source Specify path, which should be used as shortcut target.
     * @param {string} $destination Specify path, where should be shortcut created.
     * @param {IShortcutOptions} [$options] Specify shortcut details.
     * @returns {IFileSystemStatusPromise} Returns promise interface for handling shortcut event.
     */
    CreateShortcut($source, $destination, $options) {
        return super.CreateShortcut($source, $destination, $options);
    }
    /**
     * @param {string} $path Specify link path, which should be resolved to target path.
     * @returns {IFileSystemStatusPromise} Returns promise interface for handling of write event.
     */
    getLinkTargetPath($path) {
        return super.getLinkTargetPath($path);
    }
    /**
     * Validate, if Directory or File is empty
     * @param {string} $path Specify path, which should be validated.
     * @returns {IFileSystemStatusPromise} Returns promise interface for handling this event.
     */
    IsEmpty($path) {
        return super.IsEmpty($path);
    }
    /**
     * @param {string} $path Specify path, which should be packed.
     * @param {IArchiveOptions} [$options] Specify additional options for pack process.
     * @returns {IFileSystemFilePromise} Returns promise interface for handling pack event.
     */
    Pack($path, $options) {
        return super.Pack($path, $options);
    }
    /**
     * @param {string} $path Specify path, which should be validated.
     * @returns {IFileSystemStatusPromise} Returns promise interface for handling this event.
     */
    IsFile($path) {
        return super.IsFile($path);
    }
}
/**
 * FileSystemHandlerConnectorAsync class provides same wrapping as FileSystemHandlerConnector but with native promise handling.
 */
export class FileSystemHandlerConnectorAsync extends BaseFileSystemHandlerConnector {
    /**
     * @returns {Promise<string>} Returns promise interface for handling of data receive event.
     */
    getTempPath() {
        return this.asyncInvoke(super.getTempPath);
    }
    /**
     * @returns {Promise<string>} Returns promise interface for handling of data receive event.
     */
    getProjectBasePath() {
        return this.asyncInvoke(super.getProjectBasePath);
    }
    /**
     * @returns {Promise<string>} Returns promise interface for handling of data receive event.
     */
    getAppDataPath() {
        return this.asyncInvoke(super.getAppDataPath);
    }
    /**
     * @returns {Promise<string>} Returns promise interface for handling of data receive event.
     */
    getLocalAppDataPath() {
        return this.asyncInvoke(super.getLocalAppDataPath);
    }
    /**
     * @returns {Promise<string>} Returns promise interface for handling of data receive event.
     */
    getHostLocation() {
        return this.asyncInvoke(super.getHostLocation);
    }
    /**
     * @param {string} [$path] Specify path, which should be looked up.
     * @returns {Promise<IFileSystemItemProtocol[]>} Returns promise interface for handling of data receive event.
     */
    getPathMap($path) {
        return this.asyncInvoke(super.getPathMap, $path);
    }
    /**
     * @param {string} [$additionalInfo=false] Specify, if additional network information should be processed e.g. ARP with DNS lookup.
     * @returns {Promise<IFileSystemItemProtocol[]>} Returns promise interface for handling of data receive event.
     */
    getNetworkMap($additionalInfo = false) {
        return this.asyncInvoke(super.getNetworkMap, $additionalInfo);
    }
    /**
     * @param {string} $path Specify path, which should be looked up.
     * @returns {Promise<IFileSystemItemProtocol[]>} Returns promise interface for handling of data receive event.
     */
    getDirectoryContent($path) {
        return this.asyncInvoke(super.getDirectoryContent, $path);
    }
    /**
     * @param {string|string[]} $pattern Specify pattern for search.
     * @returns {Promise<string[]>} Returns a unique array of all file or directory paths that match the given $pattern.
     */
    Expand($pattern) {
        return this.asyncInvoke(super.Expand, $pattern);
    }
    /**
     * @param {string} $path Specify path, which should be validated.
     * @returns {Promise<boolean>} Returns promise interface for handling of existence event.
     */
    Exists($path) {
        return this.asyncInvoke(super.Exists, $path);
    }
    /**
     * @param {string} $path Specify file path, which should be used as data destination.
     * @param {string} $data Specify data, which should saved.
     * @param {boolean} [$append=false] Specify, if data should be appended to existing data in the file.
     * @param {boolean} [$stream=false] Specify, if data should be consumed as base64 stream.
     * @returns {Promise<boolean>} Returns promise interface for handling of write event.
     */
    Write($path, $data, $append = false, $stream = false) {
        return this.asyncInvoke(super.Write, $path, $data, $append, $stream);
    }
    /**
     * @param {string} $path Specify file path, which should be read.
     * @param {boolean} [$stream=false] Specify, if output should be in base64 format.
     * @returns {Promise<string>} Returns promise interface for handling of data receive event.
     */
    Read($path, $stream = false) {
        return this.asyncInvoke(super.Read, $path, $stream);
    }
    /**
     * @param {string} $path Specify path, which should be deleted.
     * @param {($args : ProgressEventArgs) => void} [$onChange] Specify callback used for progress processing.
     * @returns {Promise<boolean>} Returns promise interface for handling delete event.
     */
    Delete($path, $onChange) {
        return new Promise(($resolve, $reject) => {
            try {
                const promise = super.Delete($path);
                if (!ObjectValidator.IsEmptyOrNull($onChange)) {
                    promise.OnChange($onChange);
                }
                if (!ObjectValidator.IsEmptyOrNull(promise.OnError)) {
                    promise.OnError(($error) => {
                        $reject(new Error($error.Message()));
                    });
                }
                promise.Then($resolve);
            }
            catch (ex) {
                $reject(ex);
            }
        });
    }
    /**
     * @param {string} $path Specify path, which should be created.
     * @returns {Promise<boolean>} Returns promise interface for handling directory create event.
     */
    CreateDirectory($path) {
        return this.asyncInvoke(super.CreateDirectory, $path);
    }
    /**
     * @param {string} $oldPath Specify path, which should be renamed.
     * @param {string} $newPath Specify new path value.
     * @returns {Promise<boolean>} Returns promise interface for handling rename event.
     */
    Rename($oldPath, $newPath) {
        return this.asyncInvoke(super.Rename, $oldPath, $newPath);
    }
    /**
     * @param {string} $sourcePath Specify path, which should be used as data source.
     * @param {string} $destinationPath Specify path, where should be data stored.
     * @param {($args : ProgressEventArgs) => void} [$onChange] Specify callback used for progress processing.
     * @returns {Promise<boolean>} Returns promise interface for handling copy event.
     */
    Copy($sourcePath, $destinationPath, $onChange) {
        return new Promise(($resolve, $reject) => {
            try {
                const promise = super.Copy($sourcePath, $destinationPath);
                if (!ObjectValidator.IsEmptyOrNull($onChange)) {
                    promise.OnChange($onChange);
                }
                if (!ObjectValidator.IsEmptyOrNull(promise.OnError)) {
                    promise.OnError(($error) => {
                        $reject(new Error($error.Message()));
                    });
                }
                promise.Then($resolve);
            }
            catch (ex) {
                $reject(ex);
            }
        });
    }
    /**
     * @param {string | IFileSystemDownloadOptions} $source Specify path or HTTP request options,
     * which should be used for download of data source.
     * @param {IFileSystemDownloadHandlers} [$handlers] Specify callbacks used for progress processing.
     * @returns {Promise<IFileSystemDownloadResponse>} Returns promise interface for handling download event.
     */
    Download($source, $handlers) {
        return new Promise(($resolve, $reject) => {
            try {
                const promise = super.Download($source);
                if (!ObjectValidator.IsEmptyOrNull($handlers)) {
                    if (!ObjectValidator.IsEmptyOrNull($handlers.onStart)) {
                        promise.OnStart($handlers.onStart);
                    }
                    if (!ObjectValidator.IsEmptyOrNull($handlers.onChange)) {
                        promise.OnChange($handlers.onChange);
                    }
                }
                if (!ObjectValidator.IsEmptyOrNull(promise.OnError)) {
                    promise.OnError(($error) => {
                        $reject(new Error($error.Message()));
                    });
                }
                promise.Then(($pathOrHeaders, $body) => {
                    $resolve({
                        body: $body,
                        headers: $pathOrHeaders,
                        tmpPath: $pathOrHeaders
                    });
                });
            }
            catch (ex) {
                $reject(ex);
            }
        });
    }
    /**
     * @param {number} $id Specify connection id, which should be closed.
     * @returns {Promise<boolean>} Returns promise interface for handling download abort event.
     */
    AbortDownload($id) {
        return this.asyncInvoke(super.AbortDownload, $id);
    }
    /**
     * @param {string} $path Specify path, which should be unpacked.
     * @param {IArchiveOptions} [$options] Specify additional options for unpack process.
     * @returns {Promise<string>} Returns promise interface for handling unpack event.
     */
    Unpack($path, $options) {
        return this.asyncInvoke(super.Unpack, $path, $options);
    }
    /**
     * @param {string} $source Specify path, which should be used as shortcut target.
     * @param {string} $destination Specify path, where should be shortcut created.
     * @param {IShortcutOptions} [$options] Specify shortcut details.
     * @returns {Promise<boolean>} Returns promise interface for handling shortcut event.
     */
    CreateShortcut($source, $destination, $options) {
        return this.asyncInvoke(super.CreateShortcut, $source, $destination, $options);
    }
    /**
     * @param {string} $path Specify link path, which should be resolved to target path.
     * @returns {Promise<string>} Returns promise interface for handling of write event.
     */
    getLinkTargetPath($path) {
        return this.asyncInvoke(super.getLinkTargetPath, $path);
    }
    /**
     * Validate, if Directory or File is empty
     * @param {string} $path Specify path, which should be validated.
     * @returns {Promise<boolean>} Returns promise interface for handling this event.
     */
    IsEmpty($path) {
        return this.asyncInvoke(super.IsEmpty, $path);
    }
    /**
     * @param {string} $path Specify path, which should be packed.
     * @param {IArchiveOptions} [$options] Specify additional options for pack process.
     * @returns {Promise<string>} Returns promise interface for handling pack event.
     */
    Pack($path, $options) {
        return this.asyncInvoke(super.Pack, $path, $options);
    }
    /**
     * @param {string} $path Specify path, which should be validated.
     * @returns {Promise<boolean>} Returns promise interface for handling this event.
     */
    IsFile($path) {
        return this.asyncInvoke(super.IsFile, $path);
    }
}
/** Window run style for OS shortcuts (normal, maximized, minimized). */
export var ShortcutRunStyle;
(function (ShortcutRunStyle) {
    ShortcutRunStyle[ShortcutRunStyle["NORMAL"] = 1] = "NORMAL";
    ShortcutRunStyle[ShortcutRunStyle["MAX"] = 3] = "MAX";
    ShortcutRunStyle[ShortcutRunStyle["MIN"] = 7] = "MIN";
})(ShortcutRunStyle || (ShortcutRunStyle = {}));
// generated-code-start
/* eslint-disable */
export const IFileSystemMapPromise = globalThis.RegisterInterface(["Then"]);
export const IFileSystemStatusErrorPromise = globalThis.RegisterInterface(["OnError", "Then"]);
export const IFileSystemStatusPromise = globalThis.RegisterInterface(["Then"]);
export const IFileSystemFileErrorPromise = globalThis.RegisterInterface(["OnError", "Then"]);
export const IFileSystemFilePromise = globalThis.RegisterInterface(["Then"]);
export const IFileSystemChangePromise = globalThis.RegisterInterface(["OnChange", "Then"]);
export const IFileSystemDownloadPromise = globalThis.RegisterInterface(["OnStart", "OnChange", "OnComplete", "OnError", "Then"]);
export const IFileSystemExpandPromise = globalThis.RegisterInterface(["Then"]);
export const IFileSystemResultProtocol = globalThis.RegisterInterface(["type", "rangeStart", "rangeEnd", "currentValue", "path", "headers", "body", "data"]);
export const IFileSystemDownloadOptions = globalThis.RegisterInterface(["method", "url", "headers", "body", "streamOutput", "proxy", "streamReturnsBuffer", "verbose", "strictSSL", "proxyConfig", "mTLS"]);
export const IProxyConfig = globalThis.RegisterInterface(["httpProxy", "httpsProxy", "noProxy"]);
export const IMTLSConfig = globalThis.RegisterInterface(["cert", "key", "ca"]);
export const IFileSystemDownloadHandlers = globalThis.RegisterInterface(["onStart", "onChange"]);
export const IFileSystemDownloadResponse = globalThis.RegisterInterface(["tmpPath", "headers", "body"]);
export const IShortcutOptions = globalThis.RegisterInterface(["args", "workingDir", "runStyle", "icon", "iconIndex", "hotkey", "desc"]);
export const IArchiveOptions = globalThis.RegisterInterface(["cwd", "output", "type", "autoStrip", "override"]);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.FileSystemHandlerConnector", FileSystemHandlerConnector);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.FileSystemHandlerConnectorAsync", FileSystemHandlerConnectorAsync);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFileSystemMapPromise", IFileSystemMapPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFileSystemStatusErrorPromise", IFileSystemStatusErrorPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFileSystemStatusPromise", IFileSystemStatusPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFileSystemFileErrorPromise", IFileSystemFileErrorPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFileSystemFilePromise", IFileSystemFilePromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFileSystemChangePromise", IFileSystemChangePromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFileSystemDownloadPromise", IFileSystemDownloadPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFileSystemExpandPromise", IFileSystemExpandPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFileSystemResultProtocol", IFileSystemResultProtocol);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFileSystemDownloadOptions", IFileSystemDownloadOptions);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IProxyConfig", IProxyConfig);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IMTLSConfig", IMTLSConfig);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFileSystemDownloadHandlers", IFileSystemDownloadHandlers);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IFileSystemDownloadResponse", IFileSystemDownloadResponse);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IShortcutOptions", IShortcutOptions);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IArchiveOptions", IArchiveOptions);
//# sourceMappingURL=FileSystemHandlerConnector.js.map