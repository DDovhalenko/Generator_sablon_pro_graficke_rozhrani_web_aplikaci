/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
import { LiveContentWrapper } from "../WebServiceApi/LiveContentWrapper.js";
/**
 * IdeHandlerConnector class provides wrapping of IDE manipulation provided by Jxbrowser bridge.
 */
export class IdeHandlerConnector extends BaseConnector {
    /**
     * @param {string} [$path] Define path where file chooser should be initialized
     * @param {string[]} [$extensions] Define extensions filter
     * @returns {IIdeHandlerFileChooserPromise} Returns promise interface for handling of open file chooser event.
     */
    OpenFileChooser($path, $extensions) {
        const path = ObjectValidator.IsSet($path) ? $path : null;
        const extensions = ObjectValidator.IsSet($extensions) ? $extensions : null;
        return this.invoke("OpenFileChooser", path, extensions, this.getId());
    }
    /**
     * @param {string} $title Define dialog title
     * @param {string} $message Define dialog message
     * @returns {IIdeHandlerSuccessPromise} Returns promise interface for handling of open info dialog event.
     */
    OpenInfoDialog($title, $message) {
        return this.invoke("OpenInfoDialog", $title, $message, this.getId());
    }
    /**
     * @returns {IIdeHandlerPathPromise} Returns promise interface for handling of path info dialog event.
     */
    getWorkspaceRoot() {
        return this.invoke("getWorkspaceRoot", this.getId());
    }
    /**
     * @param {string} $name Specify event name value.
     * @param {IWebServiceResponseHandler} [$handler] Specify handler, which should be used for handling of event data.
     * @returns {void}
     */
    AddEventListener($name, $handler) {
        LiveContentWrapper.AddEventHandler(this.getClient(), this.getServerNamespaces(), $name, (...$args) => {
            $handler.apply(this, $args);
        });
    }
    getClientType() {
        return WebServiceClientType.JXBROWSER_BRIDGE;
    }
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.JXBROWSER_BRIDGE] = "Io.Oidis.IdeJRE.Connectors.IdeHandler";
        return namespaces;
    }
}
// generated-code-start
export const IIdeHandlerFileChooserPromise = globalThis.RegisterInterface(["Then"]);
export const IIdeHandlerPathPromise = globalThis.RegisterInterface(["Then"]);
export const IIdeHandlerSuccessPromise = globalThis.RegisterInterface(["Then"]);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IdeHandlerConnector", IdeHandlerConnector);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IIdeHandlerFileChooserPromise", IIdeHandlerFileChooserPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IIdeHandlerPathPromise", IIdeHandlerPathPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IIdeHandlerSuccessPromise", IIdeHandlerSuccessPromise);
//# sourceMappingURL=IdeHandlerConnector.js.map