/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "./../../../../Io/Oidis/Commons/Enums/Events/EventType.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
/**
 * NetworkingConnector class provides wrapping of networking services provided by Oidis Connector instance.
 */
export class NetworkingConnector extends BaseConnector {
    /**
     * @returns {INetworkingConnectorPortPromise} Returns promise interface for handling of free port.
     */
    getFreePort() {
        return this.invoke("getFreePort");
    }
    /**
     * Start listening on a TCP port for incoming connections. Provides streaming
     * events for client connect, message receive, and listener completion.
     * @param {number} $port Specify the port number to listen on.
     * @returns {INetworkingConnectorListenPromise} Returns promise with OnConnect/OnMessage/Then handlers.
     */
    AddPortListener($port) {
        const callbacks = {
            onConnect($clientId) {
                // declare default callback
            },
            onMessage($data) {
                // declare default callback
            },
            onComplete() {
                // declare default callback
            }
        };
        this.invoke("AddPortListener", $port)
            .Then(($result) => {
            if (ObjectValidator.IsSet($result.type)) {
                if ($result.type === EventType.ON_START) {
                    callbacks.onConnect($result.data);
                }
                else if ($result.type === EventType.ON_CHANGE) {
                    callbacks.onMessage($result.data);
                }
                else if ($result.type === EventType.ON_COMPLETE) {
                    callbacks.onComplete();
                }
            }
        });
        const promise = {
            OnConnect: ($callback) => {
                callbacks.onConnect = $callback;
                return promise;
            },
            OnMessage: ($callback) => {
                callbacks.onMessage = $callback;
                return promise;
            },
            Then: ($callback) => {
                callbacks.onComplete = $callback;
            }
        };
        return promise;
    }
    /**
     * Remove a previously registered port listener, disconnecting the specified client.
     * @param {number} $port Specify the port number of the listener.
     * @param {string} $clientId Specify the client identifier to disconnect.
     * @returns {INetworkingAcknowledgePromise} Returns promise resolving when listener is removed.
     */
    RemovePortListener($port, $clientId) {
        return this.invoke("RemovePortListener", $clientId, $port);
    }
    /**
     * Write data to a specific TCP port.
     * @param {string} $data Specify the data string to send.
     * @param {number} $port Specify the target port number.
     * @returns {INetworkingAcknowledgePromise} Returns promise resolving when write completes.
     */
    WriteToPort($data, $port) {
        return this.invoke("WriteToPort", $data, $port);
    }
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.DESKTOP_CONNECTOR] = "Io.Oidis.Connector.Connectors.Network";
        namespaces[WebServiceClientType.BUILDER_CONNECTOR] = "Io.Oidis.Builder.Connectors.Network";
        namespaces[WebServiceClientType.FORWARD_CLIENT] = "Io.Oidis.Connector.Connectors.Network";
        return namespaces;
    }
}
// generated-code-start
/* eslint-disable */
export const INetworkingConnectorPortPromise = globalThis.RegisterInterface(["Then"]);
export const INetworkingAcknowledgePromise = globalThis.RegisterInterface(["Then"]);
export const INetworkingConnectorListenPromise = globalThis.RegisterInterface(["OnConnect", "OnMessage"], INetworkingAcknowledgePromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.NetworkingConnector", NetworkingConnector);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.INetworkingConnectorPortPromise", INetworkingConnectorPortPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.INetworkingAcknowledgePromise", INetworkingAcknowledgePromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.INetworkingConnectorListenPromise", INetworkingConnectorListenPromise);
//# sourceMappingURL=NetworkingConnector.js.map