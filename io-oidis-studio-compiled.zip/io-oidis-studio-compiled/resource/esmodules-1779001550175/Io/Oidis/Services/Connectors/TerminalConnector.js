import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
/**
 * Abstract base implementing process execution operations shared by both callback
 * and async connector variants. Provides Execute, Spawn, Elevate, Kill, and Open
 * methods that delegate to the backend Terminal service via LCP.
 */
class BaseTerminalConnector extends BaseConnector {
    Execute($command, $args, $cwdOrOptions) {
        return this.getProcessProtocol("Execute", $command, ObjectValidator.IsEmptyOrNull($args) ? [] : $args, $cwdOrOptions);
    }
    Spawn($command, $args, $cwdOrOptions) {
        return this.getProcessProtocol("Spawn", $command, ObjectValidator.IsEmptyOrNull($args) ? [] : $args, $cwdOrOptions);
    }
    Open($path) {
        return this.invoke("Open", $path)
            .DataFormatter(this.getDataFormatter);
    }
    Elevate($command, $args, $cwdOrOptions) {
        return this.getProcessProtocol("Elevate", $command, ObjectValidator.IsEmptyOrNull($args) ? [] : $args, $cwdOrOptions);
    }
    Kill($pathOrName) {
        return this.invoke("Kill", $pathOrName);
    }
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.DESKTOP_CONNECTOR] = "Io.Oidis.Connector.Connectors.Terminal";
        namespaces[WebServiceClientType.BUILDER_CONNECTOR] = "Io.Oidis.Builder.Connectors.Terminal";
        namespaces[WebServiceClientType.FORWARD_CLIENT] = "Io.Oidis.Connector.Connectors.Terminal";
        namespaces[WebServiceClientType.HOST_CLIENT] = "Io.Oidis.Connector.Connectors.Terminal";
        return namespaces;
    }
    getDataFormatter($data) {
        if ($data === "null") {
            return null;
        }
        else {
            if (!ObjectValidator.IsEmptyOrNull($data) && ObjectValidator.IsSet($data.type)) {
                return $data.data;
            }
            else {
                return $data;
            }
        }
    }
    getProcessProtocol($methodName, $command, $args, $cwdOrOptions) {
        const callbacks = {
            OnExit($exitCode, $stdout, $stderr) {
                // declare default callback
            },
            OnMessage($data) {
                // declare default callback
            }
        };
        let options = { cwd: "" };
        if (!ObjectValidator.IsEmptyOrNull($cwdOrOptions)) {
            if (ObjectValidator.IsString($cwdOrOptions)) {
                options = { cwd: $cwdOrOptions };
            }
            else {
                options = $cwdOrOptions;
            }
        }
        this.invoke($methodName, $command, $args, options)
            .DataFormatter(this.getDataFormatter)
            .Then(($returnValue, $stdout, $stderr) => {
            if (ObjectValidator.IsArray($returnValue)) {
                $stdout = $returnValue[1][0];
                $stderr = $returnValue[1][1];
                $returnValue = $returnValue[0];
            }
            if ($returnValue === null || ObjectValidator.IsInteger($returnValue)) {
                callbacks.OnExit($returnValue, $stdout, $stderr);
            }
            else if (!ObjectValidator.IsEmptyOrNull($returnValue)) {
                callbacks.OnMessage($returnValue);
            }
        });
        const promise = {
            OnMessage($callback) {
                callbacks.OnMessage = $callback;
                return promise;
            },
            Then($callback) {
                callbacks.OnExit = $callback;
            }
        };
        return promise;
    }
}
/**
 * TerminalConnector class provides wrapping of local file system services provided by Oidis Connector instance.
 */
export class TerminalConnector extends BaseTerminalConnector {
    /**
     * Create new child process and wait for process end
     * @param {string} $command Specify command, which should be executed.
     * @param {string[]} [$args] Specify command args, which should be passed to the executed process.
     * @param {string} [$cwdOrOptions] Specify current working directory for process execution or compact terminal options.
     * @returns {IProcessPromise} Returns promise API connected with response on process exit.
     */
    Execute($command, $args, $cwdOrOptions) {
        return super.Execute($command, $args, $cwdOrOptions);
    }
    /**
     * Create new child process and provide async stdout/stderr by OnMessage event
     * @param {string} $command Specify command, which should be executed.
     * @param {string[]} [$args] Specify command args, which should be passed to the executed process.
     * @param {string} [$cwdOrOptions] Specify current working directory for process execution or compact terminal options.
     * @returns {IProcessPromise} Returns promise API connected with response on process exit.
     */
    Spawn($command, $args, $cwdOrOptions) {
        return super.Spawn($command, $args, $cwdOrOptions);
    }
    /**
     * @param {string} $path Specify path, which should be opened.
     * @returns {IOpenPromise} Returns promise API connected with terminal response.
     */
    Open($path) {
        return super.Open($path);
    }
    /**
     * Create new elevated child process and wait for process end
     * @param {string} $command Specify command, which should be executed.
     * @param {string[]} [$args] Specify command args, which should be passed to the executed process.
     * @param {string} [$cwdOrOptions] Specify current working directory for process execution or compact terminal options.
     * @returns {IProcessPromise} Returns promise API connected with response on process exit.
     */
    Elevate($command, $args, $cwdOrOptions) {
        return super.Elevate($command, $args, $cwdOrOptions);
    }
    /**
     * Kill process on specified path or by name
     * @param {string} $pathOrName Specify path where should be process located or process name.
     * @returns {IAcknowledgePromise} Returns promise API connected with response on process kill.
     */
    Kill($pathOrName) {
        return super.Kill($pathOrName);
    }
}
/**
 * TerminalConnectorAsync class provides same wrapping as TerminalConnector but with native promise handling.
 */
export class TerminalConnectorAsync extends BaseTerminalConnector {
    Execute(...$args) {
        return this.asyncProcess(super.Execute, $args);
    }
    Spawn(...$args) {
        return this.asyncProcess(super.Spawn, $args);
    }
    /**
     * @param {string} $path Specify path, which should be opened.
     * @returns {IOpenPromise} Returns promise API connected with terminal response.
     */
    Open($path) {
        return this.asyncInvoke(super.Open, $path);
    }
    Elevate(...$args) {
        return this.asyncProcess(super.Elevate, $args);
    }
    /**
     * Kill process on specified path or by name
     * @param {string} $pathOrName Specify path where should be process located or process name.
     * @returns {Promise<boolean>} Returns promise API connected with response on process kill.
     */
    Kill($pathOrName) {
        return this.asyncInvoke(super.Kill, $pathOrName);
    }
    asyncProcess($method, $args) {
        return new Promise(($resolve, $reject) => {
            try {
                const options = {
                    command: $args[0]
                };
                if ($args.length === 2) {
                    if (ObjectValidator.IsArray($args[1])) {
                        options.args = $args[1];
                    }
                    else {
                        options.onChange = $args[1];
                    }
                }
                else if ($args.length === 3) {
                    options.args = $args[1];
                    if (ObjectValidator.IsString($args[2]) || ObjectValidator.IsObject($args[2]) ||
                        ObjectValidator.IsEmptyOrNull($args[2])) {
                        options.cwdOrOptions = $args[2];
                    }
                    else {
                        options.onChange = $args[2];
                    }
                }
                else if ($args.length > 3) {
                    options.args = $args[1];
                    options.cwdOrOptions = $args[2];
                    options.onChange = $args[3];
                }
                const promise = $method.apply(this, [options.command, options.args, options.cwdOrOptions]);
                if (!ObjectValidator.IsEmptyOrNull(options.onChange)) {
                    promise.OnMessage(options.onChange);
                }
                if (!ObjectValidator.IsEmptyOrNull(promise.OnError)) {
                    promise.OnError(($error) => {
                        $reject(new Error($error.Message()));
                    });
                }
                promise.Then(($exitCode, $stdout, $stderr) => {
                    $resolve({
                        exitCode: $exitCode,
                        std: [$stdout, $stderr],
                        stderr: $stderr,
                        stdout: $stdout
                    });
                });
            }
            catch (ex) {
                $reject(ex);
            }
        });
    }
}
// generated-code-start
export const IAdvancedTerminalOptions = globalThis.RegisterInterface(["colored", "noTerminalLog", "noExitOnStderr", "useStdIn"]);
export const ITerminalOptions = globalThis.RegisterInterface(["cwd", "env", "shell", "verbose", "detached", "advanced"]);
export const IProcessPromise = globalThis.RegisterInterface(["OnMessage", "Then"]);
export const IOpenPromise = globalThis.RegisterInterface(["Then"]);
export const IExecuteResult = globalThis.RegisterInterface(["exitCode", "stdout", "stderr", "std"]);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.TerminalConnector", TerminalConnector);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.TerminalConnectorAsync", TerminalConnectorAsync);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IAdvancedTerminalOptions", IAdvancedTerminalOptions);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.ITerminalOptions", ITerminalOptions);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IProcessPromise", IProcessPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IOpenPromise", IOpenPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IExecuteResult", IExecuteResult);
//# sourceMappingURL=TerminalConnector.js.map