/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "./../../../../Io/Oidis/Commons/Enums/Events/EventType.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { Convert } from "./../../../../Io/Oidis/Commons/Utils/Convert.js";
import { ObjectDecoder } from "./../../../../Io/Oidis/Commons/Utils/ObjectDecoder.js";
import { ObjectEncoder } from "./../../../../Io/Oidis/Commons/Utils/ObjectEncoder.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { BaseConnector } from "../Primitives/BaseConnector.js";
/**
 * WindowHandlerConnector class provides wrapping of window manipulation provided by Oidis Connector instance.
 */
export class WindowHandlerConnector extends BaseConnector {
    subscribers;
    pid;
    title;
    /**
     * @param {number} $pid Specify process ID, which should be handled
     * @param {string} [$title] Specify Window title in desired process
     */
    constructor($pid, $title) {
        super({ reconnect: true, suppressInit: true });
        this.subscribers = new ArrayList();
        if (ObjectValidator.IsSet($pid)) {
            this.pid = Property.Integer(this.pid, $pid);
            this.title = Property.String(this.title, $title);
        }
        this.init();
    }
    /**
     * @returns {IWindowHandlerConnectorEvents} Returns events interface connected with connector instance.
     */
    getEvents() {
        const superEvents = this.getClient().getEvents();
        this.extendClientEvents(superEvents, "OnNotifyIconClick");
        this.extendClientEvents(superEvents, "OnNotifyIconDoubleClick", "OnNotifyIconDbClick");
        this.extendClientEvents(superEvents, "OnNotifyIconBalloonClick");
        this.extendClientEvents(superEvents, "OnNotifyIconContextItemSelected");
        this.extendClientEvents(superEvents, "OnWindowChanged");
        return superEvents;
    }
    /**
     * @param {string} $windowId Specify window identifier.
     * @returns {IWindowHandlerStatusPromise} Returns promise interface for handling of window close event.
     */
    Close($windowId) {
        return this.invoke("Close", $windowId, this.pid, this.title);
    }
    /**
     * @param {string} $url Specify url which should be opened in new window.
     * @param {IWindowHandlerOpenOptions} [$options] Specify options, which should be passed to the executed command.
     * @returns {IWindowHandlerOpenPromise} Returns promise interface for handling of open event.
     */
    Open($url, $options) {
        const callbacks = {
            then($windowId, $url, $data) {
                // declare default callback
            }
        };
        this.invoke("Open", $url, $options)
            .Then(($result) => {
            if (ObjectValidator.IsSet($result.type)) {
                const result = $result;
                if (result.type === EventType.ON_COMPLETE) {
                    callbacks.then(result.windowId, result.url, result.data);
                }
            }
        });
        return {
            Then: ($callback) => {
                callbacks.then = $callback;
            }
        };
    }
    /**
     * @param {string} $windowId Specify window identifier.
     * @returns {IWindowHandlerCookiesPromise} Returns promise interface for handling of get cookies event.
     */
    getCookies($windowId) {
        return this.invoke("getCookies", $windowId);
    }
    /**
     * @param {string} $windowId Specify window identifier.
     * @param {IWindowHandlerScriptExecuteOptions} $options Specify options, which should be passed to the executed command.
     * @returns {IWindowHandlerChangePromise} Returns promise interface for handling of script execute event.
     */
    ScriptExecute($windowId, $options) {
        const callbacks = {
            onComplete($status) {
                // declare default callback
            },
            onMessage($message) {
                // declare default callback
            },
            onStart() {
                // declare default callback
            }
        };
        if (ObjectValidator.IsFunction($options.script)) {
            $options.script = "(" + Convert.FunctionToString($options.script) + ")();";
        }
        this.invoke("ScriptExecute", $windowId, $options)
            .Then(($result) => {
            if (ObjectValidator.IsSet($result.type)) {
                const result = $result;
                if (result.type === EventType.ON_START) {
                    callbacks.onStart();
                }
                else if (result.type === EventType.ON_CHANGE) {
                    callbacks.onMessage(result.data);
                }
                else if (result.type === EventType.ON_COMPLETE) {
                    callbacks.onComplete(true);
                }
            }
        });
        const promise = {
            OnMessage: ($callback) => {
                callbacks.onMessage = $callback;
                return promise;
            },
            OnStart: ($callback) => {
                callbacks.onStart = $callback;
                return promise;
            },
            Then: ($callback) => {
                callbacks.onComplete = $callback;
            }
        };
        return promise;
    }
    /**
     * @returns {IWindowHandlerStatusPromise} Returns promise interface for handling of window minimize event.
     */
    Minimize() {
        return this.invoke("Minimize", this.pid, this.title);
    }
    /**
     * @returns {IWindowHandlerStatusPromise} Returns promise interface for handling of window maximize event.
     */
    Maximize() {
        return this.invoke("Maximize", this.pid, this.title);
    }
    /**
     * Restore window state to normal state
     * @returns {IWindowHandlerStatusPromise} Returns promise interface for handling of window restore event.
     */
    Restore() {
        return this.invoke("Restore", this.pid, this.title);
    }
    /**
     * @param {number} $x Specify position from top
     * @param {number} $y Specify position from left
     * @returns {IWindowHandlerStatusPromise} Returns promise interface for handling of window move event.
     */
    MoveTo($x, $y) {
        return this.invoke("MoveTo", $x, $y, this.pid, this.title);
    }
    /**
     * @param {WindowCornerType} $cornerType Specify corner, which should be binded with new size coordinates
     * @param {number} $dx Specify position from top
     * @param {number} $dy Specify position from left
     * @returns {IWindowHandlerStatusPromise} Returns promise interface for handling of window move event.
     */
    Resize($cornerType, $dx, $dy) {
        return this.invoke("Resize", $cornerType, $dx, $dy, this.pid, this.title);
    }
    /**
     * @param {boolean} $status Specify, if window can be resized or not.
     * @returns {IWindowHandlerStatusPromise} Returns promise interface for handling of window resize handling event.
     */
    CanResize($status) {
        return this.invoke("CanResize", $status);
    }
    /**
     * @param {string} [$windowId] Specify window identifier.
     * @returns {IWindowHandlerStatusPromise} Returns promise interface for handling of window existence event.
     */
    Exists($windowId) {
        return this.invoke("Exists", $windowId, this.pid, this.title);
    }
    /**
     * @param {string} [$windowId] Specify window identifier.
     * @returns {IWindowHandlerStatusPromise} Returns promise interface for handling of window show event.
     */
    Show($windowId) {
        return this.invoke("Show", $windowId);
    }
    /**
     * @param {string} [$windowId] Specify window identifier.
     * @returns {IWindowHandlerStatusPromise} Returns promise interface for handling of window hide event.
     */
    Hide($windowId) {
        return this.invoke("Hide", $windowId);
    }
    /**
     * @param {string} [$windowId] Specify window identifier.
     * @returns {IWindowHandlerStatusPromise} Returns promise interface for handling of window state event.
     */
    getState($windowId) {
        return this.invoke("getState", $windowId);
    }
    /**
     * Creates notify icon in the system tray. Method fails if notify icon exists for current root window.
     * @param {IWindowHandlerNotifyIcon} $notifyIcon Specify notify icon options.
     * @returns {ILiveContentFormatterPromise} Returns promise interface for handling of window state event.
     */
    CreateNotifyIcon($notifyIcon) {
        const callbacks = {
            onComplete($status) {
                // declare default callback
            },
            onMessage($message) {
                // declare default callback
            }
        };
        this.invoke("CreateNotifyIcon", $notifyIcon)
            .Then(($result) => {
            if (ObjectValidator.IsSet($result.type)) {
                const result = $result;
                if (result.type === EventType.ON_MESSAGE) {
                    callbacks.onMessage(result.request);
                }
            }
        });
        const promise = {
            OnMessage: ($callback) => {
                callbacks.onMessage = $callback;
                return promise;
            },
            Then: ($callback) => {
                callbacks.onComplete = $callback;
            }
        };
        return promise;
    }
    /**
     * Modify notify icon previously created in the system tray. If notify icon is not exists than will be created with current options.
     * @param {IWindowHandlerNotifyIcon} $notifyIcon Specify notify icno options.
     * @returns {ILiveContentFormatterPromise} Returns promise interface for handling of window state event.
     */
    ModifyNotifyIcon($notifyIcon) {
        return this.invoke("ModifyNotifyIcon", $notifyIcon);
    }
    /**
     * Destroys existing notify icon.
     * @returns {ILiveContentFormatterPromise} Returns promise interface for handling of window state event.
     */
    DestroyNotifyIcon() {
        return this.invoke("DestroyNotifyIcon");
    }
    /**
     * Sets state of TaskBar progress attached with current root window.
     * @param {TaskBarProgressState} $state Specify new progress state.
     * @returns {ILiveContentFormatterPromise} Returns promise interface for handling of window state event.
     */
    setTaskBarProgressState($state) {
        return this.invoke("setTaskBarProgressState", $state);
    }
    /**
     * Sets progress value of TaskBar attached with current root window.
     * @param {number} $completed Specify completed progress (must be less or equal to $total).
     * @param {number} $total Specify maximal limit of progress.
     * @returns {ILiveContentFormatterPromise} Returns promise interface for handling of window state event.
     */
    setTaskBarProgressValue($completed, $total) {
        return this.invoke("setTaskBarProgressValue", $completed, $total);
    }
    /**
     * @param {string} $name Specify event name value.
     * @param {IWebServiceResponseHandler} $handler Specify handler, which should be used for handling of event data.
     * @returns {void}
     */
    AddEventListener($name, $handler) {
        this.getClient().Send(this.getProtocol("AddEventListener", {
            name: $name
        }), ($data) => {
            if ($data.type === "AddEventListener") {
                if (ObjectDecoder.Base64($data.data) === "true") {
                    if (!this.subscribers.KeyExists($name)) {
                        this.subscribers.Add(new ArrayList(), $name);
                    }
                    this.subscribers.getItem($name).Add($handler, $data.id);
                }
            }
            else if ($data.type === "FireEvent") {
                const data = JSON.parse(ObjectDecoder.Base64($data.data));
                if (this.subscribers.KeyExists(data.name)) {
                    const handlers = this.subscribers.getItem(data.name);
                    handlers.foreach(($handler, $id) => {
                        if ($id === $data.id) {
                            $handler.apply(this, JSON.parse(ObjectDecoder.Base64(data.args)));
                        }
                    });
                }
            }
        });
    }
    /**
     * @param {string} $name Specify event name value, which should be removed from events pool.
     * @returns {void}
     */
    RemoveEventListener($name) {
        if (this.subscribers.KeyExists($name)) {
            this.subscribers.RemoveAt(this.subscribers.getKeys().indexOf($name));
        }
    }
    /**
     * Sets progress value of TaskBar attached with current root window.
     * @param {IWindowHandlerFileDialogSettings} $settings Specify file dialog options.
     * @returns {IWindowHandlerFileDialogPromise} Returns promise interface for handling of file dialog events.
     */
    ShowFileDialog($settings) {
        const callbacks = {
            then($status, $path) {
                // declare default callback
            }
        };
        this.invoke("ShowFileDialog", $settings)
            .Then(($result, $path) => {
            if (ObjectValidator.IsArray($path) && $path.length === 1) {
                callbacks.then($result, $path[0]);
            }
            else {
                callbacks.then($result, $path);
            }
        });
        return {
            Then: ($callback) => {
                callbacks.then = $callback;
            }
        };
    }
    /**
     * Show HTML debug window from CEF instance.
     * @returns {IWindowHandlerStatusPromise} Returns promise interface for handling of debug console promise.
     */
    ShowDebugConsole() {
        return this.invoke("ShowDebugConsole");
    }
    getClientType() {
        if (!ObjectValidator.IsEmptyOrNull(this.pid) || !ObjectValidator.IsEmptyOrNull(this.title)) {
            return WebServiceClientType.DESKTOP_CONNECTOR;
        }
        return WebServiceClientType.CEF_QUERY;
    }
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.CEF_QUERY] = "Io.Oidis.ChromiumRE.Connectors.WindowHandler";
        namespaces[WebServiceClientType.DESKTOP_CONNECTOR] = "Io.Oidis.Connector.Connectors.WindowHandler";
        return namespaces;
    }
    getProtocol($type, $data) {
        return {
            data: ObjectEncoder.Base64(JSON.stringify($data)),
            type: $type
        };
    }
    extendClientEvents($container, $eventType, $interfaceName) {
        if (!ObjectValidator.IsSet($interfaceName)) {
            $interfaceName = $eventType;
        }
        $container[$eventType] = ($handler) => {
            this.AddEventListener($interfaceName, $handler);
        };
    }
}
// generated-code-start
/* eslint-disable */
export const IWindowHandlerOpenOptions = globalThis.RegisterInterface(["hidden"]);
export const IWindowHandlerScriptExecuteOptions = globalThis.RegisterInterface(["script"]);
export const IWindowHandlerResultProtocol = globalThis.RegisterInterface(["type", "data", "url", "windowId"]);
export const IWindowHandlerNotifyProtocol = globalThis.RegisterInterface(["type", "request"]);
export const IWindowHandlerOpenPromise = globalThis.RegisterInterface(["Then"]);
export const IWindowHandlerChangePromise = globalThis.RegisterInterface(["OnStart", "OnMessage", "Then"]);
export const IWindowHandlerStatusPromise = globalThis.RegisterInterface(["Then"]);
export const IWindowHandlerStatePromise = globalThis.RegisterInterface(["Then"]);
export const IWindowHandlerCookiesPromise = globalThis.RegisterInterface(["Then"]);
export const IWindowHandlerNotifyPromise = globalThis.RegisterInterface(["OnMessage", "Then"]);
export const IWindowHandlerFileDialogPromise = globalThis.RegisterInterface(["Then"]);
export const IWindowHandlerFileDialogSettings = globalThis.RegisterInterface(["title", "filter", "filterIndex", "path", "openOnly", "folderOnly", "multiSelect", "initialDirectory", "singleton", "timeout"]);
export const IWindowHandlerSaveFileDialogSettings = globalThis.RegisterInterface(["title", "filter", "filterIndex", "path", "initialDirectory", "extension", "autoExtension", "restore", "override", "singleton", "timeout"]);
export const IWindowHandlerCookie = globalThis.RegisterInterface(["path", "name", "value"]);
export const IWindowHandlerNotifyIcon = globalThis.RegisterInterface(["tip", "icon", "balloon", "contextMenu"]);
export const IWindowHandlerNotifyBalloon = globalThis.RegisterInterface(["title", "message", "type", "userIcon", "noSound"]);
export const IWindowHandlerNotifyIconContextMenu = globalThis.RegisterInterface(["items"]);
export const IWindowHandlerNotifyIconContextMenuItem = globalThis.RegisterInterface(["name", "label", "position"]);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.WindowHandlerConnector", WindowHandlerConnector);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerOpenOptions", IWindowHandlerOpenOptions);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerScriptExecuteOptions", IWindowHandlerScriptExecuteOptions);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerResultProtocol", IWindowHandlerResultProtocol);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerNotifyProtocol", IWindowHandlerNotifyProtocol);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerOpenPromise", IWindowHandlerOpenPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerChangePromise", IWindowHandlerChangePromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerStatusPromise", IWindowHandlerStatusPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerStatePromise", IWindowHandlerStatePromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerCookiesPromise", IWindowHandlerCookiesPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerNotifyPromise", IWindowHandlerNotifyPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerFileDialogPromise", IWindowHandlerFileDialogPromise);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerFileDialogSettings", IWindowHandlerFileDialogSettings);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerSaveFileDialogSettings", IWindowHandlerSaveFileDialogSettings);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerCookie", IWindowHandlerCookie);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerNotifyIcon", IWindowHandlerNotifyIcon);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerNotifyBalloon", IWindowHandlerNotifyBalloon);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerNotifyIconContextMenu", IWindowHandlerNotifyIconContextMenu);
globalThis.RegisterClass("Io.Oidis.Services.Connectors.IWindowHandlerNotifyIconContextMenuItem", IWindowHandlerNotifyIconContextMenuItem);
//# sourceMappingURL=WindowHandlerConnector.js.map