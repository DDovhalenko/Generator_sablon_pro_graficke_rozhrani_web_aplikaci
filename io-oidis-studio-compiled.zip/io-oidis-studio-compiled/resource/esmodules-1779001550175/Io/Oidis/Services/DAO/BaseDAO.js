/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { LanguageType } from "./../../../../Io/Oidis/Commons/Enums/LanguageType.js";
import { SyntaxConstants } from "./../../../../Io/Oidis/Commons/Enums/SyntaxConstants.js";
import { ExceptionsManager } from "./../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Resources } from "./Resources.js";
/**
 * BaseDAO class provides object oriented data parsed from resources stored at external files in JSON format
 * and basic data handling focused on controllers for business logic.
 */
export class BaseDAO extends BaseObject {
    static defaultConfigurationPath = "resource/data/Io/Oidis/Services/Configuration/BaseConfiguration.jsonp";
    static staticConfiguration;
    static loadedResources;
    language;
    configurationPath;
    parent;
    imports;
    configLibrary;
    configInstance;
    errorHandler;
    /**
     * Remove a previously loaded resource from the static cache by file path.
     * @param {string} $filePath Specify the file path of the resource to unload.
     */
    static UnloadResource($filePath) {
        BaseDAO.loadedResources.RemoveAt(BaseDAO.loadedResources.IndexOf(BaseDAO.loadedResources.getItem($filePath)));
    }
    static getDaoInterfaceClassName($interfaceName) {
        return BaseDAO;
    }
    static passGlobalVariables($processor, $variables) {
        let propertyName;
        for (propertyName in $variables) {
            if (ObjectValidator.IsSet($processor[propertyName])) {
                $processor[propertyName] = $variables[propertyName];
                if (ObjectValidator.IsSet($processor.$super)) {
                    $processor.$super[propertyName] = $variables[propertyName];
                }
            }
            else {
                ExceptionsManager.Throw("Configuration Processor", "Unable to pass global variables - identifier \"" + propertyName + "\" has not been detected.");
            }
        }
    }
    constructor() {
        super();
        this.setConfigurationPath(Reflection.getInstance().getClass(this.getClassName()).defaultConfigurationPath);
        this.setDefaultLanguage(LanguageType.EN);
        if (!ObjectValidator.IsSet(BaseDAO.staticConfiguration)) {
            BaseDAO.staticConfiguration = new ArrayList();
        }
        if (!ObjectValidator.IsSet(BaseDAO.loadedResources)) {
            BaseDAO.loadedResources = new ArrayList();
        }
        this.parent = null;
        this.imports = new ArrayList();
    }
    /**
     * @returns {BaseDAO} Returns DAO from, which has been current DAO extended.
     */
    getParentDAO() {
        return this.parent;
    }
    /**
     * @param {string} $variableName Specify import variable name, which should be looked up
     * @returns {BaseDAO} Returns imported DAO in case of that variable name exist, otherwise null.
     */
    getImportedDAO($variableName) {
        if (this.imports.KeyExists($variableName)) {
            return this.imports.getItem($variableName);
        }
        return null;
    }
    /**
     * @returns {string} Returns data source name for current DAO instance
     */
    getDaoDataSource() {
        return this.configurationPath;
    }
    /**
     * @param {Language} $language Specify language for, which should be data loaded.
     * @param {Function} $asyncHandler Specify asynchronous handler which should be executed when DAO is loaded.
     * @param {boolean} [$force=false] Force load DAO data all its dependencies.
     * @returns {void}
     */
    Load($language, $asyncHandler, $force = false) {
        if ($force) {
            const propertyName = "configInstance";
            delete this[propertyName];
        }
        const requiredLanguage = $language.toString();
        const thisClass = Reflection.getInstance().getClass(this.getClassName());
        const resourcesClass = this.getResourcesHandler();
        if (!BaseDAO.staticConfiguration.KeyExists(this.configurationPath) || $force) {
            BaseDAO.staticConfiguration.Add(new ArrayList(), this.configurationPath);
        }
        const thisConfiguration = BaseDAO.staticConfiguration.getItem(this.configurationPath);
        const fireLoaded = () => {
            const loadImports = () => {
                const imports = this.getStaticConfiguration().imports;
                if (!ObjectValidator.IsEmptyOrNull(imports)) {
                    const importsVariables = [];
                    let index = 0;
                    let varName;
                    for (varName in imports) {
                        if (!ObjectValidator.IsEmptyOrNull(varName) && !ObjectValidator.IsEmptyOrNull(imports[varName])) {
                            importsVariables[index] = varName;
                            index++;
                        }
                    }
                    if (index > 0) {
                        index = 0;
                        const loadImport = () => {
                            const importDAO = new (thisClass.getDaoInterfaceClassName(null))();
                            importDAO.setErrorHandler(this.errorHandler);
                            importDAO.setConfigurationPath(imports[importsVariables[index]]);
                            importDAO.Load($language, () => {
                                const interfaceDaoClass = thisClass.getDaoInterfaceClassName(importDAO.getConfigurationInterface());
                                let interfaceDAO = importDAO;
                                if (!importDAO.IsTypeOf(interfaceDaoClass)) {
                                    interfaceDAO = new interfaceDaoClass();
                                    let propertyName;
                                    for (propertyName in importDAO) {
                                        if (interfaceDAO.hasOwnProperty(propertyName)) {
                                            interfaceDAO[propertyName] = importDAO[propertyName];
                                        }
                                    }
                                }
                                this.imports.Add(interfaceDAO, importsVariables[index]);
                                index++;
                                if (index < importsVariables.length) {
                                    loadImport();
                                }
                                else {
                                    $asyncHandler();
                                }
                            }, $force);
                        };
                        loadImport();
                    }
                    else {
                        $asyncHandler();
                    }
                }
                else {
                    $asyncHandler();
                }
            };
            const extendsConfig = this.getStaticConfiguration().extendsConfig;
            if (!ObjectValidator.IsEmptyOrNull(extendsConfig)) {
                const parent = new (thisClass.getDaoInterfaceClassName(null))();
                parent.setErrorHandler(this.errorHandler);
                parent.setConfigurationPath(extendsConfig);
                parent.Load($language, () => {
                    const interfaceDaoClass = thisClass.getDaoInterfaceClassName(parent.getConfigurationInterface());
                    let interfaceDAO = parent;
                    if (!parent.IsTypeOf(interfaceDaoClass)) {
                        interfaceDAO = new interfaceDaoClass();
                        let propertyName;
                        for (propertyName in parent) {
                            if (interfaceDAO.hasOwnProperty(propertyName)) {
                                interfaceDAO[propertyName] = parent[propertyName];
                            }
                        }
                    }
                    this.parent = interfaceDAO;
                    loadImports();
                }, $force);
            }
            else {
                loadImports();
            }
        };
        if (!thisConfiguration.KeyExists(requiredLanguage) ||
            (!ObjectValidator.IsEmptyOrNull(thisConfiguration.getItem(requiredLanguage)) &&
                thisConfiguration.getItem(requiredLanguage).hasOwnProperty("noCache"))) {
            const loadedResources = [];
            let localization;
            const loadParents = ($filePath, $localizationLoad, $onLoadHandler) => {
                if (!ObjectValidator.IsEmptyOrNull($filePath) && !loadedResources.includes($filePath)) {
                    const processData = ($data, $filePath) => {
                        loadedResources.push($filePath);
                        if (!ObjectValidator.IsEmptyOrNull($data)) {
                            const parentPath = $data.extendsConfig;
                            if (!$localizationLoad) {
                                thisConfiguration.Add(resourcesClass.Extend($data, thisConfiguration.getItem(this.language)), this.language);
                            }
                            else {
                                localization = resourcesClass.Extend($data, localization);
                            }
                            loadParents(parentPath, $localizationLoad, $onLoadHandler);
                        }
                        else {
                            $onLoadHandler();
                        }
                    };
                    const loadResource = ($path) => {
                        resourcesClass.Load($path, ($data, $filePath) => {
                            if (!ObjectValidator.IsEmptyOrNull($data)) {
                                BaseDAO.loadedResources.Add(resourcesClass.DeepClone($data), $filePath);
                            }
                            processData($data, $filePath);
                        }, this.errorHandler);
                    };
                    if (BaseDAO.loadedResources.KeyExists($filePath) && !$force) {
                        const item = BaseDAO.loadedResources.getItem($filePath);
                        if (item.hasOwnProperty("noCache") && item.noCache) {
                            loadResource($filePath);
                        }
                        else {
                            processData(resourcesClass.DeepClone(item), $filePath);
                        }
                    }
                    else {
                        loadResource($filePath);
                    }
                }
                else {
                    $onLoadHandler();
                }
            };
            const onLoadHandler = () => {
                if (ObjectValidator.IsSet(localization)) {
                    thisConfiguration.Add(resourcesClass.Extend(resourcesClass.DeepClone(thisConfiguration.getItem(this.language)), localization), requiredLanguage);
                    this.language = requiredLanguage;
                }
                fireLoaded();
            };
            const loadLocalization = () => {
                if (!ObjectValidator.IsEmptyOrNull(requiredLanguage) && this.language !== requiredLanguage &&
                    ObjectValidator.IsSet(thisConfiguration.getItem(this.language).localization) &&
                    thisConfiguration.getItem(this.language).localization.hasOwnProperty(StringUtils.ToLowerCase(requiredLanguage))) {
                    const processData = ($data, $filePath) => {
                        if (!ObjectValidator.IsEmptyOrNull($data) && !loadedResources.includes($filePath)) {
                            loadedResources.push($filePath);
                            localization = $data;
                            loadParents($data.extendsConfig, true, onLoadHandler);
                        }
                        else {
                            onLoadHandler();
                        }
                    };
                    const loadResource = ($path) => {
                        resourcesClass.Load($path, ($data, $filePath) => {
                            if (!ObjectValidator.IsEmptyOrNull($data)) {
                                BaseDAO.loadedResources.Add(resourcesClass.DeepClone($data), $filePath);
                            }
                            processData($data, $filePath);
                        }, onLoadHandler);
                    };
                    const localizationFilePath = thisConfiguration.getItem(this.language).localization[StringUtils.ToLowerCase(requiredLanguage)];
                    if (BaseDAO.loadedResources.KeyExists(localizationFilePath) && !$force) {
                        const item = BaseDAO.loadedResources.getItem(localizationFilePath);
                        if (item.hasOwnProperty("noCache") && item.noCache) {
                            processData(resourcesClass.DeepClone(item), localizationFilePath);
                        }
                    }
                    else {
                        loadResource(localizationFilePath);
                    }
                }
                else {
                    fireLoaded();
                }
            };
            if (!thisConfiguration.KeyExists(this.language) ||
                (!ObjectValidator.IsEmptyOrNull(thisConfiguration.getItem(requiredLanguage)) &&
                    thisConfiguration.getItem(requiredLanguage).hasOwnProperty("noCache"))) {
                const processData = ($data, $filePath) => {
                    if (!ObjectValidator.IsEmptyOrNull($data) && !loadedResources.includes($filePath)) {
                        loadedResources.push($filePath);
                        thisConfiguration.Add($data, this.language);
                        loadParents($data.extendsConfig, false, loadLocalization);
                    }
                };
                const loadResource = ($path) => {
                    resourcesClass.Load($path, ($data, $filePath) => {
                        if (!ObjectValidator.IsEmptyOrNull($data)) {
                            BaseDAO.loadedResources.Add(resourcesClass.DeepClone($data), $filePath);
                        }
                        processData($data, $filePath);
                    }, this.errorHandler);
                };
                if (BaseDAO.loadedResources.KeyExists(this.configurationPath) && !$force) {
                    const item = BaseDAO.loadedResources.getItem(this.configurationPath);
                    if (item.hasOwnProperty("noCache") && item.noCache) {
                        loadResource(this.configurationPath);
                    }
                    else {
                        processData(resourcesClass.DeepClone(item), this.configurationPath);
                    }
                }
                else {
                    loadResource(this.configurationPath);
                }
            }
            else {
                loadLocalization();
            }
        }
        else {
            if (!ObjectValidator.IsEmptyOrNull(requiredLanguage) && this.language !== requiredLanguage) {
                this.language = requiredLanguage;
            }
            fireLoaded();
        }
    }
    /**
     * @returns {IBaseConfiguration} Returns data, which are representing DAO static configuration.
     */
    getStaticConfiguration() {
        if (!BaseDAO.staticConfiguration.KeyExists(this.configurationPath)) {
            BaseDAO.staticConfiguration.Add(new ArrayList(), this.configurationPath);
        }
        return BaseDAO.staticConfiguration.getItem(this.configurationPath).getItem(this.language);
    }
    /**
     * @returns {object} Returns list of global variables, which have been parsed from page configuration.
     */
    getGlobalVariables() {
        return {};
    }
    /**
     * @param {object} $variables Specify variables, which should be passed to page configuration to the global variables identifiers.
     * @returns {void}
     */
    setGlobalVariables($variables) {
        if (!ObjectValidator.IsSet(this.configInstance)) {
            this.getConfigurationInstance();
        }
        BaseDAO.passGlobalVariables(this.configInstance, $variables);
    }
    /**
     * @returns {string} Returns value, which represents current version of the configuration.
     */
    getConfigurationInterface() {
        return ObjectValidator.IsSet(this.getStaticConfiguration().$interface) ?
            this.getStaticConfiguration().$interface : this.getStaticConfiguration().interface;
    }
    /**
     * @returns {string} Returns value, which represents current version of the configuration.
     */
    getConfigurationVersion() {
        return this.getStaticConfiguration().version;
    }
    /**
     * @param {string} $value Specify file path, which should be used as DAO data source.
     * @returns {void}
     */
    setConfigurationPath($value) {
        this.configurationPath = Property.String(this.configurationPath, $value);
    }
    /**
     * @param {object} [$value] Specify library object, which should be appended to the configuration instance.
     * @returns {object} Returns library object, which should be appended to the configuration instance.
     */
    ConfigurationLibrary($value) {
        if (ObjectValidator.IsSet($value)) {
            this.configLibrary = $value;
        }
        if (!ObjectValidator.IsSet(this.configLibrary)) {
            const library = {};
            library.Echo = (...$attributes) => {
                Echo.Printf.apply(Echo, $attributes); // eslint-disable-line prefer-spread
            };
            library.Log = (...$attributes) => {
                LogIt.Debug.apply(LogIt, $attributes); // eslint-disable-line prefer-spread
            };
            library.Error = (...$attributes) => {
                LogIt.Error(StringUtils.Format.apply(String, $attributes));
            };
            library.Warning = (...$attributes) => {
                LogIt.Warning(StringUtils.Format.apply(String, $attributes));
            };
            this.configLibrary = library;
        }
        return this.configLibrary;
    }
    /**
     * @returns {object} Returns page configuration as class instance.
     */
    getConfigurationInstance() {
        if (!ObjectValidator.IsSet(this.configInstance)) {
            const thisClass = Reflection.getInstance().getClass(this.getClassName());
            const getConfigClass = ($dao, $extend) => {
                const config = $dao.getStaticConfiguration();
                let dao = $dao;
                const interfaceDaoClass = thisClass.getDaoInterfaceClassName(ObjectValidator.IsSet(config.$interface) ? config.$interface : config.interface);
                let propertyName;
                if (!dao.IsTypeOf(interfaceDaoClass)) {
                    dao = new interfaceDaoClass();
                    for (propertyName in $dao) {
                        if (dao.hasOwnProperty(propertyName)) {
                            dao[propertyName] = $dao[propertyName];
                        }
                    }
                    $dao = dao;
                }
                const processor = () => {
                    // create class instance with empty body
                };
                for (propertyName in $extend) {
                    if (!processor.prototype.hasOwnProperty(propertyName)) {
                        processor.prototype[propertyName] = $extend[propertyName];
                    }
                }
                const superDao = $dao.parent;
                if (!ObjectValidator.IsEmptyOrNull(superDao)) {
                    const superClass = getConfigClass(superDao, $extend);
                    processor.prototype.$super = new superClass();
                    processor.prototype._super = processor.prototype.$super;
                }
                $dao.imports.foreach(($importDao, $variableName) => {
                    if (!processor.prototype.hasOwnProperty($variableName)) {
                        const importClass = getConfigClass($importDao, $extend);
                        processor.prototype[$variableName] = new importClass();
                    }
                    else {
                        ExceptionsManager.Throw("Configuration Processor", "Import identifier \"" + $variableName + "\" already in use.");
                    }
                });
                for (propertyName in config) {
                    if (propertyName !== SyntaxConstants.CONSTRUCTOR) {
                        if (!processor.prototype.hasOwnProperty(propertyName)) {
                            processor.prototype[propertyName] = config[propertyName];
                        }
                        else {
                            ExceptionsManager.Throw("Configuration Processor", "Reserved identifier \"" + propertyName + "\" has been detected.");
                        }
                    }
                }
                BaseDAO.passGlobalVariables(processor.prototype, $dao.getGlobalVariables());
                return processor;
            };
            const configClass = getConfigClass(this, this.ConfigurationLibrary());
            this.configInstance = new configClass();
        }
        BaseDAO.passGlobalVariables(this.configInstance, this.getGlobalVariables());
        return this.configInstance;
    }
    /**
     * Produce a human-readable string representation of the DAO data source path and configuration.
     * @param {string} [$prefix=""] Specify indentation prefix for the JSON output.
     * @param {boolean} [$htmlTag=true] Specify whether the output should include HTML formatting.
     * @returns {string} Returns formatted string with data source path and configuration JSON.
     */
    ToString($prefix = "", $htmlTag = true) {
        let source = "/" + this.getDaoDataSource();
        if ($htmlTag) {
            source = "<b>" + source + "</b>";
        }
        return source + StringUtils.NewLine($htmlTag) +
            $prefix + JSON.stringify(this.getStaticConfiguration());
    }
    /**
     * Set a custom error handler invoked when resource loading fails.
     * @param {Function} $handler Specify the error callback receiving event args and file path.
     */
    setErrorHandler($handler) {
        this.errorHandler = $handler;
    }
    /**
     * Return the Resources class used for loading and merging JSONP configuration files.
     * Subclasses may override to provide a custom resource handler.
     * @returns {any} Returns the Resources class reference.
     */
    getResourcesHandler() {
        return Resources;
    }
    /**
     * Set the default language for configuration loading and localization.
     * @param {LanguageType} $value Specify the language type to use as default.
     */
    setDefaultLanguage($value) {
        if (LanguageType.Contains($value)) {
            this.language = $value.toString();
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Services.DAO.BaseDAO", BaseDAO);
//# sourceMappingURL=BaseDAO.js.map