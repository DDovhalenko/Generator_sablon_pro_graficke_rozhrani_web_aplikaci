/*! ******************************************************************************************************** *
 *
 * Copyright 2022-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "./../../../../Io/Oidis/Commons/Primitives/BaseEnum.js";
/**
 * Represents the lifecycle states of the backend environment during startup.
 * Used by EnvironmentConnector to track initialization progress.
 *
 * Typical progression: IDLE -> STARTING -> LOADED -> DB_CONNECTING -> DB_CONNECTED
 * -> DB_PREPARED -> AGENTS_INIT -> ADMIN_INIT -> ADMIN_ENABLED
 */
export class EnvironmentState extends BaseEnum {
    static IDLE = "idle";
    static STARTING = "starting";
    static LOADED = "loaded";
    static DB_CONNECTING = "dbConnecting";
    static DB_CONNECTION_ERROR = "dbConnectionError";
    static DB_CONNECTED = "dbConnected";
    static DB_NOT_CONNECTED = "dbNotConnected";
    static DB_PREPARED = "dbPrepared";
    static AGENTS_INIT = "agentsInit";
    static ADMIN_INIT = "adminInit";
    static ADMIN_ENABLED = "adminEnabled";
}
globalThis.RegisterClass("Io.Oidis.Services.Enums.EnvironmentState", EnvironmentState);
//# sourceMappingURL=EnvironmentState.js.map