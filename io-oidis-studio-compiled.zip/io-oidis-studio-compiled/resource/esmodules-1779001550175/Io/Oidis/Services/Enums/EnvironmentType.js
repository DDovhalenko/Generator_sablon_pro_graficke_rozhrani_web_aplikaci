/*! ******************************************************************************************************** *
 *
 * Copyright 2022-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "./../../../../Io/Oidis/Commons/Primitives/BaseEnum.js";
/**
 * Identifies the deployment environment in which the application is running.
 * Queried via EnvironmentConnector.getEnvType() to adjust behavior per environment.
 *
 * - NONE -- unknown/uninitialized
 * - DEV -- development mode
 * - EAP -- early access program (pre-release)
 * - PROD -- production
 * - MAINTENANCE -- maintenance mode (limited functionality)
 * - LOCALHOST -- local development server via io-oidis-localhost
 */
export class EnvironmentType extends BaseEnum {
    static NONE = "none";
    static DEV = "dev";
    static EAP = "eap";
    static PROD = "prod";
    static MAINTENANCE = "maintenance";
    static LOCALHOST = "localhost";
}
globalThis.RegisterClass("Io.Oidis.Services.Enums.EnvironmentType", EnvironmentType);
//# sourceMappingURL=EnvironmentType.js.map