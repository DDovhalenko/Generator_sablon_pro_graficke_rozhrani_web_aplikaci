/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/**
 * Status codes emitted during the installation process to track progress.
 * Used by InstallationRecipeDAO and IInstallationProcessEventsHandler
 * to communicate step-by-step progress to the UI.
 *
 * - GENERAL -- generic progress update
 * - CLONE -- repository cloning in progress
 * - EXTRACT_START -- archive extraction started
 * - DOWNLOAD_START / DOWNLOAD_CHANGE -- file download lifecycle
 * - CHAIN_START / CHAIN_CHANGE / CHAIN_END -- installation chain step lifecycle
 * - VALIDATED -- validation step completed successfully
 * - SKIPPED -- step was skipped (already satisfied)
 * - STEP_START -- individual protocol step beginning
 */
export var InstallationProgressCode;
(function (InstallationProgressCode) {
    InstallationProgressCode[InstallationProgressCode["GENERAL"] = 0] = "GENERAL";
    InstallationProgressCode[InstallationProgressCode["CLONE"] = 1] = "CLONE";
    InstallationProgressCode[InstallationProgressCode["EXTRACT_START"] = 2] = "EXTRACT_START";
    InstallationProgressCode[InstallationProgressCode["DOWNLOAD_START"] = 3] = "DOWNLOAD_START";
    InstallationProgressCode[InstallationProgressCode["DOWNLOAD_CHANGE"] = 4] = "DOWNLOAD_CHANGE";
    InstallationProgressCode[InstallationProgressCode["CHAIN_START"] = 5] = "CHAIN_START";
    InstallationProgressCode[InstallationProgressCode["CHAIN_CHANGE"] = 6] = "CHAIN_CHANGE";
    InstallationProgressCode[InstallationProgressCode["CHAIN_END"] = 7] = "CHAIN_END";
    InstallationProgressCode[InstallationProgressCode["VALIDATED"] = 8] = "VALIDATED";
    InstallationProgressCode[InstallationProgressCode["SKIPPED"] = 9] = "SKIPPED";
    InstallationProgressCode[InstallationProgressCode["STEP_START"] = 10] = "STEP_START";
})(InstallationProgressCode || (InstallationProgressCode = {}));
//# sourceMappingURL=InstallationProgressCode.js.map