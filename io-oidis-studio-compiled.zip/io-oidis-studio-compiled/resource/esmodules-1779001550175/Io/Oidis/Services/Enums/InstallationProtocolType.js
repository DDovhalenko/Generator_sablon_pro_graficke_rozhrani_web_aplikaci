/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "./../../../../Io/Oidis/Commons/Primitives/BaseEnum.js";
/**
 * Defines the types of installation protocol operations that can be executed
 * by InstallationRecipeDAO. Each type maps to a specific chain of steps
 * defined in the installation recipe configuration.
 *
 * - VALIDATE -- check prerequisites before installation
 * - INSTALL_STATUS -- evaluate whether installation is needed (condition check)
 * - INSTALL -- perform the installation
 * - UNINSTALL -- remove the installed package
 * - REPAIR -- fix a broken installation
 */
export class InstallationProtocolType extends BaseEnum {
    static VALIDATE = "validate";
    static INSTALL_STATUS = "installCondition";
    static INSTALL = "install";
    static UNINSTALL = "uninstall";
    static REPAIR = "repair";
}
globalThis.RegisterClass("Io.Oidis.Services.Enums.InstallationProtocolType", InstallationProtocolType);
//# sourceMappingURL=InstallationProtocolType.js.map