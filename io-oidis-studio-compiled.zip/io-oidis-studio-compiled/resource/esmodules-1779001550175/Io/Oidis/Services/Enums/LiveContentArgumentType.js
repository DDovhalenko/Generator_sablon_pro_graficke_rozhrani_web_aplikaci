/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "./../../../../Io/Oidis/Commons/Primitives/BaseEnum.js";
/**
 * Defines type markers used by the LiveContent Protocol (LCP) to annotate method arguments
 * and return values for cross-boundary serialization between frontend and backend.
 *
 * Prefixes:
 * - CALLBACK -- marks a callback function argument
 * - IN_* -- input parameter types sent from frontend to backend
 * - OUT_* -- output parameter types received from backend
 * - RETURN_* -- return value type markers for method responses
 */
export class LiveContentArgumentType extends BaseEnum {
    static CALLBACK = "__[CALLBACK]__";
    static IN_STRING = "__[IN:STRING]__";
    static IN_INT = "__[IN:INT]__";
    static IN_DOUBLE = "__[IN:DOUBLE]__";
    static IN_FLOAT = "__[IN:FLOAT]__";
    static IN_BOOLEAN = "__[IN:BOOLEAN]__";
    static IN_OBJECT = "__[IN:OBJECT]__";
    static IN_STRUCT = "__[IN:STRUCT]__";
    static IN_ARRAY = "__[IN:ARRAY]__";
    static IN_BUFFER = "__[IN:BUFFER]__";
    static OUT_STRING = "__[OUT:STRING]__";
    static OUT_INT = "__[OUT:INT]__";
    static OUT_DOUBLE = "__[OUT:DOUBLE]__";
    static OUT_FLOAT = "__[OUT:FLOAT]__";
    static OUT_BOOLEAN = "__[OUT:BOOLEAN]__";
    static OUT_OBJECT = "__[OUT:OBJECT]__";
    static OUT_ARRAY = "__[OUT:ARRAY]__";
    static OUT_BUFFER = "__[OUT:BUFFER]__";
    static RETURN_VOID = "__[RETURN:VOID]__";
    static RETURN_STRING = "__[RETURN:STRING]__";
    static RETURN_INT = "__[RETURN:INT]__";
    static RETURN_DOUBLE = "__[RETURN:DOUBLE]__";
    static RETURN_FLOAT = "__[RETURN:FLOAT]__";
    static RETURN_BOOLEAN = "__[RETURN:BOOLEAN]__";
}
globalThis.RegisterClass("Io.Oidis.Services.Enums.LiveContentArgumentType", LiveContentArgumentType);
//# sourceMappingURL=LiveContentArgumentType.js.map