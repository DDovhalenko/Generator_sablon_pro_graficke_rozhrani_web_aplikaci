/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { WebServiceClientType } from "./../../../../Io/Oidis/Commons/Enums/WebServiceClientType.js";
/**
 * Icon types for system tray notification balloons displayed via WindowHandlerConnector.
 * Maps to native OS notification icon styles.
 *
 * - NONE -- no icon
 * - INFO -- informational notification
 * - WARNING -- warning notification
 * - ERROR -- error notification
 * - USER -- custom user-defined icon
 */
export class NotifyBalloonIconType extends WebServiceClientType {
    static NONE = "none";
    static INFO = "info";
    static WARNING = "warning";
    static ERROR = "error";
    static USER = "user";
}
globalThis.RegisterClass("Io.Oidis.Services.Enums.NotifyBalloonIconType", NotifyBalloonIconType);
//# sourceMappingURL=NotifyBalloonIconType.js.map