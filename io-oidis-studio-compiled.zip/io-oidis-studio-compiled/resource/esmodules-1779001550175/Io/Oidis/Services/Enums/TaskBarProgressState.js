/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { WebServiceClientType } from "./../../../../Io/Oidis/Commons/Enums/WebServiceClientType.js";
/**
 * Windows taskbar progress indicator states used by WindowHandlerConnector.setTaskBarProgressState().
 * Maps to native Windows ITaskbarList3 progress states.
 *
 * - NOPROGRESS -- no progress indicator shown
 * - INDETERMINATE -- pulsing/marquee indicator (unknown duration)
 * - NORMAL -- standard green progress bar
 * - ERROR -- red progress bar indicating failure
 * - PAUSED -- yellow progress bar indicating paused state
 */
export class TaskBarProgressState extends WebServiceClientType {
    static NOPROGRESS = "NOPROGRESS";
    static INDETERMINATE = "INDETERMINATE";
    static NORMAL = "NORMAL";
    static ERROR = "ERROR";
    static PAUSED = "PAUSED";
}
globalThis.RegisterClass("Io.Oidis.Services.Enums.TaskBarProgressState", TaskBarProgressState);
//# sourceMappingURL=TaskBarProgressState.js.map