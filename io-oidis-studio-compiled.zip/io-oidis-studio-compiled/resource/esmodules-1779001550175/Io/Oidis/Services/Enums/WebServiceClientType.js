/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { WebServiceClientType as Parent } from "./../../../../Io/Oidis/Commons/Enums/WebServiceClientType.js";
/**
 * Extends the commons WebServiceClientType with service-layer transport client types.
 * Each constant identifies a deployment topology that determines how LCP requests
 * are routed between the frontend and backend.
 *
 * - BUILDER_CONNECTOR -- CLI/build system (Oidis Builder) connection
 * - DESKTOP_CONNECTOR -- Desktop application via OidisConnector (JxBrowser, Electron)
 * - REST_CONNECTOR -- Pure REST/HTTP client for server-to-server calls
 * - HUB_CONNECTOR -- Oidis Hub direct connection (centralized orchestration)
 * - FORWARD_CLIENT -- Agent forwarding through Hub to a remote agent
 * - HOST_CLIENT -- Localhost hosting mode (dev server or self-hosted)
 */
export class WebServiceClientType extends Parent {
    static BUILDER_CONNECTOR = "BuilderConnector";
    static DESKTOP_CONNECTOR = "DesktopConnector";
    static REST_CONNECTOR = "RestConnector";
    static HUB_CONNECTOR = "HubConnector";
    static FORWARD_CLIENT = "ForwardClient";
    static HOST_CLIENT = "HostClient";
}
globalThis.RegisterClass("Io.Oidis.Services.Enums.WebServiceClientType", WebServiceClientType);
//# sourceMappingURL=WebServiceClientType.js.map