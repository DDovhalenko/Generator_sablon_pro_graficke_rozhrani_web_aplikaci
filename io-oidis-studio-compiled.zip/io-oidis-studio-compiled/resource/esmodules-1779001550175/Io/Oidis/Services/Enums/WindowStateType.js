/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseEnum } from "./../../../../Io/Oidis/Commons/Primitives/BaseEnum.js";
/**
 * Window display states used by WindowHandlerConnector for window management operations.
 * Corresponds to native OS window states.
 */
export class WindowStateType extends BaseEnum {
    static MINIMIZED = "minimized";
    static NORMAL = "normal";
    static MAXIMIZED = "maximized";
}
globalThis.RegisterClass("Io.Oidis.Services.Enums.WindowStateType", WindowStateType);
//# sourceMappingURL=WindowStateType.js.map