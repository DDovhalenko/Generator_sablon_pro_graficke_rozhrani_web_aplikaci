var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var AuthHttpResolver_1;
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { DataFormatType } from "./../../../../Io/Oidis/Commons/Enums/DataFormatType.js";
import { HttpStatusType } from "./../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
import { ObjectDecoder } from "./../../../../Io/Oidis/Commons/Utils/ObjectDecoder.js";
import { ObjectEncoder } from "./../../../../Io/Oidis/Commons/Utils/ObjectEncoder.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { PersistenceType } from "./../../../../Io/Oidis/Gui/Enums/PersistenceType.js";
import { BaseErrorPage } from "./../../../../Io/Oidis/Gui/ErrorPages/BaseErrorPage.js";
import { PersistenceFactory } from "./../../../../Io/Oidis/Gui/PersistenceFactory.js";
import { Resolver } from "./../../../../Io/Oidis/Commons/Primitives/Decorators.js";
/**
 * AuthHttpResolver handles HTTP 401 Not Authorized responses. It manages authentication
 * token persistence using CLIENT_IP-scoped storage and provides token-based request
 * re-invocation for failed protocol calls. Subclasses can implement login forms that
 * call reinvokeRequest() with a valid token to retry the original request.
 */
let AuthHttpResolver = AuthHttpResolver_1 = class AuthHttpResolver extends BaseErrorPage {
    tokenExpiration;
    /**
     * Clear the persisted authentication token, effectively logging the user out.
     */
    static LogOut() {
        PersistenceFactory.getPersistence(PersistenceType.CLIENT_IP, AuthHttpResolver_1.ClassName()).Destroy("token");
    }
    /**
     * Return the currently persisted authentication token.
     * @returns {string} Returns the stored token, or an empty string if none exists.
     */
    static getToken() {
        const token = PersistenceFactory.getPersistence(PersistenceType.CLIENT_IP, AuthHttpResolver_1.ClassName())
            .Variable("token");
        return ObjectValidator.IsEmptyOrNull(token) ? "" : token;
    }
    /**
     * Return the persistence variable name used for the current authentication token.
     * @returns {string} Returns the token key name.
     */
    static getTokenName() {
        return AuthHttpResolver_1.ClassName() + ".CurrentToken";
    }
    /**
     * Return the favicon path for the 401 error page.
     * @returns {string} Returns the path to the forbidden icon.
     */
    getFaviconSource() {
        return "resource/graphics/Io/Oidis/Gui/ForbiddenIcon.ico";
    }
    /**
     * Return the page title for the 401 error page.
     * @returns {string} Returns "HTTP 401".
     */
    getPageTitle() {
        return "HTTP 401";
    }
    /**
     * Return the error message header text.
     * @returns {string} Returns "HTTP status 401".
     */
    getMessageHeader() {
        return "HTTP status 401";
    }
    /**
     * Return the error message body text.
     * @returns {string} Returns "Not authorized.".
     */
    getMessageBody() {
        return "Not authorized.";
    }
    /**
     * Set the token expiration time used when persisting a new authentication token.
     * @param {string} $value Specify the expiration time string.
     */
    setExpirationTime($value) {
        this.tokenExpiration = Property.String(this.tokenExpiration, $value);
    }
    /**
     * Re-invoke the original failed request with a new authentication token. Retrieves
     * the original protocol and client from POST data, updates the protocol with the
     * token and CONTINUE status, persists the token, and re-sends the request.
     * @param {string} $token Specify the new authentication token to use.
     */
    reinvokeRequest($token) {
        if (this.RequestArgs().POST().KeyExists("Protocol")) {
            const protocol = this.RequestArgs().POST().getItem("Protocol");
            const client = this.RequestArgs().POST().getItem("Client");
            if (!ObjectValidator.IsEmptyOrNull(client) && !ObjectValidator.IsEmptyOrNull(protocol)) {
                protocol.origin = this.getRequest().getBaseUrl();
                protocol.status = HttpStatusType.CONTINUE;
                protocol.token = $token;
                if (protocol.format !== DataFormatType.JSON) {
                    if (ObjectValidator.IsObject(protocol.data)) {
                        protocol.data = ObjectEncoder.Base64(JSON.stringify(protocol.data));
                    }
                    else {
                        protocol.data = ObjectEncoder.Base64(ObjectDecoder.Base64(ObjectDecoder.Base64(protocol.data)));
                    }
                }
                const persistence = PersistenceFactory.getPersistence(PersistenceType.CLIENT_IP, this.getClassName());
                persistence.ExpireTime(this.tokenExpiration);
                persistence.Variable("token", $token);
                client.Send(JSON.stringify(protocol));
            }
        }
    }
};
AuthHttpResolver = AuthHttpResolver_1 = __decorate([
    Resolver("/ServerError/Http/NotAuthorized")
], AuthHttpResolver);
export { AuthHttpResolver };
globalThis.RegisterClass("Io.Oidis.Services.ErrorPages.AuthHttpResolver", AuthHttpResolver);
//# sourceMappingURL=AuthHttpResolver.js.map