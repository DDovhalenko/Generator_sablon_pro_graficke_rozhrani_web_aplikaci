var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseErrorPage } from "./../../../../Io/Oidis/Gui/ErrorPages/BaseErrorPage.js";
import { Resolver } from "./../../../../Io/Oidis/Commons/Primitives/Decorators.js";
/**
 * ConnectionLostPage displays an error page when a WebSocket or HTTP connection to a
 * backend service is lost. Shows the requesting owner and server URL, and provides
 * a restart() method to stop and re-establish the communication channel.
 */
let ConnectionLostPage = class ConnectionLostPage extends BaseErrorPage {
    /**
     * Return the page title for the connection lost error page.
     * @returns {string} Returns "Connection Lost".
     */
    getPageTitle() {
        return "Connection Lost";
    }
    /**
     * Return the error message header text.
     * @returns {string} Returns "Service is unreachable".
     */
    getMessageHeader() {
        return "Service is unreachable";
    }
    /**
     * Return the error message body including the requesting owner and target server URL.
     * @returns {string} Returns a message identifying who made the request and where it was directed.
     */
    getMessageBody() {
        return "Service request done by: " + this.RequestArgs().POST().getItem("Owner") + ", " +
            "to: " + this.RequestArgs().POST().getItem("Client").getServerUrl();
    }
    /**
     * Return the name of the component that owns the failed connection request.
     * @returns {string} Returns the owner identifier from the POST data.
     */
    getOwner() {
        return this.RequestArgs().POST().getItem("Owner");
    }
    /**
     * Restart the WebSocket communication by stopping and re-starting the client
     * that lost its connection.
     */
    restart() {
        const client = this.RequestArgs().POST().getItem("Client");
        client.StopCommunication();
        client.StartCommunication();
    }
};
ConnectionLostPage = __decorate([
    Resolver("/ServerError/Http/ConnectionLost")
], ConnectionLostPage);
export { ConnectionLostPage };
globalThis.RegisterClass("Io.Oidis.Services.ErrorPages.ConnectionLostPage", ConnectionLostPage);
//# sourceMappingURL=ConnectionLostPage.js.map