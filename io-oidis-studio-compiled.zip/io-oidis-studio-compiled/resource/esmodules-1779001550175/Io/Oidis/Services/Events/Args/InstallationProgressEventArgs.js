/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ProgressEventArgs } from "./../../../../../Io/Oidis/Commons/Events/Args/ProgressEventArgs.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
import { InstallationProgressCode } from "../../Enums/InstallationProgressCode.js";
/**
 * InstallationProgressEventArgs class provides args connected with installation progress.
 */
export class InstallationProgressEventArgs extends ProgressEventArgs {
    message;
    status;
    code;
    /**
     * @param {string} [$message] Specify message, which describes current progress.
     */
    constructor($message) {
        super();
        this.status = false;
        this.code = InstallationProgressCode.GENERAL;
        this.Message($message);
    }
    /**
     * @param {string} [$value] Set message, which describes current progress.
     * @returns {string} Returns message value, which describes current progress.
     */
    Message($value) {
        return this.message = Property.String(this.message, $value);
    }
    /**
     * @param {boolean} [$value] Set actual status for current progress.
     * @returns {boolean} Returns status for current progress.
     */
    Status($value) {
        return this.status = Property.Boolean(this.status, $value);
    }
    /**
     * @param {InstallationProgressCode} [$value] Set progress code.
     * @returns {InstallationProgressCode} Returns progress code value.
     */
    ProgressCode($value) {
        if (ObjectValidator.IsSet($value)) {
            this.code = $value;
        }
        return this.code;
    }
}
globalThis.RegisterClass("Io.Oidis.Services.Events.Args.InstallationProgressEventArgs", InstallationProgressEventArgs);
//# sourceMappingURL=InstallationProgressEventArgs.js.map