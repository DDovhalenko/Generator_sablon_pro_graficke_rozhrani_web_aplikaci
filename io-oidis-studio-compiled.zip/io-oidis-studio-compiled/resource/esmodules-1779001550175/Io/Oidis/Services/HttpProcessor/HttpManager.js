/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { HttpManager as Parent } from "./../../../../Io/Oidis/Gui/HttpProcessor/HttpManager.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
/**
 * HttpManager extends the GUI HttpManager with JRE-specific navigation support.
 * In JRE environments, external links are opened via the TerminalConnector instead
 * of browser-based navigation, using a lazily initialized connector instance.
 */
export class HttpManager extends Parent {
    connector;
    /**
     * Navigate to a link or reload the page. In JRE environments with a valid link and
     * boolean data flag, delegates to TerminalConnector.Open() to launch the URL in the
     * system default handler. Otherwise falls back to the parent ReloadTo() behavior.
     * @param {string} [$link] Specify the URL or route to navigate to.
     * @param {any} [$data] Specify POST data or a boolean flag triggering JRE terminal open.
     * @param {boolean} [$async] Specify true for asynchronous navigation.
     */
    ReloadTo($link, $data, $async) {
        if (this.getRequest().IsJre() && !ObjectValidator.IsEmptyOrNull($link) && ObjectValidator.IsBoolean($data) && $data) {
            if (!ObjectValidator.IsSet(this.connector)) {
                import("../Connectors/TerminalConnector.js").then(($exports) => {
                    this.connector = new $exports.TerminalConnector();
                    this.connector.Open($link);
                }).catch(($error) => {
                    LogIt.Error("Failed to open link by terminal connector", $error);
                });
            }
            else {
                this.connector.Open($link);
            }
        }
        else {
            super.ReloadTo($link, $data, $async);
        }
    }
}
globalThis.RegisterClass("Io.Oidis.Services.HttpProcessor.HttpManager", HttpManager);
//# sourceMappingURL=HttpManager.js.map