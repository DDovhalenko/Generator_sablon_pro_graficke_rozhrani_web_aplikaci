/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { HttpResolver as Parent } from "./../../../../Io/Oidis/Gui/HttpProcessor/HttpResolver.js";
import { HttpManager } from "./HttpManager.js";
/**
 * HttpResolver extends the GUI HttpResolver to provide the services-specific HttpManager
 * class. This resolver is used by the Loader to initialize the HTTP processing pipeline
 * with JRE-aware navigation capabilities.
 */
export class HttpResolver extends Parent {
    /**
     * Return the services-specific HttpManager class constructor.
     * @returns {any} Returns the HttpManager class with JRE terminal support.
     */
    getHttpManagerClass() {
        return HttpManager;
    }
}
globalThis.RegisterClass("Io.Oidis.Services.HttpProcessor.HttpResolver", HttpResolver);
//# sourceMappingURL=HttpResolver.js.map