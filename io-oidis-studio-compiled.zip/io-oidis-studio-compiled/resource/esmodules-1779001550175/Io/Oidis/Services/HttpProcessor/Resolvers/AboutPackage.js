var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BaseHttpResolver } from "./../../../../../Io/Oidis/Commons/HttpProcessor/Resolvers/BaseHttpResolver.js";
import { Index as CommonsIndex } from "./../../../../../Io/Oidis/Commons/Index.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { Index as GuiIndex } from "./../../../../../Io/Oidis/Gui/Index.js";
import { StaticPageContentManager } from "./../../../../../Io/Oidis/Gui/Utils/StaticPageContentManager.js";
import { Resolver, ResolverScope } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
/**
 * AboutPackage request resolver class provides handling of application dependencies content.
 */
let AboutPackage = class AboutPackage extends BaseHttpResolver {
    resolver() {
        this.registerResolver("/about/Oidis/Commons", CommonsIndex);
        this.registerResolver("/about/Oidis/Gui", GuiIndex);
        let output = "<div class=\"GuiInterface\">" +
            "<h1>Oidis Services Library</h1>" +
            "<div class=\"Index\">";
        output +=
            "<H3>Library dependencies</H3>" +
                "<a href=\"#" + this.createLink("/about/Oidis/Commons") + "\">Oidis Commons library</a>" +
                StringUtils.NewLine() +
                "<a href=\"#" + this.createLink("/about/Oidis/Gui") + "\">Oidis Gui library</a>" +
                StringUtils.NewLine() +
                "</div>" +
                "</div>";
        output +=
            "<div class=\"Note\">" +
                "version: " + this.getEnvironmentArgs().getProjectVersion() +
                ", build: " + this.getEnvironmentArgs().getBuildTime() +
                "</div>";
        StaticPageContentManager.Clear();
        StaticPageContentManager.Title("Oidis Services - Package Info");
        StaticPageContentManager.BodyAppend(output);
        StaticPageContentManager.Draw();
    }
};
AboutPackage = __decorate([
    Resolver(["/about/Package"], { scope: ResolverScope.DEV })
], AboutPackage);
export { AboutPackage };
globalThis.RegisterClass("Io.Oidis.Services.HttpProcessor.Resolvers.AboutPackage", AboutPackage);
//# sourceMappingURL=AboutPackage.js.map