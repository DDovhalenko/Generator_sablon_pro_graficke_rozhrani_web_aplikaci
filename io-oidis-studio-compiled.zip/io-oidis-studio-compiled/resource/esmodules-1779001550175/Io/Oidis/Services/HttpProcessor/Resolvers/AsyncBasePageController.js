/*! ******************************************************************************************************** *
 *
 * Copyright 2021-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { ArrayList } from "./../../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { EventType } from "./../../../../../Io/Oidis/Gui/Enums/Events/EventType.js";
import { AsyncBaseHttpController } from "./../../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/AsyncBaseHttpController.js";
import { EnvironmentConnector } from "../../Connectors/EnvironmentConnector.js";
import { ExceptionsManager } from "./../../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
/**
 * AsyncBasePageController extends AsyncBaseHttpController with DAO-based configuration
 * loading, environment validation, and access control. It provides an async lifecycle
 * for page controllers: canResolve → loadResources → beforeLoad → afterLoad → onSuccess/onError.
 * Subclasses set a BasePageDAO via setDao() to enable automatic localization loading,
 * page title formatting, and model argument resolution.
 */
export class AsyncBasePageController extends AsyncBaseHttpController {
    dao;
    /**
     * Prepare page content by setting the page title from the DAO configuration,
     * formatted with the current project version.
     */
    PreparePageContent() {
        super.PreparePageContent();
        if (!ObjectValidator.IsEmptyOrNull(this.dao)) {
            try {
                this.setPageTitle(StringUtils.Format(this.dao.getPageTitle(), this.getEnvironmentArgs().getProjectVersion()));
            }
            catch (ex) {
                LogIt.Error(ex);
            }
        }
    }
    /**
     * Return the typed page localization configuration from the DAO.
     * @returns {IBasePageLocalization} Returns the page localization data, or null if no DAO is set.
     */
    getPageConfiguration() {
        if (!ObjectValidator.IsEmptyOrNull(this.dao)) {
            return this.dao.getPageConfiguration();
        }
        return null;
    }
    /**
     * Return the viewer arguments resolved from the DAO configuration.
     * @returns {BaseViewerArgs} Returns the model arguments, or null if no DAO is set.
     */
    getModelArgs() {
        if (!ObjectValidator.IsEmptyOrNull(this.dao)) {
            return this.dao.getModelArgs();
        }
        return null;
    }
    /**
     * Validate whether the current browser is supported. Extends parent validation
     * to also allow search bot user agents.
     * @returns {boolean} Returns true if the browser is supported or the request is from a search bot.
     */
    browserValidator() {
        return super.browserValidator() || this.getRequest().IsSearchBot();
    }
    /**
     * Check whether the target view has already been rendered. Returns true if the DAO
     * exists but has no static configuration data loaded.
     * @param {any} $target Specify the render target to check.
     * @returns {boolean} Returns true if the view is already rendered or the DAO has no static data.
     */
    isRendered($target) {
        return super.isRendered($target) ||
            (!ObjectValidator.IsEmptyOrNull(this.dao) && ObjectValidator.IsEmptyOrNull(this.dao.getStaticConfiguration()));
    }
    /**
     * Determine whether the controller can resolve the current request. Checks the
     * environment loading state and access validation. Redirects to the init page
     * if the environment is not loaded, or to the not-authorized page if access is denied.
     * @param {Function} $resolve Specify the callback to invoke with the resolution status.
     */
    async canResolve($resolve) {
        if (await this.environmentCheckEnabled() &&
            !await EnvironmentConnector.getInstanceSingleton().IsEnvironmentLoaded()) {
            $resolve(false);
            this.reloadToInitPage();
        }
        else if (!await this.accessValidator()) {
            $resolve(false);
            this.reloadToNotAuthorized();
        }
        else {
            $resolve(true);
        }
    }
    /**
     * Return the arguments array passed to the async process pipeline.
     * @returns {any[]} Returns array containing the instance owner, model args, and DAO.
     */
    getProcessArgs() {
        return [this.InstanceOwner(), this.getModelArgs(), this.getDao()];
    }
    /**
     * Set the BasePageDAO instance used for configuration loading and localization.
     * @param {BasePageDAO} $value Specify the DAO instance to assign.
     */
    setDao($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.dao = $value;
        }
    }
    /**
     * Return the current BasePageDAO instance.
     * @returns {BasePageDAO} Returns the DAO used by this controller.
     */
    getDao() {
        return this.dao;
    }
    /**
     * Determine whether environment readiness should be checked before resolving.
     * Override this method and return true to enforce environment loading validation.
     * @returns {Promise<boolean>} Returns promise resolving to false by default.
     */
    async environmentCheckEnabled() {
        return false;
    }
    /**
     * Load the DAO configuration resources for the current language. On completion,
     * prepares page content and fires the ON_LOAD event. Falls back to parent
     * loadResources() if no DAO is set.
     */
    loadResources() {
        if (!ObjectValidator.IsEmptyOrNull(this.dao)) {
            this.dao.Load(this.getLanguage(), () => {
                this.PreparePageContent();
                this.getEventsManager().FireEvent(this.getClassName(), EventType.ON_LOAD);
            }, true);
        }
        else {
            super.loadResources();
        }
    }
    /**
     * Lifecycle hook called before the panel instance is loaded. Override to prepare
     * the instance or its arguments before the loading process begins.
     * @param {BasePanel} [$instance] Specify the panel instance being loaded.
     * @param {BaseViewerArgs} [$args] Specify the viewer arguments.
     * @param {BasePageDAO} [$dao] Specify the page DAO.
     */
    async beforeLoad($instance, $args, $dao) {
        // override this method for ability to prepare instance before it is loaded
    }
    /**
     * Lifecycle hook called after the panel instance has been loaded. Override to
     * configure the instance or bind additional event handlers.
     * @param {BasePanel} [$instance] Specify the loaded panel instance.
     * @param {BaseViewerArgs} [$args] Specify the viewer arguments.
     * @param {BasePageDAO} [$dao] Specify the page DAO.
     */
    async afterLoad($instance, $args, $dao) {
        // override this method for ability to setup instance after it is loaded
    }
    /**
     * Lifecycle hook called after the controller has been successfully loaded.
     * Override to handle post-load controller state or trigger additional logic.
     * @param {BasePanel} [$instance] Specify the successfully loaded panel instance.
     * @param {BaseViewerArgs} [$args] Specify the viewer arguments.
     * @param {BasePageDAO} [$dao] Specify the page DAO.
     */
    async onSuccess($instance, $args, $dao) {
        // override this method for ability to handle controller state after it has been successfully loaded
    }
    /**
     * Lifecycle hook called when the controller encounters an error during loading.
     * Default implementation throws the error via ExceptionsManager.
     * @param {Error} $error Specify the error that occurred.
     */
    async onError($error) {
        ExceptionsManager.Throw(this.getClassName(), $error);
    }
    /**
     * Redirect the user to the HTTP 401 Not Authorized error page,
     * passing the current request as the referer for potential re-invocation.
     */
    reloadToNotAuthorized() {
        const postData = new ArrayList();
        postData.Add(this.getRequest(), "Referer");
        this.getHttpManager().ReloadTo("/ServerError/Http/NotAuthorized", postData, true);
    }
    /**
     * Redirect the user to the environment initialization page when
     * the backend environment is not yet loaded, passing the current request as referer.
     */
    reloadToInitPage() {
        const postData = new ArrayList();
        postData.Add(this.getRequest(), "Referer");
        this.getHttpManager().ReloadTo("/ServerError/NotReady", postData, true);
    }
}
globalThis.RegisterClass("Io.Oidis.Services.HttpProcessor.Resolvers.AsyncBasePageController", AsyncBasePageController);
//# sourceMappingURL=AsyncBasePageController.js.map