/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { BrowserType } from "./../../../../../Io/Oidis/Commons/Enums/BrowserType.js";
import { GeneralEventOwner } from "./../../../../../Io/Oidis/Commons/Enums/Events/GeneralEventOwner.js";
import { WebServiceClientEventType } from "./../../../../../Io/Oidis/Commons/Enums/Events/WebServiceClientEventType.js";
import { LanguageType } from "./../../../../../Io/Oidis/Commons/Enums/LanguageType.js";
import { PersistenceType } from "./../../../../../Io/Oidis/Commons/Enums/PersistenceType.js";
import { ExceptionsManager } from "./../../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { BaseHttpResolver } from "./../../../../../Io/Oidis/Commons/HttpProcessor/Resolvers/BaseHttpResolver.js";
import { PersistenceFactory } from "./../../../../../Io/Oidis/Commons/PersistenceApi/PersistenceFactory.js";
import { Convert } from "./../../../../../Io/Oidis/Commons/Utils/Convert.js";
import { Echo } from "./../../../../../Io/Oidis/Commons/Utils/Echo.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectEncoder } from "./../../../../../Io/Oidis/Commons/Utils/ObjectEncoder.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { EventType } from "./../../../../../Io/Oidis/Gui/Enums/Events/EventType.js";
import { GeneralCssNames } from "./../../../../../Io/Oidis/Gui/Enums/GeneralCssNames.js";
import { HttpRequestConstants } from "./../../../../../Io/Oidis/Gui/Enums/HttpRequestConstants.js";
import { ResizeableType } from "./../../../../../Io/Oidis/Gui/Enums/ResizeableType.js";
import { WindowCornerType } from "./../../../../../Io/Oidis/Gui/Enums/WindowCornerType.js";
import { ResizeEventArgs } from "./../../../../../Io/Oidis/Gui/Events/Args/ResizeEventArgs.js";
import { ElementEventsManager } from "./../../../../../Io/Oidis/Gui/Events/ElementEventsManager.js";
import { BasePanelViewer } from "./../../../../../Io/Oidis/Gui/Primitives/BasePanelViewer.js";
import { BaseViewer } from "./../../../../../Io/Oidis/Gui/Primitives/BaseViewer.js";
import { GuiElement } from "./../../../../../Io/Oidis/Gui/Primitives/GuiElement.js";
import { ElementOffset } from "./../../../../../Io/Oidis/Gui/Structures/ElementOffset.js";
import { Size } from "./../../../../../Io/Oidis/Gui/Structures/Size.js";
import { ElementManager } from "./../../../../../Io/Oidis/Gui/Utils/ElementManager.js";
import { StaticPageContentManager } from "./../../../../../Io/Oidis/Gui/Utils/StaticPageContentManager.js";
import { WindowManager } from "./../../../../../Io/Oidis/Gui/Utils/WindowManager.js";
import { ViewerCacheManager } from "./../../../../../Io/Oidis/Gui/ViewerCacheManager.js";
import { ViewerManager } from "./../../../../../Io/Oidis/Gui/ViewerManager.js";
import { FileSystemHandlerConnector } from "../../Connectors/FileSystemHandlerConnector.js";
import { WindowHandlerConnector } from "../../Connectors/WindowHandlerConnector.js";
import { BasePageDAO } from "../../DAO/BasePageDAO.js";
import { WindowStateType } from "../../Enums/WindowStateType.js";
/**
 * BasePageController is the synchronous page controller base class for Oidis Services applications.
 * It manages the full page lifecycle including window chrome (drag bars, resize bars, minimize/maximize/close
 * buttons), loading indicators, DAO-based configuration, viewer management, and developer tools.
 * In JRE environments, it integrates with WindowHandlerConnector for native window management.
 * Subclasses must call setModelClassName() and setDao() in their constructor.
 */
export class BasePageController extends BaseHttpResolver {
    loaderIcon;
    loaderText;
    loaderProgressLabel;
    minimizeButton;
    maximizeButton;
    closeButton;
    appIcon;
    appTitle;
    dragBar;
    topResizeBar;
    leftResizeBar;
    topLeftResizeBar;
    topRightResizeBar;
    rightResizeBar;
    bottomResizeBar;
    bottomLeftResizeBar;
    bottomRightResizeBar;
    modelClassName;
    modelObject;
    pageTitle;
    faviconSource;
    loaderProgressText;
    dao;
    language;
    cacheFilePath;
    viewerManager;
    resizeableType;
    minSize;
    constructor() {
        super();
        this.pageTitle = "Oidis Services v" + this.getEnvironmentArgs().getProjectVersion();
        this.faviconSource = "resource/graphics/icon.ico";
        this.modelClassName = "";
        this.modelObject = null;
        const loaderIconClass = this.getLoaderIconClass();
        if (!ObjectValidator.IsEmptyOrNull(loaderIconClass)) {
            this.loaderIcon = new loaderIconClass(null, "AppContentLoader_Icon");
            this.loaderIcon.DisableAsynchronousDraw();
        }
        const loaderTextClass = this.getLoaderTextClass();
        if (!ObjectValidator.IsEmptyOrNull(loaderTextClass)) {
            this.loaderText = new loaderTextClass("Loading, please wait ...", "AppContentLoader_Text");
            this.loaderText.DisableAsynchronousDraw();
            this.loaderProgressText = "Progress: {0}%";
            this.loaderProgressLabel = new loaderTextClass("", "AppContentLoader_ProgressText");
            this.loaderProgressLabel.StyleClassName("AppContentLoaderProgress");
            this.loaderProgressLabel.DisableAsynchronousDraw();
        }
        const appIconClass = this.getAppIconClass();
        if (!ObjectValidator.IsEmptyOrNull(appIconClass)) {
            this.appIcon = new appIconClass(null);
            this.appIcon.DisableAsynchronousDraw();
        }
        const appTitleTextClass = this.getAppTitleTextClass();
        if (!ObjectValidator.IsEmptyOrNull(appTitleTextClass)) {
            this.appTitle = new appTitleTextClass("");
            this.appTitle.DisableAsynchronousDraw();
        }
        const appImageButtonClass = this.getAppImageButtonClass();
        if (!ObjectValidator.IsEmptyOrNull(appImageButtonClass)) {
            this.minimizeButton = new appImageButtonClass();
            this.minimizeButton.DisableAsynchronousDraw();
            this.maximizeButton = new appImageButtonClass();
            this.maximizeButton.DisableAsynchronousDraw();
            this.closeButton = new appImageButtonClass();
            this.closeButton.DisableAsynchronousDraw();
        }
        const appDragBarClass = this.getAppDragBarClass();
        if (!ObjectValidator.IsEmptyOrNull(appDragBarClass)) {
            this.dragBar = new appDragBarClass();
            this.dragBar.DisableAsynchronousDraw();
            this.dragBar.StyleClassName("AppDragBar");
        }
        const appResizeBarClass = this.getAppResizeBarClass();
        if (!ObjectValidator.IsEmptyOrNull(appResizeBarClass)) {
            this.topLeftResizeBar = new appResizeBarClass(ResizeableType.HORIZONTAL_AND_VERTICAL);
            this.topLeftResizeBar.DisableAsynchronousDraw();
            this.topResizeBar = new appResizeBarClass(ResizeableType.VERTICAL);
            this.topResizeBar.DisableAsynchronousDraw();
            this.topRightResizeBar = new appResizeBarClass(ResizeableType.HORIZONTAL_AND_VERTICAL);
            this.topRightResizeBar.DisableAsynchronousDraw();
            this.leftResizeBar = new appResizeBarClass(ResizeableType.HORIZONTAL);
            this.leftResizeBar.DisableAsynchronousDraw();
            this.rightResizeBar = new appResizeBarClass(ResizeableType.HORIZONTAL);
            this.rightResizeBar.DisableAsynchronousDraw();
            this.bottomLeftResizeBar = new appResizeBarClass(ResizeableType.HORIZONTAL_AND_VERTICAL);
            this.bottomLeftResizeBar.DisableAsynchronousDraw();
            this.bottomResizeBar = new appResizeBarClass(ResizeableType.VERTICAL);
            this.bottomResizeBar.DisableAsynchronousDraw();
            this.bottomRightResizeBar = new appResizeBarClass(ResizeableType.HORIZONTAL_AND_VERTICAL);
            this.bottomRightResizeBar.DisableAsynchronousDraw();
        }
        this.language = LanguageType.EN;
        this.cacheFilePath = "";
        this.viewerManager = null;
        this.setResizeableType(ResizeableType.NONE);
        this.setDao(new BasePageDAO());
        this.minSize = new Size();
        this.setWindowMinimalSize(200, 200);
    }
    /**
     * @returns {ViewerManager} Returns instance of viewer manager, which is handling current page viewer instance.
     */
    InstanceOwner() {
        return this.viewerManager;
    }
    /**
     * Prepare current page content based on controller needs.
     * @returns {void}
     */
    PreparePageContent() {
        this.setPageTitle(StringUtils.Format(this.dao.getPageTitle(), this.getEnvironmentArgs().getProjectVersion()));
        this.setLoaderText(this.dao.getPageLoadingText());
        this.setLoaderProgressText(this.dao.getPageLoadingProgressText());
        StaticPageContentManager.Language(this.language);
    }
    /**
     * @returns {BaseViewer} Returns controller's model, if controller has been successfully executed, otherwise null.
     */
    getModel() {
        return this.modelObject;
    }
    /**
     * @returns {IBasePageLocalization} Returns page configuration arguments loaded from configuration file.
     */
    getPageConfiguration() {
        return this.dao.getPageConfiguration();
    }
    /**
     * @param {Language} [$language] Specify language variant of the arguments.
     * @param {Function} [$asyncHandler] Specify asynchronous handler,
     * if arguments should be loaded asynchronously or from the file.
     * @returns {BaseViewerArgs} Returns arguments, which has been set to the controller's model.
     */
    getModelArgs($language, $asyncHandler) {
        if (!ObjectValidator.IsSet($language)) {
            const persistence = PersistenceFactory.getPersistence(PersistenceType.BROWSER);
            if (persistence.Exists(LanguageType.ClassNameWithoutNamespace())) {
                this.language = persistence.Variable(LanguageType.ClassNameWithoutNamespace());
            }
            else {
                this.language = StaticPageContentManager.Language();
            }
        }
        else if (this.language !== $language && LanguageType.Contains($language)) {
            this.language = $language;
        }
        this.dao.Load(this.language, () => {
            this.PreparePageContent();
            if (ObjectValidator.IsSet($asyncHandler)) {
                $asyncHandler(this.dao.getModelArgs());
            }
        });
        return this.dao.getModelArgs();
    }
    /**
     * Process the page request. Validates the browser, initializes the Echo output,
     * and delegates to the resolver. Redirects to a browser error page if unsupported.
     */
    Process() {
        if (!this.browserValidator()) {
            LogIt.Error("Unsupported browser. User Agent: " + this.getRequest().getUserAgent());
            this.getHttpManager().ReloadTo("/ServerError/Browser", null, true);
            this.stop();
        }
        else {
            Echo.Init();
            this.resolver();
        }
    }
    /**
     * Set the fully qualified class name of the model viewer to load for this page.
     * Accepts either a string or an IClassName instance.
     * @param {string | IClassName} $value Specify the model class name or an IClassName instance.
     */
    setModelClassName($value) {
        if (!ObjectValidator.IsString($value) && ObjectValidator.IsSet($value.ClassName)) {
            $value = $value.ClassName();
        }
        this.modelClassName = Property.String(this.modelClassName, $value);
    }
    /**
     * Set the BasePageDAO instance used for page configuration and localization loading.
     * @param {BasePageDAO} $value Specify the DAO instance.
     */
    setDao($value) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.dao = $value;
        }
    }
    /**
     * Return the current BasePageDAO instance.
     * @returns {BasePageDAO} Returns the DAO used by this controller.
     */
    getDao() {
        return this.dao;
    }
    /**
     * @returns {IIcon} This method should return class with
     * interface Io.Oidis.Gui.Interfaces.UserControls.IIcon
     */
    getLoaderIconClass() {
        return null;
    }
    /**
     * @returns {ILabel} This method should return class with
     * interface Io.Oidis.Gui.Interfaces.UserControls.ILabel
     */
    getLoaderTextClass() {
        return null;
    }
    /**
     * @returns {ImageButton} This method should return class with
     * interface Io.Oidis.Gui.Interfaces.UserControls.ImageButton
     */
    getAppImageButtonClass() {
        return null;
    }
    /**
     * @returns {IIcon} This method should return class with
     * interface Io.Oidis.Gui.Interfaces.UserControls.IIcon
     */
    getAppIconClass() {
        return null;
    }
    /**
     * @returns {ILabel} This method should return class with
     * interface Io.Oidis.Gui.Interfaces.UserControls.ILabel
     */
    getAppTitleTextClass() {
        return null;
    }
    /**
     * @returns {IResizeBar} This method should return class with
     * interface Io.Oidis.Gui.Interfaces.Components.IResizeBar
     */
    getAppResizeBarClass() {
        return null;
    }
    /**
     * @returns {IDragBar} This method should return class with
     * interface Io.Oidis.Gui.Interfaces.Components.IDragBar
     */
    getAppDragBarClass() {
        return null;
    }
    /**
     * Set the page title. In browser environments updates the document title via
     * StaticPageContentManager; in JRE environments updates the app title label.
     * @param {string} $value Specify the page title text.
     */
    setPageTitle($value) {
        this.pageTitle = Property.String(this.pageTitle, $value);
        if (!this.getRequest().IsJre()) {
            StaticPageContentManager.Title(this.pageTitle);
        }
        else if (!ObjectValidator.IsEmptyOrNull(this.appTitle)) {
            this.appTitle.Text(this.pageTitle);
        }
    }
    /**
     * Set the page favicon source path.
     * @param {string} $value Specify the path to the favicon icon file.
     */
    setPageIconSource($value) {
        this.faviconSource = Property.String(this.faviconSource, $value);
        StaticPageContentManager.FaviconSource(this.faviconSource);
    }
    /**
     * Set the file path used for page static cache loading.
     * @param {string} $value Specify the cache file path.
     */
    setCacheFilePath($value) {
        this.cacheFilePath = Property.String(this.cacheFilePath, $value);
    }
    /**
     * Load DAO configuration resources for the current language. Reads the persisted
     * language preference, loads the DAO, prepares page content, and fires ON_LOAD.
     */
    loadResources() {
        const persistence = PersistenceFactory.getPersistence(PersistenceType.BROWSER);
        if (persistence.Exists(LanguageType.ClassNameWithoutNamespace())) {
            this.language = persistence.Variable(LanguageType.ClassNameWithoutNamespace());
        }
        if (!ObjectValidator.IsEmptyOrNull(this.dao)) {
            this.dao.Load(this.language, () => {
                this.PreparePageContent();
                this.setCacheFilePath(this.dao.getCacheFilePath());
                this.getEventsManager().FireEvent(this.getClassName(), EventType.ON_LOAD, false);
            });
        }
        else {
            this.PreparePageContent();
            this.getEventsManager().FireEvent(this.getClassName(), EventType.ON_LOAD, false);
        }
    }
    resolver() {
        const isJreSimulator = this.getRequest().IsJre(true);
        const loaderResize = () => {
            if (ElementManager.IsVisible("AppContentLoader")) {
                const pageSize = isJreSimulator ?
                    new Size("Browser", true) : WindowManager.getSize();
                const loaderSize = new Size();
                loaderSize.Width(ElementManager.getElement("AppContentLoader_Icon_Icon").offsetWidth +
                    ElementManager.getElement("AppContentLoader_Text").offsetWidth);
                loaderSize.Height(ElementManager.getElement("AppContentLoader_Text_Text").offsetHeight);
                ElementManager.setWidth("AppContentLoader", loaderSize.Width());
                ElementManager.setWidth("AppContentLoader_Content", loaderSize.Width());
                ElementManager.setCssProperty("AppContentLoader", "top", (pageSize.Height() - loaderSize.Height()) / 2);
                ElementManager.setCssProperty("AppContentLoader", "left", (pageSize.Width() - loaderSize.Width()) / 2);
                ElementManager.setOpacity("AppContentLoader", 100);
            }
        };
        let progressIndex = 0;
        if (!ElementManager.Exists("AppContentLoader", true)) {
            if (!ObjectValidator.IsEmptyOrNull(this.loaderProgressLabel)) {
                const loadingProgressHandler = () => {
                    if (progressIndex < 100) {
                        progressIndex++;
                        this.loaderProgressLabel.Text(StringUtils.Format(this.loaderProgressText, progressIndex));
                    }
                };
                this.getEventsManager().setEvent(ViewerManager.ClassName(), EventType.ON_CHANGE, loadingProgressHandler);
                this.getEventsManager().setEvent(BaseViewer.ClassName(), EventType.ON_CHANGE, loadingProgressHandler);
            }
            if (!ObjectValidator.IsEmptyOrNull(this.loaderText)) {
                this.loaderText.getEvents().setOnChange(loaderResize);
            }
            if (!ObjectValidator.IsEmptyOrNull(this.loaderIcon) && !ObjectValidator.IsEmptyOrNull(this.loaderText)) {
                WindowManager.getEvents().setOnResize(loaderResize);
            }
            StaticPageContentManager.Clear();
            StaticPageContentManager.FaviconSource(this.faviconSource);
            const EOL = StringUtils.NewLine(false);
            const cssInterfaceName = this.getCssInterfaceName();
            if (this.getRequest().IsJre() || isJreSimulator) {
                let windowHandler;
                if (!isJreSimulator) {
                    windowHandler = new WindowHandlerConnector();
                }
                let blurFired = false;
                WindowManager.getEvents().setOnFocus(() => {
                    ElementManager.setClassName("Browser", BrowserType[BrowserType.JAVA_RE] + " FOCUS");
                });
                WindowManager.getEvents().setOnBlur(() => {
                    blurFired = true;
                    ElementManager.setClassName("Browser", BrowserType[BrowserType.JAVA_RE]);
                });
                const closeHandler = () => {
                    this.getHttpManager().ReloadTo("/PersistenceManager", null, true);
                    if (!isJreSimulator) {
                        windowHandler.Close();
                    }
                };
                WindowManager.getEvents().setOnLoad(() => {
                    if (!blurFired) {
                        ElementManager.setClassName("Browser", BrowserType[BrowserType.JAVA_RE] + " FOCUS");
                    }
                    let size = WindowManager.getSize();
                    const borderOffset = ElementManager.getCssIntegerValue("Browser", "border-width", true) * 2 +
                        ElementManager.getElement("Browser").offsetTop +
                        ElementManager.getElement("Browser").offsetLeft;
                    const resizeResizeBars = ($size) => {
                        const resizeBarClass = this.getAppResizeBarClass();
                        if (!ObjectValidator.IsEmptyOrNull(resizeBarClass)) {
                            let width = $size.Width() - borderOffset;
                            let height = $size.Height() - borderOffset;
                            if (width < this.minSize.Width()) {
                                width = this.minSize.Width();
                            }
                            if (height < this.minSize.Height()) {
                                height = this.minSize.Height();
                            }
                            resizeBarClass.setWidth(this.topResizeBar, width);
                            resizeBarClass.setWidth(this.bottomResizeBar, width);
                            ElementManager.setCssProperty(this.topRightResizeBar, "left", width);
                            ElementManager.setCssProperty(this.rightResizeBar, "left", width);
                            ElementManager.setCssProperty(this.bottomRightResizeBar, "left", width);
                            resizeBarClass.setHeight(this.leftResizeBar, height);
                            resizeBarClass.setHeight(this.rightResizeBar, height);
                            ElementManager.setCssProperty(this.bottomLeftResizeBar, "top", height);
                            ElementManager.setCssProperty(this.bottomResizeBar, "top", height);
                            ElementManager.setCssProperty(this.bottomRightResizeBar, "top", height);
                        }
                    };
                    resizeResizeBars(size);
                    let distanceChange;
                    const getNormalizedResizeOffset = ($resizeBarEventArgs) => {
                        if (!ObjectValidator.IsEmptyOrNull(distanceChange) && !ObjectValidator.IsEmptyOrNull($resizeBarEventArgs)) {
                            const resize = new ElementOffset(distanceChange.getDistanceY(), distanceChange.getDistanceX());
                            const resizeBar = $resizeBarEventArgs.Owner();
                            if (resizeBar === this.leftResizeBar || resizeBar === this.topLeftResizeBar ||
                                resizeBar === this.bottomLeftResizeBar) {
                                resize.Left(resize.Left() * -1);
                            }
                            if (resizeBar === this.topResizeBar || resizeBar === this.topLeftResizeBar ||
                                resizeBar === this.topRightResizeBar) {
                                resize.Top(resize.Top() * -1);
                            }
                            return resize;
                        }
                        return new ElementOffset();
                    };
                    let lastDistanceX = 0;
                    let lastDistanceY = 0;
                    const resizeHandler = ($eventArgs) => {
                        distanceChange = $eventArgs;
                        const normalizedSize = getNormalizedResizeOffset($eventArgs);
                        const resizeArgs = new ResizeEventArgs();
                        resizeArgs.Owner(this);
                        resizeArgs.Width(size.Width() + normalizedSize.Left());
                        resizeArgs.Height(size.Height() + normalizedSize.Top());
                        let width = resizeArgs.Width() - borderOffset;
                        const resizeEnvelop = () => {
                            let height = resizeArgs.Height() - borderOffset;
                            if (width < this.minSize.Width()) {
                                width = this.minSize.Width();
                            }
                            if (height < this.minSize.Height()) {
                                height = this.minSize.Height();
                            }
                            ElementManager.setCssProperty("Browser", "width", width);
                            ElementManager.setCssProperty("Browser", "height", height);
                            if (!ObjectValidator.IsEmptyOrNull(this.dragBar)) {
                                ElementManager.setCssProperty(this.dragBar, "width", width);
                                ElementManager.setCssProperty(this.dragBar, "left", (-1) * width);
                            }
                            this.getEventsManager().FireEvent("Browser", EventType.ON_RESIZE, resizeArgs);
                        };
                        if (!ObjectValidator.IsEmptyOrNull($eventArgs)) {
                            let dx = $eventArgs.getDistanceX() - lastDistanceX;
                            let dy = $eventArgs.getDistanceY() - lastDistanceY;
                            let cornerType;
                            lastDistanceX = $eventArgs.getDistanceX();
                            lastDistanceY = $eventArgs.getDistanceY();
                            if ($eventArgs.Owner() === this.bottomResizeBar ||
                                $eventArgs.Owner() === this.bottomRightResizeBar ||
                                $eventArgs.Owner() === this.rightResizeBar) {
                                cornerType = WindowCornerType.TOP_LEFT;
                            }
                            else if ($eventArgs.Owner() === this.topResizeBar ||
                                $eventArgs.Owner() === this.topLeftResizeBar ||
                                $eventArgs.Owner() === this.leftResizeBar) {
                                cornerType = WindowCornerType.BOTTOM_RIGHT;
                            }
                            else if ($eventArgs.Owner() === this.topRightResizeBar) {
                                cornerType = WindowCornerType.BOTTOM_LEFT;
                            }
                            else if ($eventArgs.Owner() === this.bottomLeftResizeBar) {
                                cornerType = WindowCornerType.TOP_RIGHT;
                            }
                            if ($eventArgs.Owner() === this.topRightResizeBar ||
                                $eventArgs.Owner() === this.bottomLeftResizeBar) {
                                document.body.style.cursor = "ne-resize";
                            }
                            if (cornerType === WindowCornerType.TOP_LEFT ||
                                cornerType === WindowCornerType.BOTTOM_LEFT) {
                                if (dx < 0) {
                                    if (window.outerWidth + dx < this.minSize.Width()) {
                                        dx = 0;
                                    }
                                    else if (window.outerWidth <= this.minSize.Width()) {
                                        dx = 0;
                                    }
                                }
                            }
                            if (cornerType === WindowCornerType.BOTTOM_RIGHT ||
                                cornerType === WindowCornerType.TOP_RIGHT) {
                                if (dx > 0) {
                                    if (window.outerWidth - dx < this.minSize.Width()) {
                                        dx = 0;
                                    }
                                    else if (window.outerWidth <= this.minSize.Width()) {
                                        dx = 0;
                                    }
                                }
                            }
                            if (cornerType === WindowCornerType.TOP_LEFT ||
                                cornerType === WindowCornerType.TOP_RIGHT) {
                                if (dy < 0) {
                                    if (window.outerHeight + dy < this.minSize.Height()) {
                                        dy = 0;
                                    }
                                    else if (window.outerHeight <= this.minSize.Height()) {
                                        dy = 0;
                                    }
                                }
                            }
                            if (cornerType === WindowCornerType.BOTTOM_RIGHT ||
                                cornerType === WindowCornerType.BOTTOM_LEFT) {
                                if (dy > 0) {
                                    if (window.outerHeight - dy < this.minSize.Height()) {
                                        dy = 0;
                                    }
                                    else if (window.outerHeight <= this.minSize.Height()) {
                                        dy = 0;
                                    }
                                }
                            }
                            if (dx !== 0 || dy !== 0) {
                                if (!isJreSimulator) {
                                    windowHandler.Resize(cornerType, dx, dy).Then(resizeEnvelop);
                                }
                                else {
                                    resizeEnvelop();
                                }
                            }
                        }
                        else {
                            resizeEnvelop();
                        }
                    };
                    const resizeStartHandler = ($eventArgs) => {
                        lastDistanceX = $eventArgs.getDistanceX();
                        lastDistanceY = $eventArgs.getDistanceY();
                    };
                    const resizeFinishHandler = ($eventArgs) => {
                        const normalizedSize = getNormalizedResizeOffset($eventArgs);
                        size.Width(size.Width() + normalizedSize.Left());
                        size.Height(size.Height() + normalizedSize.Top());
                        resizeResizeBars(size);
                        distanceChange = null;
                        const resizeArgs = new ResizeEventArgs();
                        resizeArgs.Owner(this);
                        resizeArgs.Width(size.Width());
                        resizeArgs.Height(size.Height());
                        this.getEventsManager().FireEvent("Browser", EventType.ON_RESIZE_COMPLETE, resizeArgs);
                    };
                    resizeHandler();
                    resizeFinishHandler();
                    const fitBrowserToWindow = () => {
                        size = WindowManager.getSize();
                        if (!isJreSimulator) {
                            size.Width(window.outerWidth);
                            size.Height(window.outerHeight);
                        }
                        resizeResizeBars(size);
                        resizeHandler();
                        resizeFinishHandler();
                    };
                    const initResizeType = this.resizeableType;
                    const windowStateHandler = () => {
                        if (!isJreSimulator) {
                            windowHandler.getState().Then(($state) => {
                                if ($state !== WindowStateType.MAXIMIZED) {
                                    windowHandler.Maximize().Then(() => {
                                        fitBrowserToWindow();
                                        this.setResizeableType(ResizeableType.NONE);
                                    });
                                }
                                else {
                                    windowHandler.Restore().Then(() => {
                                        fitBrowserToWindow();
                                        this.setResizeableType(initResizeType);
                                    });
                                }
                            });
                        }
                        else {
                            fitBrowserToWindow();
                        }
                    };
                    if (!isJreSimulator) {
                        if (ObjectValidator.IsEmptyOrNull(this.maximizeButton) ||
                            (!ObjectValidator.IsEmptyOrNull(this.maximizeButton) && !this.maximizeButton.Visible()) ||
                            this.resizeableType === ResizeableType.NONE) {
                            windowHandler.CanResize(false);
                        }
                        if (!ObjectValidator.IsEmptyOrNull(this.minimizeButton)) {
                            this.minimizeButton.getEvents().setOnClick(() => {
                                windowHandler.Minimize();
                            });
                        }
                        if (!ObjectValidator.IsEmptyOrNull(this.maximizeButton)) {
                            this.maximizeButton.getEvents().setOnClick(windowStateHandler);
                        }
                        if (!ObjectValidator.IsEmptyOrNull(this.closeButton)) {
                            this.closeButton.getEvents().setOnClick(closeHandler);
                        }
                        if (!ObjectValidator.IsEmptyOrNull(this.appIcon)) {
                            this.appIcon.getEvents().setOnDoubleClick(closeHandler);
                        }
                        if (!ObjectValidator.IsEmptyOrNull(this.dragBar)) {
                            const windowPosition = new ElementOffset();
                            let skipMoveMessage = false;
                            let moveInitialized = false;
                            let maximizeOnComplete = false;
                            this.dragBar.getEvents().setOnDoubleClick(() => {
                                windowStateHandler();
                            });
                            const isWithinWindow = ($eventArgs) => {
                                return $eventArgs.NativeEventArgs().screenX >= window.screenX &&
                                    $eventArgs.NativeEventArgs().screenX <= window.screenX + window.outerWidth &&
                                    $eventArgs.NativeEventArgs().screenY >= window.screenY &&
                                    $eventArgs.NativeEventArgs().screenY <= window.screenY + window.outerHeight;
                            };
                            this.dragBar.getEvents().setOnDragStart(() => {
                                if (!moveInitialized) {
                                    windowPosition.Top(window.screenY);
                                    windowPosition.Left(window.screenX);
                                    moveInitialized = true;
                                    skipMoveMessage = false;
                                }
                            });
                            this.dragBar.getEvents().setOnDragChange(($eventArgs) => {
                                if (isWithinWindow($eventArgs)) {
                                    const left = $eventArgs.getDistanceX();
                                    const top = $eventArgs.getDistanceY();
                                    if (!skipMoveMessage && (left !== 0 || top !== 0)) {
                                        const move = () => {
                                            skipMoveMessage = true;
                                            windowHandler
                                                .MoveTo(windowPosition.Left() + left, windowPosition.Top() + top)
                                                .Then(() => {
                                                moveInitialized = false;
                                                skipMoveMessage = false;
                                                fitBrowserToWindow();
                                            });
                                        };
                                        windowHandler.getState().Then(($state) => {
                                            if ($state === WindowStateType.MAXIMIZED) {
                                                if (top > 5) {
                                                    skipMoveMessage = true;
                                                    windowPosition.Top(0);
                                                    windowHandler.Restore().Then(move);
                                                }
                                            }
                                            else {
                                                if ($eventArgs.NativeEventArgs().screenY <= 0) {
                                                    maximizeOnComplete = true;
                                                }
                                                move();
                                            }
                                        });
                                    }
                                }
                            });
                            this.dragBar.getEvents().setOnDragComplete(($eventArgs) => {
                                if (maximizeOnComplete && $eventArgs.NativeEventArgs().screenY <= 0) {
                                    windowStateHandler();
                                }
                                moveInitialized = false;
                                skipMoveMessage = false;
                                maximizeOnComplete = false;
                            });
                        }
                        if (!ObjectValidator.IsEmptyOrNull(this.getAppResizeBarClass())) {
                            const originSize = new Size();
                            const originPosition = new ElementOffset();
                            const fireResizeEvent = ($width, $height) => {
                                const resizeArgs = new ResizeEventArgs();
                                resizeArgs.Owner(this);
                                resizeArgs.Width($width);
                                resizeArgs.Height($height);
                                ElementManager.setCssProperty("Browser", "height", resizeArgs.Height() - borderOffset);
                                this.getEventsManager().FireEvent("Browser", EventType.ON_RESIZE, resizeArgs);
                            };
                            const fitToHeight = () => {
                                if (window.screen.availHeight - window.outerHeight > 0) {
                                    originSize.Width(window.outerWidth);
                                    originSize.Height(window.outerHeight);
                                    originPosition.Left(window.screenX);
                                    originPosition.Top(window.screenY);
                                    windowHandler
                                        .MoveTo(window.screenX, 0)
                                        .Then(() => {
                                        windowHandler
                                            .Resize(WindowCornerType.TOP_LEFT, 0, window.screen.availHeight - window.outerHeight)
                                            .Then(() => {
                                            fireResizeEvent(window.screen.availWidth, window.screen.availHeight);
                                        });
                                    });
                                }
                                else {
                                    if (originSize.Width() > 0 && originSize.Height() > 0) {
                                        windowHandler
                                            .Resize(WindowCornerType.TOP_LEFT, originSize.Width() - window.outerWidth, originSize.Height() - window.outerHeight)
                                            .Then(() => {
                                            windowHandler
                                                .MoveTo(originPosition.Left(), originPosition.Top())
                                                .Then(() => {
                                                fireResizeEvent(originSize.Width(), originSize.Height());
                                            });
                                        });
                                    }
                                }
                            };
                            this.topResizeBar.getEvents().setOnDoubleClick(fitToHeight);
                            this.bottomResizeBar.getEvents().setOnDoubleClick(fitToHeight);
                        }
                        windowHandler.getEvents().OnWindowChanged(($eventArgs) => {
                            if ($eventArgs.state !== WindowStateType.MINIMIZED) {
                                fitBrowserToWindow();
                                if ($eventArgs.state === WindowStateType.MAXIMIZED) {
                                    this.setResizeableType(ResizeableType.NONE);
                                }
                                else {
                                    this.setResizeableType(initResizeType);
                                }
                            }
                        });
                    }
                    else {
                        ElementManager.setCssProperty("Content", "margin", 0);
                        if (!ObjectValidator.IsEmptyOrNull(this.maximizeButton)) {
                            this.maximizeButton.getEvents().setOnClick(() => {
                                fitBrowserToWindow();
                            });
                        }
                        if (!ObjectValidator.IsEmptyOrNull(this.dragBar)) {
                            this.dragBar.getEvents().setOnDoubleClick(fitBrowserToWindow);
                            const windowOffset = new ElementOffset();
                            this.dragBar.getEvents().setOnDragStart(() => {
                                windowOffset.Top(ElementManager.getElement("Browser").offsetTop);
                                windowOffset.Left(ElementManager.getElement("Browser").offsetLeft);
                            });
                            this.dragBar.getEvents().setOnDragChange(($eventArgs) => {
                                ElementManager.setPosition("Browser", new ElementOffset(windowOffset.Top() + $eventArgs.getDistanceY(), windowOffset.Left() + $eventArgs.getDistanceX()));
                            });
                        }
                    }
                    if (!ObjectValidator.IsEmptyOrNull(this.appTitle)) {
                        this.appTitle.getEvents().setOnDoubleClick(windowStateHandler);
                    }
                    if (!ObjectValidator.IsEmptyOrNull(this.getAppResizeBarClass())) {
                        const barsList = [
                            this.topLeftResizeBar,
                            this.topResizeBar,
                            this.topRightResizeBar,
                            this.leftResizeBar,
                            this.rightResizeBar,
                            this.bottomLeftResizeBar,
                            this.bottomResizeBar,
                            this.bottomRightResizeBar
                        ];
                        barsList.forEach(($resizeBar) => {
                            $resizeBar.getEvents().setOnResizeStart(resizeStartHandler);
                            $resizeBar.getEvents().setOnResizeChange(resizeHandler);
                            $resizeBar.getEvents().setOnResizeComplete(($eventArgs) => {
                                resizeFinishHandler($eventArgs);
                                this.getEventsManager().FireAsynchronousMethod(fitBrowserToWindow);
                            });
                        });
                    }
                    this.getEventsManager().FireAsynchronousMethod(fitBrowserToWindow);
                });
                const appWindow = this.addGuiElement().StyleClassName(cssInterfaceName)
                    .Add(this.addGuiElement().StyleClassName("AppHeader")
                    .Add(this.appIcon)
                    .Add(this.appTitle))
                    .Add(this.addGuiElement("AppHeader")
                    .setAttribute("position", "absolute")
                    .setAttribute("top", "0")
                    .setAttribute("right", "0")
                    .Add(this.dragBar)
                    .Add(this.addGuiElement().StyleClassName("AppButtons")
                    .Add(this.minimizeButton)
                    .Add(this.maximizeButton)
                    .Add(this.closeButton)))
                    .Add(this.addGuiElement().StyleClassName("AppResizeBars")
                    .Add(this.addGuiElement().StyleClassName(GeneralCssNames.TOP)
                    .Add(this.addGuiElement().StyleClassName(GeneralCssNames.LEFT).Add(this.topLeftResizeBar))
                    .Add(this.addGuiElement().StyleClassName(GeneralCssNames.CENTER).Add(this.topResizeBar))
                    .Add(this.addGuiElement().StyleClassName(GeneralCssNames.RIGHT).Add(this.topRightResizeBar)))
                    .Add(this.addGuiElement().StyleClassName(GeneralCssNames.MIDDLE)
                    .Add(this.addGuiElement().StyleClassName(GeneralCssNames.LEFT).Add(this.leftResizeBar))
                    .Add(this.addGuiElement().StyleClassName(GeneralCssNames.CENTER))
                    .Add(this.addGuiElement().StyleClassName(GeneralCssNames.RIGHT).Add(this.rightResizeBar)))
                    .Add(this.addGuiElement().StyleClassName(GeneralCssNames.BOTTOM)
                    .Add(this.addGuiElement().StyleClassName(GeneralCssNames.LEFT).Add(this.bottomLeftResizeBar))
                    .Add(this.addGuiElement().StyleClassName(GeneralCssNames.CENTER).Add(this.bottomResizeBar))
                    .Add(this.addGuiElement().StyleClassName(GeneralCssNames.RIGHT).Add(this.bottomRightResizeBar))));
                StaticPageContentManager.BodyAppend(appWindow.Draw(EOL));
            }
            const appContentLoader = this.addGuiElement("AppContentLoader")
                .StyleClassName(cssInterfaceName)
                .setAttribute("position", "absolute")
                .setAttribute("top", "100px")
                .setAttribute("left", "100px")
                .setAttribute("opacity", "0")
                .Add(this.addGuiElement("AppContentLoader_Content").StyleClassName("AppContentLoader")
                .Add(this.loaderIcon)
                .Add(this.loaderText))
                .Add(this.loaderProgressLabel);
            StaticPageContentManager.BodyAppend(appContentLoader.Draw(EOL));
            const developerCorner = this.addGuiElement().StyleClassName("DeveloperCorner").GuiTypeTag("DeveloperCorner")
                .Visible(false)
                .Add(this.addGuiElement("DeveloperCorner_EchoEnvelop").StyleClassName("Services")
                .Add(this.addGuiElement().StyleClassName("Label").Add("Echo output"))
                .Add(this.addGuiElement("DeveloperCorner_EchoTarget").StyleClassName("Echo")));
            StaticPageContentManager.BodyAppend(developerCorner.Draw(EOL));
            const stream = Echo.getStream();
            if (!ObjectValidator.IsEmptyOrNull(stream)) {
                Echo.Clear();
            }
            StaticPageContentManager.Draw();
            ElementManager.setCssProperty(window.document.body, "margin", 0);
            Echo.Init("DeveloperCorner_EchoTarget", true);
            Echo.setOnPrint(($message) => {
                this.getEventsManager().FireAsynchronousMethod(() => {
                    if (!ObjectValidator.IsEmptyOrNull($message)) {
                        LogIt.Info(StringUtils.StripTags($message));
                    }
                });
            });
            Echo.Print(stream);
            if (this.getRequest().IsJre() || isJreSimulator) {
                ElementManager.setClassName("Browser", BrowserType[BrowserType.JAVA_RE] + " FOCUS");
            }
            this.getEventsManager().FireEvent(GeneralEventOwner.BODY, EventType.ON_LOAD);
        }
        else {
            ViewerManager.getLoadedViewers().foreach(($viewer) => {
                if (!ObjectValidator.IsEmptyOrNull($viewer.getInstance())) {
                    $viewer.getInstance().Visible(false);
                }
            });
            ElementManager.Show("AppContentLoader");
            if (!ObjectValidator.IsEmptyOrNull(this.loaderProgressLabel)) {
                this.loaderProgressLabel.Text("");
            }
        }
        if (!ObjectValidator.IsEmptyOrNull(this.loaderIcon) && !ObjectValidator.IsEmptyOrNull(this.loaderText)) {
            this.getEventsManager().FireAsynchronousMethod(loaderResize, 100);
        }
        Echo.Init("DeveloperCorner_EchoTarget", true);
        StaticPageContentManager.Title(this.pageTitle);
        const viewPort = document.createElement("meta");
        viewPort.name = "viewport";
        viewPort.content = "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0";
        StaticPageContentManager.HeadMetaDataAppend(viewPort);
        this.getEventsManager().setEvent(this.getClassName(), EventType.ON_LOAD, () => {
            this.getEventsManager().setEvent(ViewerManager.ClassName(), EventType.ON_COMPLETE, ($eventArgs) => {
                if (!$eventArgs.AsyncCallback()) {
                    ElementManager.Hide("AppContentLoader");
                    if (!ObjectValidator.IsEmptyOrNull(this.loaderProgressLabel)) {
                        this.loaderProgressLabel.Text("");
                    }
                    if (ElementManager.Exists("DeveloperCorner_ContextMenu", true)) {
                        const contextMenu = ElementManager.getElement("DeveloperCorner_ContextMenu").parentNode;
                        contextMenu.parentNode.removeChild(contextMenu);
                    }
                    if (!ObjectValidator.IsEmptyOrNull($eventArgs.Result())) {
                        if ($eventArgs.Result().IsTypeOf(ViewerCacheManager)) {
                            StaticPageContentManager.BodyAppend($eventArgs.Result().Show() + StringUtils.NewLine(false));
                        }
                        else {
                            const view = $eventArgs.Result();
                            this.modelObject = view;
                            if (!view.IsCached()) {
                                StaticPageContentManager.BodyAppend(view.Show() + StringUtils.NewLine(false));
                            }
                            if (!ObjectValidator.IsEmptyOrNull(view.getInstance())) {
                                const instance = this.getModel().getInstance();
                                this.beforeLoad(instance, this.getModelArgs(), this.getDao());
                                instance.getEvents().setOnComplete(() => {
                                    this.afterLoad(instance, this.getModelArgs(), this.getDao());
                                });
                                view.getInstance().Visible(true);
                                const getBrowserSize = () => {
                                    const borderOffset = ElementManager.getCssIntegerValue("Browser", "border-width") * 2;
                                    const browserSize = new Size("Browser", true);
                                    browserSize.Height((browserSize.Height() === 0 ?
                                        WindowManager.getSize().Height() : browserSize.Height()) -
                                        borderOffset -
                                        ElementManager.getElement("Browser").offsetTop * 2 -
                                        (!ObjectValidator.IsEmptyOrNull(ElementManager.getElement(this.dragBar)) ?
                                            ElementManager.getElement(this.dragBar).offsetHeight : 0));
                                    browserSize.Width((browserSize.Width() === 0 ?
                                        WindowManager.getSize().Width() : browserSize.Width()) -
                                        borderOffset);
                                    return browserSize;
                                };
                                this.getEventsManager().setEvent("Browser", EventType.ON_RESIZE, () => {
                                    const browserSize = getBrowserSize();
                                    ElementManager.setWidth(view.getInstance().Id(), browserSize.Width());
                                    ElementManager.setHeight(view.getInstance().Id(), browserSize.Height());
                                });
                                this.getEventsManager().setEvent("Browser", EventType.ON_RESIZE_COMPLETE, () => {
                                    const browserSize = getBrowserSize();
                                    const instance = view.getInstance();
                                    if (instance.Width() !== browserSize.Width() ||
                                        instance.Height() !== browserSize.Height()) {
                                        instance.Width(browserSize.Width());
                                        instance.Height(browserSize.Height());
                                    }
                                });
                            }
                            /* dev:start */
                            if (!this.getEnvironmentArgs().IsProductionMode()) {
                                StaticPageContentManager.BodyAppend(this.contextMenu());
                            }
                            /* dev:end */
                            this.getEventsManager().FireEvent(this.getClassName(), EventType.ON_SUCCESS);
                            this.getEventsManager().FireEvent(this.getClassName(), EventType.ON_COMPLETE);
                            this.onSuccess(this.getModel().getInstance(), this.getModelArgs(), this.getDao());
                        }
                        this.getEventsManager().FireEvent(GeneralEventOwner.BODY, EventType.ON_LOAD);
                    }
                    else {
                        this.getEventsManager().FireEvent(this.getClassName(), EventType.ON_ERROR);
                        this.getEventsManager().FireEvent(this.getClassName(), EventType.ON_COMPLETE);
                        this.onError();
                    }
                }
            });
            this.viewerManager = new ViewerManager(this.modelClassName, null, this.getModelArgs());
            this.viewerManager.setCacheFilePath(this.cacheFilePath);
            if (StringUtils.Contains(this.getRequest().getScriptPath(), HttpRequestConstants.FORCE_REFRESH)) {
                this.viewerManager.ReloadCacheEnabled(true);
                this.viewerManager.Process();
            }
            else {
                if (ViewerManager.Exists(this.viewerManager.getId())) {
                    ElementManager.Hide("AppContentLoader");
                    if (!ObjectValidator.IsEmptyOrNull(this.loaderProgressLabel)) {
                        this.loaderProgressLabel.Text("");
                    }
                    this.modelObject = ViewerManager.getLoadedViewers().getItem(this.viewerManager.getId());
                    this.getModel().getInstance().Visible(true);
                    this.getEventsManager().FireEvent(this.getClassName(), EventType.ON_SUCCESS);
                    this.onSuccess(this.getModel().getInstance(), this.getModelArgs(), this.getDao());
                }
                else {
                    this.viewerManager.Process();
                }
            }
        });
        this.loadResources();
    }
    /**
     * Lifecycle hook called before the model instance is loaded. Override to prepare
     * the instance or its arguments before the loading process begins.
     * @param {IBaseGuiObject} [$instance] Specify the GUI object instance being loaded.
     * @param {BaseViewerArgs} [$args] Specify the viewer arguments.
     * @param {BasePageDAO} [$dao] Specify the page DAO.
     */
    beforeLoad($instance, $args, $dao) {
        // override this method for ability to prepare instance before it is loaded
    }
    /**
     * Lifecycle hook called after the model instance has been loaded. Override to
     * configure the instance or bind additional event handlers.
     * @param {IBaseGuiObject} [$instance] Specify the loaded GUI object instance.
     * @param {BaseViewerArgs} [$args] Specify the viewer arguments.
     * @param {BasePageDAO} [$dao] Specify the page DAO.
     */
    afterLoad($instance, $args, $dao) {
        // override this method for ability to setup instance after it is loaded
    }
    /**
     * Lifecycle hook called after the controller has been successfully loaded.
     * Override to handle post-load controller state or trigger additional logic.
     * @param {IBaseGuiObject} [$instance] Specify the successfully loaded GUI object instance.
     * @param {BaseViewerArgs} [$args] Specify the viewer arguments.
     * @param {BasePageDAO} [$dao] Specify the page DAO.
     */
    onSuccess($instance, $args, $dao) {
        // override this method for ability to handle controller state after it has been successfully loaded
    }
    /**
     * Lifecycle hook called when the model viewer fails to load. Default implementation
     * throws an error indicating the model class name was not found.
     */
    onError() {
        ExceptionsManager.Throw("Application loader", "Model \"" + this.modelClassName + "\" source file or persistence instance " +
            "has not been found! Please, validate correct usage of this.setModelClassName() in constructor.");
    }
    /**
     * Set the window resize behavior by showing or hiding the appropriate resize bars.
     * @param {ResizeableType} $value Specify the resize type (NONE, HORIZONTAL, VERTICAL, HORIZONTAL_AND_VERTICAL).
     */
    setResizeableType($value) {
        if (!ObjectValidator.IsEmptyOrNull(this.getAppResizeBarClass())) {
            this.resizeableType = $value;
            switch ($value) {
                case ResizeableType.HORIZONTAL:
                    this.topLeftResizeBar.Visible(false);
                    this.topResizeBar.Visible(false);
                    this.topRightResizeBar.Visible(false);
                    this.leftResizeBar.Visible(true);
                    this.rightResizeBar.Visible(true);
                    this.bottomLeftResizeBar.Visible(false);
                    this.bottomResizeBar.Visible(false);
                    this.bottomRightResizeBar.Visible(false);
                    break;
                case ResizeableType.VERTICAL:
                    this.topLeftResizeBar.Visible(false);
                    this.topResizeBar.Visible(true);
                    this.topRightResizeBar.Visible(false);
                    this.leftResizeBar.Visible(false);
                    this.rightResizeBar.Visible(false);
                    this.bottomLeftResizeBar.Visible(false);
                    this.bottomResizeBar.Visible(true);
                    this.bottomRightResizeBar.Visible(false);
                    break;
                case ResizeableType.HORIZONTAL_AND_VERTICAL:
                    this.topLeftResizeBar.Visible(true);
                    this.topResizeBar.Visible(true);
                    this.topRightResizeBar.Visible(true);
                    this.leftResizeBar.Visible(true);
                    this.rightResizeBar.Visible(true);
                    this.bottomLeftResizeBar.Visible(true);
                    this.bottomResizeBar.Visible(true);
                    this.bottomRightResizeBar.Visible(true);
                    break;
                default:
                    this.topLeftResizeBar.Visible(false);
                    this.topResizeBar.Visible(false);
                    this.topRightResizeBar.Visible(false);
                    this.leftResizeBar.Visible(false);
                    this.rightResizeBar.Visible(false);
                    this.bottomLeftResizeBar.Visible(false);
                    this.bottomResizeBar.Visible(false);
                    this.bottomRightResizeBar.Visible(false);
                    break;
            }
        }
    }
    /**
     * Set the minimum window dimensions for JRE window resize operations.
     * @param {number} $width Specify the minimum width in pixels.
     * @param {number} $height Specify the minimum height in pixels.
     */
    setWindowMinimalSize($width, $height) {
        this.minSize.Width($width);
        this.minSize.Height($height);
    }
    /**
     * Return the CSS interface class name derived from the controller's class name.
     * @returns {string} Returns the class name with dots removed for use as a CSS class.
     */
    getCssInterfaceName() {
        return StringUtils.Remove(BasePageController.ClassName(), ".");
    }
    /**
     * Create and return a new GuiElement with an optional identifier.
     * @param {string} [$id] Specify the element identifier.
     * @returns {IGuiElement} Returns a new GuiElement instance.
     */
    addGuiElement($id) {
        return new GuiElement().Id($id);
    }
    /* dev:start */
    contextMenu() {
        WindowManager.getEvents().setOnRightClick(($eventArgs) => {
            $eventArgs.PreventDefault();
            let top = WindowManager.getMouseY($eventArgs.NativeEventArgs(), true) + 15;
            let left = WindowManager.getMouseX($eventArgs.NativeEventArgs(), true) + 15;
            this.getEventsManager().FireAsynchronousMethod(() => {
                const menu = ElementManager.getElement("DeveloperCorner_ContextMenu", true);
                ElementManager.Show(menu);
                const menuSize = new Size(menu.id, true);
                const windowSize = WindowManager.getSize();
                if (top + menuSize.Height() > windowSize.Height()) {
                    top = windowSize.Height() - menuSize.Height() - 20;
                }
                if (left + menuSize.Width() > windowSize.Width()) {
                    left = windowSize.Width() - menuSize.Width() - 20;
                }
                ElementManager.setCssProperty(menu, "top", top);
                ElementManager.setCssProperty(menu, "left", left);
            }, 100);
        });
        WindowManager.getEvents().setOnClick(() => {
            if (ElementManager.IsVisible("DeveloperCorner_ContextMenu")) {
                ElementManager.Hide("DeveloperCorner_ContextMenu");
            }
        });
        WindowManager.getEvents().setOnLoad(() => {
            const generateCacheEvents = new ElementEventsManager("GenerateCacheLink");
            const showCacheDataLinkEvents = new ElementEventsManager("ShowCacheDataLink");
            const showCacheReportLinkEvents = new ElementEventsManager("ShowCacheReportLink");
            const cleanCacheLinkEvents = new ElementEventsManager("CleanCacheLink");
            const forceRefreshLinkEvents = new ElementEventsManager("ForceRefreshLink");
            const showEchoLinkEvents = new ElementEventsManager("ShowEchoLink");
            const echoTargetId = "DeveloperCorner_EchoTarget";
            const echoTargetEvents = new ElementEventsManager(echoTargetId);
            const showEcho = () => {
                ElementManager.Show(ElementManager.getElement("DeveloperCorner_EchoEnvelop", true));
                const windowSize = WindowManager.getSize();
                const contentHeight = ElementManager.getElement(echoTargetId, true).offsetHeight;
                if (contentHeight > windowSize.Height()) {
                    ElementManager.setHeight(echoTargetId, windowSize.Height() - 35);
                }
            };
            generateCacheEvents.setOnClick(($args) => {
                $args.PreventDefault();
                if (this.getModel().IsMemberOf(BasePanelViewer)) {
                    this.getEventsManager().FireAsynchronousMethod(() => {
                        const startTime = new Date().getTime();
                        this.viewerManager.getCache(() => {
                            const report = "<b>Cache has been created.</b> " +
                                "Process time: " + Convert.TimeToSeconds(new Date().getTime() - startTime) + " seconds";
                            showEcho();
                            Echo.Println(report);
                            this.viewerManager.getCacheRawData(($data) => {
                                const fs = new FileSystemHandlerConnector();
                                this.getEventsManager().Clear("" + fs.getId(), WebServiceClientEventType.ON_ERROR);
                                fs.getEvents().OnError(() => {
                                    Echo.Println("Unable to store cache data. " +
                                        "Please use Show Cache raw data option for manual storage.");
                                });
                                fs.getHostLocation().Then(($path) => {
                                    $path = StringUtils.Replace($path, "\\", "/");
                                    let cachePath = "";
                                    if (StringUtils.Contains($path, "/target/")) {
                                        if (StringUtils.Contains($path, "/build/target/target/")) {
                                            cachePath = StringUtils.Substring(StringUtils.Remove($path, "/build/target/"), 0, StringUtils.IndexOf($path, "/target/") - 6);
                                        }
                                        else {
                                            cachePath = StringUtils.Substring($path, 0, StringUtils.IndexOf($path, "/target/", false) - 6);
                                        }
                                    }
                                    else {
                                        cachePath = $path;
                                    }
                                    cachePath = StringUtils.Replace(cachePath + "/" + this.cacheFilePath, "\\", "/");
                                    Echo.Println("Writing cache file \"" + cachePath + "\"");
                                    fs.Write(cachePath, "JsonpData(\"" +
                                        ObjectEncoder.Base64($data, true) +
                                        "\");").Then(($status) => {
                                        if ($status === true) {
                                            let targetPath = "/build/target/target/";
                                            if (!StringUtils.Contains($path, targetPath) &&
                                                !StringUtils.Contains(this.getRequest().getHostUrl(), targetPath)) {
                                                targetPath = "/build/target/";
                                            }
                                            targetPath = StringUtils.Replace(cachePath, this.cacheFilePath, targetPath + this.cacheFilePath);
                                            fs.Copy(cachePath, targetPath);
                                            Echo.Println("Cache data has been stored");
                                            this.viewerManager.ClearCache();
                                        }
                                        else {
                                            Echo.Println("Storage of cache data to the file has failed.");
                                        }
                                    });
                                });
                            });
                        });
                    }, 1000);
                }
            });
            showCacheDataLinkEvents.setOnClick(($args) => {
                $args.PreventDefault();
                Echo.Clear();
                this.viewerManager.getCacheRawData(($data) => {
                    const cacheViewer = document.createElement("textarea");
                    cacheViewer.innerHTML = "JsonpData(\"" +
                        ObjectEncoder.Base64($data, true) +
                        "\");";
                    ElementManager.getElement(echoTargetId).appendChild(cacheViewer);
                    const windowSize = WindowManager.getSize();
                    ElementManager.setSize(cacheViewer, windowSize.Width() - 50, windowSize.Height() - 50);
                    ElementManager.setCssProperty(cacheViewer, "margin-top", 15);
                    showEcho();
                });
            });
            showCacheReportLinkEvents.setOnClick(($args) => {
                $args.PreventDefault();
                this.viewerManager.getCacheRawData(() => {
                    Echo.Clear();
                    Echo.Printf(this.viewerManager);
                    showEcho();
                });
            });
            cleanCacheLinkEvents.setOnClick(($args) => {
                $args.PreventDefault();
                this.viewerManager.ClearCache(false);
                this.getHttpManager().Refresh();
            });
            forceRefreshLinkEvents.setOnClick(($args) => {
                $args.PreventDefault();
                this.viewerManager.ClearCache();
                this.getHttpManager().Refresh();
            });
            showEchoLinkEvents.setOnClick(($args) => {
                $args.PreventDefault();
                showEcho();
            });
            echoTargetEvents.setOnDoubleClick(() => {
                ElementManager.Hide("DeveloperCorner_EchoEnvelop");
            });
            generateCacheEvents.Subscribe("DeveloperCorner_ContextMenu_GenerateCache", true);
            showCacheDataLinkEvents.Subscribe("DeveloperCorner_ContextMenu_ShowCacheData", true);
            showCacheReportLinkEvents.Subscribe("DeveloperCorner_ContextMenu_ShowCacheReport", true);
            cleanCacheLinkEvents.Subscribe("DeveloperCorner_ContextMenu_CleanCache", true);
            forceRefreshLinkEvents.Subscribe("DeveloperCorner_ContextMenu_ForceRefresh", true);
            showEchoLinkEvents.Subscribe("DeveloperCorner_ContextMenu_ShowEcho", true);
            echoTargetEvents.Subscribe(true);
        });
        return this.addGuiElement().StyleClassName("DeveloperCorner").GuiTypeTag("DeveloperCorner")
            .Add(this.addGuiElement("DeveloperCorner_ContextMenu").StyleClassName("ContextMenu").Visible(false)
            .Add(this.addGuiElement("DeveloperCorner_ContextMenu_GenerateCache").StyleClassName("Link")
            .Add("Generate Cache"))
            .Add(this.addGuiElement("DeveloperCorner_ContextMenu_ShowCacheData").StyleClassName("Link")
            .Add("Show Cache raw data"))
            .Add(this.addGuiElement("DeveloperCorner_ContextMenu_ShowCacheReport").StyleClassName("Link")
            .Add("Show Cache report"))
            .Add(this.addGuiElement("DeveloperCorner_ContextMenu_CleanCache").StyleClassName("Link")
            .Add("Destroy generated Cache"))
            .Add(this.addGuiElement("DeveloperCorner_ContextMenu_ForceRefresh").StyleClassName("Link")
            .Add("Force refresh"))
            .Add(this.addGuiElement("DeveloperCorner_ContextMenu_ShowEcho").StyleClassName("Link")
            .Add("Show Echo output")))
            .Draw(StringUtils.NewLine(false));
    }
    /* dev:end */
    setLoaderText($value) {
        if (!ObjectValidator.IsEmptyOrNull(this.loaderText)) {
            this.loaderText.Text($value);
        }
    }
    setLoaderProgressText($value) {
        this.loaderProgressText = Property.String(this.loaderProgressText, $value);
    }
}
globalThis.RegisterClass("Io.Oidis.Services.HttpProcessor.Resolvers.BasePageController", BasePageController);
//# sourceMappingURL=BasePageController.js.map