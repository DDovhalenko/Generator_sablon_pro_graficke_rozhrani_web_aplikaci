var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { ExceptionsManager } from "./../../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { BaseHttpResolver } from "./../../../../../Io/Oidis/Commons/HttpProcessor/Resolvers/BaseHttpResolver.js";
import { Resolver } from "./../../../../../Io/Oidis/Commons/Primitives/Decorators.js";
import { LogIt } from "./../../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { StaticPageContentManager } from "./../../../../../Io/Oidis/Gui/Utils/StaticPageContentManager.js";
import { EnvironmentConnector } from "../../Connectors/EnvironmentConnector.js";
/**
 * InitPage is displayed when a page controller detects that the backend environment
 * is not yet loaded. It shows a loading message, subscribes to the environment loading
 * listener, and automatically redirects to the root page once the environment becomes ready.
 */
let InitPage = class InitPage extends BaseHttpResolver {
    /**
     * Resolve the init page by checking environment readiness. If not loaded, displays
     * a static loading page and listens for the environment to finish loading. Once ready,
     * redirects to the application root. If already loaded, redirects immediately.
     */
    resolver() {
        EnvironmentConnector.getInstanceSingleton().IsEnvironmentLoaded()
            .then(($status) => {
            if (!$status) {
                StaticPageContentManager.Clear();
                StaticPageContentManager.Title("Loading");
                StaticPageContentManager.BodyAppend("Application is not ready please wait");
                StaticPageContentManager.Draw();
                EnvironmentConnector.getInstanceSingleton().AddLoadingListener()
                    .OnError(($error) => {
                    LogIt.Error($error.Message());
                    StaticPageContentManager.BodyAppend("Failed to init environment");
                })
                    .Then(() => {
                    window.location.href = "/";
                });
            }
            else {
                window.location.href = "/";
            }
        })
            .catch(($error) => {
            ExceptionsManager.HandleException($error);
        });
    }
};
InitPage = __decorate([
    Resolver("/ServerError/NotReady")
], InitPage);
export { InitPage };
globalThis.RegisterClass("Io.Oidis.Services.HttpProcessor.Resolvers.InitPage", InitPage);
//# sourceMappingURL=InitPage.js.map