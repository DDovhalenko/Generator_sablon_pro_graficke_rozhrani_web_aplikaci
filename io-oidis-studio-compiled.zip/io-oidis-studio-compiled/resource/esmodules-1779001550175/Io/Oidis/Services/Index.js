var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IndexPage } from "./../../../Io/Oidis/Gui/Pages/IndexPage.js";
import { AsyncBasePageController } from "./HttpProcessor/Resolvers/AsyncBasePageController.js";
import { Resolver, ResolverScope } from "./../../../Io/Oidis/Commons/Primitives/Decorators.js";
/* dev:start */
import { AgentsRegisterConnectorTest } from "./RuntimeTests/AgentsRegisterConnectorTest.js";
import { AsyncFileSystemConnectorTest } from "./RuntimeTests/AsyncFileSystemConnectorTest.js";
import { AsyncTerminalConnectorTest } from "./RuntimeTests/AsyncTerminalConnectorTest.js";
import { CertsConnectorTest } from "./RuntimeTests/CertsConnectorTest.js";
import { COMproxyConnectorTest } from "./RuntimeTests/COMproxyConnectorTest.js";
import { FFIProxyConnectorTest } from "./RuntimeTests/FFIProxyConnectorTest.js";
import { FileSystemConnectorTest } from "./RuntimeTests/FileSystemConnectorTest.js";
import { IdeHandlerConnectorTest } from "./RuntimeTests/IdeHandlerConnectorTest.js";
import { InstallationProcessTest } from "./RuntimeTests/InstallationProcessTest.js";
import { JxbrowserLiveContentWrapperTest } from "./RuntimeTests/JxbrowserLiveContentWrapperTest.js";
import { LogInTest } from "./RuntimeTests/LogInTest.js";
import { NetworkingConnectorTest } from "./RuntimeTests/NetworkingConnectorTest.js";
import { PageControllerTest } from "./RuntimeTests/PageControllerTest.js";
import { RenderTest } from "./RuntimeTests/RenderTest.js";
import { ReportServiceTest } from "./RuntimeTests/ReportServiceTest.js";
import { RestWebServiceTest } from "./RuntimeTests/RestWebServiceTest.js";
import { TerminalConnectorTest } from "./RuntimeTests/TerminalConnectorTest.js";
import { VirtualBoxConnectorTest } from "./RuntimeTests/VirtualBoxConnectorTest.js";
import { WebSocketsServiceTest } from "./RuntimeTests/WebSocketsServiceTest.js";
import { WindowHandlerConnectorTest } from "./RuntimeTests/WindowHandlerConnectorTest.js";
/* dev:end */
/**
 * Index request resolver class provides handling of web index page.
 */
let Index = class Index extends AsyncBasePageController {
    constructor() {
        super();
        this.setInstanceOwner(new IndexPage());
    }
    async onSuccess($instance) {
        $instance.headerTitle.Content("Oidis Framework Services Library");
        $instance.headerInfo.Content("Oidis Framework library focused on services and " +
            "business logic for applications build on Oidis Framework");
        let content = "";
        /* dev:start */
        content += `
            <h3>Runtime tests</h3>
            <a href="${RestWebServiceTest.CallbackLink()}">REST web services test</a>
            <a href="${WebSocketsServiceTest.CallbackLink()}">WebSockets services test</a>
            <a href="${ReportServiceTest.CallbackLink()}">Report service test</a>
            <a href="${FileSystemConnectorTest.CallbackLink()}">FileSystem connector test</a>
            <a href="${AsyncFileSystemConnectorTest.CallbackLink()}">FileSystem connector test ASYNC</a>
            <a href="${COMproxyConnectorTest.CallbackLink()}">COM Proxy test</a>
            <a href="${FFIProxyConnectorTest.CallbackLink()}">FFI Proxy test</a>
            <a href="${TerminalConnectorTest.CallbackLink()}">Terminal connector test</a>
            <a href="${AsyncTerminalConnectorTest.CallbackLink()}">Terminal connector test ASYNC</a>
            <a href="${AgentsRegisterConnectorTest.CallbackLink()}">AgentsRegister connector test</a>
            <a href="${NetworkingConnectorTest.CallbackLink()}">Terminal connector test ASYNC</a>
            <a href="${LogInTest.CallbackLink()}">LogIn test</a>
            <a href="${InstallationProcessTest.CallbackLink()}">Installation process test</a>
            <a href="${WindowHandlerConnectorTest.CallbackLink()}">WindowHandler connector test</a>
            <a href="${JxbrowserLiveContentWrapperTest.CallbackLink()}">Jxbrowser LiveContentWrapper Test</a>
            <a href="${IdeHandlerConnectorTest.CallbackLink()}">Jxbrowser IdeHandlerConnector Test</a>
            <a href="${VirtualBoxConnectorTest.CallbackLink()}">VirtualBox connector Test</a>
            <a href="?debug=JRESimulator#/${PageControllerTest.ClassNameWithoutNamespace()}">PageController Test</a>
            <a href="${RenderTest.CallbackLink()}">Render Test</a>
            <a href="${CertsConnectorTest.CallbackLink()}">Certs connector Test</a>
            `;
        /* dev:end */
        $instance.pageIndex.Content(content);
        $instance.footerInfo.Content("" +
            "version: " + this.getEnvironmentArgs().getProjectVersion() +
            ", build: " + this.getEnvironmentArgs().getBuildTime() +
            ", " + this.getEnvironmentArgs().getProjectConfig().target.copyright);
    }
};
Index = __decorate([
    Resolver(["/", "/index", "/web/", "/ServerError/Http/DefaultPage"], { scope: ResolverScope.DEV }),
    __metadata("design:paramtypes", [])
], Index);
export { Index };
globalThis.RegisterClass("Io.Oidis.Services.Index", Index);
//# sourceMappingURL=Index.js.map