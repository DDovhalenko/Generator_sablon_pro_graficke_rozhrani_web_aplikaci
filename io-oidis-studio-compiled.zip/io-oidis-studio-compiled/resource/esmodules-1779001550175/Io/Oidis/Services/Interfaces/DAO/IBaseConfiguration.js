// generated-code-start
/* eslint-disable */
export const IImports = globalThis.RegisterInterface(["variable", "source"]);
export const ILocalization = globalThis.RegisterInterface(["en", "cz", "cs", "cn"]);
export const IBaseConfiguration = globalThis.RegisterInterface(["version", "extendsConfig", "$interface", "imports", "localization", "noCache", "$super", "Echo", "Log", "Warning", "Error"]);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.DAO.IImports", IImports);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.DAO.ILocalization", ILocalization);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.DAO.IBaseConfiguration", IBaseConfiguration);
//# sourceMappingURL=IBaseConfiguration.js.map