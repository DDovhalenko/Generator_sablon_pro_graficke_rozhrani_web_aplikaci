import { IBaseConfiguration } from "./IBaseConfiguration.js";
// generated-code-start
/* eslint-disable */
export const IInstallationHandler = globalThis.RegisterInterface([]);
export const IInstallationPackageSource = globalThis.RegisterInterface(["options", "x86", "x64"]);
export const IInstallationPackage = globalThis.RegisterInterface(["name", "description", "info", "size", "version", "source", "installCondition", "selectSource", "getSource", "install", "uninstall", "repair", "validate", "force", "optional"]);
export const IInstallationRecipeNotifications = globalThis.RegisterInterface(["package_is_installed_correctly", "package_is_missing_or_damaged__0__", "package_is_already_installed", "step__0__has_been_skipped", "unsupported_callback_status__0__detected_for__1__at_step__2__", "undefined_installation_protocol__0__", "undefined_installation_chain__0__", "unsupported_definition_of_package_source_for__0__", "package_source__0__for__1__does_not_exist", "unable_to_clone_package_source_for__0__", "required_GIT__0__has_not_been_found", "get_source__0__", "unable_to_delete_downloaded_package", "unable_to_move_package_source_to_tmp_destination", "unable_to_create_installation_folder", "undefined_package_source_for__0__"]);
export const IInstallationEnvironment = globalThis.RegisterInterface(["block", "packages", "getChain", "terminal", "fileSystem", "utils", "notifications", "onChange"], IBaseConfiguration);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.DAO.IInstallationHandler", IInstallationHandler);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.DAO.IInstallationPackageSource", IInstallationPackageSource);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.DAO.IInstallationPackage", IInstallationPackage);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.DAO.IInstallationRecipeNotifications", IInstallationRecipeNotifications);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.DAO.IInstallationEnvironment", IInstallationEnvironment);
//# sourceMappingURL=IBaseInstallationRecipe.js.map