/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IBaseConfiguration } from "./IBaseConfiguration.js";
// generated-code-start
/* eslint-disable */
export const IBasePageLocalization = globalThis.RegisterInterface(["cacheFile", "title", "loading", "loadingProgress"], IBaseConfiguration);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.DAO.IBasePageLocalization", IBasePageLocalization);
//# sourceMappingURL=IBasePageLocalization.js.map