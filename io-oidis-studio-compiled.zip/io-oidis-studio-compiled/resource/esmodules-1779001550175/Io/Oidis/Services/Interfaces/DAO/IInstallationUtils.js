// generated-code-start
/* eslint-disable */
export const IInstallationUtils = globalThis.RegisterInterface(["getVersion", "VersionIsIncluded", "getRegisterValue", "setRegisterValue", "setRegisterValues", "RegisterValueExists", "AnyOfRegisterValueExists", "RemoveRegisterKey", "RunExecutable", "Elevate", "Is64Bit", "SystemPathExists", "AddToSystemPath", "RemoveSystemPath", "getSystemDrive", "getWinDir", "getProgramFilesPath", "getDesktopPath", "getStartMenuPath", "getLocalAppDataPath", "getGitPath", "getMinGWPath", "getMsysPath", "getCmakePath", "Clone", "RegisterApp", "RunSilentUninstall", "ShellExecute"]);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.DAO.IInstallationUtils", IInstallationUtils);
//# sourceMappingURL=IInstallationUtils.js.map