// generated-code-start
export const IWindowChangedEvent = globalThis.RegisterInterface(["x", "y", "width", "height", "state"]);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.Events.IWindowChangedEvent", IWindowChangedEvent);
//# sourceMappingURL=IWindowChangedEvent.js.map