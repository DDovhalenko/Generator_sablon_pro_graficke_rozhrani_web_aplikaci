/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2018 NXP
 * Copyright 2019-2025 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IWebServiceClientEvents } from "./../../../../../Io/Oidis/Commons/Interfaces/Events/IWebServiceClientEvents.js";
// generated-code-start
/* eslint-disable */
export const IWindowHandlerConnectorEvents = globalThis.RegisterInterface(["OnNotifyIconClick", "OnNotifyIconDoubleClick", "OnNotifyIconBalloonClick", "OnNotifyIconContextItemSelected", "OnWindowChanged"], IWebServiceClientEvents);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.Events.IWindowHandlerConnectorEvents", IWindowHandlerConnectorEvents);
//# sourceMappingURL=IWindowHandlerConnectorEvents.js.map