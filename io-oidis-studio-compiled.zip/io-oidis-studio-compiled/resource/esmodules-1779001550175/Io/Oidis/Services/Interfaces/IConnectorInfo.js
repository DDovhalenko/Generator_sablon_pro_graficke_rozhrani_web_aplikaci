// generated-code-start
export const IConnectorInfo = globalThis.RegisterInterface(["owner", "namespace", "requester", "created"]);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.IConnectorInfo", IConnectorInfo);
//# sourceMappingURL=IConnectorInfo.js.map