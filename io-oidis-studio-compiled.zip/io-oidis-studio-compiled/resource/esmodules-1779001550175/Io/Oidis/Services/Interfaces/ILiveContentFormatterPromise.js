// generated-code-start
export const ILiveContentFormatterPromise = globalThis.RegisterInterface(["DataFormatter", "OnError", "Then"]);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.ILiveContentFormatterPromise", ILiveContentFormatterPromise);
//# sourceMappingURL=ILiveContentFormatterPromise.js.map