// generated-code-start
export const ILiveContentErrorPromise = globalThis.RegisterInterface(["OnError", "Then"]);
export const ILiveContentPromise = globalThis.RegisterInterface(["Then"]);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.ILiveContentErrorPromise", ILiveContentErrorPromise);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.ILiveContentPromise", ILiveContentPromise);
//# sourceMappingURL=ILiveContentPromise.js.map