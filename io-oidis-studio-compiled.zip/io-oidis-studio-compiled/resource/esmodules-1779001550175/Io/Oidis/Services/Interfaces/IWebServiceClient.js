/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { IWebServiceClient as Parent } from "./../../../../Io/Oidis/Commons/Interfaces/IWebServiceClient.js";
// generated-code-start
export const IWebServiceClient = globalThis.RegisterInterface(["Send"], Parent);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.IWebServiceClient", IWebServiceClient);
//# sourceMappingURL=IWebServiceClient.js.map