// generated-code-start
/* eslint-disable */
export const IWebServiceException = globalThis.RegisterInterface(["message", "file", "line", "col", "code", "stack", "args"]);
export const ILiveContentProtocol = globalThis.RegisterInterface(["name", "args", "returnValue"]);
export const IWebServiceProtocol = globalThis.RegisterInterface(["id", "clientId", "type", "status", "origin", "token", "data", "language", "version", "format", "keepAlive"]);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.IWebServiceException", IWebServiceException);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.ILiveContentProtocol", ILiveContentProtocol);
globalThis.RegisterClass("Io.Oidis.Services.Interfaces.IWebServiceProtocol", IWebServiceProtocol);
//# sourceMappingURL=IWebServiceProtocol.js.map