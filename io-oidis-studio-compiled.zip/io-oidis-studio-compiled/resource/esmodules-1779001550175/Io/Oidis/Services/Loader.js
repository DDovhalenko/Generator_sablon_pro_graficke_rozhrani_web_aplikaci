/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { Loader as Parent } from "./../../../Io/Oidis/Gui/Loader.js";
import "./ForceCompile.js";
import { HttpResolver } from "./HttpProcessor/HttpResolver.js";
/**
 * Loader class provides handling of application content singleton.
 */
export class Loader extends Parent {
    /**
     * Return the singleton Loader instance cast to the services-specific Loader type.
     * @returns {Loader} Returns the services Loader singleton.
     */
    static getInstance() {
        return super.getInstance();
    }
    /**
     * Return the HTTP resolver instance cast to the services-specific HttpResolver type.
     * @returns {HttpResolver} Returns the services HttpResolver with JRE-aware HttpManager.
     */
    getHttpResolver() {
        return super.getHttpResolver();
    }
    /**
     * Return the HTTP manager instance cast to the services-specific HttpManager type.
     * @returns {HttpManager} Returns the services HttpManager with JRE terminal support.
     */
    getHttpManager() {
        return super.getHttpManager();
    }
    /**
     * Create and return a new services HttpResolver initialized with the project name.
     * @returns {HttpResolver} Returns a new HttpResolver instance for the current project.
     */
    initResolver() {
        return new HttpResolver(this.getEnvironmentArgs().getProjectName());
    }
}
globalThis.RegisterClass("Io.Oidis.Services.Loader", Loader);
//# sourceMappingURL=Loader.js.map