/*! ******************************************************************************************************** *
 *
 * Copyright 2018-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { WebServiceClientEventType } from "./../../../../Io/Oidis/Commons/Enums/Events/WebServiceClientEventType.js";
import { EventsManager } from "./../../../../Io/Oidis/Commons/Events/EventsManager.js";
import { ExceptionsManager } from "./../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { WebSocketsClient } from "./../../../../Io/Oidis/Commons/WebServiceApi/Clients/WebSocketsClient.js";
import { EventType } from "./../../../../Io/Oidis/Gui/Enums/Events/EventType.js";
import { Resources } from "../DAO/Resources.js";
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { ILiveContentErrorPromise } from "../Interfaces/ILiveContentPromise.js";
import { Loader } from "../Loader.js";
import { LiveContentWrapper } from "../WebServiceApi/LiveContentWrapper.js";
import { WebServiceClientFactory } from "../WebServiceApi/WebServiceClientFactory.js";
/**
 * Abstract base class for all frontend connectors in the Oidis Framework.
 *
 * BaseConnector provides the foundational plumbing for frontend-to-backend RPC communication
 * via the LiveContent Protocol (LCP). Subclasses override getServerNamespaces() to map
 * client types to backend class namespaces, then use invoke() or asyncInvoke() to call
 * backend `@Extern` methods.
 *
 * Key responsibilities:
 * - Auto-detects the appropriate client type based on the runtime environment (desktop, hub, builder, etc.)
 * - Creates and manages the transport client (WebSocket, HTTP, AJAX) via WebServiceClientFactory
 * - Handles reconnection logic, error propagation, and connection loss scenarios
 * - Provides both callback-based (invoke) and Promise-based (asyncInvoke) invocation APIs
 * - Supports Hub agent forwarding via setAgent() for distributed deployments
 * - Offers progressWrapper() for long-running operations with progress reporting
 */
export class BaseConnector extends BaseObject {
    httpManager;
    options;
    serverClassName;
    client;
    propagateError;
    token;
    constructor($optionsOrReconnect, $serverConfigurationSource, $clientType) {
        super();
        if (ObjectValidator.IsEmptyOrNull($optionsOrReconnect) || ObjectValidator.IsObject($optionsOrReconnect)) {
            this.options = this.resolveDefaultOptions($optionsOrReconnect);
            if (this.options.reconnect) {
                this.options.maxReconnectCount = -1;
            }
        }
        else {
            this.options = this.resolveDefaultOptions({
                clientType: $clientType,
                serverConfigurationSource: $serverConfigurationSource
            });
            if (ObjectValidator.IsBoolean($optionsOrReconnect)) {
                this.options.maxReconnectCount = $optionsOrReconnect ? -1 : 0;
            }
            else {
                this.options.maxReconnectCount = $optionsOrReconnect;
            }
            if (this.options.maxReconnectCount !== 0) {
                this.options.reconnect = true;
            }
        }
        this.httpManager = Loader.getInstance().getHttpManager();
        this.propagateError = false;
        if (!this.options.suppressInit) {
            this.init();
        }
    }
    /**
     * @returns {string} Returns token used for communication protocol override.
     */
    get Token() {
        return this.token;
    }
    /**
     * @param {string} $value Set token used for communication protocol override.
     */
    set Token($value) {
        this.token = $value;
    }
    /**
     * @returns {number} Returns connector id suitable for events handling and connectors factory.
     */
    getId() {
        return this.client.getId();
    }
    /**
     * @returns {IWebServiceClientEvents} Returns events interface connected with connector instance.
     */
    getEvents() {
        return this.client.getEvents();
    }
    /**
     * @param {string} $name Specify name of remote agent which should be looked up by Oidis Hub.
     * @param {string|WebServiceConfiguration} [$serverConfigurationSource] Specify source for configuration of
     * server-client communication.
     * @returns {void}
     */
    setAgent($name, $serverConfigurationSource) {
        EventsManager.getInstanceSingleton().Clear("" + this.getId());
        this.client = null;
        if (!ObjectValidator.IsEmptyOrNull($serverConfigurationSource)) {
            if (ObjectValidator.IsString($serverConfigurationSource)) {
                if (!StringUtils.EndsWith($serverConfigurationSource, "/connector.config.jsonp")) {
                    $serverConfigurationSource += "/connector.config.jsonp";
                }
                this.options.serverConfigurationSource = $serverConfigurationSource;
            }
            else {
                this.options.serverConfigurationSource = $serverConfigurationSource;
            }
        }
        this.options.clientType = WebServiceClientType.FORWARD_CLIENT;
        this.init();
        this.setAgentName($name);
    }
    setAgentName($name) {
        if (!ObjectValidator.IsEmptyOrNull(this.getClient()) && (this.options.clientType === WebServiceClientType.FORWARD_CLIENT)) {
            this.getClient().AgentName($name);
        }
    }
    /**
     * Overrides method used for forwarding client processing on Hub.
     * Default value is "Io.Oidis.Hub.Utils.ConnectorHub.ForwardRequest".
     * @param $method Specify full namespace for method in class inherited from Io.Oidis.Hub.Primitives.AgentsRegister.
     * @returns {void}
     */
    setForwardingMethod($method) {
        const client = this.getClient();
        if (client.hasOwnProperty("forwardingMethod")) { // has ForwardingClient.forwardingMethod - field
            client.ForwardingMethod($method);
        }
    }
    /**
     * @param {boolean} $value Specify if connector should treat error as global exception or not.
     * @returns {boolean} Returns true if error should trows exception otherwise false.
     */
    ErrorPropagation($value) {
        return this.propagateError = Property.Boolean(this.propagateError, $value);
    }
    /**
     * Auto-detects the appropriate WebServiceClientType based on the current runtime environment.
     * Decision tree: localhost hosting -> HOST_CLIENT, JRE/plugin/connector -> DESKTOP_CONNECTOR,
     * server -> HUB_CONNECTOR, fallback -> BUILDER_CONNECTOR.
     * Subclasses can override to force a specific client type.
     * @returns {WebServiceClientType} The detected client type
     */
    getClientType() {
        let type;
        const request = this.httpManager.getRequest();
        if (!request.IsIdeaHost()) {
            if (request.IsLocalhostHosting()) {
                type = WebServiceClientType.HOST_CLIENT;
            }
            else if (request.IsJre() || request.IsPlugin() || request.IsConnector() || request.IsConnector(true)) {
                type = WebServiceClientType.DESKTOP_CONNECTOR;
            }
            else if (request.IsOnServer() || request.IsOnServer(true)) {
                type = WebServiceClientType.HUB_CONNECTOR;
            }
        }
        if (ObjectValidator.IsEmptyOrNull(type)) {
            type = WebServiceClientType.BUILDER_CONNECTOR;
        }
        return type;
    }
    /**
     * Returns a map of WebServiceClientType to backend class namespace.
     * Subclasses MUST override this to specify which backend class handles requests
     * for each deployment topology.
     * @returns {object} Map where keys are WebServiceClientType values and values are fully qualified backend class names
     */
    getServerNamespaces() {
        const namespaces = {};
        namespaces[WebServiceClientType.DESKTOP_CONNECTOR] = "";
        namespaces[WebServiceClientType.HUB_CONNECTOR] = "";
        namespaces[WebServiceClientType.BUILDER_CONNECTOR] = "";
        return namespaces;
    }
    /**
     * Initializes the transport client based on the resolved client type and server namespace.
     * Sets up reconnection handlers, error handlers, and connection loss detection.
     * Called automatically from constructor unless suppressInit option is set.
     * @throws {Error} If the client type has no namespace mapping in getServerNamespaces()
     */
    init() {
        const $serverConfigurationSource = this.options.serverConfigurationSource;
        const $clientType = this.options.clientType;
        const $maxReconnectCount = this.options.maxReconnectCount;
        const type = ObjectValidator.IsEmptyOrNull($clientType) ? this.getClientType() : $clientType;
        const namespaces = this.getServerNamespaces();
        if (namespaces.hasOwnProperty(type)) {
            this.serverClassName = namespaces[type];
            if (!ObjectValidator.IsEmptyOrNull(this.serverClassName)) {
                this.client = this.getWebServiceClientFactory().getClient(type, $serverConfigurationSource);
            }
        }
        if (!ObjectValidator.IsEmptyOrNull(this.client)) {
            if ($maxReconnectCount === -1) {
                const reconnectHandler = () => {
                    this.client.StartCommunication();
                };
                this.client.getEvents().OnClose(reconnectHandler);
                this.client.getEvents().OnTimeout(reconnectHandler);
            }
            else if ($maxReconnectCount >= 0 && this.client.IsMemberOf(WebSocketsClient)) {
                this.client.MaxReconnectsCount($maxReconnectCount);
            }
            const onErrorHandler = ($eventArgs) => {
                if (!this.propagateError && Loader.getInstance().getEnvironmentArgs().IsProductionMode()) {
                    ExceptionsManager.Throw(this.getClassName(), $eventArgs.Exception());
                }
                else {
                    LogIt.Warning($eventArgs.Exception().ToString("", false));
                }
            };
            if ((type === WebServiceClientType.REST_CONNECTOR || type === WebServiceClientType.HUB_CONNECTOR) &&
                $maxReconnectCount === 0) {
                const timeoutHandler = () => {
                    const data = new ArrayList();
                    data.Add(this.getClassName(), "Owner");
                    data.Add(this.client, "Client");
                    this.httpManager.ReloadTo("/ServerError/Http/ConnectionLost", data, true);
                };
                this.client.getEvents().OnTimeout(timeoutHandler);
                this.client.getEvents().OnError(($eventArgs) => {
                    this.httpManager.IsOnline(($status) => {
                        if ($status) {
                            onErrorHandler($eventArgs);
                        }
                        else {
                            timeoutHandler();
                        }
                    });
                });
            }
            else {
                this.client.getEvents().OnError(onErrorHandler);
            }
        }
        else {
            throw new Error(type + " is not defined as WebServiceClient in getServerNamespaces for instance of " + this.getClassName());
        }
    }
    getClient() {
        return this.client;
    }
    getServerNamespace() {
        return this.serverClassName;
    }
    /**
     * Invokes a backend `@Extern` method via LCP using the callback-based API.
     * Returns a chainable promise: .DataFormatter() -> .OnError() -> .Then()
     * @param $method Backend method name to invoke
     * @param $args Arguments to pass to the backend method
     * @returns {ILiveContentFormatterPromise} Chainable callback promise
     */
    invoke($method, ...$args) {
        return LiveContentWrapper.InvokeMethod.apply(LiveContentWrapper, // eslint-disable-line prefer-spread
        [{ client: this.client, className: this.serverClassName, name: $method, args: $args, token: this.Token }]);
    }
    /**
     * Invokes a backend `@Extern` method via LCP using native Promises.
     * Wraps invoke() in a Promise for async/await compatibility.
     * Can also accept a callback-returning function as the first argument for custom invocation patterns.
     * @param $method Backend method name (string) or a function returning ILiveContentFormatterPromise
     * @param $args Arguments to pass to the backend method
     * @returns {Promise<any>} Promise resolving with the backend return value
     */
    asyncInvoke($method, ...$args) {
        return new Promise(($resolve, $reject) => {
            try {
                let promise;
                if (ObjectValidator.IsString($method)) {
                    promise = this.invoke.apply(this, [$method].concat($args)); // eslint-disable-line prefer-spread
                }
                else {
                    promise = $method.apply(this, $args);
                }
                if (!ObjectValidator.IsEmptyOrNull(promise.OnError)) {
                    promise.OnError(($error) => {
                        const error = new Error($error.Message());
                        error.stack = $error.Exception().Stack();
                        $reject(error);
                    });
                }
                promise.Then((...$args) => {
                    if ($args.length === 1) {
                        $args = $args[0];
                    }
                    $resolve($args);
                });
            }
            catch (ex) {
                $reject(ex);
            }
        });
    }
    /**
     * Converts a Promise-based async method back to the callback-based ILiveContentFormatterPromise API.
     * Useful when a connector internally uses async/await but needs to expose the legacy callback chain.
     * @param $asyncMethod Promise to wrap in the callback API
     * @returns {ILiveContentFormatterPromise} Chainable callback promise bridging the async result
     */
    toSyncInvoke($asyncMethod) {
        const callbacks = {
            dataFormatter: ($data) => {
                return $data;
            },
            onError: null,
            then: null
        };
        const onErrorHandler = ($error) => {
            if (!ObjectValidator.IsEmptyOrNull(callbacks.onError)) {
                callbacks.onError($error);
            }
            else {
                throw $error;
            }
        };
        $asyncMethod
            .then(($output) => {
            try {
                $output = callbacks.dataFormatter($output);
                if (!ObjectValidator.IsEmptyOrNull(callbacks.then)) {
                    callbacks.then($output);
                }
            }
            catch (ex) {
                onErrorHandler(ex);
            }
        })
            .catch(($error) => {
            onErrorHandler($error);
        });
        return {
            DataFormatter($formatter) {
                callbacks.dataFormatter = $formatter;
                return callbacks;
            },
            OnError($callback) {
                callbacks.onError = $callback;
                return callbacks;
            },
            Then($callback) {
                callbacks.then = $callback;
            }
        };
    }
    errorHandler($callback, $error, $args) {
        if (ObjectValidator.IsEmptyOrNull($callback)) {
            EventsManager.getInstanceSingleton().FireEvent("" + this.getId(), WebServiceClientEventType.ON_ERROR, $error);
        }
        else {
            $callback.apply(this, [$error].concat($args));
        }
    }
    getWebServiceClientFactory() {
        return WebServiceClientFactory;
    }
    /**
     * Merges user-provided options with default connector options.
     * Subclasses can override to inject additional defaults (e.g. forced clientType).
     * @param $options User-provided options (may be partial or undefined)
     * @returns {IConnectorOptions} Fully resolved options with defaults applied
     */
    resolveDefaultOptions($options) {
        const defaultOptions = {
            maxReconnectCount: 0,
            reconnect: false,
            suppressInit: false
        };
        return Resources.Extend(defaultOptions, $options);
    }
    /**
     * Wraps a backend method invocation with progress reporting support.
     * Handles ON_CHANGE and ON_START events from the backend during long-running operations
     * (downloads, installations, etc.) and forwards them to the provided onChange callback.
     * @param $method Backend method name to invoke
     * @param $args Arguments to pass to the backend method
     * @param $onChange Callback receiving IFetchProgress updates during execution
     * @returns {Promise<TData>} Promise resolving with the final result
     */
    progressWrapper($method, $args, $onChange) {
        return new Promise(($resolve, $reject) => {
            try {
                const callbacks = {
                    onChange($data) {
                        // declare default callback
                    },
                    onError: null,
                    then($status) {
                        // declare default callback
                    }
                };
                LiveContentWrapper.InvokeMethod
                    .apply(this, [{ client: this.client, className: this.serverClassName, name: $method, args: $args, token: this.Token }])
                    .OnError(($error, ...$args) => {
                    this.errorHandler(callbacks.onError, $error, $args);
                })
                    .Then(($result) => {
                    if (!ObjectValidator.IsEmptyOrNull($result)) {
                        if (ObjectValidator.IsObject($result) && ObjectValidator.IsSet($result.type)) {
                            if ($result.type === EventType.ON_CHANGE || $result.type === EventType.ON_START) {
                                callbacks.onChange($result.data);
                            }
                            else {
                                callbacks.then($result);
                            }
                        }
                        else {
                            callbacks.then($result);
                        }
                    }
                });
                const promise = {
                    OnChange: ($callback) => {
                        callbacks.onChange = $callback;
                        return promise;
                    },
                    OnError: ($callback) => {
                        callbacks.onError = $callback;
                        return promise;
                    },
                    Then: ($callback) => {
                        callbacks.then = $callback;
                    }
                };
                if (!ObjectValidator.IsEmptyOrNull($onChange)) {
                    promise.OnChange($onChange);
                }
                if (!ObjectValidator.IsEmptyOrNull(promise.OnError)) {
                    promise.OnError(($error) => {
                        $reject(new Error($error.Message()));
                    });
                }
                promise.Then($resolve);
            }
            catch (ex) {
                $reject(ex);
            }
        });
    }
}
// generated-code-start
/* eslint-disable */
export const IConnectorOptions = globalThis.RegisterInterface(["clientType", "maxReconnectCount", "serverConfigurationSource", "suppressInit", "reconnect"]);
export const IFetchProgress = globalThis.RegisterInterface(["index", "from", "message", "warning"]);
export const IFetchProgressPromise = globalThis.RegisterInterface(["OnChange", "OnError", "Then"], ILiveContentErrorPromise);
globalThis.RegisterClass("Io.Oidis.Services.Primitives.BaseConnector", BaseConnector);
globalThis.RegisterClass("Io.Oidis.Services.Primitives.IConnectorOptions", IConnectorOptions);
globalThis.RegisterClass("Io.Oidis.Services.Primitives.IFetchProgress", IFetchProgress);
globalThis.RegisterClass("Io.Oidis.Services.Primitives.IFetchProgressPromise", IFetchProgressPromise);
//# sourceMappingURL=BaseConnector.js.map