import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { AgentsRegisterConnector } from "../Connectors/AgentsRegisterConnector.js";
import { Loader } from "../Loader.js";
import { WebServiceClientFactory } from "../WebServiceApi/WebServiceClientFactory.js";
export class AgentsRegisterConnectorTest extends RuntimeTestRunner {
    connector;
    before() {
        this.connector = new AgentsRegisterConnector();
        // this.connector = new AgentsRegisterConnector(true, "http://192.168.99.1:80/connector.config.jsonp");
        this.connector.getEvents().OnError(($args) => {
            Echo.Println($args.Message());
        });
        const client = WebServiceClientFactory.getClientById(this.connector.getId());
        client.getServerPath(($path) => {
            Echo.Printf("<b>Hub configuration:</b> uri - \"{0}\", server root - \"{1}\"", client.getServerUrl(), $path);
        });
    }
    AgentTest() {
        this.addButton("getAgentsList", () => {
            this.connector.getAgentsList()
                .Then(($list) => {
                Echo.Printf(JSON.stringify($list, null, 2));
            });
        });
        this.addButton("RegisterAgent", () => {
            this.connector.RegisterAgent({ name: "test-connector", platform: "unknown", domain: "none", version: "newest" })
                .OnMessage(($data) => {
                Echo.Printf("Message data: " + JSON.stringify($data));
            })
                .Then(($success) => {
                if ($success) {
                    Echo.Printf("Registration success");
                }
                else {
                    Echo.Printf("Registration failed");
                }
            });
        });
        this.addButton("RegisterAgentWithCredentials", () => {
            this.connector.RegisterAgent({
                credentials: {
                    authToken: "",
                    userName: "admin"
                },
                domain: "none-with-credentials",
                name: "test-connector-with-credentials",
                packageInfo: {
                    buildTime: new Date(Loader.getInstance().getEnvironmentArgs().getBuildTime()).getTime(),
                    name: Loader.getInstance().getEnvironmentArgs().getProjectName(),
                    platform: Loader.getInstance().getEnvironmentArgs().getPlatform(),
                    release: Loader.getInstance().getEnvironmentArgs().getReleaseName(),
                    version: Loader.getInstance().getEnvironmentArgs().getProjectVersion()
                },
                platform: "unknown",
                version: "newest"
            })
                .OnMessage(($data) => {
                Echo.Printf("Message with credentials data: " + JSON.stringify($data));
            })
                .Then(($success) => {
                if ($success) {
                    Echo.Printf("Registration with credentials succeed");
                }
                else {
                    Echo.Printf("Registration with credentials failed");
                }
            });
        });
        this.addButton("ForwardMessage", () => {
            this.connector.ForwardMessage(StringUtils.getSha1("none" + "unknown"), "some data")
                .Then(($status) => {
                Echo.Printf("Forward message status: " + $status);
            });
        });
        this.addButton("ForwardMessageWithCredentials", () => {
            this.connector.ForwardMessage(StringUtils.getSha1("none-with-credentials" + "unknown"), "some data")
                .Then(($status) => {
                Echo.Printf("Forward message with credentials status: " + $status);
            });
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.AgentsRegisterConnectorTest", AgentsRegisterConnectorTest);
//# sourceMappingURL=AgentsRegisterConnectorTest.js.map