import { TimeoutManager } from "./../../../../Io/Oidis/Commons/Events/TimeoutManager.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { ElementManager } from "./../../../../Io/Oidis/Gui/Utils/ElementManager.js";
import { FileSystemHandlerConnectorAsync, ShortcutRunStyle } from "../Connectors/FileSystemHandlerConnector.js";
export class AsyncFileSystemConnectorTest extends RuntimeTestRunner {
    fileSystem;
    resourceData;
    constructor() {
        super();
        // this.setMethodFilter("testExists");
    }
    async testExists() {
        this.assertOk(await this.fileSystem.Exists(this.resourceData + "/testCaseA.cmd"));
    }
    async testReadFile() {
        const data = await this.fileSystem.Read(this.resourceData + "/testCaseA.cmd");
        this.assertOk(!ObjectValidator.IsEmptyOrNull(data));
        Echo.Printf("<b>File content:</b>");
        Echo.PrintCode(data);
    }
    async testWriteFile() {
        this.assertOk(await this.fileSystem.Write(this.resourceData + "/test.txt", "some test data"));
        await this.fileSystem.Delete(this.resourceData + "/test.txt");
        const data = await (new Promise(($resolve) => {
            let data = "some long long long long long long long long long long long long long long long long test data\r\n";
            const manager = new TimeoutManager();
            const prepareData = () => {
                if (StringUtils.Length(data) < 1024 * 1024 * 5) {
                    data += data;
                    manager.Add(prepareData);
                }
                else {
                    $resolve(data);
                }
            };
            manager.Add(prepareData);
            manager.Execute();
        }));
        this.assertOk(await this.fileSystem.Write(this.resourceData + "/largeTest.txt", data));
        await this.fileSystem.Delete(this.resourceData + "/largeTest.txt");
    }
    async testRenameFile() {
        this.assertOk(await this.fileSystem.Rename(this.resourceData + "/testCaseA.cmd", this.resourceData + "/renamed.cmd"));
        this.assertOk(await this.fileSystem.Rename(this.resourceData + "/renamed.cmd", this.resourceData + "/testCaseA.cmd"));
    }
    async testCopyFile() {
        this.assertOk(await this.fileSystem.Copy(this.resourceData + "/archTest1.zip", this.resourceData + "/copiedArch.zip"));
        await this.fileSystem.Delete(this.resourceData + "/copiedArch.zip");
    }
    async testDeleteFile() {
        await this.fileSystem.Copy(this.resourceData + "/archTest1.zip", this.resourceData + "/copiedArch.zip");
        this.assertOk(await this.fileSystem.Exists(this.resourceData + "/copiedArch.zip"));
        this.assertOk(await this.fileSystem.Delete(this.resourceData + "/copiedArch.zip"));
    }
    async testGetTempPath() {
        const data = await this.fileSystem.getTempPath();
        this.assertOk(!ObjectValidator.IsEmptyOrNull(data));
        Echo.Printf("<b>Temp folder path:</b>");
        Echo.PrintCode(data);
    }
    async testCreateDirectory() {
        this.assertOk(await this.fileSystem.CreateDirectory(this.resourceData + "/TestFolder"));
        await this.fileSystem.Delete(this.resourceData + "/TestFolder");
    }
    async testDownload() {
        let connectionId;
        this.addButton("Stop download", () => {
            this.fileSystem.AbortDownload(connectionId).then(($status) => {
                if ($status) {
                    Echo.Printf("Download has been aborted.");
                }
                else {
                    Echo.Printf("Download abort has been failed.");
                }
            }).catch(($error) => {
                Echo.Printf("Download abort has been failed with error: {0}", $error.message);
            });
        });
        Echo.Printf("complete: {0}", (await this.fileSystem
            .Download("https://gitlab.com/oidis/io-oidis-builder/raw/develop/README.md", {
            onChange: ($args) => {
                Echo.Printf("change: {0}/{1}", $args.CurrentValue() + "", $args.RangeEnd() + "");
            },
            onStart: ($id) => {
                connectionId = $id;
                Echo.Printf("start");
            }
        })).tmpPath);
        const result = await this.fileSystem
            .Download({
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0"
            },
            streamOutput: true,
            url: "https://gitlab.com/oidis/io-oidis-builder/raw/develop/README.md"
        }, {
            onChange: ($args) => {
                Echo.Printf("change: {0}/{1}", $args.CurrentValue() + "", $args.RangeEnd() + "");
            },
            onStart: () => {
                Echo.Printf("start");
            }
        });
        Echo.Printf(result.headers);
        Echo.PrintCode(result.body);
        try {
            await this.fileSystem.Download({
                url: "https://bitbucket.org/unknown-for-test/io-oidis-builder/" +
                    "raw/f897ba2642a2a6512e8b2bbf1f0b44bfee75a474/README.md"
            });
            Echo.Printf("<b>Failed to call error handler for Download</b>");
        }
        catch (ex) {
            Echo.Printf("download error handler called with: {0}", ex.message);
        }
    }
    async testUnpack() {
        let path = await this.fileSystem.Unpack(this.resourceData + "/archTest1.zip");
        this.assertOk(!ObjectValidator.IsEmptyOrNull(path));
        if (!ObjectValidator.IsEmptyOrNull(path)) {
            Echo.Printf("<b>File unpacked to:</b>");
            Echo.Printf(path);
            await this.fileSystem.Delete(path);
        }
        path = await this.fileSystem.Unpack(this.resourceData + "/archTest2.tar.bz2");
        this.assertOk(!ObjectValidator.IsEmptyOrNull(path));
        if (!ObjectValidator.IsEmptyOrNull(path)) {
            Echo.Printf("<b>File unpacked to:</b>");
            Echo.Printf(path);
            await this.fileSystem.Delete(path);
        }
        try {
            /// TODO: use some corrupted archive file for more robust use-case
            await this.fileSystem.Unpack("*//*/*-+*$unknown");
            Echo.Printf("Failed to handle error for Unpack");
        }
        catch (ex) {
            Echo.Printf("Error handler called for Unpack with: {0}", ex.message);
        }
    }
    async testPack() {
        let path = await this.fileSystem.Pack(this.resourceData + "/archTest", { type: "zip" });
        this.assertOk(!ObjectValidator.IsEmptyOrNull(path));
        if (!ObjectValidator.IsEmptyOrNull(path)) {
            Echo.Printf("<b>File packed to:</b>");
            Echo.Printf(path);
            await this.fileSystem.Delete(path);
        }
        path = await this.fileSystem.Pack(this.resourceData + "/archTest", { type: "tar.bz2" });
        this.assertOk(!ObjectValidator.IsEmptyOrNull(path));
        if (!ObjectValidator.IsEmptyOrNull(path)) {
            Echo.Printf("<b>File packed to:</b>");
            Echo.Printf(path);
            await this.fileSystem.Delete(path);
        }
        try {
            await this.fileSystem.Pack(this.resourceData + "/unknown");
            Echo.Printf("Failed to handle error for Unpack");
        }
        catch (ex) {
            Echo.Printf("Error handler called for Unpack with: {0}", ex.message);
        }
    }
    async testCopyDir() {
        Echo.Println("Directory copy progress: <span id=\"testCopyDirBar\"></span>");
        this.assertOk(await this.fileSystem.Copy(this.resourceData, this.resourceData + "_Copy", ($args) => {
            ElementManager.setInnerHtml("testCopyDirBar", $args.CurrentValue() + "/" + $args.RangeEnd());
        }));
    }
    async testDeleteDir() {
        Echo.Println("Directory delete progress: <span id=\"testDeleteDirBar\"></span>");
        this.assertOk(await this.fileSystem
            .Delete(this.resourceData + "_Copy", ($args) => {
            ElementManager.setInnerHtml("testDeleteDirBar", $args.CurrentValue() + "/" + $args.RangeEnd());
        }));
    }
    async __IgnoretestCreateShortcut() {
        /// TODO: use correct parameters and limit it only for Windows
        this.assertOk(await this.fileSystem.CreateShortcut("source", "destination", {
            args: ["arg1", "arg2"],
            desc: "descritpion",
            hotkey: 5,
            icon: "path-to-icon",
            iconIndex: 3,
            runStyle: ShortcutRunStyle.NORMAL,
            workingDir: "working directory"
        }));
        try {
            await this.fileSystem.CreateShortcut("", "", {
                args: ["arg1", "arg2"],
                desc: "descritpion",
                hotkey: 5,
                icon: "path-to-icon",
                iconIndex: 3,
                runStyle: ShortcutRunStyle.NORMAL,
                workingDir: "working directory"
            });
            this.assertOk(false, "Failed to handle error for Create shortcut.");
        }
        catch (ex) {
            Echo.Printf("Error handler called for Create shortcut with: {0}", ex.message);
            this.assertOk(true);
        }
    }
    async __IgnoretestGetLinkTargetPath() {
        /// TODO: unsupported on backend
        const path = await this.fileSystem.getLinkTargetPath("D:/SystemTemp");
        this.assertOk(!ObjectValidator.IsEmptyOrNull(path));
        if (!ObjectValidator.IsEmptyOrNull(path)) {
            Echo.Println("real path: " + path);
        }
        else {
            Echo.Println("failed");
        }
    }
    async __IgnoretestGetNetworkMap() {
        /// TODO: unsupported on backend
        Echo.Printf(await this.fileSystem.getNetworkMap());
        Echo.Printf(await this.fileSystem.getNetworkMap(true));
    }
    async __IgnoretestGetRootFolders() {
        /// TODO: fatal error on backend
        Echo.Printf(await this.fileSystem.getPathMap());
    }
    async testGetDirectoryContent() {
        /// TODO: not working correctly...
        Echo.Printf(await this.fileSystem.getDirectoryContent("C:\\Windows"));
    }
    async __IgnoretestGetPathMap() {
        /// TODO: fatal error on backend
        Echo.Printf(await this.fileSystem.getPathMap("C:\\Program Files\\"));
    }
    async testExpand() {
        Echo.Printf(await this.fileSystem.Expand("C:/Windows/*"));
        Echo.Printf(await this.fileSystem.Expand(["C:/Program Files/*", "C:/Windows/*"]));
    }
    async __IgnoreAgentTest() {
        /// TODO: try automatic back-end registration to https://hub.oidis.io/connector.config.jsonp
        //        otherwise it requires locally running hub and can't be automated
        const connector = new FileSystemHandlerConnectorAsync();
        connector.setAgent("test-connector-win", "http://localhost:8090/connector.config.jsonp");
        this.assertOk(await connector.Exists(this.getAbsoluteRoot()));
    }
    before() {
        this.fileSystem = new FileSystemHandlerConnectorAsync();
        this.fileSystem.getEvents().OnError(($args) => {
            Echo.Println($args.Message());
        });
        this.resourceData = this.getAbsoluteRoot() + "/test/resource/data/Io/Oidis/Services/RuntimeTests";
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.AsyncFileSystemConnectorTest", AsyncFileSystemConnectorTest);
//# sourceMappingURL=AsyncFileSystemConnectorTest.js.map