import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { TerminalConnectorAsync } from "../Connectors/TerminalConnector.js";
import { WebServiceClientFactory } from "../WebServiceApi/WebServiceClientFactory.js";
export class AsyncTerminalConnectorTest extends RuntimeTestRunner {
    connector;
    async CmdSyncTest() {
        this.timeoutLimit(-1);
        let output = await this.connector
            .Execute("wui", ["--version"], ($data) => {
            Echo.Print($data);
        });
        Echo.Printf("out: {0}</br>err: {1}", output.stdout, output.stderr);
        this.assertOk(output.exitCode === 0, "Execution status (wui)");
        output = await this.connector
            .Execute("cmd", ["/c", "dir"], "../../", ($data) => {
            Echo.Print($data);
        });
        Echo.Printf("out: {0}</br>err: {1}", output.stdout, output.stderr);
        this.assertOk(output.exitCode === 0, "Execution status (cmd)");
        output = await this.connector
            .Execute("ping", ["127.0.0.1"], ($data) => {
            Echo.Print($data);
        });
        this.assertOk(output.exitCode === 0, "Execution status (ping)");
        output = await this.connector
            .Spawn("ping", ["127.0.0.1"], ($data) => {
            Echo.Print($data);
        });
        this.assertOk(output.exitCode === 0, "Execution status (ping spawn)");
        output = await this.connector
            .Spawn("wui", ["--version"], ($data) => {
            if ($data === ".") {
                Echo.Print($data);
            }
            else {
                Echo.Println($data);
            }
        });
        if (output.exitCode === 0) {
            await this.connector.Spawn("wui", ["--path"]);
        }
        output = await this.connector.Spawn("wui", ["--version"]);
        if (output.exitCode === 0) {
            Echo.Printf(output.stdout);
            output = await this.connector.Spawn("wui", ["--path"]);
            if (output.exitCode === 0) {
                Echo.Printf(output.stdout);
            }
        }
        this.addButton("run sync testCase*.cmd", () => {
            this.connector
                .Execute("testCaseA.cmd", [], this.getAbsoluteRoot() + "/test/resource/data/Io/Oidis/Services/RuntimeTests", ($data) => {
                Echo.Print($data);
            })
                .then(($result) => {
                Echo.Println("test call #1 - " + ($result.exitCode === 0 ? "succeed" : "failed"));
            })
                .catch((error) => {
                Echo.Println("test call #1 - failed: " + error.message);
            });
            this.connector
                .Execute("testCaseA.cmd", [], { cwd: this.getAbsoluteRoot() + "/test/resource/data/Io/Oidis/Services/RuntimeTests" }, ($data) => {
                Echo.Print($data);
            })
                .then(($result) => {
                Echo.Println("test call #2 - " + ($result.exitCode === 0 ? "succeed" : "failed"));
            })
                .catch((error) => {
                Echo.Println("test call #2 - failed: " + error.message);
            });
            this.connector
                .Execute("testCaseA.cmd", [], {
                env: {
                    PATH: this.getAbsoluteRoot() + "/test/resource/data/Io/Oidis/Services/RuntimeTests;%PATH%"
                }
            }, ($data) => {
                Echo.Print($data);
            })
                .then(($result) => {
                Echo.Println("test call #3 - " + ($result.exitCode === 0 ? "succeed" : "failed"));
            })
                .catch((error) => {
                Echo.Println("test call #3 - failed: " + error.message);
            });
        });
    }
    CmdAsyncTest() {
        this.addButton("get async WUI Info", () => {
            this.connector.Spawn("wui", ["--version"])
                .then(($result) => {
                Echo.Println("async: spawn wui --version - " + ($result.exitCode === 0 ? "succeed" : "failed"));
            })
                .catch((error) => {
                Echo.Println("async: spawn wui --version - failed: " + error.message);
            });
            this.connector.Spawn("wui", ["--path"])
                .then(($result) => {
                Echo.Println("async: spawn wui --path - " + ($result.exitCode === 0 ? "succeed" : "failed"));
            })
                .catch((error) => {
                Echo.Println("async: spawn wui --path - failed: " + error.message);
            });
        });
        this.addButton("test spawn async (ping 127.0.0.1 and ping 8.8.8.8)", () => {
            this.connector
                .Spawn("ping", ["127.0.0.1"], ($data) => {
                Echo.Println($data);
            })
                .then(($result) => {
                Echo.Println("ping 127.0.0.1 - " + ($result.exitCode === 0 ? "succeed" : "failed"));
            })
                .catch((error) => {
                Echo.Println("ping 127.0.0.1 - failed: " + error.message);
            });
            this.connector
                .Spawn("ping", ["8.8.8.8"], ($data) => {
                Echo.Println($data);
            })
                .then(($result) => {
                Echo.Println("ping 8.8.8.8 - " + ($result.exitCode === 0 ? "succeed" : "failed"));
            })
                .catch((error) => {
                Echo.Println("ping 8.8.8.8 - failed: " + error.message);
            });
        });
        this.addButton("test spawn async (test *.cmd)", () => {
            this.connector
                .Spawn("testCaseA.cmd", [], "./test/resource/data/Io/Oidis/Services/RuntimeTests", ($data) => {
                Echo.Println($data);
            })
                .then(($result) => {
                Echo.Println("test call #1 - " + ($result.exitCode === 0 ? "succeed" : "failed"));
            })
                .catch((error) => {
                Echo.Println("test call #1 - failed: " + error.message);
            });
            this.connector
                .Spawn("testCaseB.cmd", [], "./test/resource/data/Io/Oidis/Services/RuntimeTests", ($data) => {
                Echo.Println($data);
            })
                .then(($result) => {
                Echo.Println("test call #2 - " + ($result.exitCode === 0 ? "succeed" : "failed"));
            })
                .catch((error) => {
                Echo.Println("test call #2 - failed: " + error.message);
            });
        });
    }
    OpenTest() {
        this.addButton("open executable", async () => {
            await this.connector.Open("notepad.exe");
        });
    }
    ElevateTest() {
        this.addButton("elevate process", async () => {
            await this.connector.Elevate("AT");
        });
    }
    __IgnoreAgentTest() {
        const connector = new TerminalConnectorAsync();
        connector.setAgent("test-connector-win", "https://localhost.wuiframework.com/connector.config.jsonp");
        this.addButton("Forward to agent", async () => {
            this.assertOk((await connector.Spawn("wui", ["path"], ($data) => {
                Echo.Printf($data);
            })).exitCode === 0);
        });
    }
    before() {
        this.connector = new TerminalConnectorAsync();
        this.connector.getEvents().OnError(($args) => {
            Echo.Println($args.Message());
        });
        const client = WebServiceClientFactory.getClientById(this.connector.getId());
        return ($done) => {
            client.getServerPath(($path) => {
                Echo.Printf("<b>Server configuration:</b> uri - \"{0}\", server root - \"{1}\"", client.getServerUrl(), $path);
                $done();
            });
        };
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.AsyncTerminalConnectorTest", AsyncTerminalConnectorTest);
//# sourceMappingURL=AsyncTerminalConnectorTest.js.map