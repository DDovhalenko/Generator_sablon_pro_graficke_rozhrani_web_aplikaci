/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { COMproxyConnector } from "../Connectors/COMproxyConnector.js";
import { LiveContentArgumentType } from "../Enums/LiveContentArgumentType.js";
export class COMproxyConnectorTest extends RuntimeTestRunner {
    instanceId;
    testCreateInstanceFromCLSID() {
        const service = new COMproxyConnector();
        this.addButton("Create FreeMASTER instance", () => {
            service
                .CreateInstanceFromCLSID("{48A185F1-FFDB-11D3-80E3-00C04F176153}")
                .Then(($instanceId) => {
                this.instanceId = $instanceId;
                Echo.Printf("Instance id: " + $instanceId);
            });
        });
    }
    testCreateInstanceFromCLSIDas() {
        const service = new COMproxyConnector();
        this.addButton("Create named FreeMASTER instance", () => {
            service
                .CreateInstanceFromCLSIDas("{48A185F1-FFDB-11D3-80E3-00C04F176153}", "FM")
                .Then(($instanceId) => {
                this.instanceId = $instanceId;
                Echo.Printf("Instance id: " + $instanceId);
            });
        });
    }
    testCreateInstanceFromProgID() {
        const service = new COMproxyConnector();
        this.addButton("Create MCB.PCM instance", () => {
            service
                .CreateInstanceFromProgID("MCB.PCM")
                .Then(($instanceId) => {
                this.instanceId = $instanceId;
                Echo.Printf("Instance id: " + $instanceId);
            });
        });
    }
    testCreateInstanceFromProgIDas() {
        const service = new COMproxyConnector();
        this.addButton("Create named MCB.PCM instance", () => {
            service
                .CreateInstanceFromProgIDas("MCB.PCM", "FM")
                .Then(($instanceId) => {
                this.instanceId = $instanceId;
                Echo.Printf("Instance id: " + $instanceId);
            });
        });
    }
    testGetFreeMASTERversion() {
        const service = new COMproxyConnector();
        this.addButton("Get FreeMASTER version", () => {
            service
                .InvokeMethod(this.instanceId, "GetAppVersion", LiveContentArgumentType.OUT_STRING)
                .Then(($versionNumber, $versionString) => {
                Echo.Printf("FreeMASTER version: " + $versionString + "[" + $versionNumber + "]");
            });
        });
    }
    testInstanceExists() {
        const service = new COMproxyConnector();
        this.addButton("Named instance exists", () => {
            service
                .Exists("FM")
                .Then(($status) => {
                if ($status) {
                    Echo.Printf("instance exists");
                }
                else {
                    Echo.Printf("instance does not exists");
                }
            });
        });
    }
    testDestroyInstance() {
        const service = new COMproxyConnector();
        this.addButton("Destroy current instance", () => {
            service.Destroy(this.instanceId);
        });
    }
    testTestEvent() {
        const service = new COMproxyConnector();
        let registered = false;
        this.addButton("Test event", () => {
            if (!registered) {
                service.AddEventHandler(this.instanceId, "OnCommPortStateChanged", 0x1002, (...$args) => {
                    Echo.Printf("OnCommPortStateChanged args: {0}", $args);
                });
                service.AddEventHandler(this.instanceId, "OnTestEv", 0x1001, (...$args) => {
                    Echo.Printf("OnTestEv args: {0}", $args);
                });
                registered = true;
            }
            const callback = ($returnValue, $instanceID, $eventName) => {
                Echo.Printf("event fired: " + $instanceID + ", " + $eventName);
            };
            service.TestEvent(this.instanceId, 0x1002).Then(callback);
            service.TestEvent(this.instanceId, 0x1001).Then(callback);
        });
    }
    testTearDown() {
        const service = new COMproxyConnector();
        this.addButton("Tear down", () => {
            service
                .TearDown()
                .Then(($status) => {
                if ($status) {
                    Echo.Printf("session destroyed");
                }
                else {
                    Echo.Printf("failed to destroy session");
                }
            });
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.COMproxyConnectorTest", COMproxyConnectorTest);
//# sourceMappingURL=COMproxyConnectorTest.js.map