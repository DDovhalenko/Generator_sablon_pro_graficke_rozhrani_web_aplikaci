import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { CertsConnector } from "../Connectors/CertsConnector.js";
export class CertsConnectorTest extends RuntimeTestRunner {
    connector;
    before() {
        this.connector = new CertsConnector();
        this.connector.getEvents().OnError(($args) => {
            Echo.Println($args.Message());
        });
    }
    testGetCertsForLocalhost() {
        return ($done) => {
            this.connector
                .getCertsFor("localhost.oidis.io")
                .Then(($cert, $key) => {
                this.assertEquals(ObjectValidator.IsEmptyOrNull($cert), false);
                this.assertEquals(ObjectValidator.IsEmptyOrNull($key), false);
                $done();
            });
        };
    }
    testGetCertsFromBlackList() {
        return ($done) => {
            this.connector
                .getCertsFor("www.oidis.io")
                .Then(($cert, $key) => {
                this.assertEquals(ObjectValidator.IsEmptyOrNull($cert), true);
                this.assertEquals(ObjectValidator.IsEmptyOrNull($key), true);
                $done();
            });
        };
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.CertsConnectorTest", CertsConnectorTest);
//# sourceMappingURL=CertsConnectorTest.js.map