import { Convert } from "./../../../../Io/Oidis/Commons/Utils/Convert.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { WindowManager } from "./../../../../Io/Oidis/Gui/Utils/WindowManager.js";
import { FFIProxyConnector } from "../Connectors/FFIProxyConnector.js";
import { FileSystemHandlerConnector } from "../Connectors/FileSystemHandlerConnector.js";
import { TerminalConnector } from "../Connectors/TerminalConnector.js";
import { LiveContentArgumentType } from "../Enums/LiveContentArgumentType.js";
import { WebServiceClientFactory } from "../WebServiceApi/WebServiceClientFactory.js";
export class FFIProxyConnectorTest extends RuntimeTestRunner {
    service = new FFIProxyConnector();
    targetRoot;
    testResourceRoot;
    libraryPath;
    generator;
    constructor() {
        super();
        // this.setMethodFilter("testVarious");
    }
    testLoadLibraryFromPath() {
        this.addButton("Load Library from absolute path", () => {
            this.service
                .Load(this.libraryPath)
                .Then(($returnValue, $libPath) => {
                if ($returnValue) {
                    Echo.Printf("Library loaded from: {0}", $libPath);
                }
                else {
                    Echo.Printf("Failed to load the library");
                }
            });
        });
    }
    testReturn() {
        return ($done) => {
            const invokes = [];
            let index = 0;
            const getNextInvoke = () => {
                if (index < invokes.length) {
                    Echo.Println("invoke " + (index + 1) + "/" + invokes.length);
                    invokes[index]();
                    index++;
                }
                else {
                    $done();
                }
            };
            invokes.push(() => {
                // #1
                this.service
                    .InvokeMethod("ReturnInt", LiveContentArgumentType.RETURN_INT)
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, 23);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #2
                this.service
                    .InvokeMethod("ReturnBool", LiveContentArgumentType.RETURN_BOOLEAN)
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, true);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #3
                this.service
                    .InvokeMethod("ReturnFloat", LiveContentArgumentType.RETURN_FLOAT)
                    .Then(($returnValue) => {
                    this.assertEquals(Convert.ToFixed($returnValue, 12), 16.299999237061);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #4
                this.service
                    .InvokeMethod("ReturnDouble", LiveContentArgumentType.RETURN_DOUBLE)
                    .Then(($returnValue) => {
                    this.assertEquals(Convert.ToFixed($returnValue, 12), 33.44);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #5
                this.service
                    .InvokeMethod("ReturnString", LiveContentArgumentType.RETURN_STRING)
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, "returned string");
                    getNextInvoke();
                });
            });
            this.service
                .Load(this.libraryPath)
                .Then(($returnValue, $libPath) => {
                if ($returnValue) {
                    Echo.Printf("Library loaded from: {0}", $libPath);
                    getNextInvoke();
                }
                else {
                    Echo.Printf("Failed to load the library");
                    $done();
                }
            });
        };
    }
    testInputArgs() {
        return ($done) => {
            const invokes = [];
            let index = 0;
            const getNextInvoke = () => {
                if (index < invokes.length) {
                    Echo.Println("invoke " + (index + 1) + "/" + invokes.length);
                    invokes[index]();
                    index++;
                }
                else {
                    $done();
                }
            };
            invokes.push(() => {
                // #1
                this.service
                    .InvokeMethod("CallWithEmpty", LiveContentArgumentType.RETURN_BOOLEAN)
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, true);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #2
                this.service
                    .InvokeMethod("CallWithInt", LiveContentArgumentType.RETURN_BOOLEAN, 123)
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, true);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #3
                this.service
                    .InvokeMethod("CallWithBool", LiveContentArgumentType.RETURN_BOOLEAN, true)
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, true);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #4
                this.service
                    .InvokeMethod("CallWithFloat", LiveContentArgumentType.RETURN_BOOLEAN, {
                    type: LiveContentArgumentType.IN_FLOAT,
                    value: 3.14
                })
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, true);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #5
                this.service
                    .InvokeMethod("CallWithDouble", LiveContentArgumentType.RETURN_BOOLEAN, 6.28)
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, true);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #6
                this.service
                    .InvokeMethod("CallWithString", LiveContentArgumentType.RETURN_BOOLEAN, {
                    type: LiveContentArgumentType.IN_STRING,
                    value: "hello world"
                })
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, true);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #7
                this.service
                    .InvokeMethod("CallWithString", LiveContentArgumentType.RETURN_BOOLEAN, "hello world")
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, true);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #8
                this.service
                    .InvokeMethod("CallWithStruct", LiveContentArgumentType.RETURN_BOOLEAN, {
                    type: LiveContentArgumentType.IN_STRUCT,
                    value: {
                        fields: {
                            a: 234,
                            b: true,
                            c: "struct string"
                        },
                        typeName: "TestStruct"
                    }
                })
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, true);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #9
                this.service
                    .InvokeMethod("CallWithIntArray", LiveContentArgumentType.RETURN_BOOLEAN, {
                    type: LiveContentArgumentType.IN_ARRAY,
                    value: {
                        items: [301, 303, 305, 407, 409, 502, 504, 806, 708, 900],
                        typeName: LiveContentArgumentType.IN_INT
                    }
                }, 10)
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, true);
                    this.service
                        .InvokeMethod("CallWithIntArray", LiveContentArgumentType.RETURN_BOOLEAN, {
                        type: LiveContentArgumentType.IN_ARRAY,
                        value: {
                            items: [301, 303, 305, 407, 409, 502, 504, 806, 708, 900],
                            typeName: LiveContentArgumentType.IN_INT
                        }
                    }, 10)
                        .Then(($returnValue) => {
                        this.assertEquals($returnValue, true);
                        getNextInvoke();
                    });
                });
            });
            invokes.push(() => {
                // #10
                this.service
                    .InvokeMethod("CallWithBuffer", LiveContentArgumentType.RETURN_BOOLEAN, {
                    type: LiveContentArgumentType.IN_BUFFER,
                    value: [0, 1, 2, 3, 4, 5, 6, 7]
                }, 8)
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, true);
                    getNextInvoke();
                });
            });
            this.service
                .Load(this.libraryPath)
                .Then(($returnValue, $libPath) => {
                if ($returnValue) {
                    Echo.Printf("Library loaded from: {0}", $libPath);
                    getNextInvoke();
                }
                else {
                    Echo.Printf("Failed to load the library");
                    $done();
                }
            });
        };
    }
    testOutputArgs() {
        return ($done) => {
            const invokes = [];
            let index = 0;
            const getNextInvoke = () => {
                if (index < invokes.length) {
                    Echo.Println("invoke " + (index + 1) + "/" + invokes.length);
                    invokes[index]();
                    index++;
                }
                else {
                    $done();
                }
            };
            invokes.push(() => {
                // #1
                this.service
                    .InvokeMethod("output_args_int", LiveContentArgumentType.RETURN_VOID, {
                    type: LiveContentArgumentType.OUT_INT,
                    value: 111
                })
                    .Then(($returnValue, $output) => {
                    this.assertEquals($returnValue, null);
                    this.assertEquals($output, 15);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #2
                this.service
                    .InvokeMethod("output_args_char", LiveContentArgumentType.RETURN_VOID, {
                    type: LiveContentArgumentType.OUT_STRING,
                    value: "hello world"
                })
                    .Then(($returnValue, $output) => {
                    this.assertEquals($returnValue, null);
                    this.assertEquals($output, "some text");
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #3
                this.service
                    .InvokeMethod("output_args_char", LiveContentArgumentType.RETURN_VOID, {
                    type: LiveContentArgumentType.OUT_STRING,
                    value: 10
                })
                    .Then(($returnValue, $output) => {
                    this.assertEquals($returnValue, null);
                    this.assertEquals($output, "some text");
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #4
                this.service
                    .InvokeMethod("output_args_float", LiveContentArgumentType.RETURN_VOID, {
                    type: LiveContentArgumentType.OUT_FLOAT,
                    value: 1.1
                })
                    .Then(($returnValue, $data) => {
                    this.assertEquals($returnValue, null);
                    this.assertEquals(Convert.ToFixed($data, 12), 12.119999885559);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #5
                this.service
                    .InvokeMethod("output_args_double", LiveContentArgumentType.RETURN_VOID, {
                    type: LiveContentArgumentType.OUT_DOUBLE,
                    value: 6.66
                })
                    .Then(($returnValue, $data) => {
                    this.assertEquals($returnValue, null);
                    this.assertEquals(Convert.ToFixed($data, 12), 56.119998931885);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #6
                this.service
                    .InvokeMethod("output_args_bool", LiveContentArgumentType.RETURN_VOID, {
                    type: LiveContentArgumentType.OUT_BOOLEAN,
                    value: true
                })
                    .Then(($returnValue, $data) => {
                    this.assertEquals($returnValue, null);
                    this.assertEquals($data, false);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #7
                this.service
                    .InvokeMethod("output_args_buffer", LiveContentArgumentType.RETURN_VOID, {
                    type: LiveContentArgumentType.OUT_BUFFER,
                    value: 20
                })
                    .Then(($returnValue, $data) => {
                    this.assertEquals($returnValue, null);
                    this.assertEquals($data.type, "Buffer");
                    this.assertDeepEqual($data.data, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]);
                    getNextInvoke();
                });
            });
            this.service
                .Load(this.libraryPath)
                .Then(($returnValue, $libPath) => {
                if ($returnValue) {
                    Echo.Printf("Library loaded from: {0}", $libPath);
                    getNextInvoke();
                }
                else {
                    Echo.Printf("Failed to load the library");
                    $done();
                }
            });
        };
    }
    testVarious() {
        return ($done) => {
            const invokes = [];
            let index = 0;
            const getNextInvoke = () => {
                if (index < invokes.length) {
                    Echo.Println("invoke " + (index + 1) + "/" + invokes.length);
                    invokes[index]();
                    index++;
                }
                else {
                    $done();
                }
            };
            invokes.push(() => {
                // #1
                this.service
                    .InvokeMethod("int_func_int_bool", LiveContentArgumentType.RETURN_INT, 43, true)
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, 29);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #2
                this.service
                    .InvokeMethod("int_func_bool_int", LiveContentArgumentType.RETURN_INT, true, 44)
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, 23);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #3
                this.service
                    .InvokeMethod("add_input_ints", LiveContentArgumentType.RETURN_INT, 11, 21)
                    .Then(($returnValue) => {
                    this.assertEquals($returnValue, 32);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #4
                this.service
                    .InvokeMethod("output_args_int_bool_float", LiveContentArgumentType.RETURN_INT, {
                    type: LiveContentArgumentType.OUT_INT,
                    value: 11
                }, {
                    type: LiveContentArgumentType.OUT_BOOLEAN,
                    value: true
                }, {
                    type: LiveContentArgumentType.OUT_FLOAT,
                    value: 36.98
                })
                    .Then(($returnValue, $intOut, $boolOut, $floatOut) => {
                    this.assertEquals($returnValue, 3);
                    this.assertEquals($intOut, 12);
                    this.assertEquals($boolOut, false);
                    this.assertEquals(Convert.ToFixed($floatOut, 12), 3.140000104904);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #5
                this.service
                    .InvokeMethod("input_int_double_output_bool_int_input_string", LiveContentArgumentType.RETURN_INT, 78, {
                    value: 79.5
                }, {
                    type: LiveContentArgumentType.OUT_BOOLEAN,
                    value: true
                }, {
                    type: LiveContentArgumentType.OUT_INT,
                    value: 17
                }, {
                    type: LiveContentArgumentType.IN_STRING,
                    value: "last one"
                })
                    .Then(($returnValue, $boolOut, $intOut) => {
                    this.assertEquals($returnValue, 8);
                    this.assertEquals($boolOut, false);
                    this.assertEquals($intOut, 432);
                    getNextInvoke();
                });
            });
            invokes.push(() => {
                // #5
                this.service
                    .InvokeMethod("append_string", LiveContentArgumentType.RETURN_INT, "hello ", "world", { type: LiveContentArgumentType.OUT_STRING, value: 20 })
                    .Then(($returnValue, $output) => {
                    this.assertEquals($returnValue, 11);
                    this.assertEquals($output, "hello world");
                    getNextInvoke();
                });
            });
            this.service
                .Load(this.libraryPath)
                .Then(($returnValue, $libPath) => {
                if ($returnValue) {
                    Echo.Printf("Library loaded from: {0}", $libPath);
                    getNextInvoke();
                }
                else {
                    Echo.Printf("Failed to load the library");
                    $done();
                }
            });
        };
    }
    testBenchmark() {
        const iterations = 1000;
        const delay = 0; // ms
        // const iterations : number = 3000;
        // const delay : number = 50; // ms
        this.timeoutLimit(100000);
        return ($done) => {
            let index = 0;
            const makeCall = ($callback) => {
                if (index % 100 === 0) {
                    Echo.Println(".");
                    WindowManager.ScrollToBottom();
                }
                else {
                    Echo.Print(".");
                }
                this.service
                    .InvokeMethod("CallWithEmpty", LiveContentArgumentType.RETURN_VOID)
                    .Then(() => {
                    index++;
                    if (index > iterations) {
                        $callback();
                    }
                    else if (delay > 0) {
                        setTimeout(() => {
                            makeCall($callback);
                        }, delay);
                    }
                    else {
                        makeCall($callback);
                    }
                });
            };
            this.service
                .Load(this.libraryPath)
                .Then(($returnValue, $libPath) => {
                if ($returnValue) {
                    Echo.Printf("Library loaded from: {0}", $libPath);
                    const start = new Date().getTime();
                    makeCall(() => {
                        const end = Convert.TimeToSeconds(new Date().getTime() - start);
                        Echo.Printf("Invoked {0} iterations in {1}s with average {2}ms", iterations + "", end + "", (end / iterations * 1000) + "");
                        $done();
                    });
                }
                else {
                    Echo.Printf("Failed to load the library");
                    $done();
                }
            });
        };
    }
    before() {
        this.timeoutLimit(100000);
        return ($done) => {
            const buildLib = () => {
                const terminal = new TerminalConnector(true);
                const fileSystem = new FileSystemHandlerConnector(true);
                this.testResourceRoot = this.targetRoot + "/test/resource/data/Io/Oidis/Services/RuntimeTests/FFIProxyLib";
                fileSystem.getTempPath()
                    .Then(($tmpPath) => {
                    if (!StringUtils.StartsWith($tmpPath, "/")) {
                        Echo.Print("Identified as windows platform...");
                        this.generator = "MinGW Makefiles";
                        this.libraryPath = "libFFIProxyLib.dll";
                    }
                    else {
                        Echo.Print("Identified as posix platform...");
                        this.generator = "Unix Makefiles";
                        this.libraryPath = "libFFIProxyLib.so";
                    }
                    this.libraryPath = this.testResourceRoot + "/build/" + this.libraryPath;
                    fileSystem
                        .Exists(this.libraryPath)
                        .Then(($status) => {
                        if ($status) {
                            Echo.Printf("Library already exists, build skipped.");
                            $done();
                        }
                        else {
                            fileSystem
                                .CreateDirectory(this.testResourceRoot + "/build_cache")
                                .Then(($status) => {
                                if ($status) {
                                    terminal
                                        .Spawn("wui", ["--", "cmake", "-G", "\"" + this.generator + "\"", ".."], this.testResourceRoot + "/build_cache")
                                        .Then(($exitCode, $stdOut, $stdErr) => {
                                        if ($exitCode !== 0) {
                                            Echo.Printf("Build failed:\n" + $stdOut + $stdErr);
                                        }
                                        else {
                                            terminal
                                                .Spawn("wui", ["--", "cmake", "--build", "."], this.testResourceRoot + "/build_cache")
                                                .Then(($exitCode, $stdOut, $stdErr) => {
                                                if ($exitCode === 0) {
                                                    $done();
                                                }
                                                else {
                                                    Echo.Printf("Can not build library:\n" + $stdOut + $stdErr);
                                                }
                                            });
                                        }
                                    });
                                }
                                else {
                                    Echo.Printf("Failed to prepare build cache for test resource.");
                                }
                            });
                        }
                    });
                });
            };
            if (this.getRequest().IsConnector()) {
                WebServiceClientFactory.getClientById(this.service.getId()).getServerPath(($path) => {
                    this.targetRoot = StringUtils.Replace($path, "\\", "/");
                    buildLib();
                });
            }
            else {
                this.targetRoot = StringUtils.Remove(this.getRequest().getHostUrl(), "file:///", "file://", "/index.html");
                buildLib();
            }
        };
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.FFIProxyConnectorTest", FFIProxyConnectorTest);
//# sourceMappingURL=FFIProxyConnectorTest.js.map