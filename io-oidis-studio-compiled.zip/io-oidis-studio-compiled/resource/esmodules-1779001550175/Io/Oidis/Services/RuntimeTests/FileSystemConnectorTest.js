import { TimeoutManager } from "./../../../../Io/Oidis/Commons/Events/TimeoutManager.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { ElementManager } from "./../../../../Io/Oidis/Gui/Utils/ElementManager.js";
import { FileSystemHandlerConnector, ShortcutRunStyle } from "../Connectors/FileSystemHandlerConnector.js";
export class FileSystemConnectorTest extends RuntimeTestRunner {
    fileSystem;
    resourceData;
    before() {
        this.fileSystem = new FileSystemHandlerConnector();
        this.fileSystem.getEvents().OnError(($args) => {
            Echo.Println($args.Message());
        });
        this.resourceData = this.getAbsoluteRoot() + "/test/resource/data/Io/Oidis/Services/RuntimeTests";
    }
    testExists() {
        this.addButton("File exists", () => {
            this.fileSystem
                .Exists(this.resourceData + "/testCaseA.cmd")
                .Then(($success) => {
                if ($success) {
                    Echo.Printf("<b>File has been found</b>");
                }
                else {
                    Echo.Printf("<b>File does not exist</b>");
                }
            });
        });
    }
    testReadFile() {
        this.addButton("Read file", () => {
            this.fileSystem
                .Read(this.resourceData + "/testCaseA.cmd")
                .Then(($data) => {
                Echo.Printf("<b>File content:</b>");
                Echo.PrintCode($data);
            });
        });
    }
    testWriteFile() {
        this.addButton("Write file", () => {
            this.fileSystem
                .Write(this.resourceData + "/test.txt", "some test data")
                .Then(($success) => {
                if ($success) {
                    Echo.Printf("<b>File has been written successfully</b>");
                    this.fileSystem
                        .Delete(this.resourceData + "/test.txt")
                        .Then(($success) => {
                        Echo.Printf("<b>File has been deleted</b>");
                    });
                }
                else {
                    Echo.Printf("<b>File write has failed</b>");
                }
            });
        });
        this.addButton("Write large file", () => {
            let data = "some long long long long long long long long long long long long long long long long test data\r\n";
            const manager = new TimeoutManager();
            const prepareData = () => {
                if (StringUtils.Length(data) < 1024 * 1024 * 5) {
                    data += data;
                    manager.Add(prepareData);
                }
                else {
                    this.fileSystem
                        .Write(this.resourceData + "/largeTest.txt", data)
                        .Then(($success) => {
                        if ($success) {
                            Echo.Printf("<b>File has been written successfully</b>");
                        }
                        else {
                            Echo.Printf("<b>File write has failed</b>");
                        }
                    });
                }
            };
            manager.Add(prepareData);
            manager.Execute();
        });
    }
    testRenameFile() {
        this.addButton("Rename file", () => {
            this.fileSystem
                .Rename(this.resourceData + "/testCaseA.cmd", this.resourceData + "/renamed.cmd")
                .Then(($success) => {
                if ($success) {
                    Echo.Printf("<b>File has been renamed successfully</b>");
                    this.fileSystem
                        .Rename(this.resourceData + "/renamed.cmd", this.resourceData + "/testCaseA.cmd")
                        .Then(($success) => {
                        if ($success) {
                            Echo.Printf("<b>File has been renamed back</b>");
                        }
                        else {
                            Echo.Printf("<b>File renamed (back) has failed</b>");
                        }
                    });
                }
                else {
                    Echo.Printf("<b>File renamed has failed</b>");
                }
            });
        });
    }
    testCopyFile() {
        this.addButton("Copy file", () => {
            this.fileSystem
                .Copy(this.resourceData + "/archTest1.zip", this.resourceData + "/copiedArch.zip")
                .Then(($success) => {
                if ($success) {
                    Echo.Printf("<b>File has been copied successfully</b>");
                }
                else {
                    Echo.Printf("<b>File copy has failed</b>");
                }
            });
        });
    }
    testDeleteFile() {
        this.addButton("Delete file", () => {
            this.fileSystem.Exists(this.resourceData + "/copiedArch.zip").Then(($status) => {
                if ($status) {
                    this.fileSystem
                        .Delete(this.resourceData + "/copiedArch.zip")
                        .Then(($success) => {
                        if ($success) {
                            Echo.Printf("<b>File has been deleted successfully</b>");
                        }
                        else {
                            Echo.Printf("<b>File delete has failed</b>");
                        }
                    });
                }
                else {
                    Echo.Printf("<b>Click on Copy file before.</b>");
                }
            });
        });
    }
    testGetTempPath() {
        this.addButton("Get Temp path location", () => {
            this.fileSystem
                .getTempPath()
                .Then(($data) => {
                Echo.Printf("<b>Temp folder path:</b>");
                Echo.PrintCode($data);
            });
        });
    }
    testCreateDirectory() {
        this.addButton("Create Dir", () => {
            this.fileSystem
                .CreateDirectory(this.resourceData + "/TestFolder")
                .Then(($success) => {
                if ($success) {
                    Echo.Printf("<b>Folder has been created successfully</b>");
                    this.fileSystem
                        .Delete(this.resourceData + "/TestFolder")
                        .Then(($success) => {
                        if ($success) {
                            Echo.Printf("<b>Created folder has been deleted</b>");
                        }
                        else {
                            Echo.Printf("<b>Created folder can not be deleted</b>");
                        }
                    });
                }
                else {
                    Echo.Printf("<b>Folder creation has failed</b>");
                }
            });
        });
    }
    testDownload() {
        let connectionId;
        this.addButton("Download file", () => {
            this.fileSystem
                .Download("https://gitlab.com/oidis/io-oidis-builder/raw/develop/README.md")
                .OnStart(($id) => {
                connectionId = $id;
                Echo.Printf("start");
            })
                .OnChange(($args) => {
                Echo.Printf("change: {0}/{1}", $args.CurrentValue() + "", $args.RangeEnd() + "");
            })
                .OnComplete(($tmpPath) => {
                Echo.Printf("complete: {0}", $tmpPath);
            });
        });
        this.addButton("Stop download", () => {
            this.fileSystem
                .AbortDownload(connectionId)
                .Then(($status) => {
                if ($status) {
                    Echo.Printf("Download has been aborted.");
                }
                else {
                    Echo.Printf("Download abort has been failed.");
                }
            });
        });
        this.addButton("Download as stream", () => {
            this.fileSystem
                .Download({
                headers: {
                    "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:50.0) Gecko/20100101 Firefox/50.0"
                },
                streamOutput: true,
                url: "https://gitlab.com/oidis/io-oidis-builder/raw/develop/README.md"
            })
                .OnStart(() => {
                Echo.Printf("start");
            })
                .OnChange(($args) => {
                Echo.Printf("change: {0}/{1}", $args.CurrentValue() + "", $args.RangeEnd() + "");
            })
                .OnComplete(($headers, $body) => {
                Echo.Printf($headers);
                Echo.PrintCode($body);
            });
        });
        this.addButton("Download with error handler", () => {
            this.fileSystem
                .Download({
                url: "https://bitbucket.org/unknown-for-test/io-oidis-builder/" +
                    "raw/f897ba2642a2a6512e8b2bbf1f0b44bfee75a474/README.md"
            })
                .OnError(($error) => {
                Echo.Printf("download error handler called with: {0}", $error);
            })
                .OnComplete(() => {
                Echo.Printf("<b>Failed to call error handler for Download</b>");
            });
        });
    }
    testUnpack() {
        this.addButton("Unpack zip file", () => {
            this.fileSystem
                .Unpack(this.resourceData + "/archTest1.zip")
                .Then(($path) => {
                if (!ObjectValidator.IsEmptyOrNull($path)) {
                    Echo.Printf("<b>File unpacked to:</b>");
                    Echo.Printf($path);
                }
            });
        });
        this.addButton("Unpack tar.bz2 file", () => {
            this.fileSystem
                .Unpack(this.resourceData + "/archTest2.tar.bz2")
                .Then(($path) => {
                if (!ObjectValidator.IsEmptyOrNull($path)) {
                    Echo.Printf("<b>File unpacked to:</b>");
                    Echo.Printf($path);
                }
            });
        });
        this.addButton("Unpack with error (hard to simulate, delete lzma-native.dll from connector/builder before)", () => {
            this.fileSystem
                .Unpack("*//*/*-+*$unknown")
                .OnError(($error) => {
                Echo.Printf("Error handler called for Unpack with: {0}", $error);
            })
                .Then(($path) => {
                Echo.Printf("Failed to handle error for Unpack");
            });
        });
    }
    testPack() {
        this.addButton("Pack zip file", () => {
            this.fileSystem
                .Pack(this.resourceData + "/archTest", { type: "zip" })
                .Then(($path) => {
                if (!ObjectValidator.IsEmptyOrNull($path)) {
                    Echo.Printf("<b>File packed to:</b>");
                    Echo.Printf($path);
                }
            });
        });
        this.addButton("Pack tar.bz2 file", () => {
            this.fileSystem
                .Pack(this.resourceData + "/archTest", { type: "tar.bz2" })
                .Then(($path) => {
                if (!ObjectValidator.IsEmptyOrNull($path)) {
                    Echo.Printf("<b>File packed to:</b>");
                    Echo.Printf($path);
                }
            });
        });
        this.addButton("Pack with error", () => {
            this.fileSystem
                .Pack(this.resourceData + "/unknown")
                .OnError(($error) => {
                Echo.Printf("Error handler called for Unpack with: {0}", $error);
            })
                .Then(($path) => {
                Echo.Printf("Failed to handle error for Unpack");
            });
        });
    }
    testCopyDir() {
        let barIterator = 0;
        this.addButton("Copy dir", () => {
            barIterator++;
            Echo.Println("Directory copy progress: <span id=\"testCopyDirBar_" + barIterator + "\"></span>");
            this.fileSystem
                .Copy(this.resourceData, this.resourceData + "_Copy")
                .OnChange(($args) => {
                ElementManager.setInnerHtml("testCopyDirBar_" + barIterator, $args.CurrentValue() + "/" + $args.RangeEnd());
            })
                .Then(($success) => {
                if ($success) {
                    Echo.Printf("<b>Directory has been copied successfully</b>");
                }
                else {
                    Echo.Printf("<b>Directory copy has failed</b>");
                }
            });
        });
    }
    testDeleteDir() {
        let barIterator = 0;
        this.addButton("Delete dir", () => {
            barIterator++;
            Echo.Println("Directory delete progress: <span id=\"testDeleteDirBar_" + barIterator + "\"></span>");
            this.fileSystem
                .Delete(this.resourceData + "_Copy")
                .OnChange(($args) => {
                ElementManager.setInnerHtml("testDeleteDirBar_" + barIterator, $args.CurrentValue() + "/" + $args.RangeEnd());
            })
                .Then(($success) => {
                if ($success) {
                    Echo.Printf("<b>Directory has been deleted successfully</b>");
                }
                else {
                    Echo.Printf("<b>Directory deleted has failed</b>");
                }
            });
        });
    }
    testCreateShortcut() {
        this.addButton("Create shortcut", () => {
            this.fileSystem.CreateShortcut("source", "destination", {
                args: ["arg1", "arg2"],
                desc: "descritpion",
                hotkey: 5,
                icon: "path-to-icon",
                iconIndex: 3,
                runStyle: ShortcutRunStyle.NORMAL,
                workingDir: "working directory"
            })
                .Then(($code) => {
                if ($code === true) {
                    Echo.Println("succeed");
                }
                else {
                    Echo.Println("failed");
                }
            });
        });
        this.addButton("Create shortcut with error", () => {
            this.fileSystem.CreateShortcut("", "", {
                args: ["arg1", "arg2"],
                desc: "descritpion",
                hotkey: 5,
                icon: "path-to-icon",
                iconIndex: 3,
                runStyle: ShortcutRunStyle.NORMAL,
                workingDir: "working directory"
            })
                .OnError(($error) => {
                Echo.Printf("Error handler called for Create shortcut with: {0}", $error);
            })
                .Then(($code) => {
                Echo.Printf("Failed to handle error for Create shortcut.");
            });
        });
    }
    testgetLinkTargetPath() {
        this.addButton("Get Link target", () => {
            this.fileSystem.getLinkTargetPath("D:/SystemTemp")
                .Then(($path) => {
                if (!ObjectValidator.IsEmptyOrNull($path)) {
                    Echo.Println("real path: " + $path);
                }
                else {
                    Echo.Println("failed");
                }
            });
        });
    }
    testGetNetworkMap() {
        this.addButton("Get network map", () => {
            this.fileSystem
                .getNetworkMap()
                .Then(($data) => {
                Echo.Printf($data);
            });
        });
        this.addButton("Get network map advanced", () => {
            this.fileSystem
                .getNetworkMap(true)
                .Then(($data) => {
                Echo.Printf($data);
            });
        });
    }
    testGetRootFolders() {
        this.addButton("Get root FS interface", () => {
            this.fileSystem
                .getPathMap()
                .Then(($data) => {
                Echo.Printf($data);
            });
        });
    }
    testGetDirectoryContent() {
        this.addButton("Get folder content", () => {
            this.fileSystem
                .getDirectoryContent("C:\\Windows")
                .Then(($data) => {
                Echo.Printf($data);
            });
        });
    }
    testGetPathMap() {
        this.addButton("Get path map", () => {
            this.fileSystem
                .getPathMap("C:\\Program Files\\")
                .Then(($data) => {
                Echo.Printf($data);
            });
        });
    }
    testExpand() {
        this.addButton("Expand simple", () => {
            this.fileSystem
                .Expand("C:/Windows/*")
                .Then(($data) => {
                Echo.Printf($data);
            });
        });
        this.addButton("Expand map", () => {
            this.fileSystem
                .Expand(["C:/Program Files/*", "C:/Windows/*"])
                .Then(($data) => {
                Echo.Printf($data);
            });
        });
    }
    AgentTest() {
        const connector = new FileSystemHandlerConnector();
        connector.setAgent("test-connector-win", "https://localhost.oidis.io/connector.config.jsonp");
        this.addButton("Forward to agent", () => {
            connector
                .Exists(this.getAbsoluteRoot())
                .Then(($success) => {
                Echo.Printf($success);
            });
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.FileSystemConnectorTest", FileSystemConnectorTest);
//# sourceMappingURL=FileSystemConnectorTest.js.map