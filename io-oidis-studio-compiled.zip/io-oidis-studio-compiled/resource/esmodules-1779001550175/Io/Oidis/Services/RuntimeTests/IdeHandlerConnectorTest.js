/*! ******************************************************************************************************** *
 *
 * Copyright 2017 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { IdeHandlerConnector } from "../Connectors/IdeHandlerConnector.js";
export class IdeHandlerConnectorTest extends RuntimeTestRunner {
    ideHandler = new IdeHandlerConnector();
    FileChooserTest() {
        this.addButton("Open file chooser", () => {
            this.ideHandler
                .OpenFileChooser("C:/OidisFramework/", ["*.txt"])
                .Then(($paths) => {
                Echo.Println("Chosen files are : " + $paths);
            });
        });
    }
    DialogTest() {
        this.addButton("Open info dialog", () => {
            this.ideHandler
                .OpenInfoDialog("Mock Title", "Mock Message")
                .Then(($success) => {
                if ($success) {
                    Echo.Println("Info dialog opened");
                }
                else {
                    Echo.Println("Info dialog opening failed");
                }
            });
        });
    }
    WorkspaceRootTest() {
        this.addButton("Get workspace root", () => {
            this.ideHandler
                .getWorkspaceRoot()
                .Then(($path) => {
                Echo.Println("Workspace path : " + $path);
            });
        });
    }
    AddEventListenerTest() {
        this.addButton("Add event listener", () => {
            this.ideHandler
                .AddEventListener("testEvent", ($eventData1, $eventData2) => {
                Echo.Println($eventData1);
                Echo.Println($eventData2);
            });
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.IdeHandlerConnectorTest", IdeHandlerConnectorTest);
//# sourceMappingURL=IdeHandlerConnectorTest.js.map