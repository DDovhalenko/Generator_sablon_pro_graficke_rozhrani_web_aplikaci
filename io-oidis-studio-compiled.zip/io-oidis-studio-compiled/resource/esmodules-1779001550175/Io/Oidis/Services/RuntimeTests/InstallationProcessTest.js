/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { LanguageType } from "./../../../../Io/Oidis/Commons/Enums/LanguageType.js";
import { Convert } from "./../../../../Io/Oidis/Commons/Utils/Convert.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { ElementManager } from "./../../../../Io/Oidis/Gui/Utils/ElementManager.js";
import { WindowManager } from "./../../../../Io/Oidis/Gui/Utils/WindowManager.js";
import { InstallationRecipeDAO } from "../DAO/InstallationRecipeDAO.js";
import { InstallationProgressCode } from "../Enums/InstallationProgressCode.js";
import { InstallationProtocolType } from "../Enums/InstallationProtocolType.js";
export class InstallationProcessTest extends RuntimeTestRunner {
    installDao;
    installScript;
    forceChain;
    chain;
    constructor() {
        super();
        this.setScript("test/resource/data/Io/Oidis/Services/Configuration/BaseInstallationRecipe.jsonp");
        this.setChain([
            "Netfx4Full",
            "VisualStudio2015",
            "VisualCppBuildTools",
            "VCRedist2012",
            "VCRedist2015",
            "Java",
            "Git",
            "Python",
            "Ruby",
            "Cmake",
            "Mingw",
            "Msys2",
            "PortableGit",
            "PortableCMake"
        ]);
    }
    testRegisterApp() {
        this.addButton("Add to WIN Register", () => {
            const env = this.getEnvironmentArgs();
            this.getDao().getConfigurationInstance().utils.RegisterApp(true, "Oidis/" + env.getAppName() + "_TEST", env.getProjectVersion(), StringUtils.Replace("C:/" +
                env.getProjectName() + "-" + StringUtils.Replace(env.getProjectVersion(), ".", "-"), "/", "\\"), ($status) => {
                this.assertEquals($status, true, "Validate that WIN register has been added");
                if ($status) {
                    this.getDao().getConfigurationInstance().utils.RegisterValueExists("HKLM/SOFTWARE/Oidis/" + env.getAppName() + "_TEST", "CurrentVersion", ($status) => {
                        this.assertEquals($status, true, "Validate existence of WIN register key");
                        if ($status) {
                            this.getDao().getConfigurationInstance().utils.RemoveRegisterKey("HKLM/SOFTWARE/Oidis/" + env.getAppName() + "_TEST", "", ($status) => {
                                this.assertEquals($status, true, "Validate that WIN register has been removed");
                                if ($status) {
                                    this.getDao().getConfigurationInstance().utils.RegisterValueExists("HKLM/SOFTWARE/Oidis/" + env.getAppName() + "_TEST", "CurrentVersion", ($status) => {
                                        this.assertEquals($status, false, "Validate non-existence of WIN register key");
                                    });
                                }
                            });
                        }
                    });
                }
            });
        });
        this.addButton("Add to WIN Path", () => {
            const env = this.getEnvironmentArgs();
            const path = StringUtils.Replace("C:/" +
                env.getProjectName() + "-" + StringUtils.Replace(env.getProjectVersion(), ".", "-") + "/TEST", "/", "\\");
            this.getDao().getConfigurationInstance().utils.AddToSystemPath(true, path, ($status) => {
                this.assertEquals($status, true, "Validate that WIN Path has been added");
                if ($status) {
                    this.getDao().getConfigurationInstance().utils.SystemPathExists(path, ($status) => {
                        this.assertEquals($status, true, "Validate existence of WIN Path");
                        if ($status) {
                            this.getDao().getConfigurationInstance().utils.RemoveSystemPath(path, ($status) => {
                                this.assertEquals($status, true, "Validate that WIN Path has been removed");
                                if ($status) {
                                    this.getDao().getConfigurationInstance().utils.SystemPathExists(path, ($status) => {
                                        this.assertEquals($status, false, "Validate non-existence of WIN Path");
                                    });
                                }
                            });
                        }
                    });
                }
            });
        });
    }
    testValidate() {
        this.addButton("Run validation", () => {
            this.runProtocol(InstallationProtocolType.VALIDATE);
        });
    }
    testInstall() {
        this.addButton("Run Install chain", () => {
            this.runProtocol(InstallationProtocolType.INSTALL);
        });
        this.addButton("Stop installation", () => {
            this.installDao.Abort();
        });
    }
    testUninstall() {
        this.addButton("Run Uninstall chain", () => {
            this.runProtocol(InstallationProtocolType.UNINSTALL);
        });
    }
    testFix() {
        this.addButton("Run Repair chain", () => {
            this.runProtocol(InstallationProtocolType.REPAIR);
        });
    }
    before() {
        this.installDao = new InstallationRecipeDAO();
        this.installDao.setConfigurationPath(this.installScript);
        this.installDao.ConfigurationLibrary().Log = this.installDao.ConfigurationLibrary().Echo;
        let rootPath = this.getRequest().getHostUrl();
        if (StringUtils.Contains(rootPath, ".html")) {
            rootPath = StringUtils.Substring(rootPath, 0, StringUtils.IndexOf(rootPath, "/", false));
        }
        Echo.Println("<i id=\"LoadingScript\">Loading install script ...</i>");
        Echo.Println("<span id=\"ScriptProcess\"></span>");
        this.installDao.getEvents().setOnStart(() => {
            Echo.Printf("Running installation recipe version \"{0}\".", this.installDao.getConfigurationVersion());
            WindowManager.ScrollToBottom();
        });
        let estimation;
        let startTime;
        this.installDao.getEvents().setOnChange(($eventArgs) => {
            if ($eventArgs.ProgressCode() === InstallationProgressCode.DOWNLOAD_START) {
                startTime = new Date().getTime();
            }
            if ($eventArgs.ProgressCode() === InstallationProgressCode.DOWNLOAD_CHANGE) {
                const forecast = ($eventArgs.RangeEnd() - $eventArgs.CurrentValue()) /
                    ($eventArgs.CurrentValue() / ((new Date().getTime() - startTime) / 1000));
                if (forecast < 60) {
                    estimation = Convert.ToFixed(forecast, 0) + " s";
                }
                else if (forecast > 60 && forecast < 3600) {
                    estimation = Convert.ToFixed(forecast / 60, 0) + " min";
                }
                else if (forecast > 3600) {
                    estimation = Convert.ToFixed(forecast / 3600, 0) + " h";
                }
                ElementManager.setInnerHtml("ScriptProcess", StringUtils.Format("<b>Get data source:</b> {0}, ({3}) {1}/{2}", $eventArgs.Message(), $eventArgs.CurrentValue() + "", $eventArgs.RangeEnd() + "", estimation));
                window.scrollTo(0, ElementManager.getElement("ScriptProcess").offsetTop);
            }
            else if ($eventArgs.ProgressCode() === InstallationProgressCode.STEP_START) {
                Echo.Printf("Step {0}, {1}/{2}", $eventArgs.Message(), $eventArgs.CurrentValue() + "", $eventArgs.RangeEnd() + "");
            }
            else {
                if ($eventArgs.CurrentValue() > -1) {
                    Echo.Printf("{0}, {1}/{2}", $eventArgs.Message(), $eventArgs.CurrentValue() + "", $eventArgs.RangeEnd() + "");
                }
                else {
                    Echo.Println($eventArgs.Message());
                }
                WindowManager.ScrollToBottom();
            }
        });
        this.installDao.getEvents().setOnComplete(() => {
            Echo.Println("Installation has finished.");
            WindowManager.ScrollToBottom();
        });
        this.installDao.getEvents().setOnError(($eventArgs) => {
            Echo.Printf("ERROR: {0}", $eventArgs.Message());
            WindowManager.ScrollToBottom();
        });
        return ($done) => {
            this.installDao.Load(LanguageType.EN, () => {
                ElementManager.Hide("LoadingScript");
                let configPath = this.installDao.getDaoDataSource();
                if (!StringUtils.Contains(configPath, "http://", "https://", "file://", "www.")) {
                    configPath = rootPath + "/" + configPath;
                }
                Echo.Println("<b>Configuration data source:</b> " + configPath + StringUtils.NewLine());
                if (ObjectValidator.IsEmptyOrNull(this.installDao.getChain()) || this.forceChain) {
                    this.installDao.getStaticConfiguration().getChain = () => {
                        return this.chain;
                    };
                }
                $done();
            });
        };
    }
    setScript($path) {
        if (!ObjectValidator.IsEmptyOrNull($path)) {
            this.installScript = $path;
        }
    }
    setChain($value, $force = false) {
        if (!ObjectValidator.IsEmptyOrNull($value)) {
            this.chain = $value;
            this.forceChain = $force;
        }
    }
    getDao() {
        return this.installDao;
    }
    runProtocol($type) {
        switch ($type) {
            case InstallationProtocolType.VALIDATE:
                Echo.Println("<h2>Validation report</h2>");
                break;
            case InstallationProtocolType.INSTALL:
                Echo.Println("<h2>Installation report</h2>");
                break;
            case InstallationProtocolType.UNINSTALL:
                Echo.Println("<h2>Uninstallation report</h2>");
                break;
            case InstallationProtocolType.REPAIR:
                Echo.Println("<h2>Repair report</h2>");
                break;
            default:
                Echo.Println("<h2>Report for: " + $type + "</h2>");
                break;
        }
        this.installDao.RunInstallationChain($type);
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.InstallationProcessTest", InstallationProcessTest);
//# sourceMappingURL=InstallationProcessTest.js.map