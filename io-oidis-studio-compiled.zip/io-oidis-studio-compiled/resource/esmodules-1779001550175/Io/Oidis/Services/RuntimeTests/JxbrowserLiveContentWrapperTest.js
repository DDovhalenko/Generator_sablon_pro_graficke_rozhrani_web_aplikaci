/*! ******************************************************************************************************** *
 *
 * Copyright 2017 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { LiveContentWrapper } from "../WebServiceApi/LiveContentWrapper.js";
import { WebServiceClientFactory } from "../WebServiceApi/WebServiceClientFactory.js";
export class JxbrowserLiveContentWrapperTest extends RuntimeTestRunner {
    client;
    serverClassName = "Io.Oidis.Jcommons.TestClass";
    setUp() {
        this.client = WebServiceClientFactory.getClient(WebServiceClientType.JXBROWSER_BRIDGE);
        this.client.setResponseFormatter(null);
    }
    testMethodCalls() {
        this.addButton("string TestMethod(double, float)", () => {
            LiveContentWrapper.InvokeMethod(this.client, this.serverClassName, "TestMethod", 1500.16498494, 2500.51561684986).Then(($response) => {
                Echo.Println("Returned : " + $response);
            });
        });
        this.addButton("float TestMethod(string, float)", () => {
            LiveContentWrapper.InvokeMethod(this.client, this.serverClassName, "TestMethod", "Test String", 45645.5156635434541684986).Then(($response) => {
                Echo.Println("Returned : " + $response);
            });
        });
        this.addButton("Non-existent method", () => {
            LiveContentWrapper.InvokeMethod(this.client, this.serverClassName, "TestMethodd", "Test String", 45645.5156635434541684986).Then(($response) => {
                Echo.Println("Returned : " + $response);
            });
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.JxbrowserLiveContentWrapperTest", JxbrowserLiveContentWrapperTest);
//# sourceMappingURL=JxbrowserLiveContentWrapperTest.js.map