/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { ElementEventsManager } from "./../../../../Io/Oidis/Gui/Events/ElementEventsManager.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { ElementManager } from "./../../../../Io/Oidis/Gui/Utils/ElementManager.js";
import { StaticPageContentManager } from "./../../../../Io/Oidis/Gui/Utils/StaticPageContentManager.js";
import { AuthManagerConnector } from "../Connectors/AuthManagerConnector.js";
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { AuthHttpResolver } from "../ErrorPages/AuthHttpResolver.js";
import { LiveContentWrapper } from "../WebServiceApi/LiveContentWrapper.js";
import { WebServiceClientFactory } from "../WebServiceApi/WebServiceClientFactory.js";
class LogInPage extends AuthHttpResolver {
    service;
    constructor() {
        super();
        this.service = new AuthManagerConnector(false, "https://localhost.oidis.io/connector.config.jsonp");
        this.setExpirationTime("10 sec");
    }
    resolver() {
        const loginFormId = "LogInForm";
        if (!ElementManager.Exists(loginFormId)) {
            const loginNameId = "LoginUserNameId";
            const loginPassId = "LoginPasswordId";
            const loginButtonId = "LoginLogInButtonId";
            StaticPageContentManager.BodyAppend("<div id=\"" + loginFormId + "\">" +
                "<h2>Log in</h2>" +
                "Username<br><input type=\"text\" id=\"" + loginNameId + "\"><br>" +
                "Password<br><input type=\"password\" id=\"" + loginPassId + "\"><br>" +
                "<div style=\"border: 1px solid red; cursor: pointer; " +
                "width: 250px; overflow-x: hidden; overflow-y: hidden; " +
                "text-align: center; font-size: 16px; font-family: Consolas; color: red;\" " +
                "id=\"" + loginButtonId + "\">Log in</div>" +
                "</div>");
            const eventsLogin = new ElementEventsManager(loginButtonId);
            eventsLogin.setOnClick(async () => {
                try {
                    const $token = await this.service.LogIn(ElementManager.getElement(loginNameId).value, ElementManager.getElement(loginPassId).value);
                    if (!ObjectValidator.IsEmptyOrNull($token)) {
                        ElementManager.Hide(loginFormId);
                        Echo.Printf("You have successfully logged in with token: {0}", $token);
                        this.reinvokeRequest($token);
                    }
                    else {
                        Echo.Printf("Invalid user, please try again.");
                    }
                }
                catch (ex) {
                    Echo.Printf(ex.message);
                }
            });
            this.getEventsManager().FireAsynchronousMethod(() => {
                eventsLogin.Subscribe();
            });
        }
        else {
            ElementManager.Show(loginFormId);
        }
    }
}
export class LogInTest extends RuntimeTestRunner {
    testInvokeSecuredFunction() {
        const loginFormId = "LogInForm";
        const client = WebServiceClientFactory.getClient(WebServiceClientType.HUB_CONNECTOR, "https://localhost.oidis.io/connector.config.jsonp");
        this.addButton("Invoke secure function", () => {
            LiveContentWrapper.InvokeMethod(client, "Io.Oidis.Hub.RuntimeTests.UserManagerTestHandler", "SecuredMethod")
                .Then(($success) => {
                ElementManager.Hide(loginFormId);
                if ($success) {
                    Echo.Printf("Secured function successfully invoked.");
                }
                else {
                    Echo.Printf("Secured function invocation failed.");
                }
            });
        });
    }
    testInvalidateToken() {
        this.addButton("Invalidate token", () => {
            AuthHttpResolver.LogOut();
            Echo.Printf("User has been logged out.");
        });
    }
    __IgnoretestLoginFacebook() {
        // example url for logging into fb/getting token by redirecting
        //
        // https://www.facebook.com/dialog/oauth/
        // ?client_id=201158640315306&redirect_uri=http://localhost.oidis.io/io-oidis-services/
    }
    __IgnoretestLoginGoogle() {
        // example url for logging into google/getting token by redirecting
        //
        // https://accounts.google.com/o/oauth2/
        // v2/auth?scope=email%20profile&redirect_uri=http://localhost.oidis.io/io-oidis-services
        // &response_type=code&client_id=176530116802-vfhiqjrgt5f5th6tokqutgp3ke3dpafn.apps.googleusercontent.com
    }
    before() {
        this.overrideResolver("/ServerError/Http/NotAuthorized", LogInPage);
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.LogInTest", LogInTest);
//# sourceMappingURL=LogInTest.js.map