import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { NetworkingConnector } from "../Connectors/NetworkingConnector.js";
export class NetworkingConnectorTest extends RuntimeTestRunner {
    networkingConnector;
    before() {
        this.networkingConnector = new NetworkingConnector();
        this.networkingConnector.getEvents().OnError(($args) => {
            Echo.Println($args.Message());
        });
    }
    testSingleGetFreePort() {
        this.addButton("Find free port", () => {
            this.networkingConnector
                .getFreePort()
                .Then(($port) => {
                Echo.Printf("<b>Free port found: </b>" + $port);
            });
        });
    }
    testRepeatGetFreePort() {
        this.addButton("repeat getFreePort request - async", () => {
            let lastPort = -1;
            const getNextPort = ($index) => {
                if ($index < 20) {
                    this.networkingConnector
                        .getFreePort()
                        .Then(($port) => {
                        if (lastPort === $port) {
                            Echo.Println("<b style=\"color: red;\">Ports are identical<b/>[" + $index + "]");
                        }
                        else {
                            Echo.Println("<span style=\"color: green;\">OK [" + $index + "]</span>");
                        }
                        lastPort = $port;
                        getNextPort($index + 1);
                    });
                }
            };
            getNextPort(0);
        });
        this.addButton("repeat getFreePort request - sync", () => {
            let lastPort = -1;
            for (let $index = 0; $index < 20; $index++) {
                this.networkingConnector
                    .getFreePort()
                    .Then(($port) => {
                    if (lastPort === $port) {
                        Echo.Println("<b style=\"color: red;\">Ports are identical<b/>[" + $index + "]");
                    }
                    else {
                        Echo.Println("<span style=\"color: green;\">OK [" + $index + "]</span>");
                    }
                    lastPort = $port;
                });
            }
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.NetworkingConnectorTest", NetworkingConnectorTest);
//# sourceMappingURL=NetworkingConnectorTest.js.map