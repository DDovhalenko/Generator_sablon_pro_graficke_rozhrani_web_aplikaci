var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { EventType } from "./../../../../Io/Oidis/Gui/Enums/Events/EventType.js";
import { GeneralEventOwner } from "./../../../../Io/Oidis/Gui/Enums/Events/GeneralEventOwner.js";
import { ResizeableType } from "./../../../../Io/Oidis/Gui/Enums/ResizeableType.js";
import { ResizeBarEventArgs } from "./../../../../Io/Oidis/Gui/Events/Args/ResizeBarEventArgs.js";
import { BasePanel } from "./../../../../Io/Oidis/Gui/Primitives/BasePanel.js";
import { BasePanelViewer } from "./../../../../Io/Oidis/Gui/Primitives/BasePanelViewer.js";
import { FormsObject } from "./../../../../Io/Oidis/Gui/Primitives/FormsObject.js";
import { GuiCommons } from "./../../../../Io/Oidis/Gui/Primitives/GuiCommons.js";
import { ElementManager } from "./../../../../Io/Oidis/Gui/Utils/ElementManager.js";
import { BasePageController } from "../HttpProcessor/Resolvers/BasePageController.js";
import { Resolver } from "./../../../../Io/Oidis/Commons/Primitives/Decorators.js";
export class MockButton extends FormsObject {
    buttonType;
    constructor($buttonType, $id) {
        super($id);
        this.GuiType($buttonType);
    }
    GuiType($buttonType) {
        if (ObjectValidator.IsSet($buttonType)) {
            this.buttonType = $buttonType;
        }
        return this.buttonType;
    }
    Text($value) {
        return "";
    }
    getEvents() {
        return super.getEvents();
    }
    IconName($value) {
        return "";
    }
    IsSelected($value) {
        return false;
    }
    innerHtml() {
        return this.addElement(this.Id() + "_Type").StyleClassName(this.buttonType);
    }
    innerCode() {
        this.getEvents().Subscriber(this.Id() + "_Type");
        return super.innerCode();
    }
    cssContainerName() {
        return "Button";
    }
}
export class MockResizeBar extends GuiCommons {
    resizeType;
    static setWidth($element, $value) {
        ElementManager.setWidth($element.Id() + "_Position", $value);
    }
    static setHeight($element, $value) {
        ElementManager.setHeight($element.Id() + "_Position", $value);
    }
    constructor($resizeableType, $id) {
        super($id);
        this.ResizeableType($resizeableType);
    }
    ResizeableType($type) {
        if (ObjectValidator.IsSet($type)) {
            this.resizeType = $type;
        }
        return this.resizeType;
    }
    getEvents() {
        return super.getEvents();
    }
    innerCode() {
        this.getEvents().Subscriber(this.Id() + "_Position");
        this.getEventsManager().setEvent(GeneralEventOwner.MOUSE_MOVE, EventType.ON_START, ($args, $manager) => {
            this.getEvents().FireAsynchronousMethod(() => {
                if ($manager.IsActive(MockResizeBar)) {
                    $args.StopAllPropagation();
                    const element = $manager.getActive(MockResizeBar).getFirst();
                    const eventArgs = new ResizeBarEventArgs();
                    eventArgs.Owner(element);
                    eventArgs.ResizeableType(element.ResizeableType());
                    this.getEventsManager().FireEvent(element, EventType.ON_RESIZE_START, eventArgs, false);
                }
            });
        });
        this.getEventsManager().setEvent(GeneralEventOwner.MOUSE_MOVE, EventType.ON_CHANGE, ($args, $manager) => {
            this.getEvents().FireAsynchronousMethod(() => {
                if ($manager.IsActive(MockResizeBar)) {
                    $args.StopAllPropagation();
                    const element = $manager.getActive(MockResizeBar).getFirst();
                    switch (element.ResizeableType()) {
                        case ResizeableType.HORIZONTAL_AND_VERTICAL:
                            document.body.style.cursor = "nw-resize";
                            break;
                        case ResizeableType.HORIZONTAL:
                            document.body.style.cursor = "w-resize";
                            break;
                        case ResizeableType.VERTICAL:
                            document.body.style.cursor = "n-resize";
                            break;
                        default:
                            document.body.style.cursor = "default";
                            break;
                    }
                    let distanceX = 0;
                    let distanceY = 0;
                    if (element.ResizeableType() === ResizeableType.HORIZONTAL_AND_VERTICAL ||
                        element.ResizeableType() === ResizeableType.HORIZONTAL) {
                        distanceX = $args.getDistanceX();
                    }
                    if (element.ResizeableType() === ResizeableType.HORIZONTAL_AND_VERTICAL ||
                        element.ResizeableType() === ResizeableType.VERTICAL) {
                        distanceY = $args.getDistanceY();
                    }
                    const eventArgs = new ResizeBarEventArgs();
                    eventArgs.Owner(element);
                    eventArgs.ResizeableType(element.ResizeableType());
                    eventArgs.DistanceX(distanceX);
                    eventArgs.DistanceY(distanceY);
                    this.getEventsManager().FireEvent(element, EventType.ON_RESIZE_CHANGE, eventArgs, false);
                }
            });
        });
        this.getEventsManager().setEvent(GeneralEventOwner.MOUSE_MOVE, EventType.ON_COMPLETE, ($args, $manager) => {
            this.getEvents().FireAsynchronousMethod(() => {
                $args.StopAllPropagation();
                const elements = $manager.getActive(MockResizeBar);
                elements.foreach(($element) => {
                    const eventArgs = new ResizeBarEventArgs();
                    eventArgs.Owner($element);
                    eventArgs.ResizeableType($element.ResizeableType());
                    this.getEventsManager().FireEvent($element, EventType.ON_RESIZE_COMPLETE, eventArgs, false);
                    this.getEventsManager().FireEvent($element, EventType.ON_RESIZE, eventArgs, false);
                    $manager.setActive($element, false);
                });
            });
        });
        this.getEvents().setOnMouseDown(($args, $manager) => {
            $manager.setActive(this, true);
        });
        this.getEvents().setOnMouseUp(() => {
            document.body.style.cursor = "default";
        });
        return super.innerCode();
    }
    innerHtml() {
        return this.addElement().Add(this.addElement(this.Id() + "_Position").StyleClassName(this.resizeType));
    }
    cssContainerName() {
        return "ResizeBar";
    }
}
export class MockDragBar extends GuiCommons {
    getEvents() {
        return super.getEvents();
    }
    innerCode() {
        this.getEventsManager().setEvent(GeneralEventOwner.MOUSE_MOVE, EventType.ON_START, ($args, $manager) => {
            this.getEvents().FireAsynchronousMethod(() => {
                if ($manager.IsActive(MockDragBar)) {
                    $args.StopAllPropagation();
                    const element = $manager.getActive(MockDragBar).getFirst();
                    $args.Owner(element);
                    this.getEventsManager().FireEvent(element, EventType.ON_DRAG_START, $args, false);
                    document.body.style.cursor = "move";
                }
            });
        });
        this.getEventsManager().setEvent(GeneralEventOwner.MOUSE_MOVE, EventType.ON_CHANGE, ($args, $manager) => {
            this.getEvents().FireAsynchronousMethod(() => {
                if ($manager.IsActive(MockDragBar)) {
                    $args.StopAllPropagation();
                    const element = $manager.getActive(MockDragBar).getFirst();
                    $args.Owner(element);
                    this.getEventsManager().FireEvent(element, EventType.ON_DRAG_CHANGE, $args);
                }
            });
        });
        this.getEventsManager().setEvent(GeneralEventOwner.MOUSE_MOVE, EventType.ON_COMPLETE, ($args, $manager) => {
            this.getEvents().FireAsynchronousMethod(() => {
                $args.StopAllPropagation();
                const elements = $manager.getActive(MockDragBar);
                elements.foreach(($element) => {
                    $args.Owner($element);
                    this.getEventsManager().FireEvent($element, EventType.ON_DRAG_COMPLETE, $args, false);
                    $manager.setActive($element, false);
                });
            });
        });
        this.getEvents().setOnMouseDown(($args, $manager) => {
            $manager.setActive(this, true);
        });
        this.getEvents().setOnMouseUp(() => {
            document.body.style.cursor = "default";
        });
        return super.innerCode();
    }
    cssContainerName() {
        return "DragBar";
    }
}
export class MockPanel extends BasePanel {
    innerHtml() {
        return this.addElement()
            .Add(this.addElement().Width(500).Height(500)
            .setAttribute("background-color", "silver")
            .setAttribute("position", "absolute")
            .Add("validation element with size: 500x500 px"))
            .Add(this.addElement().StyleClassName("Logo")
            .Add(this.addElement().StyleClassName("Oidis")));
    }
}
export class MockViewer extends BasePanelViewer {
    constructor() {
        super();
        this.setInstance(new MockPanel());
    }
}
let PageControllerTest = class PageControllerTest extends BasePageController {
    constructor() {
        super();
        this.setModelClassName(MockViewer);
        this.minimizeButton.GuiType("AppMinimize");
        this.maximizeButton.GuiType("AppMaximize");
        this.closeButton.GuiType("AppClose");
        this.setResizeableType(ResizeableType.HORIZONTAL_AND_VERTICAL);
    }
    getAppImageButtonClass() {
        return MockButton;
    }
    getAppResizeBarClass() {
        return MockResizeBar;
    }
    getAppDragBarClass() {
        return MockDragBar;
    }
    resolver() {
        Echo.Println("<style>" +
            ".AppDragBar {cursor: move;}" +
            ".AppButtons {top: 5px !important; right: 5px !important;}" +
            ".Button {float: left; margin-left: 3px;}" +
            ".Button .AppMinimize {border-radius: 10px; background-color: green; width: 20px; height: 20px;}" +
            ".Button .AppMaximize {border-radius: 10px; background-color: orange; width: 20px; height: 20px;}" +
            ".Button .AppClose {border-radius: 10px; background-color: red; width: 20px; height: 20px;}" +
            ".ResizeBar {float: right; left: 0; top: 1px; position: relative;}" +
            ".ResizeBar .X {cursor: w-resize;}" +
            ".ResizeBar .Y {cursor: n-resize;}" +
            ".ResizeBar .XY {cursor: nw-resize;}" +
            ".MockPanel {background-color: gainsboro;}" +
            "</style>");
        super.resolver();
    }
};
PageControllerTest = __decorate([
    Resolver(["/PageControllerTest"]),
    __metadata("design:paramtypes", [])
], PageControllerTest);
export { PageControllerTest };
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.MockButton", MockButton);
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.MockResizeBar", MockResizeBar);
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.MockDragBar", MockDragBar);
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.MockPanel", MockPanel);
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.MockViewer", MockViewer);
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.PageControllerTest", PageControllerTest);
//# sourceMappingURL=PageControllerTest.js.map