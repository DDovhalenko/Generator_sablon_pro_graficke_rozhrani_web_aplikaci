import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { TerminalConnector } from "../Connectors/TerminalConnector.js";
import { WebServiceClientFactory } from "../WebServiceApi/WebServiceClientFactory.js";
export class TerminalConnectorTest extends RuntimeTestRunner {
    connector;
    before() {
        this.connector = new TerminalConnector();
        this.connector.getEvents().OnError(($args) => {
            Echo.Println($args.Message());
        });
        const client = WebServiceClientFactory.getClientById(this.connector.getId());
        client.getServerPath(($path) => {
            Echo.Printf("<b>Server configuration:</b> uri - \"{0}\", server root - \"{1}\"", client.getServerUrl(), $path);
        });
    }
    CmdSyncTest() {
        this.addButton("test execute (wui --version)", () => {
            this.connector
                .Execute("wui", ["--version"])
                .OnMessage(($data) => {
                Echo.Print($data);
            })
                .Then(($code, $stdout, $stderr) => {
                Echo.Printf("out: {0}</br>err: {1}", $stdout, $stderr);
                if ($code === 0) {
                    Echo.Println("succeed");
                }
                else {
                    Echo.Println("failed");
                }
            });
        });
        this.addButton("test execute (cmd /c dir)", () => {
            this.connector
                .Execute("cmd", ["/c", "dir"], "../../")
                .OnMessage(($data) => {
                Echo.Print($data);
            })
                .Then(($code, $stdout, $stderr) => {
                Echo.Printf("out: {0}</br>err: {1}", $stdout, $stderr);
                if ($code === 0) {
                    Echo.Println("succeed");
                }
                else {
                    Echo.Println("failed");
                }
            });
        });
        this.addButton("test execute (ping 127.0.0.1)", () => {
            this.connector
                .Execute("ping", ["127.0.0.1"])
                .OnMessage(($data) => {
                Echo.Print($data);
            })
                .Then(($code) => {
                if ($code === 0) {
                    Echo.Println("succeed");
                }
                else {
                    Echo.Println("failed");
                }
            });
        });
        this.addButton("test spawn (ping 127.0.0.1", () => {
            this.connector
                .Spawn("ping", ["127.0.0.1"])
                .OnMessage(($data) => {
                Echo.Print($data);
            })
                .Then(($code) => {
                if ($code === 0) {
                    Echo.Println("succeed");
                }
                else {
                    Echo.Println("failed");
                }
            });
        });
        this.addButton("get sync WUI Info - OnMessage", () => {
            this.connector
                .Spawn("wui", ["--version"])
                .OnMessage(($data) => {
                if ($data === ".") {
                    Echo.Print($data);
                }
                else {
                    Echo.Println($data);
                }
            })
                .Then(($code) => {
                if ($code === 0) {
                    this.connector
                        .Spawn("wui", ["--path"]);
                }
            });
        });
        this.addButton("get sync WUI Info - stdout", () => {
            this.connector
                .Spawn("wui", ["--version"])
                .Then(($code, $stdout) => {
                if ($code === 0) {
                    Echo.Printf($stdout);
                    this.connector
                        .Spawn("wui", ["--path"])
                        .Then(($code, $stdout) => {
                        if ($code === 0) {
                            Echo.Printf($stdout);
                        }
                    });
                }
            });
        });
        this.addButton("run sync testCase*.cmd", () => {
            this.connector
                .Execute("testCaseA.cmd", [], this.getAbsoluteRoot() + "/test/resource/data/Io/Oidis/Services/RuntimeTests")
                .OnMessage(($data) => {
                Echo.Println($data);
            })
                .Then(($code) => {
                Echo.Print("testCaseA - ");
                if ($code === 0) {
                    Echo.Println("succeed");
                }
                else {
                    Echo.Println("failed");
                }
            });
            this.connector
                .Execute("testCaseA.cmd", [], { cwd: this.getAbsoluteRoot() + "/test/resource/data/Io/Oidis/Services/RuntimeTests" })
                .OnMessage(($data) => {
                Echo.Println($data);
            })
                .Then(($code) => {
                Echo.Print("testCaseA - ");
                if ($code === 0) {
                    Echo.Println("succeed");
                }
                else {
                    Echo.Println("failed");
                }
            });
            this.connector
                .Execute("testCaseA.cmd", [], {
                env: {
                    PATH: this.getAbsoluteRoot() + "/test/resource/data/Io/Oidis/Services/RuntimeTests;%PATH%"
                }
            })
                .OnMessage(($data) => {
                Echo.Println($data);
            })
                .Then(($code) => {
                Echo.Print("testCaseA - ");
                if ($code === 0) {
                    Echo.Println("succeed");
                }
                else {
                    Echo.Println("failed");
                }
            });
        });
    }
    CmdAsyncTest() {
        this.addButton("get async WUI Info", () => {
            this.connector.Spawn("wui", ["--version"])
                .Then(($code) => {
                Echo.Print("async: spawn wui --version");
                if ($code === 0) {
                    Echo.Println("succeed");
                }
                else {
                    Echo.Println("failed");
                }
            });
            this.connector.Spawn("wui", ["--path"])
                .Then(($code) => {
                Echo.Print("async: spawn wui --path");
                if ($code === 0) {
                    Echo.Println("succeed");
                }
                else {
                    Echo.Println("failed");
                }
            });
        });
        this.addButton("test spawn async (ping 127.0.0.1 and ping 8.8.8.8)", () => {
            this.connector.Spawn("ping", ["127.0.0.1"])
                .OnMessage(($data) => {
                Echo.Println($data);
            })
                .Then(($code) => {
                Echo.Print("ping 127.0.0.1 - ");
                if ($code === 0) {
                    Echo.Println("succeed");
                }
                else {
                    Echo.Println("failed");
                }
            });
            this.connector.Spawn("ping", ["8.8.8.8"])
                .OnMessage(($data) => {
                Echo.Println($data);
            })
                .Then(($code) => {
                Echo.Print("ping 8.8.8.8 - ");
                if ($code === 0) {
                    Echo.Println("succeed");
                }
                else {
                    Echo.Println("failed");
                }
            });
        });
        this.addButton("test spawn async (test *.cmd)", () => {
            this.connector.Spawn("testCaseA.cmd", [], "./test/resource/data/Io/Oidis/Services/RuntimeTests")
                .OnMessage(($data) => {
                Echo.Println($data);
            })
                .Then(($code) => {
                Echo.Print("testCaseA - ");
                if ($code === 0) {
                    Echo.Println("succeed");
                }
                else {
                    Echo.Println("failed");
                }
            });
            this.connector.Spawn("testCaseB.cmd", [], "./test/resource/data/Io/Oidis/Services/RuntimeTests")
                .OnMessage(($data) => {
                Echo.Println($data);
            })
                .Then(($code) => {
                Echo.Print("testCaseB - ");
                if ($code === 0) {
                    Echo.Println("succeed");
                }
                else {
                    Echo.Println("failed");
                }
            });
        });
    }
    OpenTest() {
        this.addButton("open executable", () => {
            this.connector.Open("notepad.exe");
        });
    }
    ElevateTest() {
        this.addButton("elevate process", () => {
            this.connector.Elevate("AT");
        });
    }
    AgentTest() {
        const connector = new TerminalConnector();
        connector.setAgent("test-connector-win", "https://localhost.oidis.io/connector.config.jsonp");
        this.addButton("Forward to agent", () => {
            connector
                .Spawn("wui", ["path"])
                .OnMessage(($data) => {
                Echo.Printf($data);
            })
                .Then(($exitCode, $stdout, $stderr) => {
                Echo.Printf($exitCode);
            });
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.TerminalConnectorTest", TerminalConnectorTest);
//# sourceMappingURL=TerminalConnectorTest.js.map