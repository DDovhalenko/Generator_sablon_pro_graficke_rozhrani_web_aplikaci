import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { VirtualBoxConnector } from "../Connectors/VirtualBoxConnector.js";
export class VirtualBoxConnectorTest extends RuntimeTestRunner {
    connector;
    before() {
        this.connector = new VirtualBoxConnector();
        this.connector.getEvents().OnError(($args) => {
            Echo.Println($args.Message());
        });
    }
    testConnection() {
        let sessionId = "";
        this.addButton("Start machine", () => {
            this.connector
                .Start("Clean Win 7")
                .Then(($success, $sessionId) => {
                if ($success) {
                    sessionId = $sessionId;
                    Echo.Printf("Hooray, virtual machine is running. Connected under: {0}", sessionId);
                }
                else {
                    Echo.Printf("<b>Sorry, bad luck :-)</b>");
                }
            });
        });
        this.addButton("Copy file", () => {
            this.connector
                .Copy(sessionId, "C:/Windows/System32/notepad.exe", "C:/Users/Guest/AppData/Local/Temp/notepad.exe")
                .Then(($success) => {
                if ($success) {
                    Echo.Printf("File copy successful");
                }
                else {
                    Echo.Printf("<b>File copy failed</b>");
                }
            });
        });
        this.addButton("Execute file", () => {
            this.connector
                .Execute(sessionId, "C:/Windows/System32/notepad.exe")
                .Then(($success) => {
                if ($success) {
                    Echo.Printf("File execute successful");
                }
                else {
                    Echo.Printf("<b>File execute failed</b>");
                }
            });
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.VirtualBoxConnectorTest", VirtualBoxConnectorTest);
//# sourceMappingURL=VirtualBoxConnectorTest.js.map