import { ExceptionsManager } from "./../../../../Io/Oidis/Commons/Exceptions/ExceptionsManager.js";
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { WebServiceClientType } from "../Enums/WebServiceClientType.js";
import { LiveContentWrapper } from "../WebServiceApi/LiveContentWrapper.js";
import { WebServiceClientFactory } from "../WebServiceApi/WebServiceClientFactory.js";
export class WebSocketsServiceTest extends RuntimeTestRunner {
    testSocketsConnection() {
        const service = WebServiceClientFactory.getClient(WebServiceClientType.DESKTOP_CONNECTOR);
        service.getEvents().OnStart(() => {
            Echo.Printf("Connection has been started.");
        });
        service.getEvents().OnClose(() => {
            Echo.Printf("Connection has been closed.");
        });
        service.getEvents().OnTimeout(() => {
            Echo.Printf("Connection timeout has been reached.");
        });
        service.getEvents().OnError(($eventArgs) => {
            ExceptionsManager.Throw($eventArgs.Owner().getClassName(), $eventArgs.Exception());
        });
        let sendCounter = 0;
        this.addButton("Send data to WebSocket service", () => {
            let receiveCounter = 0;
            for (let index = 0; index < 5; index++) {
                const wrapper = new LiveContentWrapper("Io.Oidis.Connector.Commons.LogIt");
                service.Send(wrapper.getProtocolForInvokeMethod(service.getId(), "Info", "Data send from test code. Current session send count: " + sendCounter), ($dataObject) => {
                    receiveCounter++;
                    Echo.Printf("<b>server acknowledge[" + receiveCounter + "] from " + $dataObject.origin + "</b>");
                });
                sendCounter++;
            }
        });
        this.addButton("Close connection", () => {
            service.StopCommunication();
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.WebSocketsServiceTest", WebSocketsServiceTest);
//# sourceMappingURL=WebSocketsServiceTest.js.map