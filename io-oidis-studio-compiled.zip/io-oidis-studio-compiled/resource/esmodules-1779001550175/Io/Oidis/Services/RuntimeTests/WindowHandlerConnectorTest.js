/*! ******************************************************************************************************** *
 *
 * Copyright 2017-2018 NXP
 * Copyright 2019-2022 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
/* dev:start */
import { Echo } from "./../../../../Io/Oidis/Commons/Utils/Echo.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { KeyMap } from "./../../../../Io/Oidis/Gui/Enums/KeyMap.js";
import { WindowCornerType } from "./../../../../Io/Oidis/Gui/Enums/WindowCornerType.js";
import { RuntimeTestRunner } from "./../../../../Io/Oidis/Gui/HttpProcessor/Resolvers/RuntimeTestRunner.js";
import { ElementManager } from "./../../../../Io/Oidis/Gui/Utils/ElementManager.js";
import { WindowManager } from "./../../../../Io/Oidis/Gui/Utils/WindowManager.js";
import { WindowHandlerConnector } from "../Connectors/WindowHandlerConnector.js";
import { NotifyBalloonIconType } from "../Enums/NotifyBalloonIconType.js";
import { TaskBarProgressState } from "../Enums/TaskBarProgressState.js";
import { WindowStateType } from "../Enums/WindowStateType.js";
export class WindowHandlerConnectorTest extends RuntimeTestRunner {
    windowHandler = new WindowHandlerConnector();
    WindowStateTest() {
        this.addButton("Minimize", () => {
            this.windowHandler
                .Minimize()
                .Then(($success) => {
                if ($success === true) {
                    Echo.Print("Minimized");
                }
                else {
                    Echo.Print("Minimize failed");
                }
            });
        });
        this.addButton("Maximize", () => {
            this.windowHandler
                .Maximize()
                .Then(($success) => {
                if ($success === true) {
                    Echo.Print("Maximize");
                }
                else {
                    Echo.Print("Maximize failed");
                }
            });
        });
        this.addButton("Restore", () => {
            this.windowHandler
                .Restore()
                .Then(($success) => {
                if ($success === true) {
                    Echo.Print("Restored");
                }
                else {
                    Echo.Print("Restore failed");
                }
            });
        });
    }
    WindowLocationTest() {
        this.windowHandler.getEvents().OnWindowChanged(($changedEvent) => {
            if ($changedEvent.state === WindowStateType.MAXIMIZED) {
                Echo.Println("Window = Maximized");
            }
            else if ($changedEvent.state === WindowStateType.MINIMIZED) {
                Echo.Println("Window = Minimized");
            }
            else {
                Echo.Println("Window = Normal");
            }
        });
        this.addButton("MoveTo [10; 10]", () => {
            this.windowHandler
                .MoveTo(10, 10)
                .Then(($success) => {
                if ($success === true) {
                    Echo.Print("Moved to [10; 10]");
                }
                else {
                    Echo.Print("Move failed");
                }
            });
        });
        this.addButton("MoveTo [200 ;200]", () => {
            this.windowHandler
                .MoveTo(200, 200)
                .Then(($success) => {
                if ($success === true) {
                    Echo.Print("Moved to [200; 200]");
                }
                else {
                    Echo.Print("Move failed");
                }
            });
        });
        this.addButton("Enable resize", () => {
            this.windowHandler
                .CanResize(true)
                .Then(($success) => {
                if ($success === true) {
                    Echo.Print("Resize enabled");
                }
                else {
                    Echo.Print("Resize disabled");
                }
            });
        });
        this.addButton("Disable resize", () => {
            this.windowHandler
                .CanResize(false)
                .Then(($success) => {
                if ($success === true) {
                    Echo.Print("Resize enabled");
                }
                else {
                    Echo.Print("Resize disabled");
                }
            });
        });
        this.addButton("Resize BOTTOM_RIGHT [20 ;20]", () => {
            this.windowHandler
                .Resize(WindowCornerType.BOTTOM_RIGHT, 20, 20)
                .Then(($success) => {
                if ($success === true) {
                    Echo.Print("Resized BOTTOM_RIGHT [20; 20]");
                }
                else {
                    Echo.Print("Resize failed");
                }
            });
        });
        this.addButton("Resize BOTTOM_RIGHT [-20 ;-20]", () => {
            this.windowHandler
                .Resize(WindowCornerType.BOTTOM_RIGHT, -20, -20)
                .Then(($success) => {
                if ($success === true) {
                    Echo.Print("Resized BOTTOM_RIGHT [-20; -20]");
                }
                else {
                    Echo.Print("Resize failed");
                }
            });
        });
        this.addButton("Get window state", () => {
            this.windowHandler
                .getState()
                .Then(($state) => {
                if ($state === WindowStateType.MAXIMIZED) {
                    Echo.Println("Window = Maximized");
                }
                else if ($state === WindowStateType.MINIMIZED) {
                    Echo.Println("Window = Minimized");
                }
                else {
                    Echo.Println("Window = Normal");
                }
            });
        });
    }
    WindowAdvancedTest() {
        let windowId = "";
        this.addButton("Open", () => {
            this.windowHandler
                .Open("https://www.nxp.com/webapp", {
                hidden: false
            })
                .Then(($windowId, $url, $data) => {
                windowId = $windowId;
                let dataLen = -1;
                if (ObjectValidator.IsSet($data) && ObjectValidator.IsString($data)) {
                    dataLen = StringUtils.Length($data);
                }
                Echo.Printf("Opened window: {0}/{1}:{2}", $windowId, $url, dataLen);
            });
        });
        Echo.Println("User name:</br><input id=\"testUserName\" type=\"text\">");
        Echo.Println("Password:</br><input id=\"testUserPass\" type=\"password\">");
        this.addButton("LogIn", () => {
            this.windowHandler
                .Open("https://www.nxp.com/webapp", {
                hidden: false
            })
                .Then(($windowId, $url, $data) => {
                windowId = $windowId;
                Echo.Printf("Opened: {0}", $url);
                if (StringUtils.Contains($data, "<title>NXP Sign In")) {
                    const name = ElementManager.getElement("testUserName").value;
                    const pass = ElementManager.getElement("testUserPass").value;
                    this.windowHandler.ScriptExecute($windowId, {
                        script: "" +
                            "document.getElementById(\"username\").value=\"" + name + "\";" +
                            "document.getElementById(\"password\").value=\"" + pass + "\";" +
                            "document.getElementsByName(\"loginbutton\")[0].click();"
                    })
                        .Then(($status) => {
                        if ($status === true) {
                            Echo.Printf("Script succeed");
                        }
                        else {
                            Echo.Printf("Script failed");
                        }
                    });
                }
                else if (StringUtils.Contains($data, "<title>My Account Home Page</title>")) {
                    this.windowHandler.Close($windowId);
                    this.windowHandler
                        .Open("http://www.nxp.com/products", {
                        hidden: false
                    })
                        .Then(($windowId) => {
                        this.windowHandler.getCookies($windowId).Then(($data) => {
                            let casId = "";
                            $data.forEach(($cookie) => {
                                if ($cookie.name === "JSESSIONID" && $cookie.path === "/webapp") {
                                    casId = $cookie.value;
                                }
                            });
                            Echo.Printf("cas: {0}", casId);
                            this.windowHandler.Close($windowId);
                        });
                    });
                }
            });
        });
        this.addButton("getCookies", () => {
            this.windowHandler.getCookies().Then(($data) => {
                Echo.Printf($data);
            });
        });
        this.addButton("ExecuteScript", () => {
            this.windowHandler
                .ScriptExecute(windowId, {
                script() {
                    window.cefQuery({ request: "script has been executed" });
                }
            })
                .OnStart(() => {
                Echo.Printf("Script started.");
            })
                .OnMessage(($data) => {
                Echo.Printf("Script output data: {0}", $data);
            })
                .Then(($status) => {
                if ($status === true) {
                    Echo.Print("Script succeed");
                }
                else {
                    Echo.Print("Script failed");
                }
            });
        });
        this.addButton("Close", () => {
            this.windowHandler
                .Close(windowId)
                .Then(($success) => {
                if ($success === true) {
                    Echo.Println("Closed");
                }
                else {
                    Echo.Println("Close failed");
                }
            });
        });
        this.addButton("DebugConsole", () => {
            this.windowHandler
                .ShowDebugConsole()
                .Then(($success) => {
                if ($success === true) {
                    Echo.Println("Debug console opened.");
                }
                else {
                    Echo.Println("Failed to open debug console.");
                }
            });
        });
    }
    NotifyIconTest() {
        this.windowHandler.getEvents().OnNotifyIconBalloonClick(() => {
            Echo.Println("OnNotifyIconBalloonClick called");
            this.windowHandler.Show();
        });
        this.windowHandler.getEvents().OnNotifyIconBalloonClick(() => {
            Echo.Println("OnNotifyIconBalloonClick called");
            this.windowHandler.Show();
        });
        this.windowHandler.getEvents().OnNotifyIconDoubleClick(() => {
            Echo.Println("OnNotifyIconDbClick called");
        });
        this.windowHandler.getEvents().OnNotifyIconContextItemSelected(($name) => {
            Echo.Printf("OnNotifyIconContextItemSelected called with \"{0}\"", $name);
            if ($name === "exit") {
                Echo.Println("closing");
                this.windowHandler.Close();
            }
            else if ($name === "hide") {
                this.windowHandler.Hide();
            }
            else if ($name === "open") {
                this.windowHandler.Show();
            }
        });
        this.windowHandler.getEvents().OnNotifyIconClick(() => {
            Echo.Println("OnNotifyIconClick called");
        });
        this.addButton("CreateNotifyIcon", () => {
            this.windowHandler
                .CreateNotifyIcon({
                contextMenu: {
                    items: [
                        {
                            label: "Exit",
                            name: "exit",
                            position: 1
                        },
                        {
                            label: "Open",
                            name: "open",
                            position: 0
                        },
                        {
                            label: "Hide",
                            name: "hide",
                            position: 2
                        }
                    ]
                },
                tip: "Test application"
            })
                .OnMessage(($request) => {
                Echo.Println("Notify message: " + $request);
            })
                .Then(($success) => {
                Echo.Println("Notify created");
            });
        });
        this.addButton("ModifyNotifyIcon", () => {
            this.windowHandler.ModifyNotifyIcon({
                balloon: {
                    message: "Custom data. Custom data. Custom data. Custom data. Custom data.",
                    title: "Custom title",
                    type: NotifyBalloonIconType.ERROR
                },
                contextMenu: {
                    items: [
                        {
                            label: "Exit",
                            name: "exit",
                            position: 0
                        },
                        {
                            label: "Open",
                            name: "open",
                            position: 1
                        },
                        {
                            label: "Hide",
                            name: "hide",
                            position: 2
                        }
                    ]
                },
                tip: "Modified application"
            });
        });
        this.addButton("DestroyNotifyIcon", () => {
            this.windowHandler.DestroyNotifyIcon();
        });
    }
    ProgressTest() {
        this.addButton("ProgressState", () => {
            this.windowHandler.setTaskBarProgressState(TaskBarProgressState.ERROR);
        });
        this.addButton("ProgressValue", () => {
            this.windowHandler.setTaskBarProgressValue(70, 100);
        });
    }
    FileDialogTest() {
        this.addButton("ShowFileDialog - openOnly", () => {
            const fileDialogSettings = {
                filter: ["Archive|.zip"],
                initialDirectory: this.getAbsoluteRoot(),
                openOnly: true,
                title: "Open existing file"
            };
            this.windowHandler.ShowFileDialog(fileDialogSettings)
                .Then(($success, $path) => {
                if ($success) {
                    Echo.Println("File \"" + $path + "\" has been selected.");
                }
                else {
                    Echo.Println("File dialog selection failed.");
                }
            });
        });
        this.addButton("ShowFileDialog - open/create", () => {
            const fileDialogSettings = {
                filter: ["Text|.txt"],
                openOnly: false,
                title: "Open/Create file"
            };
            this.windowHandler.ShowFileDialog(fileDialogSettings)
                .Then(($success, $path) => {
                if ($success) {
                    Echo.Println("File \"" + $path + "\" has been selected.");
                }
                else {
                    Echo.Println("File dialog selection failed.");
                }
            });
        });
        this.addButton("ShowFileDialog - openMultiple", () => {
            const fileDialogSettings = {
                filter: ["text/*"],
                multiSelect: true,
                openOnly: true,
                title: "Open multiple files"
            };
            this.windowHandler.ShowFileDialog(fileDialogSettings)
                .Then(($success, $path) => {
                if ($success) {
                    Echo.Println("Files \"" + JSON.stringify($path) + "\" has been selected.");
                }
                else {
                    Echo.Println("File dialog selection failed.");
                }
            });
        });
        this.addButton("ShowFileDialog - folder", () => {
            const fileDialogSettings = {
                folderOnly: true,
                title: "Open folder"
            };
            this.windowHandler.ShowFileDialog(fileDialogSettings)
                .Then(($success, $path) => {
                if ($success) {
                    Echo.Println("File \"" + $path + "\" has been selected.");
                }
                else {
                    Echo.Println("File dialog selection failed.");
                }
            });
        });
        this.addButton("ShowFileDialog - create default", () => {
            const fileDialogSettings = {
                filter: ["Text|.txt", "PNGs|.png", "BMPs|.bmp"],
                filterIndex: 2,
                initialDirectory: this.getAbsoluteRoot(),
                openOnly: false,
                path: "someNewFile",
                title: "Create file"
            };
            this.windowHandler.ShowFileDialog(fileDialogSettings)
                .Then(($success, $path) => {
                if ($success) {
                    Echo.Println("File \"" + $path + "\" has been selected.");
                }
                else {
                    Echo.Println("File dialog selection failed.");
                }
            });
        });
        this.addButton("ShowFileDialog - open, absolute path", () => {
            const fileDialogSettings = {
                filter: ["Text|.txt", "Html|.html;.htm"],
                openOnly: false,
                path: this.getAbsoluteRoot() + "\\index.html",
                title: "Create file"
            };
            this.windowHandler.ShowFileDialog(fileDialogSettings)
                .Then(($success, $path) => {
                if ($success) {
                    Echo.Println("File \"" + $path + "\" has been selected.");
                }
                else {
                    Echo.Println("File dialog selection failed.");
                }
            });
        });
    }
    before() {
        WindowManager.getEvents().setOnKeyDown(($eventArgs) => {
            if ($eventArgs.getKeyCode() === KeyMap.F5) {
                this.getHttpManager().Refresh();
            }
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Services.RuntimeTests.WindowHandlerConnectorTest", WindowHandlerConnectorTest);
//# sourceMappingURL=WindowHandlerConnectorTest.js.map