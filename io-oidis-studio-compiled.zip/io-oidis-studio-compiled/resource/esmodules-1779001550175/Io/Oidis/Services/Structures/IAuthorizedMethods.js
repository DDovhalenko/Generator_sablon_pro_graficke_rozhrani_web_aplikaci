// generated-code-start
export const IAuthorizedMethods = globalThis.RegisterInterface(["className", "namespaceName", "methods"]);
globalThis.RegisterClass("Io.Oidis.Services.Structures.IAuthorizedMethods", IAuthorizedMethods);
//# sourceMappingURL=IAuthorizedMethods.js.map