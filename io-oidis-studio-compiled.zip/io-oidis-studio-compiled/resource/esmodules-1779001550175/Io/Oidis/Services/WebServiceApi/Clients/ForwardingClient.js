/*! ******************************************************************************************************** *
 *
 * Copyright 2018 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { EventType } from "./../../../../../Io/Oidis/Commons/Enums/Events/EventType.js";
import { JsonUtils } from "./../../../../../Io/Oidis/Commons/Utils/JsonUtils.js";
import { ObjectDecoder } from "./../../../../../Io/Oidis/Commons/Utils/ObjectDecoder.js";
import { ObjectEncoder } from "./../../../../../Io/Oidis/Commons/Utils/ObjectEncoder.js";
import { ObjectValidator } from "./../../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../../Io/Oidis/Commons/Utils/Property.js";
import { StringUtils } from "./../../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { WebSocketsClient } from "./../../../../../Io/Oidis/Commons/WebServiceApi/Clients/WebSocketsClient.js";
import { HttpStatusType } from "./../../../../../Io/Oidis/Commons/Enums/HttpStatusType.js";
/**
 * ForwardingClient class provides a client for web sockets communication forwarded over Oidis Hub agents.
 */
export class ForwardingClient extends WebSocketsClient {
    agentName;
    forwardingMethod;
    lastResponse;
    constructor($configuration) {
        super($configuration);
        this.agentName = "OidisConnector";
        this.forwardingMethod = "Io.Oidis.Hub.Utils.ConnectorHub.ForwardRequest";
    }
    /**
     * @param {string} $value Specify agent name used for lookup on Oidis Hub.
     * @returns {string} Returns agent name value.
     */
    AgentName($value) {
        return this.agentName = Property.String(this.agentName, $value);
    }
    /**
     * Gets or sets the forwarding method namespace on Hub.
     * Default: "Io.Oidis.Hub.Utils.ConnectorHub.ForwardRequest".
     * @param $value New forwarding method namespace
     * @returns {string} Current forwarding method value
     */
    ForwardingMethod($value) {
        return this.forwardingMethod = Property.String(this.forwardingMethod, $value);
    }
    /**
     * Wraps the outgoing protocol in a Hub forwarding envelope.
     * Encodes the original protocol as a nested argument to the forwarding method,
     * so Hub can route it to the target agent.
     * @param $data Serialized protocol data (JSON string or binary buffer)
     */
    sendRequest($data) {
        if (ObjectValidator.IsString($data)) {
            const protocol = JSON.parse($data);
            protocol.data = ObjectEncoder.Base64(JSON.stringify({
                args: ObjectEncoder.Base64(JSON.stringify([this.agentName, protocol])),
                name: this.forwardingMethod
            }));
            $data = JSON.stringify(protocol);
        }
        else {
            const protocol = JsonUtils.ToJson($data);
            protocol.data = {
                args: [this.agentName, JsonUtils.DeepClone(protocol, true, false)],
                name: this.forwardingMethod
            };
            $data = JsonUtils.ToBuffer(protocol);
        }
        super.sendRequest($data);
    }
    /**
     * Unwraps a forwarded response from Hub back to the original protocol format.
     * Handles Base64-decoded return values, ON_CHANGE streaming events, and
     * agent-not-found errors.
     * @param $event WebSocket message event containing the forwarded response
     */
    onResponse($event) {
        try {
            if ($event.data !== "OK" && !ObjectValidator.IsEmptyOrNull($event.data)) {
                const isBinary = !ObjectValidator.IsString($event.data);
                let data = isBinary ? JsonUtils.ToJson($event.data) : JSON.parse($event.data);
                this.lastResponse = data;
                if (ObjectValidator.IsObject(data.data)) {
                    if (!isBinary && ObjectValidator.IsString(data.data.returnValue)) {
                        data.data.returnValue = ObjectDecoder.Base64(data.data.returnValue);
                    }
                    if ((ObjectValidator.IsBoolean(data.data.returnValue) && !data.data.returnValue) ||
                        data.data.returnValue === "false") {
                        this.throwError("Failed to forward request, no agent found.");
                    }
                    else {
                        if (!ObjectValidator.IsEmptyOrNull(data.data.returnValue)) {
                            if (ObjectValidator.IsString(data.data.returnValue)) {
                                data = JSON.parse(data.data.returnValue);
                            }
                            else if (isBinary || ObjectValidator.IsObject(data.data.returnValue)) {
                                data = data.data.returnValue;
                            }
                        }
                        if (data.type === EventType.ON_CHANGE) {
                            data.data.origin = this.getServerUrl();
                            if (ObjectValidator.IsString(data.data.data)) {
                                data.data.data = ObjectDecoder.Base64(data.data.data);
                                try {
                                    if (StringUtils.Contains(data.data.data, "{", "}")) {
                                        data.data.data = JSON.parse(data.data.data);
                                    }
                                }
                                catch (ex) {
                                    // / do nothing as it should be just string
                                }
                            }
                            super.onResponse({
                                data: data.data
                            });
                        }
                    }
                }
                else {
                    super.onResponse($event);
                }
            }
            else {
                super.onResponse($event);
            }
        }
        catch (ex) {
            this.throwError(ex);
        }
    }
    /**
     * Converts an error into a Request.Exception protocol response and dispatches it
     * through the normal response handling chain. Uses the last received response
     * as a template for the error protocol envelope.
     * @param $message Error message string or Error object with stack trace
     * @returns {void}
     */
    throwError($message) {
        if (ObjectValidator.IsEmptyOrNull(this.lastResponse)) {
            return super.throwError($message);
        }
        const responseData = JsonUtils.Clone(this.lastResponse);
        this.lastResponse = null; // free mutex-like property before a potential recursive call from surrounding try-catch
        let logMessage = "";
        let stack = null;
        if (ObjectValidator.IsSet($message.message)) {
            if (ObjectValidator.IsSet($message.stack)) {
                stack = $message.stack;
            }
            $message = $message.message;
        }
        else if (!ObjectValidator.IsString($message)) {
            logMessage = JSON.stringify($message);
            $message = logMessage;
        }
        if (ObjectValidator.IsEmptyOrNull($message)) {
            $message = "";
        }
        responseData.status = HttpStatusType.ERROR;
        responseData.type = "Request.Exception";
        responseData.data = {
            message: $message
        };
        if (!ObjectValidator.IsEmptyOrNull(stack)) {
            responseData.data.stack = stack;
        }
        super.onResponse({
            data: responseData
        });
    }
}
globalThis.RegisterClass("Io.Oidis.Services.WebServiceApi.Clients.ForwardingClient", ForwardingClient);
//# sourceMappingURL=ForwardingClient.js.map