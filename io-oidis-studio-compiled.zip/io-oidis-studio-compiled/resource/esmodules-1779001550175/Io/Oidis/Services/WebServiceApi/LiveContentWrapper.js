/*! ******************************************************************************************************** *
 *
 * Copyright 2014-2016 Freescale Semiconductor, Inc.
 * Copyright 2017-2019 NXP
 * Copyright 2019-2026 Oidis
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * The BSD-3-Clause license for this file can be found in the LICENSE.txt file included with this distribution
 * or at https://spdx.org/licenses/BSD-3-Clause.html#licenseText
 *
 * ********************************************************************************************************* */
import { DataFormatType } from "./../../../../Io/Oidis/Commons/Enums/DataFormatType.js";
import { WebServiceClientEventType } from "./../../../../Io/Oidis/Commons/Enums/Events/WebServiceClientEventType.js";
import { ErrorEventArgs } from "./../../../../Io/Oidis/Commons/Events/Args/ErrorEventArgs.js";
import { EventsManager } from "./../../../../Io/Oidis/Commons/Events/EventsManager.js";
import { ArrayList } from "./../../../../Io/Oidis/Commons/Primitives/ArrayList.js";
import { BaseObject } from "./../../../../Io/Oidis/Commons/Primitives/BaseObject.js";
import { LogIt } from "./../../../../Io/Oidis/Commons/Utils/LogIt.js";
import { ObjectDecoder } from "./../../../../Io/Oidis/Commons/Utils/ObjectDecoder.js";
import { ObjectValidator } from "./../../../../Io/Oidis/Commons/Utils/ObjectValidator.js";
import { Property } from "./../../../../Io/Oidis/Commons/Utils/Property.js";
import { Reflection } from "./../../../../Io/Oidis/Commons/Utils/Reflection.js";
import { StringUtils } from "./../../../../Io/Oidis/Commons/Utils/StringUtils.js";
import { WebSocketsClient } from "./../../../../Io/Oidis/Commons/WebServiceApi/Clients/WebSocketsClient.js";
import { LiveContentArgumentType } from "../Enums/LiveContentArgumentType.js";
import { AuthHttpResolver } from "../ErrorPages/AuthHttpResolver.js";
import { IWebServiceClient } from "../Interfaces/IWebServiceClient.js";
import { Loader } from "../Loader.js";
/**
 * Core LCP (LiveContent Protocol) encoder/decoder for frontend-to-backend RPC communication.
 *
 * This class is the heart of the Oidis RPC mechanism. It handles:
 * - Building wire-format protocol messages (IWebServiceProtocol) for method invocations,
 *   property get/set, and event handler subscriptions
 * - Parsing backend responses with automatic type coercion (Base64, JSON, primitives)
 * - Managing event handler registrations and polling for non-WebSocket transports
 * - Error propagation with full stack trace reconstruction from the backend
 *
 * Typical usage is via static factory methods (InvokeMethod, setProperty, getProperty, AddEventHandler)
 * which are called by BaseConnector. The returned instance implements a chainable callback API:
 * DataFormatter() -> OnError() -> Then()
 */
export class LiveContentWrapper extends BaseObject {
    static currentLCPversion = "1.1";
    static eventHandlers;
    serverClassName;
    type;
    name;
    clientId;
    args;
    callback;
    dataFormatter;
    errorHandler;
    static InvokeMethod($clientOrOpts, $className, $name, ...$args) {
        let options = $clientOrOpts;
        if (Reflection.getInstance().Implements($clientOrOpts, IWebServiceClient)) {
            options = {
                args: $args,
                className: $className,
                client: $clientOrOpts,
                name: $name
            };
        }
        const methodCall = new LiveContentWrapper(options.className);
        const args = [options.client.getId(), options.name];
        let index;
        for (index = 0; index < options.args.length; index++) {
            if (ObjectValidator.IsSet(options.args[index])) {
                args.push(options.args[index]);
            }
        }
        // eslint-disable-next-line prefer-spread
        const protocol = methodCall.getProtocolForInvokeMethod.apply(methodCall, args);
        if (ObjectValidator.IsSet(options.token) && ObjectValidator.IsString(options.token)) {
            protocol.token = options.token;
        }
        options.client.Send(protocol, ($data) => {
            methodCall.getResponseHandler(options.client, $data);
        });
        return methodCall;
    }
    /**
     * @param {IWebServiceClient} $client Specify web service client instance, which is handling the server-client connection.
     * @param {string} $className Specify class name, which should be reflected on server side.
     * @param {string} $name Specify property name, which should be set.
     * @param {any} $value Specify value, which should be set to the property.
     * @returns {ILiveContentPromise} Returns promise interface for handling of property set event.
     */
    static setProperty($client, $className, $name, $value) {
        const methodCall = new LiveContentWrapper($className);
        $client.Send(methodCall.getProtocolForSetProperty($client.getId(), $name, $value), ($data) => {
            methodCall.getResponseHandler($client, $data);
        });
        return methodCall;
    }
    /**
     * @param {IWebServiceClient} $client Specify web service client instance, which is handling the server-client connection.
     * @param {string} $className Specify class name, which should be reflected on server side.
     * @param {string} $name Specify property name, which should be invoked.
     * @returns {ILiveContentFormatterPromise} Returns promise interface for handling of invoke property event.
     */
    static getProperty($client, $className, $name) {
        const methodCall = new LiveContentWrapper($className);
        $client.Send(methodCall.getProtocolForGetProperty($client.getId(), $name), ($data) => {
            methodCall.getResponseHandler($client, $data);
        });
        return methodCall;
    }
    /**
     * @param {IWebServiceClient} $client Specify web service client instance, which is handling the server-client connection.
     * @param {string} $className Specify class name, which should be reflected on server side.
     * @param {string} $name Specify event name, which should be handled.
     * @param {Function} $handler Specify event handler callback, which should be asigned.
     * @returns {void}
     */
    static AddEventHandler($client, $className, $name, $handler) {
        const methodCall = new LiveContentWrapper($className);
        if (!LiveContentWrapper.eventHandlers.KeyExists($client.getId())) {
            LiveContentWrapper.eventHandlers.Add(new ArrayList(), $client.getId());
            $client.getEvents().OnClose(() => {
                LiveContentWrapper.eventHandlers.RemoveAt(LiveContentWrapper.eventHandlers.getKeys().indexOf($client.getId()));
            });
        }
        const clientEvents = LiveContentWrapper.eventHandlers.getItem($client.getId());
        const handlerOwner = $className + "." + $name;
        if (!clientEvents.KeyExists(handlerOwner)) {
            clientEvents.Add(new ArrayList(), handlerOwner);
            $client.Send(methodCall.getProtocolForAddEventHandler($client.getId(), $name), ($data) => {
                if (StringUtils.StartsWith($data.type, "LiveContentWrapper.")) {
                    if (!ObjectValidator.IsEmptyOrNull($data.data)) {
                        const wrapper = $data.data;
                        if (methodCall.memberName() === wrapper.name) {
                            methodCall.getEventHandler($data, $client.getId());
                        }
                    }
                    else if (!$client.IsTypeOf(WebSocketsClient)) {
                        const eventId = $data.id;
                        let checkerId;
                        $client.getEvents().OnClose(() => {
                            if (!ObjectValidator.IsEmptyOrNull(checkerId)) {
                                clearTimeout(checkerId);
                            }
                        });
                        const eventChecker = () => {
                            if (!ObjectValidator.IsEmptyOrNull($client) && $client.CommunicationIsRunning()) {
                                checkerId = Loader.getInstance().getHttpResolver().getEvents()
                                    .FireAsynchronousMethod(() => {
                                    $client.Send(methodCall.getProtocolForEventChecker($name, eventId), ($data) => {
                                        if (StringUtils.StartsWith($data.type, "LiveContentWrapper.") &&
                                            !ObjectValidator.IsEmptyOrNull($data.data)) {
                                            if (methodCall.memberName() === handlerOwner) {
                                                let events = [];
                                                if (ObjectValidator.IsArray($data.data)) {
                                                    events = $data.data;
                                                }
                                                let eventIndex;
                                                for (eventIndex = 0; eventIndex < events.length; eventIndex++) {
                                                    methodCall.getEventHandler(events[eventIndex], $client.getId());
                                                }
                                            }
                                        }
                                        eventChecker();
                                    });
                                }, 500);
                            }
                        };
                        eventChecker();
                    }
                }
                else {
                    methodCall.getResponseHandler($client, $data);
                }
            });
        }
        clientEvents.getItem(handlerOwner).Add($handler);
    }
    /**
     * @param {string} $forClassName Specify class name, which should be reflected on the server side.
     */
    constructor($forClassName) {
        super();
        this.serverClassName = $forClassName;
        this.args = [];
        this.callback = () => {
            // default callback
        };
        this.errorHandler = null;
        if (!ObjectValidator.IsSet(LiveContentWrapper.eventHandlers)) {
            LiveContentWrapper.eventHandlers = new ArrayList();
        }
    }
    /**
     * @param {number} $clientId Specify web service client id, which is handling the server-client connection.
     * @param {string} $name Specify method name, which should be invoked.
     * @param {...any[]} [$args] Specify method arguments, which should be passed to the invoked method.
     * @returns {IWebServiceProtocol} Returns data suitable for server-client communication.
     */
    getProtocolForInvokeMethod($clientId, $name, ...$args) {
        this.protocolType("InvokeMethod");
        this.clientId = $clientId;
        this.memberName(this.serverClassName + "." + $name);
        let index;
        this.args = [];
        for (index = 0; index < $args.length; index++) {
            this.addArgument($args[index]);
        }
        return this.toProtocol();
    }
    /**
     * @param {number} $clientId Specify web service client id, which is handling the server-client connection.
     * @param {string} $name Specify property name, which should be invoked.
     * @param {any} $value Specify value, which should be passed to the invoked property.
     * @returns {IWebServiceProtocol} Returns data suitable for server-client communication.
     */
    getProtocolForSetProperty($clientId, $name, $value) {
        this.protocolType("setProperty");
        this.clientId = $clientId;
        this.memberName(this.serverClassName + "." + $name);
        this.args = [];
        this.addArgument($value);
        return this.toProtocol();
    }
    /**
     * @param {number} $clientId Specify web service client id, which is handling the server-client connection.
     * @param {string} $name Specify property name, which should be invoked.
     * @returns {IWebServiceProtocol} Returns data suitable for server-client communication.
     */
    getProtocolForGetProperty($clientId, $name) {
        this.protocolType("getProperty");
        this.clientId = $clientId;
        this.memberName(this.serverClassName + "." + $name);
        return this.toProtocol();
    }
    /**
     * @param {number} $clientId Specify web service client id, which is handling the server-client connection.
     * @param {string} $name Specify event name, which should be handled.
     * @returns {IWebServiceProtocol} Returns data suitable for server-client communication.
     */
    getProtocolForAddEventHandler($clientId, $name) {
        this.protocolType("AddEventHandler");
        this.clientId = $clientId;
        this.memberName(this.serverClassName + "." + $name);
        this.args = [];
        return this.toProtocol();
    }
    /**
     * @param {IWebServiceProtocol} $data Specify data from server-client communication.
     * @returns {any} Returns data expected as invoke return value parsed from server-client communication data.
     */
    getReturnValue($data) {
        let returnValue = null;
        if (StringUtils.StartsWith($data.type, "LiveContentWrapper.") && !ObjectValidator.IsEmptyOrNull($data.data)) {
            const wrapper = $data.data;
            if (this.name === wrapper.name) {
                const value = $data.format !== DataFormatType.JSON && ObjectValidator.IsString(wrapper.returnValue) &&
                    /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/.test(wrapper.returnValue) ?
                    ObjectDecoder.Base64(wrapper.returnValue) : wrapper.returnValue;
                if (ObjectValidator.IsString(value)) {
                    if (StringUtils.StartsWith(value, "{") || StringUtils.StartsWith(value, "[")) {
                        try {
                            returnValue = JSON.parse(value);
                        }
                        catch (ex) {
                            returnValue = value;
                        }
                    }
                    else {
                        if (ObjectValidator.IsDouble(value)) {
                            returnValue = StringUtils.ToDouble(value);
                        }
                        else if (ObjectValidator.IsInteger(value)) {
                            returnValue = StringUtils.ToInteger(value);
                        }
                        else if (value === "true" || value === "false") {
                            returnValue = StringUtils.ToBoolean(value);
                        }
                        else if (value === LiveContentArgumentType.RETURN_VOID || value === "null") {
                            returnValue = null;
                        }
                        else {
                            returnValue = value;
                        }
                    }
                }
                else {
                    returnValue = value;
                }
            }
        }
        return returnValue;
    }
    /**
     * @param {IWebServiceProtocol} $data Specify data from server-client communication.
     * @returns {any[]} Returns data expected as output arguments parsed from server-client communication data.
     */
    getReturnArgs($data) {
        let args = [];
        if (StringUtils.StartsWith($data.type, "LiveContentWrapper.") && !ObjectValidator.IsEmptyOrNull($data.data)) {
            const wrapper = $data.data;
            if (this.name === wrapper.name) {
                if ($data.format !== DataFormatType.JSON && ObjectValidator.IsString(wrapper.returnValue) &&
                    /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/.test(wrapper.returnValue)) {
                    const value = ObjectDecoder.Base64(wrapper.args);
                    if (StringUtils.StartsWith(value, "[")) {
                        try {
                            args = JSON.parse(value);
                        }
                        catch (ex) {
                            // return args as is, if parsing is not possible - args can be already in correct format
                        }
                    }
                }
                else if (!ObjectValidator.IsEmptyOrNull(wrapper.args)) {
                    args = wrapper.args;
                }
            }
        }
        return args;
    }
    /**
     * @param {Function} $callback Specify callback function, which will be called on data received event.
     * @returns {void}
     */
    Then($callback) {
        this.callback = $callback;
    }
    /**
     * @param {Function} $formatter Specify formatter function, which will be used for formatting of the received data.
     * @returns {ILiveContentErrorPromise} Returns promise interface suitable for asynchronous communication handling.
     */
    DataFormatter($formatter) {
        this.dataFormatter = $formatter;
        return this;
    }
    /**
     * @param {Function} $callback Specify callback function, which will be called on error event.
     * @returns {ILiveContentPromise} Returns promise interface suitable for asynchronous communication handling.
     */
    OnError($callback) {
        this.errorHandler = $callback;
        return this;
    }
    protocolType($value) {
        return this.type = Property.String(this.type, $value);
    }
    memberName($value) {
        return this.name = Property.String(this.name, $value);
    }
    addArgument($value) {
        this.args.push($value);
    }
    getCallback($data) {
        const parameters = [];
        if (ObjectValidator.IsEmptyOrNull(this.dataFormatter)) {
            parameters.push(this.getReturnValue($data));
        }
        else {
            parameters.push(this.dataFormatter(this.getReturnValue($data)));
        }
        const args = this.getReturnArgs($data);
        let index;
        for (index = 0; index < args.length; index++) {
            parameters.push(args[index]);
        }
        this.callback.apply(this, parameters); // eslint-disable-line prefer-spread
    }
    getProtocolForEventChecker($name, $subscriberId) {
        this.protocolType("getEvent");
        this.memberName(this.serverClassName + "." + $name);
        this.args = [];
        this.addArgument($subscriberId);
        return this.toProtocol();
    }
    getResponseHandler($client, $data) {
        if ($data.type === WebServiceClientEventType.ON_ERROR) {
            const isJson = $data.format === DataFormatType.JSON;
            if (!isJson) {
                $data.data = ObjectDecoder.Base64($data.data);
            }
            const exceptionData = $data.data;
            let message;
            if (ObjectValidator.IsString($data.data)) {
                message = $data.data;
            }
            else if (!isJson) {
                message = ObjectDecoder.Base64(exceptionData.message);
                if (!ObjectValidator.IsEmptyOrNull(exceptionData.stack)) {
                    message = new Error(message);
                    message.stack = ObjectDecoder.Base64(exceptionData.stack);
                }
            }
            else {
                message = exceptionData.message;
                if (!ObjectValidator.IsEmptyOrNull(exceptionData.stack)) {
                    message = new Error(message);
                    message.stack = exceptionData.stack;
                }
            }
            const eventArgs = new ErrorEventArgs(message);
            eventArgs.Owner($client);
            if (!ObjectValidator.IsEmptyOrNull(this.errorHandler)) {
                let args = [eventArgs];
                if (!ObjectValidator.IsString($data.data) && !ObjectValidator.IsEmptyOrNull(exceptionData.args)) {
                    try {
                        if (!isJson) {
                            exceptionData.args = JSON.parse(ObjectDecoder.Base64(exceptionData.args));
                        }
                        args = args.concat(exceptionData.args);
                    }
                    catch (ex) {
                        LogIt.Warning("Unable to parse custom exception args. " + ex.stack);
                    }
                }
                this.errorHandler.apply(this, args); // eslint-disable-line prefer-spread
            }
            else {
                EventsManager.getInstanceSingleton().FireEvent("" + $client.getId(), WebServiceClientEventType.ON_ERROR, eventArgs);
            }
        }
        else {
            this.getCallback($data);
        }
    }
    getEventHandler($data, $clientId) {
        const parameters = [];
        const args = this.getReturnArgs($data);
        let index;
        for (index = 0; index < args.length; index++) {
            parameters.push(args[index]);
        }
        const asyncExecution = Loader.getInstance().getHttpResolver().getEvents().FireAsynchronousMethod;
        LiveContentWrapper.eventHandlers.getItem($clientId).getItem(this.memberName()).foreach(($handler) => {
            asyncExecution(() => {
                $handler.apply(this, parameters);
            }, false);
        });
    }
    toProtocol() {
        return {
            clientId: this.clientId,
            data: {
                args: this.args,
                name: this.name
            },
            format: this.getDefaultFormat() === DataFormatType.AUTO ? DataFormatType.JSON : this.getDefaultFormat(),
            id: null,
            origin: null,
            status: null,
            token: AuthHttpResolver.getToken(),
            type: "LiveContentWrapper." + this.type,
            version: LiveContentWrapper.currentLCPversion
        };
    }
    getDefaultFormat() {
        const format = Loader.getInstance().getEnvironmentArgs().getProjectConfig().lcpConfig.format;
        this.getDefaultFormat = () => {
            return format;
        };
        return format;
    }
}
// generated-code-start
export const ILCPConfig = globalThis.RegisterInterface(["client", "className", "name", "args", "token"]);
globalThis.RegisterClass("Io.Oidis.Services.WebServiceApi.LiveContentWrapper", LiveContentWrapper);
globalThis.RegisterClass("Io.Oidis.Services.WebServiceApi.ILCPConfig", ILCPConfig);
//# sourceMappingURL=LiveContentWrapper.js.map